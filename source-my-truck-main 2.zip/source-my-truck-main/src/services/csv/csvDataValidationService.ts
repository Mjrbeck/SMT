
import { VehicleRecord, VehicleImportRecord, ProcessingResult, ValidationError } from "./types";
import { validateCsvRow } from "./csvValidationService";

export const validateCsvData = (records: Record<string, string>[]): ProcessingResult & { 
  validRecords: VehicleImportRecord[]; 
  invalidRecords: VehicleImportRecord[];
  errors: ValidationError[];
  isValid: boolean;
} => {
  if (records.length === 0) {
    return {
      success: false,
      message: 'The CSV file is empty or has no valid data rows',
      createdCount: 0,
      validRecords: [],
      invalidRecords: [],
      errors: [{ row: 0, field: 'file', message: 'The CSV file is empty or has no valid data rows' }],
      isValid: false
    };
  }

  const validRecords: VehicleImportRecord[] = [];
  const invalidRecords: VehicleImportRecord[] = [];
  const errors: ValidationError[] = [];

  records.forEach((record, index) => {
    const rowNumber = index + 2; // +2 because row 1 is the header, and index is 0-based
    const { isValid, errors: rowErrors, data } = validateCsvRow(record, rowNumber);

    if (isValid && data) {
      validRecords.push(data);
    } else {
      invalidRecords.push({
        ...record,
        // Convert all properties to strings for consistent display
        ...Object.fromEntries(
          Object.entries(record).map(([key, value]) => [key, String(value)])
        )
      });
      errors.push(...rowErrors);
    }
  });

  return {
    success: errors.length === 0 && validRecords.length > 0,
    message: errors.length === 0 && validRecords.length > 0 
      ? `Found ${validRecords.length} valid vehicles` 
      : `Found ${errors.length} errors in the CSV file`,
    createdCount: 0,
    validRecords,
    invalidRecords,
    errors,
    isValid: errors.length === 0 && validRecords.length > 0
  };
};
