
import { VehicleRecord, ValidationError } from './types';

// Validate a single vehicle record
export const validateVehicleRecord = (record: VehicleRecord): { isValid: boolean; errors: string[] } => {
  const errors: string[] = [];
  const requiredFields = ['title', 'make', 'model', 'year', 'price', 'mileage', 'engine_size', 'fuel_type', 'transmission', 'registration'];
  
  // Check required fields
  for (const field of requiredFields) {
    if (!record[field]) {
      errors.push(`Missing required field: ${field}`);
    }
  }
  
  // Validate numeric fields
  const numericFields = ['year', 'price', 'mileage', 'weight'];
  for (const field of numericFields) {
    if (record[field] && isNaN(Number(record[field]))) {
      errors.push(`${field} must be a number`);
    }
  }

  return {
    isValid: errors.length === 0,
    errors
  };
};

// Validate a CSV row and return validation results
export const validateCsvRow = (
  row: Record<string, string>, 
  rowNumber: number
): { isValid: boolean; errors: ValidationError[]; data: VehicleRecord | null } => {
  const errors: ValidationError[] = [];
  const { isValid, errors: fieldErrors } = validateVehicleRecord(row);
  
  if (!isValid) {
    fieldErrors.forEach(message => {
      errors.push({
        row: rowNumber,
        field: 'validation',
        message
      });
    });
  }
  
  return {
    isValid,
    errors,
    data: isValid ? row : null
  };
};
