
// Types used across CSV service modules

// Interface for the vehicle record from CSV
export interface VehicleRecord {
  title?: string;
  make?: string;
  model?: string;
  year?: string;
  price?: string;
  mileage?: string;
  engine_size?: string;
  fuel_type?: string;
  transmission?: string;
  registration?: string;
  description?: string;
  location?: string;
  features?: string;
  body_type?: string;
  axle_configuration?: string;
  weight?: string;
  color?: string;
  doors?: string;
  [key: string]: string | undefined;
}

// Alias for vehicle import record (same structure)
export type VehicleImportRecord = VehicleRecord;

// Processing result interface
export interface ProcessingResult {
  success: boolean;
  message: string;
  createdCount: number;
  validRecords?: VehicleImportRecord[];
  invalidRecords?: VehicleImportRecord[];
  errors?: ValidationError[];
  isValid?: boolean;
}

// Validation error interface
export interface ValidationError {
  row: number;
  field: string;
  message: string;
}

// Template vehicle object with all required fields
export const templateVehicle = {
  title: "",
  make: "",
  model: "",
  year: "",
  price: "",
  mileage: "",
  engine_size: "",
  fuel_type: "",
  transmission: "",
  registration: "",
  description: "",
  location: "",
  features: "", // comma-separated values that will be converted to array
  body_type: "",
  axle_configuration: "",
  weight: ""
};

// Convert a string of comma-separated values to an array
export const stringToArray = (str: string): string[] => {
  if (!str) return [];
  return str.split(',').map(item => item.trim()).filter(Boolean);
};
