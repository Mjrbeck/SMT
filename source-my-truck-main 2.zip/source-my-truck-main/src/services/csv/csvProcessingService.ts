
import { supabase } from "@/integrations/supabase/client";
import { parse } from "papaparse";
import { ProcessingResult } from "./types";
import { validateCsvData } from "./csvDataValidationService";
import { importVehicles } from "./csvImportService";

export const processCsvFile = async (file: File): Promise<ProcessingResult> => {
  return new Promise((resolve, reject) => {
    try {
      // Get file extension
      const fileExt = file.name.split('.').pop()?.toLowerCase();
      if (fileExt !== 'csv') {
        reject(new Error('Please upload a CSV file'));
        return;
      }

      // Check file size (10MB limit)
      if (file.size > 10 * 1024 * 1024) {
        reject(new Error('File size exceeds 10MB limit'));
        return;
      }

      parse<Record<string, string>>(file, {
        header: true,
        skipEmptyLines: true,
        complete: async (results) => {
          const records = results.data;
          const validationResults = validateCsvData(records);
          
          if (validationResults.isValid && validationResults.validRecords) {
            try {
              // Get current user
              const { data: { user } } = await supabase.auth.getUser();
              
              if (!user) {
                resolve({
                  success: false,
                  message: "Authentication required",
                  createdCount: 0
                });
                return;
              }
              
              // Proceed with import
              const importResult = await importVehicles(validationResults.validRecords, user.id);
              
              resolve({
                success: importResult.success,
                message: importResult.success 
                  ? `Successfully imported ${importResult.importedCount} vehicles` 
                  : `Import failed: ${importResult.errors.join(", ")}`,
                createdCount: importResult.importedCount
              });
            } catch (error) {
              console.error("Error during import:", error);
              resolve({
                success: false,
                message: `An error occurred: ${(error as Error).message}`,
                createdCount: 0
              });
            }
          } else {
            resolve({
              success: false,
              message: "Validation failed. Please check your CSV file.",
              createdCount: 0,
              ...validationResults
            });
          }
        },
        error: (error) => {
          reject(new Error(`CSV parsing error: ${error.message}`));
        }
      });
    } catch (error) {
      reject(error);
    }
  });
};

// Re-export validation function for backward compatibility
export { validateCsvData } from "./csvDataValidationService";
