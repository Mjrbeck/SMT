
import { supabase } from "@/integrations/supabase/client";
import { VehicleImportRecord, ProcessingResult } from "./types";
import { getCurrentCredits } from "@/services/credits";
import { stringToArray } from "./types";

export const importVehicles = async (
  vehicles: VehicleImportRecord[], 
  userId: string
): Promise<{ success: boolean; importedCount: number; errors: string[] }> => {
  try {
    // Check if user has enough credits
    const { credits, error: creditsError } = await getCurrentCredits();
    
    if (creditsError) {
      return { 
        success: false, 
        importedCount: 0, 
        errors: [`Failed to check credits: ${creditsError}`] 
      };
    }
    
    if (credits < vehicles.length) {
      return { 
        success: false, 
        importedCount: 0, 
        errors: [`Not enough credits. You have ${credits} credits but need ${vehicles.length} credits to import all vehicles.`] 
      };
    }

    // Process each vehicle
    const errors: string[] = [];
    let importedCount = 0;

    for (const vehicle of vehicles) {
      try {
        // Convert vehicle data to match database schema
        const vehicleData = {
          user_id: userId,
          make: vehicle.make || '',
          model: vehicle.model || '',
          year: parseInt(vehicle.year || '0'),
          mileage: parseInt(vehicle.mileage || '0'),
          price: parseInt(vehicle.price || '0'),
          body_type: vehicle.body_type || '',
          fuel_type: vehicle.fuel_type || '',
          transmission: vehicle.transmission || '',
          color: vehicle.color || '',
          description: vehicle.description || '',
          registration: vehicle.registration || '',
          engine_size: vehicle.engine_size || '',
          doors: vehicle.doors ? parseInt(vehicle.doors) : null,
          status: 'active',
          title: `${vehicle.year} ${vehicle.make} ${vehicle.model}`, // Generate title field
          expires_at: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(), // 30 days from now
          features: vehicle.features ? stringToArray(vehicle.features) : [],
          is_poa: false, // Default value
          axle_configuration: vehicle.axle_configuration || null,
          weight: vehicle.weight ? parseInt(vehicle.weight) : null,
          location: vehicle.location || null
        };

        // Insert into database
        const { data, error } = await supabase
          .from('vehicles')
          .insert(vehicleData)
          .select()
          .single();

        if (error) {
          console.error("Error importing vehicle:", error);
          errors.push(`Row ${importedCount + 1}: ${error.message}`);
        } else {
          console.log("Vehicle imported:", data);
          importedCount++;
        }
      } catch (error) {
        console.error("Error in vehicle insert:", error);
        errors.push(`Row ${importedCount + 1}: Unexpected error`);
      }
    }

    return {
      success: importedCount > 0,
      importedCount,
      errors
    };
  } catch (error) {
    console.error("Error in importVehicles:", error);
    return {
      success: false,
      importedCount: 0,
      errors: [(error as Error).message || "An unexpected error occurred during import"]
    };
  }
};
