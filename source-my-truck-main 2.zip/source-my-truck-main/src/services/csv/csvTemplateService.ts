
import { unparse } from 'papaparse';
import { templateVehicle } from './types';

// Generate a blank CSV template
export const generateCsvTemplate = (): string => {
  return unparse([templateVehicle]);
};

// Helper to download the template
export const downloadCsvTemplate = () => {
  const csv = generateCsvTemplate();
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', 'vehicle_import_template.csv');
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};
