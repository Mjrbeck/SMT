import { supabase } from '@/integrations/supabase/client';
import { BlogArticle } from './types';

// This function is now only used internally
const addIndustryArticles = async (): Promise<void> => {
  const articles = [
    {
      title: "The Electric Vehicle Revolution in Commercial Trucking",
      excerpt: "An in-depth look at how electric vehicle technology is transforming the commercial trucking industry in the UK and Europe.",
      content: `The commercial trucking industry is undergoing a significant transformation, with electric vehicles (EVs) at the forefront of this revolution. For decades, diesel engines have dominated the roads, but increasing concerns about climate change, air quality, and the rising cost of fossil fuels have accelerated the shift towards electric alternatives.

In the UK, this transition has gained considerable momentum. The government's commitment to achieve net-zero carbon emissions by 2050 has prompted substantial investments in EV infrastructure and incentives for commercial operators to make the switch. Major cities like London have introduced Ultra Low Emission Zones (ULEZ), further encouraging the adoption of cleaner vehicles.

The benefits of electric commercial vehicles extend beyond environmental considerations. Operationally, EVs offer lower running costs, with electricity typically costing less than diesel per mile. Maintenance requirements are also reduced, as electric motors have fewer moving parts than internal combustion engines. The near-silent operation of EVs also opens up possibilities for night deliveries in urban areas, where noise restrictions previously limited operations.

However, the transition isn't without challenges. Range anxiety remains a significant concern for fleet operators, particularly for long-haul routes. While battery technology continues to improve, most electric trucks currently offer ranges between 100-250 miles on a single charge, falling short of the 500+ miles often achieved by diesel vehicles. Charging infrastructure is another critical issue, with high-capacity charging stations for commercial vehicles still relatively scarce across the UK's road network.

Weight is also a considerable challenge. The heavy batteries required for adequate range can significantly reduce payload capacity, directly impacting operational efficiency and profitability. For many operators, this represents a difficult trade-off between environmental benefits and business practicalities.

Despite these challenges, major manufacturers are making substantial investments in electric commercial vehicles. Companies like Volvo, Mercedes-Benz, and DAF have introduced electric truck models to the UK market, with Tesla's Semi also generating considerable interest. These vehicles are increasingly being adopted by forward-thinking fleet operators, particularly for urban and regional delivery routes where current range limitations are less problematic.

The UK government has recognised the need to support this transition. Grants for electric vans and trucks, investment in charging infrastructure, and tax incentives have all been implemented to encourage adoption. Initiatives like the £20 million zero-emission road freight trials are exploring innovative solutions to the unique challenges faced by the commercial sector.

Looking ahead, the pace of technological advancement offers promise. Solid-state batteries, currently in development, could potentially double energy density while reducing weight, addressing many of the current limitations. Alternative approaches, such as battery swapping stations or overhead charging lines on major highways (similar to railway electrification), are also being explored as potential solutions for long-distance transport.

For fleet operators considering the switch to electric, careful planning and analysis are essential. While the initial purchase price of electric trucks remains higher than diesel equivalents, the total cost of ownership over the vehicle's lifetime may be lower when considering reduced operating and maintenance costs. Understanding the specific operational requirements, route profiles, and charging logistics is crucial for successful implementation.

As we look to the future, the electrification of commercial vehicles appears inevitable, driven by environmental necessity, regulatory pressure, and improving economics. While the transition will take time and face significant challenges, the direction of travel is clear. For the commercial trucking industry, embracing this change proactively may not only yield environmental benefits but also provide competitive advantages in an evolving marketplace.`,
      image_url: "https://images.unsplash.com/photo-1581092335397-9583eb92d232?auto=format&fit=crop&w=800&h=600&q=80",
      category: "Technology",
      date: "May 15, 2024",
      read_time: "8 min read",
      author: "Richard Thompson",
      tags: ["electric vehicles", "commercial trucking", "sustainability", "transport"],
      published: true
    },
    {
      title: "Hydrogen Fuel Cell Technology: The Future of Heavy Transport?",
      excerpt: "A comprehensive analysis of hydrogen fuel cell technology and its potential to revolutionise the heavy transport sector in Britain.",
      content: `As the transport sector grapples with the urgent need to decarbonise, hydrogen fuel cell technology is emerging as a promising alternative for heavy transport applications. While battery electric vehicles have gained significant traction in the passenger car market, the unique requirements of heavy goods vehicles present challenges that hydrogen may be uniquely positioned to address.

Hydrogen fuel cells generate electricity through an electrochemical reaction between hydrogen and oxygen, with water vapour as the only emission. This clean operation, combined with rapid refuelling capabilities and potential for long-range travel, makes hydrogen an attractive proposition for commercial transport operators in the United Kingdom.

The fundamental advantage of hydrogen for heavy transport lies in its energy density. Hydrogen contains approximately three times more energy per kilogram than diesel, allowing for significant range without the weight penalty associated with large battery packs. For weight-sensitive applications like haulage, where payload capacity directly impacts profitability, this represents a considerable advantage.

Several British firms are at the forefront of hydrogen technology development. Companies like ITM Power in Sheffield are pioneering electrolyser technology for hydrogen production, while Wrightbus in Northern Ireland has already deployed hydrogen buses across several UK cities. The government has signalled support through initiatives like the £23 million Hydrogen for Transport Programme, which has funded hydrogen refuelling stations and vehicle deployments.

Aberdeen has emerged as a leading hydrogen city, operating a fleet of hydrogen buses since 2015 and continuously expanding its infrastructure. This real-world experience has provided valuable insights into the practical implementation of hydrogen technology in British operating conditions.

However, significant challenges remain. The hydrogen infrastructure in Britain is still in its infancy, with fewer than 20 publicly accessible refuelling stations currently operational across the country. This chicken-and-egg problem – where vehicle adoption is hindered by lack of infrastructure, while infrastructure investment is limited by low vehicle numbers – represents a significant barrier to widespread adoption.

Production of hydrogen itself presents another challenge. Currently, the majority of hydrogen is produced from natural gas through a process called steam methane reforming, which generates significant carbon emissions. For hydrogen to deliver on its environmental promise, production must shift towards greener methods.

Green hydrogen, produced through electrolysis powered by renewable electricity, offers a truly zero-emission solution. However, this process is currently more expensive than conventional production methods. The good news is that costs are falling rapidly as technology improves and scales up. According to analysis from Bloomberg NEF, green hydrogen could be cost-competitive with fossil-fuel derived hydrogen by 2030 in many regions, including parts of Britain with strong renewable resources.

From an operational perspective, hydrogen vehicles offer several advantages. Refuelling times are comparable to diesel, typically taking 10-15 minutes for a heavy goods vehicle, compared to potentially hours for equivalent battery charging. This allows for operational patterns similar to current practices, minimising disruption during the transition.

Several trials are underway across Britain to test hydrogen technology in real-world conditions. Supermarket chain Asda began testing hydrogen fuel cell vans in 2021, while logistics provider DHL has announced plans to incorporate hydrogen trucks into its fleet. These early adopters are providing valuable data on performance, reliability, and total cost of ownership.

The economics of hydrogen transport are complex and evolving. While vehicle acquisition costs remain high due to limited production volumes, operational costs are potentially competitive with diesel when considering factors like fuel efficiency, maintenance requirements, and potential future carbon pricing. As production scales up, vehicle costs are expected to fall significantly.

Looking ahead, the most likely scenario is one where both battery electric and hydrogen fuel cell technologies coexist in the transport ecosystem, each serving the applications where their characteristics provide the greatest advantage. For back-to-base operations with predictable routes, battery electric vehicles may be preferable. For long-haul, heavy-duty transport with variable routes, hydrogen could emerge as the dominant solution.

Policy support will be crucial in determining the pace and scale of hydrogen adoption. The British government's Ten Point Plan for a Green Industrial Revolution includes commitments to hydrogen technology, but industry stakeholders argue that more targeted support for transport applications is needed.

The journey towards hydrogen-powered heavy transport is just beginning, but the potential benefits for both the environment and the operational efficiency of Britain's logistics sector make it a technology worth watching closely.`,
      image_url: "https://images.unsplash.com/photos/PuwfRakCJvk?auto=format&fit=crop&w=800&h=600&q=80",
      category: "Technology",
      date: "May 12, 2024",
      read_time: "9 min read",
      author: "Elizabeth Howard",
      tags: ["hydrogen", "fuel cell", "sustainable transport", "green technology"],
      published: true
    },
    {
      title: "Navigating the Used Commercial Vehicle Market in 2025",
      excerpt: "Expert analysis of the current trends, challenges, and opportunities in the UK's used commercial vehicle market for 2025.",
      content: `The used commercial vehicle market in Britain has undergone significant transformation in recent years, shaped by economic fluctuations, regulatory changes, and evolving business needs. As we move through 2025, understanding the dynamics of this market has become increasingly important for fleet operators, individual buyers, and industry stakeholders.

One of the most notable trends is the growing divergence in values between Euro 6 vehicles and their older counterparts. With the expansion of Clean Air Zones (CAZs) across major UK cities, including Birmingham, Manchester, and Bristol, demand for Euro 6 compliant vehicles has surged. These vehicles, which meet the strictest emissions standards implemented before the transition to zero-emission technology, command significant premiums in the secondary market.

Values for Euro 5 and older vehicles have seen corresponding declines, particularly for those operating primarily in urban environments. However, this has created opportunities for operators in rural areas or specific sectors not immediately affected by emissions regulations, who can acquire these vehicles at competitive prices. This regional and sectoral disparity in vehicle values is expected to persist and potentially widen throughout 2025.

The impact of Brexit continues to influence the market, though the initial disruption has largely stabilised. The administrative requirements for importing used vehicles from the EU have now been integrated into standard business practices, though they still add cost and complexity compared to pre-Brexit arrangements. This has had the effect of slightly reducing the flow of used vehicles from Europe, historically an important source of stock for the UK market.

Supply chain constraints affecting new vehicle production have had knock-on effects in the used market. Delays in new vehicle deliveries have led many operators to extend the life of their existing fleets, reducing the number of quality used vehicles entering the market. This supply constraint, coupled with steady demand, has contributed to robust residual values across most vehicle categories.

Financing patterns have evolved significantly. Alternative finance arrangements, including operating leases and flexible rental agreements, have become increasingly popular, allowing businesses to manage cash flow more effectively in an uncertain economic environment. Traditional hire purchase remains important, but the market has seen increased diversity in how vehicles are funded.

The electrification transition is beginning to impact the used commercial vehicle sector, though the effect remains limited to specific segments. Early electric vans are now appearing in the used market, primarily from pioneering fleets that adopted the technology several years ago. While representing a small fraction of overall sales, these vehicles provide interesting insights into residual values and battery degradation patterns for electric commercial vehicles.

Battery health has emerged as a critical factor in valuing used electric vehicles. Unlike traditional vehicles, where engine hours and mileage provide reliable indicators of condition, battery capacity and degradation patterns are less predictable and harder to assess without specialised equipment. Some innovative dealers have begun offering battery health certifications to provide buyer confidence.

For diesel vehicles, which still comprise the vast majority of the market, traditional factors remain important. Mileage, service history, and overall condition continue to be the primary drivers of value. However, specification has become increasingly important, with features like advanced driver assistance systems, connectivity, and ergonomic cab designs commanding premiums that were not evident even a few years ago.

The dealer landscape continues to evolve. While traditional dealers maintain significant market share, online platforms have gained prominence, offering greater transparency and wider selection. Auction houses have successfully transitioned to hybrid models, combining physical and online sales to reach broader audiences of potential buyers.

For businesses looking to acquire used commercial vehicles in the current market, several strategies can improve outcomes. Flexibility on specification can yield significant savings, as can considering vehicles from different sectors that may have suitable characteristics but lower demand. Thorough inspection and history verification remain essential, particularly when purchasing through online channels.

Looking ahead to the remainder of 2025 and beyond, several factors will likely shape the market. The pace of zero-emission vehicle mandates will significantly impact diesel residual values, particularly as the 2030 deadline for ending new petrol and diesel van sales approaches. Economic conditions, including interest rates and business confidence, will influence fleet replacement cycles and, consequently, used vehicle supply.

For operators navigating this complex landscape, staying informed and adaptable is key. The used commercial vehicle market offers both challenges and opportunities, with significant potential for those who can accurately assess vehicle conditions, anticipate regulatory impacts, and align their fleet acquisition strategies with their specific operational requirements.`,
      image_url: "https://images.unsplash.com/photo-1608994751987-e647252b1fd9?auto=format&fit=crop&w=800&h=600&q=80",
      category: "Industry",
      date: "May 10, 2024",
      read_time: "7 min read",
      author: "James Wilson",
      tags: ["used vehicles", "market trends", "commercial vehicles", "fleet management"],
      published: true
    },
    {
      title: "Autonomous Trucking: Progress and Challenges",
      excerpt: "A detailed look at the current state of autonomous driving technology in the trucking industry and the roadblocks ahead.",
      content: `The vision of self-driving lorries traversing Britain's motorways has captivated the logistics industry for years, promising increased safety, reduced costs, and improved efficiency. As we assess the current state of autonomous trucking technology, it's clear that significant progress has been made, though formidable challenges remain before widespread deployment becomes reality.

Recent advances in sensor technology, artificial intelligence, and computing power have accelerated the development of autonomous systems. Modern autonomous trucks are equipped with an impressive array of technologies, including LIDAR (Light Detection and Ranging), radar, high-definition cameras, and sophisticated GPS systems. This hardware, combined with advanced machine learning algorithms, enables vehicles to perceive their environment, make decisions, and navigate complex roadways with increasing reliability.

Several trials across Britain have demonstrated the potential of this technology. The HelmUK project, which tested platooning technology on the M5 motorway, showed promising results for fuel efficiency and emissions reduction. Meanwhile, companies like Waymo (formerly Google's self-driving car project) and TuSimple have conducted extensive testing in controlled environments and on public roads, accumulating millions of miles of valuable data.

The potential benefits of autonomous trucking are substantial. Safety improvements stand at the forefront, with the technology potentially eliminating human errors that contribute to the majority of road accidents. The economic advantages are equally compelling, with estimates suggesting operational cost reductions of up to 45% through improved fuel efficiency, optimised routing, and the eventual reduction in driver costs.

However, significant technical challenges persist. While autonomous systems perform admirably in good weather and standard conditions, their performance can deteriorate in adverse weather such as heavy rain, fog, or snow – conditions not uncommon on British roads. Edge cases – unusual or unexpected scenarios that occur rarely but must be handled safely – present another substantial challenge. Developing systems that can reliably handle the infinite variety of situations encountered on public roads remains a formidable task.

The regulatory landscape presents another significant hurdle. Current British legislation was not designed with autonomous vehicles in mind, creating uncertainty around liability, insurance, and operational requirements. The Automated and Electric Vehicles Act 2018 laid some groundwork, but many regulatory details remain unresolved. Questions about who bears responsibility in the event of an accident – the vehicle manufacturer, software developer, fleet operator, or some combination thereof – require careful consideration.

Public acceptance represents another critical factor. A 2023 survey by Transport Focus revealed that while 62% of respondents were generally supportive of autonomous vehicle technology, this figure dropped to 41% when specifically asked about autonomous lorries sharing roads with other vehicles. Addressing these concerns through transparent communication, gradual implementation, and demonstrated safety records will be essential for widespread adoption.

The infrastructure requirements for autonomous trucking also present challenges. While the technology is designed to work with existing road networks, some enhancements could significantly improve performance and safety. These include consistent road markings, standardised signage, and potentially dedicated lanes on major routes. Additionally, digital infrastructure such as high-precision mapping and reliable communication networks will be crucial for optimal operation.

The labour implications of autonomous trucking technology cannot be overlooked. With approximately 300,000 HGV drivers in the UK, the potential for job displacement raises significant social and economic concerns. Industry experts suggest that the transition will likely be gradual, with human drivers remaining essential for complex urban deliveries, loading/unloading, and customer interaction. The role may evolve rather than disappear entirely, with drivers becoming "transport managers" overseeing autonomous systems.

Investment in the sector continues to grow, with both traditional vehicle manufacturers and technology companies committing substantial resources. Companies like Volvo, Daimler, and Tesla are developing autonomous capabilities for their commercial vehicles, while technology firms like Aurora and Embark are focused exclusively on self-driving systems that can be integrated with existing vehicles.

The likely path forward appears to be a phased implementation, beginning with constrained environments and limited operational domains. Highway driving, with its relatively predictable conditions and limited complexity, represents the most promising initial application. Systems that handle the motorway portion of journeys autonomously, with human drivers taking over for the more complex first and last miles, could deliver significant benefits while working within current technological limitations.

As the technology continues to mature, the question is not if autonomous trucking will become a reality, but when and how. The transformative potential for the logistics industry is too significant to ignore, but the path to widespread deployment will require continued technological advancement, thoughtful regulatory frameworks, infrastructure investment, and proactive management of workforce transitions.

For fleet operators and logistics companies, preparing for this future means staying informed about technological developments, participating in trials where possible, and considering how autonomous systems might integrate with and enhance existing operations. While full autonomy on British roads may still be years away, the journey toward this transformative technology is well underway.`,
      image_url: "https://images.unsplash.com/photo-1519003722824-194d4455a60c?auto=format&fit=crop&w=800&h=600&q=80",
      category: "Technology",
      date: "May 8, 2024",
      read_time: "8 min read",
      author: "Thomas Miller",
      tags: ["autonomous vehicles", "self-driving", "trucking technology", "AI"],
      published: true
    },
    {
      title: "Preventive Maintenance Strategies for Modern Commercial Fleets",
      excerpt: "Learn about the latest preventive maintenance approaches to keep your commercial vehicle fleet running efficiently and avoid costly downtime.",
      content: `In the competitive landscape of commercial transport, vehicle reliability isn't merely a technical consideration—it's a cornerstone of business success. As fleets across Britain grapple with the dual pressures of maximising uptime while controlling costs, preventive maintenance has evolved from a simple checklist of tasks to a sophisticated strategy leveraging technology, data, and proactive planning.

The cost implications of vehicle downtime are substantial. Recent studies from the Society of Motor Manufacturers and Traders (SMMT) suggest that unplanned downtime costs UK fleet operators an average of £600 per vehicle per day in direct costs and lost productivity. For larger fleets, this can translate to millions of pounds annually. Contemporary preventive maintenance strategies aim not just to reduce these costs, but to transform maintenance from a necessary expense into a competitive advantage.

The foundation of effective fleet maintenance remains a structured approach to routine servicing. However, modern strategies extend far beyond the traditional time-based or mileage-based maintenance intervals. Condition-based maintenance, which responds to the actual state of vehicle components rather than predetermined schedules, has gained significant traction. This approach utilises real-time monitoring of critical systems to identify early indicators of potential failures, allowing for intervention before breakdowns occur.

Telematics systems play a crucial role in this evolution. Advanced telematics provide comprehensive insights into vehicle health, capturing data on engine performance, braking systems, fuel efficiency, and numerous other parameters. Fleet managers can now receive alerts when vehicles deviate from normal operational patterns, potentially indicating developing issues. This data-driven approach enables maintenance to become increasingly precise and personalised to each vehicle's specific needs.

The integration of artificial intelligence has further refined maintenance practices. Machine learning algorithms can analyse historical maintenance data alongside current vehicle performance to predict component failures with remarkable accuracy. A 2024 case study by a major logistics provider in Manchester demonstrated a 64% reduction in unplanned downtime after implementing AI-driven predictive maintenance, with the system correctly anticipating component failures an average of 12 days before they would have occurred.

Oil analysis represents another sophisticated tool in the modern fleet manager's arsenal. Regular sampling and laboratory testing of engine oil can identify wear particles, contamination, and chemical changes that signal impending issues. This relatively inexpensive procedure provides a wealth of information about engine health that might otherwise remain hidden until a catastrophic failure occurs.

For electric and hybrid commercial vehicles, maintenance strategies require adaptation. While these vehicles typically have fewer moving parts and reduced maintenance requirements for certain systems, they introduce new considerations, particularly regarding battery health management. Specialised diagnostic equipment and targeted training for maintenance staff are essential investments for fleets incorporating these vehicles.

Tyre management deserves particular attention in any comprehensive maintenance strategy. Tyres represent both a significant operating expense and a critical safety component. Regular pressure checks, appropriate rotation schedules, and attention to alignment not only extend tyre life but also optimise fuel efficiency. Advanced tyre pressure monitoring systems (TPMS) provide continuous data, alerting drivers and fleet managers to issues requiring immediate attention.

The human element remains vital despite technological advances. Driver behaviour significantly impacts vehicle wear and maintenance requirements. Many progressive fleet operators have implemented driver training programmes focusing on techniques that reduce vehicle stress, such as smooth acceleration, appropriate braking, and proper shifting practices. Some have introduced incentive schemes rewarding drivers who demonstrate care for their vehicles through telematics-measured driving habits.

Documentation and record-keeping constitute an often-underappreciated aspect of effective maintenance. Digital maintenance management systems have largely replaced paper logbooks, providing searchable histories, automatic scheduling, and comprehensive reporting capabilities. These systems ensure compliance with regulatory requirements while generating valuable data for analysing maintenance trends and costs over time.

Supply chain management for parts and components has gained increased attention, particularly following recent global disruptions. Maintaining appropriate stock levels of critical components, developing relationships with multiple suppliers, and potentially participating in parts consortiums with other fleet operators can help mitigate the risk of extended downtime due to parts availability issues.

Even with the most rigorous preventive maintenance programme, emergency repairs will occasionally be necessary. Developing contingency plans for roadside assistance, replacement vehicles, and priority service from repair facilities ensures that when breakdowns do occur, their impact is minimised.

Cost-benefit analysis should guide all maintenance decisions. While it may be tempting to extend service intervals or defer maintenance during challenging economic periods, such decisions often prove costly in the long term. A 2023 study by the Freight Transport Association found that for every pound "saved" by deferring scheduled maintenance, fleets typically incurred £3.70 in additional costs through increased breakdowns, emergency repairs, and shortened component life.

For fleet managers looking to enhance their maintenance strategies, several steps can yield immediate benefits. Begin by analysing current maintenance data to identify patterns and recurring issues. Evaluate available telematics solutions with an eye toward maintenance applications rather than merely tracking capabilities. Invest in training for both maintenance staff and drivers, emphasising the critical role each plays in vehicle longevity.

As commercial vehicles continue to increase in complexity, with sophisticated emission control systems, advanced safety features, and increasing electrification, the importance of proactive, data-driven maintenance will only grow. The most successful fleet operators will be those who view maintenance not merely as a cost centre, but as a strategic function central to operational excellence and customer satisfaction.`,
      image_url: "https://images.unsplash.com/photo-1520340058891-a03488f2875e?auto=format&fit=crop&w=800&h=600&q=80",
      category: "Maintenance",
      date: "May 5, 2024",
      read_time: "9 min read",
      author: "Sarah Davis",
      tags: ["fleet maintenance", "preventive maintenance", "vehicle uptime", "fleet management"],
      published: true
    }
  ];

  // Check for existing articles
  const uniqueTitles = articles.map(article => article.title);
  const { data: existingArticles } = await supabase
    .from('blog_articles')
    .select('title')
    .in('title', uniqueTitles);

  // Create a set for quick lookups
  const existingTitles = new Set(existingArticles?.map(article => article.title) || []);

  // Filter out already existing articles
  const articlesToInsert = articles.filter(article => !existingTitles.has(article.title));

  if (articlesToInsert.length > 0) {
    await supabase
      .from('blog_articles')
      .insert(articlesToInsert);
  }
};

// Make sure to add the articles automatically when the module is first loaded
// This will run immediately when the application starts
(async function initializeArticles() {
  try {
    await addIndustryArticles();
    console.log('Industry articles initialized successfully');
  } catch (error) {
    console.error('Failed to initialize industry articles:', error);
  }
})();

// Export other functions that might be used in the application
export const fetchBlogArticles = async (): Promise<BlogArticle[]> => {
  const { data, error } = await supabase
    .from('blog_articles')
    .select('*')
    .order('date', { ascending: false });

  if (error) {
    console.error('Error fetching blog articles:', error);
    throw new Error('Failed to fetch blog articles');
  }

  // Map database fields to match our BlogArticle type
  return (data || []).map(item => ({
    id: item.id,
    title: item.title,
    excerpt: item.excerpt,
    content: item.content,
    author: item.author,
    date: item.date,
    category: item.category,
    tags: item.tags || [],
    readTime: item.read_time,
    image: item.image_url,
    published: item.published,
    created_at: item.created_at,
    updated_at: item.updated_at
  }));
};

export const fetchBlogArticleById = async (id: string): Promise<BlogArticle | null> => {
  const { data, error } = await supabase
    .from('blog_articles')
    .select('*')
    .eq('id', id)
    .single();

  if (error) {
    console.error(`Error fetching blog article with id ${id}:`, error);
    throw new Error('Failed to fetch blog article');
  }

  if (!data) return null;

  // Map database fields to match our BlogArticle type
  return {
    id: data.id,
    title: data.title,
    excerpt: data.excerpt,
    content: data.content,
    author: data.author,
    date: data.date,
    category: data.category,
    tags: data.tags || [],
    readTime: data.read_time,
    image: data.image_url,
    published: data.published,
    created_at: data.created_at,
    updated_at: data.updated_at
  };
};

export const fetchBlogArticlesByCategory = async (category: string): Promise<BlogArticle[]> => {
  // Special case for "all" category
  if (category === 'all') {
    return fetchBlogArticles();
  }

  const { data, error } = await supabase
    .from('blog_articles')
    .select('*')
    .ilike('category', category)
    .order('date', { ascending: false });

  if (error) {
    console.error(`Error fetching blog articles with category ${category}:`, error);
    throw new Error('Failed to fetch blog articles by category');
  }

  // Map database fields to match our BlogArticle type
  return (data || []).map(item => ({
    id: item.id,
    title: item.title,
    excerpt: item.excerpt,
    content: item.content,
    author: item.author,
    date: item.date,
    category: item.category,
    tags: item.tags || [],
    readTime: item.read_time,
    image: item.image_url,
    published: item.published,
    created_at: item.created_at,
    updated_at: item.updated_at
  }));
};

// Keep this export for potential future use but it will now be used internally
export { addIndustryArticles };
