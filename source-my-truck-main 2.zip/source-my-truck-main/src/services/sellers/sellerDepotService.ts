import { supabase } from "@/integrations/supabase/client";
import { VehicleData } from "@/components/VehicleCard";
import { convertToVehicleData } from "@/utils/vehicleMapper";
import { getAllVehicles } from "../vehicles/vehicleQueryService";

export interface SellerDepot {
  id: string;
  shop_name: string;
  tagline: string | null;
  description: string | null;
  website_url: string | null;
  theme_color: string | null;
  header_image_url: string | null;
  button_color: string | null;
  text_color: string | null;
  background_color: string | null;
  is_public: boolean;
  custom_url_slug: string | null;
  created_at: string;
  updated_at: string;
}

export interface SellerProfile {
  company_name: string;
  company_description: string | null;
  company_phone: string | null;
  company_address: string | null;
  logo_url: string | null;
}

export interface SellerWithVehicles {
  depot: SellerDepot | null;
  profile: SellerProfile;
  vehicles: VehicleData[];
  totalVehicles: number;
  page: number;
  pageSize: number;
}

/**
 * Check if a custom URL slug is available
 */
export const checkSlugAvailability = async (
  slug: string, 
  currentUserId?: string
): Promise<{ available: boolean; message?: string }> => {
  if (!slug || slug.length < 3) {
    return { available: false, message: "Slug must be at least 3 characters" };
  }
  
  // Check if the slug matches allowed format
  if (!/^[a-z0-9-]+$/.test(slug)) {
    return { 
      available: false, 
      message: "Slug can only contain lowercase letters, numbers, and hyphens" 
    };
  }

  // Query to check if slug is already in use by another seller
  const { data, error } = await supabase
    .from("seller_depots")
    .select("id")
    .eq("custom_url_slug", slug);

  if (error) {
    console.error("Error checking slug availability:", error);
    return { 
      available: false, 
      message: "Error checking availability" 
    };
  }

  // If no results found, slug is available
  if (!data || data.length === 0) {
    return { available: true };
  }
  
  // If the slug belongs to the current user, it's available for them
  if (currentUserId && data.length === 1 && data[0].id === currentUserId) {
    return { available: true };
  }

  // Someone else is using this slug
  return { 
    available: false, 
    message: "This URL is already taken. Please choose another." 
  };
};

/**
 * Get a seller depot by its custom URL slug
 */
export const getSellerDepotBySlug = async (slug: string): Promise<SellerDepot | null> => {
  if (!slug) {
    console.error("Missing slug in getSellerDepotBySlug");
    return null;
  }

  try {
    const { data, error } = await supabase
      .from("seller_depots")
      .select("*")
      .eq("custom_url_slug", slug)
      .eq("is_public", true)
      .maybeSingle();

    if (error) {
      console.error("Error getting seller depot by slug:", error);
      return null;
    }

    return data as SellerDepot;
  } catch (err) {
    console.error("Unexpected error in getSellerDepotBySlug:", err);
    return null;
  }
};

/**
 * Get a seller depot by seller ID
 */
export const getSellerDepotById = async (id: string): Promise<SellerDepot | null> => {
  if (!id) {
    console.error("Missing seller ID in getSellerDepotById");
    return null;
  }
  
  try {
    const { data, error } = await supabase
      .from("seller_depots")
      .select("*")
      .eq("id", id)
      .maybeSingle();

    if (error) {
      console.error("Error getting seller depot by ID:", error);
      return null;
    }

    return data as SellerDepot;
  } catch (err) {
    console.error("Unexpected error in getSellerDepotById:", err);
    return null;
  }
};

/**
 * Get seller profile information by ID
 */
export const getSellerProfileById = async (id: string): Promise<SellerProfile | null> => {
  if (!id) {
    console.error("Missing seller ID in getSellerProfileById");
    return null;
  }
  
  try {
    const { data, error } = await supabase
      .from("profiles")
      .select("company_name, company_description, company_phone, company_address, logo_url")
      .eq("id", id)
      .maybeSingle();

    if (error) {
      console.error("Error getting seller profile:", error);
      return null;
    }

    return data as SellerProfile;
  } catch (err) {
    console.error("Unexpected error in getSellerProfileById:", err);
    return null;
  }
};

/**
 * Get seller's active vehicles with pagination
 */
export const getSellerActiveVehicles = async (
  sellerId: string, 
  page = 1, 
  pageSize = 6
): Promise<{ vehicles: VehicleData[], totalCount: number }> => {
  try {
    // Calculate offset
    const offset = (page - 1) * pageSize;
    
    // Get all vehicles (filtered for active ones)
    const { data: vehiclesData, error, count } = await supabase
      .from("vehicles")
      .select("*, vehicle_images(*)", { count: 'exact' })
      .eq("user_id", sellerId)
      .eq("status", "active")
      .order("created_at", { ascending: false })
      .range(offset, offset + pageSize - 1);
      
    if (error) {
      console.error("Error getting seller vehicles:", error);
      return { vehicles: [], totalCount: 0 };
    }
    
    // Map to VehicleData format
    const vehicles = (vehiclesData || []).map(vehicle => 
      convertToVehicleData(vehicle as any)
    );
    
    return { 
      vehicles,
      totalCount: count || vehicles.length
    };
  } catch (error) {
    console.error("Error getting seller vehicles:", error);
    return { vehicles: [], totalCount: 0 };
  }
};

/**
 * Get complete seller depot information with profile and vehicles
 */
export const getSellerWithVehicles = async (
  idOrSlug: string, 
  isSlug = false,
  page = 1,
  pageSize = 6
): Promise<SellerWithVehicles | null> => {
  try {
    // First, get the depot information
    let depot: SellerDepot | null = null;
    
    if (isSlug) {
      depot = await getSellerDepotBySlug(idOrSlug);
    } else {
      depot = await getSellerDepotById(idOrSlug);
    }
    
    // If no depot found, or it's not public, return null
    if (!depot || !depot.is_public) {
      return null;
    }
    
    // Get the seller profile information
    const profile = await getSellerProfileById(depot.id);
    
    if (!profile) {
      return null;
    }
    
    // Get the seller's active vehicles with pagination
    const { vehicles, totalCount } = await getSellerActiveVehicles(depot.id, page, pageSize);
    
    return {
      depot,
      profile,
      vehicles,
      totalVehicles: totalCount,
      page,
      pageSize
    };
  } catch (error) {
    console.error("Error getting seller with vehicles:", error);
    return null;
  }
};

/**
 * Create or update a seller depot
 */
export const upsertSellerDepot = async (depotData: Partial<SellerDepot>): Promise<SellerDepot | null> => {
  try {
    // Get the current user
    const { data: { user } } = await supabase.auth.getUser();
    
    if (!user) {
      throw new Error("User not authenticated");
    }
    
    // Prepare the data for upsert
    const depot = {
      id: user.id,
      ...depotData,
      updated_at: new Date().toISOString()
    };
    
    // Upsert the depot
    const { data, error } = await supabase
      .from("seller_depots")
      .upsert(depot)
      .select()
      .single();
      
    if (error) {
      console.error("Error upserting seller depot:", error);
      return null;
    }
    
    return data as SellerDepot;
  } catch (error) {
    console.error("Error in upsertSellerDepot:", error);
    return null;
  }
};

/**
 * Upload a header image for a seller depot
 */
export const uploadHeaderImage = async (file: File): Promise<string | null> => {
  try {
    // Get the current user
    const { data: { user } } = await supabase.auth.getUser();
    
    if (!user) {
      throw new Error("User not authenticated");
    }
    
    // Create a unique file path for the user
    const filePath = `${user.id}/${Date.now()}_${file.name.replace(/\s+/g, '_')}`;
    
    // Upload the file to storage
    const { data, error } = await supabase.storage
      .from('seller-headers')
      .upload(filePath, file, {
        cacheControl: '3600',
        upsert: true
      });
      
    if (error) {
      console.error("Error uploading header image:", error);
      return null;
    }
    
    // Get the public URL for the uploaded file
    const { data: { publicUrl } } = supabase.storage
      .from('seller-headers')
      .getPublicUrl(data.path);
      
    return publicUrl;
  } catch (error) {
    console.error("Error in uploadHeaderImage:", error);
    return null;
  }
};

/**
 * Delete a header image from storage
 */
export const deleteHeaderImage = async (imageUrl: string): Promise<boolean> => {
  try {
    // Extract the file path from the URL
    const urlObj = new URL(imageUrl);
    const pathParts = urlObj.pathname.split('/');
    const filePath = pathParts.slice(pathParts.indexOf('seller-headers') + 1).join('/');
    
    // Delete the file from storage
    const { error } = await supabase.storage
      .from('seller-headers')
      .remove([filePath]);
      
    if (error) {
      console.error("Error deleting header image:", error);
      return false;
    }
    
    return true;
  } catch (error) {
    console.error("Error in deleteHeaderImage:", error);
    return false;
  }
};
