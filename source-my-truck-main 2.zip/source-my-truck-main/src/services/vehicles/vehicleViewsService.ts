
import { supabase } from "@/integrations/supabase/client";

/**
 * Records a view of a vehicle details page
 * @param vehicleId The ID of the vehicle being viewed
 * @param userId Optional ID of the authenticated user viewing the vehicle
 * @param ipAddress Optional IP address for anonymous views
 */
export const recordVehicleView = async (
  vehicleId: string,
  userId?: string,
  ipAddress?: string
) => {
  try {
    const { data, error } = await supabase
      .from('vehicle_views')
      .insert({
        vehicle_id: vehicleId,
        viewer_id: userId || null,
        ip_address: ipAddress || null
      });
      
    if (error) {
      console.error('Error recording vehicle view:', error);
      return { success: false, error };
    }
    
    return { success: true, data };
  } catch (err) {
    console.error('Unexpected error recording vehicle view:', err);
    return { success: false, error: err };
  }
};

/**
 * Get total view count for a specific vehicle
 */
export const getVehicleViewCount = async (vehicleId: string) => {
  try {
    const { count, error } = await supabase
      .from('vehicle_views')
      .select('*', { count: 'exact', head: true })
      .eq('vehicle_id', vehicleId);
      
    if (error) {
      console.error('Error getting vehicle view count:', error);
      return 0;
    }
    
    return count || 0;
  } catch (err) {
    console.error('Unexpected error getting vehicle view count:', err);
    return 0;
  }
};

/**
 * Get total views for all vehicles of a specific user
 */
export const getUserVehicleViews = async (userId: string) => {
  try {
    // Get all vehicle ids belonging to this user
    const { data: userVehicles, error: vehicleError } = await supabase
      .from('vehicles')
      .select('id')
      .eq('user_id', userId);
      
    if (vehicleError || !userVehicles?.length) {
      return 0;
    }
    
    const vehicleIds = userVehicles.map(v => v.id);
    
    // Get view count for all user vehicles
    const { count, error } = await supabase
      .from('vehicle_views')
      .select('*', { count: 'exact', head: true })
      .in('vehicle_id', vehicleIds);
      
    if (error) {
      console.error('Error getting user vehicle views:', error);
      return 0;
    }
    
    return count || 0;
  } catch (err) {
    console.error('Unexpected error getting user vehicle views:', err);
    return 0;
  }
};

/**
 * Get view statistics for vehicles
 */
export const getViewStatistics = async (vehicleIds: string[]) => {
  if (!vehicleIds.length) return {};
  
  try {
    // Get counts grouped by vehicle_id
    const { data, error } = await supabase
      .from('vehicle_views')
      .select('vehicle_id')
      .in('vehicle_id', vehicleIds);
      
    if (error || !data) {
      console.error('Error getting view statistics:', error);
      return {};
    }
    
    // Count occurrences of each vehicle_id
    const viewCounts: Record<string, number> = {};
    vehicleIds.forEach(id => { viewCounts[id] = 0 }); // Initialize all with 0
    
    data.forEach(row => {
      const id = row.vehicle_id;
      viewCounts[id] = (viewCounts[id] || 0) + 1;
    });
    
    return viewCounts;
  } catch (err) {
    console.error('Unexpected error getting view statistics:', err);
    return {};
  }
};
