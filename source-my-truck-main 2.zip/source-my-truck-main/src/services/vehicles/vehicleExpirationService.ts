
import { supabase } from "@/integrations/supabase/client";

/**
 * Reactivates an expired vehicle listing.
 * This requires the user to have at least 1 credit available.
 */
export const reactivateVehicle = async (vehicleId: string): Promise<{ 
  success: boolean; 
  error: string | null;
  insufficientCredits?: boolean;
}> => {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    
    if (!user) {
      return { 
        success: false, 
        error: "You must be logged in to reactivate a vehicle" 
      };
    }
    
    const { data: vehicle, error: vehicleError } = await supabase
      .from("vehicles")
      .select("user_id")
      .eq("id", vehicleId)
      .single();
    
    if (vehicleError) {
      console.error("Error checking vehicle ownership:", vehicleError);
      return { success: false, error: "Failed to verify ownership" };
    }
    
    if (vehicle.user_id !== user.id) {
      return { 
        success: false, 
        error: "You do not have permission to reactivate this vehicle" 
      };
    }
    
    const { data: profile, error: profileError } = await supabase
      .from("profiles")
      .select("credits")
      .eq("id", user.id)
      .single();
      
    if (profileError) {
      console.error("Error checking credits:", profileError);
      return { success: false, error: "Failed to check available credits" };
    }
    
    if (profile.credits < 1) {
      return { 
        success: false, 
        error: "You don't have enough credits to reactivate this vehicle", 
        insufficientCredits: true 
      };
    }
    
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + 30);
    
    const { error: updateError } = await supabase
      .from("vehicles")
      .update({ 
        status: "active",
        expires_at: expiresAt.toISOString()
      })
      .eq("id", vehicleId);
    
    if (updateError) {
      console.error("Error updating vehicle:", updateError);
      return { success: false, error: "Failed to reactivate vehicle" };
    }
    
    const { error: creditError } = await supabase
      .from("profiles")
      .update({ credits: profile.credits - 1 })
      .eq("id", user.id);
    
    if (creditError) {
      console.error("Error updating credits:", creditError);
      return { success: false, error: "Failed to deduct credit" };
    }
    
    const { error: transactionError } = await supabase
      .from("transactions")
      .insert({
        user_id: user.id,
        amount: 1,
        cost_pence: 0,
        status: "completed",
        payment_intent_id: null
      });
    
    if (transactionError) {
      console.error("Error creating transaction record:", transactionError);
    }
    
    return { success: true, error: null };
  } catch (error) {
    console.error("Unexpected error reactivating vehicle:", error);
    return { success: false, error: "An unexpected error occurred" };
  }
};

/**
 * Checks if a vehicle listing is expired.
 */
export const checkVehicleExpiration = async (vehicleId: string): Promise<{ 
  isExpired: boolean; 
  error: string | null;
}> => {
  try {
    const { data, error } = await supabase
      .from("vehicles")
      .select("expires_at, status")
      .eq("id", vehicleId)
      .maybeSingle();
    
    if (error) {
      console.error("Error checking vehicle expiration:", error);
      return { isExpired: false, error: "Failed to check vehicle expiration" };
    }
    
    if (!data || !data.expires_at) {
      return { isExpired: false, error: null };
    }
    
    const now = new Date();
    const expiresAt = new Date(data.expires_at);
    
    const isExpired = expiresAt < now && data.status === "active";
    
    return { isExpired, error: null };
  } catch (error) {
    console.error("Unexpected error checking vehicle expiration:", error);
    return { isExpired: false, error: "An unexpected error occurred" };
  }
};
