
import { supabase } from "@/integrations/supabase/client";

interface GeocodeResult {
  coordinates: string; // Format: "lat,lng"
  formattedAddress: string;
}

interface GeocodingCache {
  [postcode: string]: GeocodeResult | null;
}

// Cache to prevent repeated API calls for the same postcode
const geocodingCache: GeocodingCache = {};

/**
 * Geocode a UK postcode to get coordinates
 * Uses https://api.postcodes.io - a free and open postcode API for the UK
 */
export const geocodePostcode = async (postcode: string): Promise<GeocodeResult | null> => {
  // Normalize postcode format by removing spaces and converting to uppercase
  const normalizedPostcode = postcode.replace(/\s+/g, '').toUpperCase();
  
  // Check cache first
  if (geocodingCache[normalizedPostcode] !== undefined) {
    return geocodingCache[normalizedPostcode];
  }
  
  try {
    const response = await fetch(`https://api.postcodes.io/postcodes/${normalizedPostcode}`);
    
    if (!response.ok) {
      console.error(`Error geocoding postcode ${postcode}: ${response.statusText}`);
      geocodingCache[normalizedPostcode] = null;
      return null;
    }
    
    const data = await response.json();
    
    if (!data.result || !data.result.latitude || !data.result.longitude) {
      console.error('Invalid geocoding response:', data);
      geocodingCache[normalizedPostcode] = null;
      return null;
    }
    
    const result: GeocodeResult = {
      coordinates: `${data.result.latitude},${data.result.longitude}`,
      formattedAddress: data.result.formatted_address || data.result.postcode
    };
    
    // Cache the result
    geocodingCache[normalizedPostcode] = result;
    
    return result;
  } catch (error) {
    console.error('Error geocoding postcode:', error);
    geocodingCache[normalizedPostcode] = null;
    return null;
  }
};

/**
 * Get coordinates for a profile based on company address
 */
export const getProfileCoordinates = async (profileId: string): Promise<string | null> => {
  try {
    const { data, error } = await supabase
      .from('profiles')
      .select('company_address')
      .eq('id', profileId)
      .single();
    
    if (error || !data?.company_address) {
      return null;
    }
    
    // Extract postcode from company address (assuming UK format)
    const postcodeMatch = data.company_address.match(/[A-Z]{1,2}[0-9][A-Z0-9]? ?[0-9][A-Z]{2}$/i);
    if (!postcodeMatch) return null;
    
    const postcode = postcodeMatch[0];
    const geocodingResult = await geocodePostcode(postcode);
    
    return geocodingResult?.coordinates || null;
  } catch (error) {
    console.error('Error getting profile coordinates:', error);
    return null;
  }
};
