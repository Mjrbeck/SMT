
// Import and re-export all vehicle-related services
export * from './vehicleQueryService';
export * from './vehicleExpirationService';

// Explicitly re-export from vehicleManagementService with a different name to avoid conflict
import { 
  reactivateVehicle as reactivateVehicleListing,
  deleteVehicleById,
  updateVehicleStatus,
  saveVehicleListing
} from './vehicleManagementService';

export {
  deleteVehicleById,
  updateVehicleStatus,
  saveVehicleListing,
  reactivateVehicleListing
};
