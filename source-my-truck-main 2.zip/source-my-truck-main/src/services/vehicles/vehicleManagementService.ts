import { supabase } from "@/integrations/supabase/client";
import { invalidateCreditsCache } from "@/services/credits/creditsBalanceService";

// Define credit costs for different listing tiers 
const LISTING_TIER_COSTS = {
  standard: 1, // Standard tier costs exactly 1 credit
  premium: 3   // Premium tier costs 3 credits
};

/**
 * Delete a vehicle by ID.
 */
export const deleteVehicleById = async (id: string): Promise<{ success: boolean; error: string | null }> => {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    
    if (!user) {
      return { success: false, error: "You must be logged in to delete a vehicle" };
    }
    
    // Check if vehicle exists and belongs to the current user
    const { data: vehicle, error: vehicleError } = await supabase
      .from("vehicles")
      .select("user_id")
      .eq("id", id)
      .maybeSingle();  // Use maybeSingle instead of single to handle the case where the vehicle doesn't exist
    
    if (vehicleError) {
      console.error("Error checking vehicle ownership:", vehicleError);
      return { success: false, error: "Failed to verify ownership" };
    }
    
    // If vehicle doesn't exist, consider it already deleted
    if (!vehicle) {
      console.log(`Vehicle ${id} not found, may have been deleted already`);
      return { success: true, error: null };
    }
    
    if (vehicle.user_id !== user.id) {
      return { success: false, error: "You do not have permission to delete this vehicle" };
    }
    
    const { error: imagesError } = await supabase
      .from("vehicle_images")
      .delete()
      .eq("vehicle_id", id);
    
    if (imagesError) {
      console.error("Error deleting vehicle images:", imagesError);
      return { success: false, error: "Failed to delete vehicle images" };
    }
    
    // Delete vehicle views
    const { error: viewsError } = await supabase
      .from("vehicle_views")
      .delete()
      .eq("vehicle_id", id);
    
    if (viewsError) {
      console.error("Error deleting vehicle views:", viewsError);
      // Continue with deletion even if views deletion fails
    }
    
    const { error } = await supabase
      .from("vehicles")
      .delete()
      .eq("id", id);
    
    if (error) {
      console.error("Error deleting vehicle:", error);
      return { success: false, error: "Failed to delete vehicle" };
    }
    
    return { success: true, error: null };
  } catch (error) {
    console.error("Unexpected error deleting vehicle:", error);
    return { success: false, error: "An unexpected error occurred" };
  }
};

/**
 * Update vehicle status.
 */
export const updateVehicleStatus = async (id: string, status: string): Promise<{ success: boolean; error: string | null }> => {
  try {
    console.log(`Updating vehicle ${id} status to: ${status}`);
    
    const { data: vehicle, error: vehicleError } = await supabase
      .from("vehicles")
      .select("user_id, status")
      .eq("id", id)
      .single();
    
    if (vehicleError) {
      console.error("Error checking vehicle ownership:", vehicleError);
      return { success: false, error: "Failed to verify ownership" };
    }
    
    const { data: { user } } = await supabase.auth.getUser();
    
    if (!user) {
      return { success: false, error: "You must be logged in to update a vehicle" };
    }
    
    if (vehicle.user_id !== user.id) {
      return { success: false, error: "You do not have permission to update this vehicle" };
    }
    
    console.log(`Current vehicle status: ${vehicle.status}, updating to: ${status}`);
    
    const { error } = await supabase
      .from("vehicles")
      .update({ status })
      .eq("id", id);
    
    if (error) {
      console.error("Error updating vehicle status:", error);
      return { success: false, error: "Failed to update vehicle status" };
    }
    
    console.log(`Successfully updated vehicle ${id} status to: ${status}`);
    return { success: true, error: null };
  } catch (error) {
    console.error("Unexpected error updating vehicle status:", error);
    return { success: false, error: "An unexpected error occurred" };
  }
};

/**
 * Create or update a vehicle listing
 */
export const saveVehicleListing = async (
  vehicleData: any, 
  userId: string, 
  existingId?: string,
  requiredCredits: number = 1
): Promise<{ success: boolean; vehicleId?: string; error: string | null; insufficientCredits?: boolean }> => {
  try {
    console.log("Creating/updating vehicle with data:", JSON.stringify(vehicleData, null, 2));
    console.log("Required credits:", requiredCredits);
    console.log("existingId (is edit mode):", existingId ? "yes" : "no");
    
    const requiredFields = ['make', 'year'];
    
    const missingFields = requiredFields.filter((field: string) => !vehicleData[field]);
    
    // Normalize isPOA to a boolean
    const isPOA = vehicleData.isPOA === true || vehicleData.isPOA === "true";
    
    if (!isPOA) {
      // Handle price validation - ensure it's not empty and is a positive number
      let priceValue: number | null = null;
      
      if (typeof vehicleData.price === 'number') {
        priceValue = vehicleData.price;
      } else if (typeof vehicleData.price === 'string' && vehicleData.price.trim() !== '') {
        priceValue = parseFloat(vehicleData.price);
      }
      
      if (priceValue === null || isNaN(priceValue) || priceValue <= 0) {
        missingFields.push('price');
      }
    }
    
    if (missingFields.length > 0) {
      console.error("Missing required fields:", missingFields);
      return { 
        success: false, 
        error: `Missing required fields: ${missingFields.join(', ')}` 
      };
    }

    // Get the listing tier and determine credit cost (ensure only 'standard' or 'premium')
    const listingTier = vehicleData.listingTier === 'premium' ? 'premium' : 'standard';
    
    // Only deduct credits when it's a final submission to create a new listing or upgrade an existing one,
    // not for saving details or editing an existing listing
    const isNewListing = !existingId;
    
    // Calculate the credits needed based on tier
    let creditCost = 0;
    
    if (isNewListing) {
      // For new listings, use the tier cost directly
      creditCost = LISTING_TIER_COSTS[listingTier as keyof typeof LISTING_TIER_COSTS] || 1;
    } else if (requiredCredits > 0) {
      // For existing listings, only charge if explicitly requested (upgrade)
      // This should now be 0 in all normal edit cases due to our changes in useVehicleFormSubmit
      creditCost = requiredCredits;
    }
    
    console.log(`Listing tier: ${listingTier}, Credit cost: ${creditCost}, Is new listing: ${isNewListing}`);

    // Only deduct credits when needed (new listing or upgrade)
    if (creditCost > 0) {
      try {
        // First, check if the user has enough credits before trying to deduct
        const { data: profileData, error: profileError } = await supabase
          .from('profiles')
          .select('credits')
          .eq('id', userId)
          .single();
          
        if (profileError) {
          console.error("Error checking user credits:", profileError);
          return { success: false, error: "Failed to verify available credits" };
        }
        
        const availableCredits = profileData?.credits || 0;
        
        if (availableCredits < creditCost) {
          console.log(`User has insufficient credits: ${availableCredits} available, ${creditCost} needed`);
          return { 
            success: false, 
            error: `You need at least ${creditCost} credits for this operation`, 
            insufficientCredits: true 
          };
        }
        
        console.log(`User has ${availableCredits} credits, proceeding with deduction of ${creditCost} credits`);
        
        // For new listings, the database trigger only deducts 1 credit regardless of tier
        // We need to handle the correct deduction here
        if (isNewListing && listingTier === 'premium') {
          // For premium listings, we need to deduct 3 credits instead of 1
          // The database trigger will handle 1 credit, so we deduct the additional 2 here
          console.log("Premium listing - deducting additional 2 credits");
          const { data, error } = await supabase.functions.invoke("decrement_credits", {
            body: { userId, amount: 2 }
          });
          
          if (error) {
            console.error("Error deducting additional credits for premium:", error);
            
            if (error.message && error.message.includes("Insufficient credits")) {
              console.log("User has insufficient credits (confirmed by edge function)");
              return { 
                success: false, 
                error: `You need at least ${creditCost} credits for this operation`, 
                insufficientCredits: true 
              };
            }
            
            return { success: false, error: "Failed to deduct credits for premium listing" };
          }
          
          console.log("Additional credits deducted successfully. Remaining credits:", data?.remainingCredits);
        } else if (!isNewListing && creditCost > 0) {
          // For upgrades to existing listings, we need to handle credit deduction ourselves
          const { data, error } = await supabase.functions.invoke("decrement_credits", {
            body: { userId, amount: creditCost }
          });
          
          if (error) {
            console.error("Error deducting credits:", error);
            
            if (error.message && error.message.includes("Insufficient credits")) {
              console.log("User has insufficient credits (confirmed by edge function)");
              return { 
                success: false, 
                error: `You need at least ${creditCost} credits for this operation`, 
                insufficientCredits: true 
              };
            }
            
            return { success: false, error: "Failed to deduct credits" };
          }
          
          console.log("Credits deducted successfully. Remaining credits:", data?.remainingCredits);
        }
        
        // Invalidate the credits cache to ensure UI shows updated amount
        invalidateCreditsCache();
      } catch (error) {
        console.error("Error in credit deduction:", error);
        
        // If the error suggests insufficient credits
        if (error.message && error.message.includes("Insufficient credits")) {
          return { 
            success: false, 
            error: `You need at least ${creditCost} credits for this operation`, 
            insufficientCredits: true 
          };
        }
        
        return { success: false, error: "Failed to verify credits" };
      }
    } else {
      console.log("Skipping credit deduction - edit mode or no credits required");
    }
    
    // Determine the price value based on isPOA status
    let priceValue: number;
    
    if (isPOA) {
      console.log("Setting price to 0 for POA listing");
      priceValue = 0;
    } else {
      // Handle various price formats and convert to number
      if (typeof vehicleData.price === 'number') {
        priceValue = vehicleData.price;
      } else if (typeof vehicleData.price === 'string' && vehicleData.price.trim() !== '') {
        // Convert string to number, remove any non-numeric characters except decimal point
        const sanitizedPrice = vehicleData.price.replace(/[^0-9.]/g, '');
        priceValue = parseFloat(sanitizedPrice);
      } else {
        priceValue = 0;
      }
      
      // Ensure price is a valid number
      if (isNaN(priceValue)) {
        console.log("Price is NaN, using 0 as default");
        priceValue = 0;
      }
    }
    
    console.log("Final price value for database:", priceValue);
    
    const features = Array.isArray(vehicleData.features) ? vehicleData.features : [];
    
    const parseNumericOrNull = (value: any) => 
      value && !isNaN(parseFloat(value.toString())) ? parseFloat(value.toString()) : null;
    
    const modelValue = vehicleData.model !== undefined && vehicleData.model !== null && vehicleData.model !== "" 
      ? String(vehicleData.model) 
      : null;
    
    const modelPart = modelValue ? ` ${modelValue}` : '';
    const title = `${vehicleData.year} ${vehicleData.make}${modelPart}`;
    
    const vehicleRecord = {
      user_id: userId,
      title,
      make: vehicleData.make,
      model: modelValue,
      year: parseInt(String(vehicleData.year)),
      price: priceValue,
      is_poa: isPOA,
      mileage: parseNumericOrNull(vehicleData.mileage),
      engine_size: vehicleData.engineSize || null,
      fuel_type: vehicleData.fuelType || null,
      transmission: vehicleData.transmission || null,
      description: vehicleData.description || null,
      axle_configuration: vehicleData.axleConfiguration || null,
      body_type: vehicleData.bodyType || null,
      status: vehicleData.status || 'active',
      registration: vehicleData.registration || null,
      interior_condition: vehicleData.interiorCondition || null,
      exterior_condition: vehicleData.exteriorCondition || null,
      features: features,
      color: vehicleData.color || null,
      cab_type: vehicleData.cabType || null,
      driver_position: vehicleData.driverPosition || null,
      engine_power: vehicleData.enginePower || null,
      emissions_class: vehicleData.emissionsClass || null,
      number_of_seats: parseNumericOrNull(vehicleData.numberOfSeats),
      gross_vehicle_weight: parseNumericOrNull(vehicleData.grossVehicleWeight),
      volume: vehicleData.volume || null,
      internal_length: parseNumericOrNull(vehicleData.internalLength),
      internal_width: parseNumericOrNull(vehicleData.internalWidth),
      internal_height: parseNumericOrNull(vehicleData.internalHeight),
      external_length: parseNumericOrNull(vehicleData.externalLength),
      external_width: parseNumericOrNull(vehicleData.externalWidth),
      external_height: parseNumericOrNull(vehicleData.externalHeight),
      is_new: vehicleData.isNew === true,
      listing_tier: listingTier,
      video_url: vehicleData.videoUrl || null  // Add video URL to the record
    };

    console.log("Prepared vehicle record:", JSON.stringify(vehicleRecord, null, 2));

    let response;
    
    if (existingId) {
      response = await supabase
        .from('vehicles')
        .update(vehicleRecord)
        .eq('id', existingId)
        .select('id')
        .single();
    } else {
      response = await supabase
        .from('vehicles')
        .insert(vehicleRecord)
        .select('id')
        .single();
    }
    
    if (response.error) {
      console.error("Error saving vehicle:", response.error);
      
      // Check for specific error messages related to credits
      if (response.error.message?.includes("Not enough credits")) {
        console.log("Database reported insufficient credits");
        return { 
          success: false, 
          error: "You don't have enough credits for this listing", 
          insufficientCredits: true 
        };
      }
      
      return { success: false, error: response.error.message };
    }
    
    console.log("Vehicle saved successfully with ID:", response.data.id);
    
    // Invalidate the credits cache to ensure UI shows updated amount after vehicle creation
    invalidateCreditsCache();
    
    return { success: true, vehicleId: response.data.id, error: null };
  } catch (error: any) {
    console.error("Unexpected error saving vehicle:", error);
    return { success: false, error: error.message };
  }
};

/**
 * Reactivate an expired vehicle listing
 */
export const reactivateVehicle = async (id: string): Promise<{ success: boolean; error: string | null; insufficientCredits?: boolean }> => {
  try {
    console.log(`Reactivating vehicle ${id}`);

    const { data: { user } } = await supabase.auth.getUser();
    
    if (!user) {
      return { success: false, error: "You must be logged in to reactivate a vehicle" };
    }
    
    // Deduct 1 credit for reactivation using the edge function
    try {
      const { data, error } = await supabase.functions.invoke("decrement_credits", {
        body: { userId: user.id, amount: 1 }
      });
      
      if (error) {
        console.error("Error deducting credit:", error);
        
        if (error.message && error.message.includes("Insufficient credits")) {
          return { 
            success: false, 
            error: "You don't have enough credits to reactivate this listing", 
            insufficientCredits: true 
          };
        }
        
        return { success: false, error: "Failed to deduct credit" };
      }
      
      console.log("Credit deducted successfully. Remaining credits:", data?.remainingCredits);
      // Invalidate the credits cache to ensure UI shows updated amount
      invalidateCreditsCache();
    } catch (error) {
      console.error("Error in credit deduction:", error);
      return { success: false, error: "Failed to deduct credit" };
    }
    
    const { data: vehicle, error: vehicleError } = await supabase
      .from("vehicles")
      .select("user_id")
      .eq("id", id)
      .single();
    
    if (vehicleError) {
      console.error("Error checking vehicle ownership:", vehicleError);
      return { success: false, error: "Failed to verify ownership" };
    }
    
    if (vehicle.user_id !== user.id) {
      return { success: false, error: "You do not have permission to reactivate this vehicle" };
    }
    
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + 30);
    
    const { error: updateError } = await supabase
      .from("vehicles")
      .update({ 
        status: "active",
        expires_at: expiresAt.toISOString()
      })
      .eq("id", id);
    
    if (updateError) {
      console.error("Error reactivating vehicle:", updateError);
      return { success: false, error: "Failed to reactivate vehicle" };
    }
    
    console.log("Vehicle reactivated successfully");
    return { success: true, error: null };
  } catch (error) {
    console.error("Unexpected error reactivating vehicle:", error);
    return { success: false, error: "An unexpected error occurred" };
  }
};
