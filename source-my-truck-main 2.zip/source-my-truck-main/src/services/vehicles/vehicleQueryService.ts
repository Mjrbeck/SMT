
import { supabase } from "@/integrations/supabase/client";
import { VehicleData } from "@/components/VehicleCard";
import { VehicleWithImages } from "@/services/types";
import { convertToVehicleData } from "@/utils/vehicleMapper";
import { getProfileCoordinates } from "./geocodingService";

/**
 * Get a single vehicle by ID.
 */
export const getVehicleById = async (id: string): Promise<VehicleData | null> => {
  try {
    // First let's check if the youtube_url column exists in the vehicles table
    const { data: columns, error: columnsError } = await supabase
      .from('vehicles')
      .select('*')
      .limit(1);
    
    if (columnsError) {
      console.error("Error checking columns:", columnsError);
    }
    
    const { data, error } = await supabase
      .from("vehicles")
      .select(`
        *,
        vehicle_images(*)
      `)
      .eq("id", id)
      .maybeSingle();
    
    if (error) {
      console.error("Error fetching vehicle:", error);
      return null;
    }
    
    if (!data) return null;

    // Don't display draft vehicles to the public
    const { data: { user } } = await supabase.auth.getUser();
    if (data.status === 'draft' && (!user || user.id !== data.user_id)) {
      console.log("Preventing access to draft vehicle");
      return null;
    }
    
    // Get seller's location coordinates if available
    if (data.user_id) {
      const coordinates = await getProfileCoordinates(data.user_id);
      if (coordinates) {
        data.location = coordinates;
      }
    }
    
    // Log only once per request to avoid console spam
    if (process.env.NODE_ENV === 'development') {
      console.log("Vehicle data youtube_url:", data.youtube_url);
    }
    
    // Create a complete object with the youtube_url properly handled
    const completeData = {
      ...data,
      youtube_url: data.youtube_url
    };
    
    // Convert to the expected VehicleData format
    const convertedVehicleData = convertToVehicleData(completeData as unknown as VehicleWithImages);
    
    return convertedVehicleData;
  } catch (error) {
    console.error("Unexpected error fetching vehicle:", error);
    return null;
  }
};

/**
 * Get similar vehicles based on make.
 */
export const getSimilarVehicles = async (make: string, currentId: string, limit = 2): Promise<VehicleData[]> => {
  try {
    const { data, error } = await supabase
      .from("vehicles")
      .select(`
        *,
        vehicle_images(*)
      `)
      .eq("make", make)
      .eq("status", "active") // Only show active vehicles
      .neq("id", currentId)
      .limit(limit);
    
    if (error) {
      console.error("Error fetching similar vehicles:", error);
      return [];
    }
    
    // Enhance data with location information
    const enhancedData = await Promise.all((data || []).map(async (vehicle) => {
      if (vehicle.user_id) {
        const coordinates = await getProfileCoordinates(vehicle.user_id);
        if (coordinates) {
          vehicle.location = coordinates;
        }
      }
      return vehicle;
    }));
    
    return enhancedData.map((vehicle) => convertToVehicleData(vehicle as unknown as VehicleWithImages));
  } catch (error) {
    console.error("Unexpected error fetching similar vehicles:", error);
    return [];
  }
};

/**
 * Get featured vehicles for the homepage.
 */
export const getFeaturedVehicles = async (limit = 6, onlyActive = true): Promise<VehicleData[]> => {
  try {
    // Build query for active vehicles
    let query = supabase
      .from("vehicles")
      .select(`
        *,
        vehicle_images(*)
      `)
      .order("created_at", { ascending: false }); // Most recently created first
    
    // Apply active filter if requested
    if (onlyActive) {
      query = query.eq("status", "active");
    }
    
    // Apply limit
    let { data, error } = await query.limit(limit);
    
    if (error) {
      console.error("Error fetching featured vehicles:", error);
      return [];
    }
    
    // If we got no vehicles with the active filter, try again without filtering by expires_at
    if ((data?.length === 0) && onlyActive) {
      const retryQuery = supabase
        .from("vehicles")
        .select(`
          *,
          vehicle_images(*)
        `)
        .eq("status", "active")
        .order("created_at", { ascending: false })
        .limit(limit);
      
      const { data: retryData, error: retryError } = await retryQuery;
      
      if (retryError) {
        console.error("Error in retry fetch:", retryError);
        return [];
      }
      
      data = retryData || [];
    }
    
    // Enhance data with location information
    const enhancedData = await Promise.all((data || []).map(async (vehicle) => {
      if (vehicle.user_id) {
        const coordinates = await getProfileCoordinates(vehicle.user_id);
        if (coordinates) {
          vehicle.location = coordinates;
        }
      }
      return vehicle;
    }));
    
    return enhancedData.map((vehicle) => convertToVehicleData(vehicle as unknown as VehicleWithImages));
  } catch (error) {
    console.error("Unexpected error fetching featured vehicles:", error);
    return [];
  }
};

/**
 * Get all vehicles.
 */
export const getAllVehicles = async (trustedSellersOnly = false, depotVerifiedOnly = false): Promise<VehicleData[]> => {
  try {
    // Get the current user (if any)
    const { data: { user } } = await supabase.auth.getUser();

    let query = supabase
      .from('vehicles')
      .select(`
        *,
        vehicle_images(*)
      `)
      .order('created_at', { ascending: false });
    
    // Always filter for active vehicles for public browsing
    // Only exception: draft vehicles owned by current user
    if (!user) {
      query = query.eq('status', 'active');
    } else {
      // For logged-in users, show active vehicles + their own draft vehicles
      query = query.or(`status.eq.active,and(status.eq.draft,user_id.eq.${user.id})`);
    }

    const { data, error } = await query;

    if (error) {
      console.error('Error fetching vehicles:', error);
      throw error;
    }

    // If seller verification filters are needed, fetch profiles and filter
    let filteredData = data || [];
    if (trustedSellersOnly || depotVerifiedOnly) {
      const userIds = [...new Set(filteredData.map(v => v.user_id))];
      
      if (userIds.length > 0) {
        const { data: profiles } = await supabase
          .from('profiles')
          .select('id, is_trusted, depot_verified')
          .in('id', userIds);
        
        if (profiles) {
          const profileMap = new Map(profiles.map(p => [p.id, p]));
          
          filteredData = filteredData.filter(vehicle => {
            const profile = profileMap.get(vehicle.user_id);
            if (!profile) return false;
            
            if (trustedSellersOnly && !profile.is_trusted) return false;
            if (depotVerifiedOnly && !profile.depot_verified) return false;
            
            return true;
          });
        }
      }
    }

    // Enhance data with location information
    const enhancedData = await Promise.all(filteredData.map(async (vehicle) => {
      if (vehicle.user_id) {
        const coordinates = await getProfileCoordinates(vehicle.user_id);
        if (coordinates) {
          vehicle.location = coordinates;
        }
      }
      return vehicle;
    }));

    return enhancedData.map((vehicle) => convertToVehicleData(vehicle as unknown as VehicleWithImages));
  } catch (error) {
    console.error("Unexpected error fetching all vehicles:", error);
    return [];
  }
};

/**
 * Get vehicles belonging to the current user.
 */
export const getCurrentUserVehicles = async (): Promise<VehicleData[]> => {
  try {
    const { data: userData, error: userError } = await supabase.auth.getUser();
    
    if (userError || !userData.user) {
      console.error('Error getting current user:', userError);
      return [];
    }
    
    const userId = userData.user.id;
    
    const { data, error } = await supabase
      .from('vehicles')
      .select(`
        *,
        vehicle_images(*)
      `)
      .eq('user_id', userId)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching user vehicles:', error);
      return [];
    }

    // Add location data to vehicles
    const coordinates = await getProfileCoordinates(userId);
    const enhancedData = data.map(vehicle => {
      if (coordinates) {
        vehicle.location = coordinates;
      }
      return vehicle;
    });

    return (enhancedData || []).map((vehicle) => convertToVehicleData(vehicle as unknown as VehicleWithImages));
  } catch (error) {
    console.error("Unexpected error fetching user vehicles:", error);
    return [];
  }
};
