
import { supabase } from "@/integrations/supabase/client";

export const getCurrentUser = async () => {
  try {
    const { data, error } = await supabase.auth.getUser();
    
    if (error || !data.user) {
      // Don't log auth session missing errors when signing out as they're expected
      if (!(error && error.message.includes("Auth session missing") || 
            error && error.message.includes("token is expired"))) {
        console.error("Error getting current user:", error);
      }
      return null;
    }
    
    return data.user;
  } catch (error) {
    // Handle any other unexpected errors
    console.error("Unexpected error in getCurrentUser:", error);
    return null;
  }
};

// Add a helper function to check if a token is expired
export const isTokenExpired = (error: any): boolean => {
  return error && 
    (typeof error.message === 'string' && (
      error.message.includes('token is expired') || 
      error.message.includes('JWT expired')
    ));
};

// Auto sign out for expired tokens
export const handleExpiredToken = async () => {
  try {
    // Quietly sign out if token is expired - no error messages
    await supabase.auth.signOut();
    return true;
  } catch (e) {
    // Fail silently, we're just trying to clean up
    return false;
  }
};
