import { supabase } from "@/integrations/supabase/client";
import { getCurrentUser } from "./authService";

// Credit package definitions (must match PurchaseForm)
const CREDIT_PACKAGES = {
  custom: { pricePerCredit: 10.00 },
  standard: { credits: 10, pricePerCredit: 9.50 },
  premium: { credits: 20, pricePerCredit: 9.00 },
  enterprise: { credits: 50, pricePerCredit: 8.50 }
};

export const purchaseCredits = async (amount: number, packageType: string = 'custom') => {
  try {
    if (!amount || amount < 1) {
      return { 
        success: false, 
        error: "Please select at least 1 credit" 
      };
    }
    
    // Get current user
    const user = await getCurrentUser();
    if (!user) {
      return { 
        success: false, 
        error: "You must be logged in to purchase credits" 
      };
    }
    
    console.log(`Attempting to purchase ${amount} credits for user ${user.id} with package ${packageType}`);
    
    // Calculate cost based on package type
    const pricePerCredit = CREDIT_PACKAGES[packageType as keyof typeof CREDIT_PACKAGES]?.pricePerCredit || 10.00;
    
    // Create a timestamp to help ensure unique sessions
    const timestamp = new Date().getTime();
    
    // Call the Stripe checkout edge function
    const { data, error } = await supabase.functions.invoke('stripe-checkout', {
      body: { 
        amount,
        packageType, 
        pricePerCredit,
        userId: user.id,
        timestamp,
        email: user.email // Add email if available for pre-filling checkout
      }
    });
    
    if (error) {
      console.error("Error invoking stripe-checkout function:", error);
      return { 
        success: false, 
        error: "Failed to start checkout process" 
      };
    }
    
    if (!data || !data.url) {
      console.error("Invalid response from stripe-checkout:", data);
      return { 
        success: false, 
        error: "Received invalid checkout URL" 
      };
    }
    
    console.log("Redirecting to Stripe checkout:", data.url);
    console.log("Transaction ID created:", data.transactionId);
    
    // Store the transaction ID for later reference and debugging
    if (data.transactionId) {
      localStorage.setItem('pendingTransactionId', data.transactionId);
      
      // Also store the timestamp for debugging
      localStorage.setItem('pendingTransactionCreated', new Date().toISOString());
      localStorage.setItem('pendingTransactionAmount', amount.toString());
    }
    
    // Redirect to Stripe Checkout
    window.location.href = data.url;
    
    return { 
      success: true 
    };
  } catch (error) {
    console.error("Error in purchaseCredits:", error);
    return { 
      success: false, 
      error: error instanceof Error ? error.message : "Failed to process payment" 
    };
  }
};
