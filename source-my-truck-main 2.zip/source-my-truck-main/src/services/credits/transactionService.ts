
import { supabase } from "@/integrations/supabase/client";
import { invalidateCreditsCache } from "./creditsBalanceService";

// Force update the credits by invalidating the cache and fetching fresh data
export const forceUpdateCredits = async (creditAmount?: number): Promise<{ credits: number | null; error: string | null; success?: boolean; newBalance?: number }> => {
  try {
    // Invalidate the credits cache
    invalidateCreditsCache();
    
    // Get the current user
    const { data: userData } = await supabase.auth.getUser();
    
    if (!userData || !userData.user) {
      return { credits: null, error: "User not authenticated", success: false };
    }
    
    // If a credit amount was provided, add credits to the user's account
    if (creditAmount && creditAmount > 0) {
      try {
        const { error: updateError } = await supabase.rpc('add_credits', {
          user_id: userData.user.id,
          credit_amount: creditAmount
        });
        
        if (updateError) {
          console.error("Error adding credits:", updateError);
          return { credits: null, error: updateError.message, success: false };
        }
        
        // Also create a transaction record for this credit addition if it was successful
        try {
          const { error: transactionError } = await supabase
            .from('credits_transactions')
            .insert({
              user_id: userData.user.id,
              amount: creditAmount,
              cost_pence: creditAmount * 1000, // £10.00 per credit
              status: 'completed',
              payment_intent_id: `manual_${Date.now()}`
            });
            
          if (transactionError) {
            console.error("Could not create transaction record:", transactionError);
            // Don't fail the whole operation if just the transaction record fails
          }
        } catch (txError) {
          console.error("Error creating transaction record:", txError);
        }
      } catch (error) {
        console.error("Error calling add_credits function:", error);
        return { credits: null, error: "Failed to add credits", success: false };
      }
    }
    
    // Fetch the latest credits value directly from the database
    const { data, error } = await supabase
      .from('profiles')
      .select('credits')
      .eq('id', userData.user.id)
      .single();
      
    if (error) {
      console.error("Error fetching credits:", error);
      return { credits: null, error: error.message, success: false };
    }
    
    // Ensure credits is at least 0 (never negative)
    const credits = Math.max(0, data.credits || 0);
    
    // Reduce logging
    if (process.env.NODE_ENV === 'development') {
      console.log(`Credits updated for user ${userData.user.id.substring(0, 8)}: ${credits}`);
    }
    
    // Return the latest credits value
    return { 
      credits, 
      error: null, 
      success: true,
      newBalance: credits 
    };
  } catch (error) {
    console.error("Unexpected error in forceUpdateCredits:", error);
    return { credits: null, error: "An unexpected error occurred", success: false };
  }
};

// Add test credits to a user account (admin function for testing purposes)
export const addTestCredits = async (userId: string, creditAmount: number): Promise<{ success: boolean; error: string | null }> => {
  try {
    // This should only be used by admins or for testing
    const { error } = await supabase.rpc('add_credits', {
      user_id: userId,
      credit_amount: creditAmount
    });
    
    if (error) {
      console.error("Error adding test credits:", error);
      return { success: false, error: error.message };
    }
    
    // Create a transaction record for this credit addition
    try {
      const { error: transactionError } = await supabase
        .from('credits_transactions')
        .insert({
          user_id: userId,
          amount: creditAmount,
          cost_pence: creditAmount * 1000, // £10.00 per credit
          status: 'completed',
          payment_intent_id: `test_${Date.now()}`
        });
        
      if (transactionError) {
        console.error("Could not create test transaction record:", transactionError);
      }
    } catch (txError) {
      console.error("Error creating test transaction record:", txError);
    }
    
    return { success: true, error: null };
  } catch (error) {
    console.error("Unexpected error in addTestCredits:", error);
    return { success: false, error: "An unexpected error occurred" };
  }
};

// Get transaction history for the current user
export const getTransactionHistory = async () => {
  try {
    console.log("Fetching transaction history...");
    const { data: userData } = await supabase.auth.getUser();
    
    if (!userData || !userData.user) {
      console.error("User not authenticated when fetching transactions");
      return { transactions: [], error: "User not authenticated" };
    }
    
    // Try to fetch from credits_transactions table with no filtering by status
    const { data: creditTransactions, error: creditError } = await supabase
      .from('credits_transactions')
      .select('*')
      .eq('user_id', userData.user.id)
      .order('created_at', { ascending: false });
    
    if (creditError) {
      console.error("Error fetching credit transactions:", creditError);
    }
      
    // Try to fetch from transactions table
    const { data: legacyTransactions, error: legacyError } = await supabase
      .from('transactions')
      .select('*')
      .eq('user_id', userData.user.id)
      .order('created_at', { ascending: false });
    
    if (legacyError) {
      console.error("Error fetching legacy transactions:", legacyError);
    }
    
    // Log transaction counts
    console.log(`Found ${creditTransactions?.length || 0} credit transactions and ${legacyTransactions?.length || 0} legacy transactions`);
    
    // Combine both transaction sources, preferring credits_transactions if they exist
    let allTransactions = [];
    
    if (creditTransactions && creditTransactions.length > 0) {
      console.log("Credit transactions found:", creditTransactions.length);
      // Log the status of each transaction
      creditTransactions.forEach(tx => {
        console.log(`Credit Transaction ${tx.id.substring(0, 8)}: status=${tx.status}`);
      });
      allTransactions = [...creditTransactions];
    }
    
    if (legacyTransactions && legacyTransactions.length > 0) {
      console.log("Legacy transactions found:", legacyTransactions.length);
      
      // Avoid duplicates by checking payment_intent_id (if it exists in both tables)
      const existingPaymentIds = new Set(
        allTransactions
          .filter(tx => tx.payment_intent_id)
          .map(tx => tx.payment_intent_id)
      );
      
      const uniqueLegacyTransactions = legacyTransactions.filter(
        tx => !tx.payment_intent_id || !existingPaymentIds.has(tx.payment_intent_id)
      );
      
      console.log(`Adding ${uniqueLegacyTransactions.length} unique legacy transactions`);
      allTransactions = [...allTransactions, ...uniqueLegacyTransactions];
    }
    
    // Sort all transactions by date (newest first)
    allTransactions.sort((a, b) => 
      new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
    );
    
    console.log(`Returning ${allTransactions.length} total transactions`);
    
    // Return all transactions, regardless of status, and let the UI filter them
    return { transactions: allTransactions || [], error: null };
  } catch (error) {
    console.error("Unexpected error in getTransactionHistory:", error);
    return { transactions: [], error: "An unexpected error occurred" };
  }
};

export const checkTransactionStatus = async (paymentIntentId: string) => {
  try {
    if (!paymentIntentId) {
      return { success: false, error: "No payment intent ID provided" };
    }
    
    const { data: userData } = await supabase.auth.getUser();
    
    if (!userData || !userData.user) {
      return { success: false, error: "User not authenticated" };
    }
    
    // Check if the transaction exists and is completed
    const { data, error } = await supabase
      .from('credits_transactions')
      .select('*')
      .eq('payment_intent_id', paymentIntentId)
      .eq('user_id', userData.user.id)
      .single();
      
    if (error) {
      console.error("Error checking transaction status:", error);
      return { success: false, error: error.message, transaction: null };
    }
    
    // If transaction exists, return its status
    return { 
      success: true, 
      error: null, 
      transaction: data,
      completed: data.status === 'completed'
    };
  } catch (error) {
    console.error("Unexpected error in checkTransactionStatus:", error);
    return { success: false, error: "An unexpected error occurred", transaction: null };
  }
};
