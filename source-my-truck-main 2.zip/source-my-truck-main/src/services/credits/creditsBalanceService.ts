
import { supabase } from "@/integrations/supabase/client";
import { isTokenExpired, handleExpiredToken } from "./authService";

// Improved in-memory cache with better throttling and logging control
let creditsCache = {
  userId: null as string | null,
  credits: null as number | null,
  timestamp: 0,
  expiresIn: 300000, // 5 minutes cache (increased from 2 minutes)
  fetching: false,  // Flag to prevent duplicate requests
  loggingEnabled: false, // Flag to control logging
  lastInvalidation: 0, // Track when cache was last invalidated
  invalidationThrottle: 2000 // Prevent frequent invalidations (2 seconds)
};

// Control for enabling/disabling verbose logging
export const setCreditsLogging = (enabled: boolean) => {
  creditsCache.loggingEnabled = enabled;
};

export const getCurrentCredits = async () => {
  try {
    const { data: user, error: userError } = await supabase.auth.getUser();
    
    if (userError) {
      // If token is expired, handle it silently
      if (isTokenExpired(userError)) {
        await handleExpiredToken();
        // Don't log token expiration errors
        return { credits: 0, error: "User not authenticated" };
      }
      
      // Don't log auth session missing errors when signing out as they're expected
      if (!userError.message.includes("Auth session missing")) {
        console.error("Error getting user for credits:", userError);
      }
      return { credits: 0, error: "User not authenticated" };
    }
    
    if (!user || !user.user) {
      // Don't log an error message during normal logout flow
      return { credits: 0, error: "User not authenticated" };
    }
    
    // Check if we have a valid cached value
    const now = Date.now();
    if (
      creditsCache.userId === user.user.id && 
      creditsCache.credits !== null && 
      now - creditsCache.timestamp < creditsCache.expiresIn
    ) {
      // Use cached value - no logging
      return { credits: creditsCache.credits, error: null };
    }
    
    // Return cached value if a fetch is already in progress
    if (creditsCache.userId === user.user.id && creditsCache.fetching) {
      return { credits: creditsCache.credits || 0, error: null };
    }
    
    // Set fetching flag to prevent duplicate calls
    creditsCache.fetching = true;
    
    try {
      // No logging when fetching credits
      
      const { data, error } = await supabase
        .from('profiles')
        .select('credits')
        .eq('id', user.user.id)
        .maybeSingle();
        
      // Reset fetching flag
      creditsCache.fetching = false;
      
      if (error) {
        // Check if error is due to expired token
        if (error.message.includes('JWT expired')) {
          await handleExpiredToken();
          return { credits: 0, error: "Session expired" };
        }
        
        console.error("Error fetching credits:", error);
        return { credits: 0, error: error.message };
      }
      
      if (!data) {
        // If no profile is found, default to 1 credit for new users
        // This aligns with the handle_new_user() DB function that gives 1 free credit on signup
        const defaultCredits = 1;
        
        // Update cache with default value
        creditsCache = {
          ...creditsCache,
          userId: user.user.id,
          credits: defaultCredits,
          timestamp: now,
          fetching: false
        };
        
        return { credits: defaultCredits, error: null };
      }
      
      // Ensure credits is at least 0 (never negative)
      const credits = Math.max(0, data.credits || 0);
      
      // Update cache
      creditsCache = {
        ...creditsCache,
        userId: user.user.id,
        credits: credits,
        timestamp: now,
        fetching: false
      };
      
      return { credits, error: null };
    } catch (error) {
      // Reset fetching flag if there's an error
      creditsCache.fetching = false;
      throw error;
    }
  } catch (error) {
    console.error("Unexpected error in getCurrentCredits:", error);
    return { credits: 0, error: "An unexpected error occurred" };
  }
};

// Add a function to invalidate the cache when needed (e.g., after creating a listing or purchasing credits)
export const invalidateCreditsCache = () => {
  const now = Date.now();
  
  // Apply throttling to cache invalidations to prevent rapid successive calls
  if (now - creditsCache.lastInvalidation < creditsCache.invalidationThrottle) {
    return; // Skip this invalidation as it's too soon after the last one
  }
  
  // No logging on cache invalidation
  
  creditsCache = {
    ...creditsCache,
    userId: null,
    credits: null,
    timestamp: 0,
    fetching: false,
    lastInvalidation: now
  };
};

// Force update credits - used for testing and in situations where we need guaranteed fresh data
export const forceUpdateCredits = async (creditAmount: number) => {
  try {
    const { data: user, error: userError } = await supabase.auth.getUser();
    
    if (userError) {
      if (isTokenExpired(userError)) {
        await handleExpiredToken();
      }
      return { success: false, error: "Not authenticated", newBalance: null };
    }
    
    if (!user || !user.user) {
      return { success: false, error: "Not authenticated", newBalance: null };
    }
    
    // This function directly calls the 'add_credits' RPC function in Supabase
    const { data, error } = await supabase.rpc('add_credits', {
      user_id: user.user.id,
      credit_amount: creditAmount
    });
    
    if (error) {
      // Check if error is due to expired token
      if (error.message.includes('JWT expired')) {
        await handleExpiredToken();
        return { success: false, error: "Session expired", newBalance: null };
      }
      
      console.error("Error updating credits:", error);
      return { success: false, error: error.message, newBalance: null };
    }
    
    // Invalidate cache after successful update
    invalidateCreditsCache();
    
    // Get updated balance
    const { credits: newBalance } = await getCurrentCredits();
    
    return { success: true, error: null, newBalance };
  } catch (error) {
    console.error("Error in forceUpdateCredits:", error);
    return { success: false, error: "An unexpected error occurred", newBalance: null };
  }
};
