
import { Transaction } from "@/components/profile/types";
import { supabase } from "@/integrations/supabase/client";
import { jsPDF } from "jspdf";
// Import the autoTable plugin properly
import autoTable from "jspdf-autotable";

export const generateInvoice = async (transaction: Transaction): Promise<boolean> => {
  try {
    // Get user information for the invoice
    const { data: userData } = await supabase.auth.getUser();
    if (!userData || !userData.user) {
      console.error("No user found when generating invoice");
      return false;
    }

    // Get profile for company name
    const { data: profile } = await supabase
      .from('profiles')
      .select('company_name')
      .eq('id', userData.user.id)
      .single();

    const companyName = profile?.company_name || "Customer";
    
    // Create a new PDF document
    const doc = new jsPDF();
    
    // Set document properties
    const invoiceNumber = transaction.id.substring(0, 8);
    const invoiceDate = new Date(transaction.created_at).toLocaleDateString('en-GB');
    const creditAmount = transaction.amount;
    
    // Handle free credits by setting a default price of £1 per credit
    const costPence = transaction.cost_pence === 0 ? creditAmount * 100 : transaction.cost_pence;
    const total = (costPence / 100).toFixed(2);
    
    // Add header
    doc.setFontSize(22);
    doc.setTextColor(41, 64, 195); // Brand blue
    doc.text("Source my Truck", 20, 25);

    // Invoice title
    doc.setFontSize(28);
    doc.setTextColor(40, 40, 40);
    doc.text("INVOICE", 20, 40);
    
    // Add invoice details
    doc.setFontSize(10);
    doc.setTextColor(80, 80, 80);
    
    // Left side - Customer info
    doc.text("BILL TO:", 20, 60);
    doc.setFont("helvetica", "bold");
    doc.text(companyName, 20, 65);
    doc.setFont("helvetica", "normal");
    doc.text(userData.user.email || "", 20, 70);
    
    // Right side - Invoice info
    doc.text("Invoice Number:", 140, 60);
    doc.text(`SMT-${invoiceNumber}`, 170, 60);
    
    doc.text("Date:", 140, 65);
    doc.text(invoiceDate, 170, 65);
    
    // Add line below header
    doc.setDrawColor(200, 200, 200);
    doc.line(20, 75, 190, 75);
    
    // Add item table
    const tableColumn = ["Description", "Quantity", "Price", "Amount"];
    const tableRows: any[][] = [
      [
        `Credit purchase (${creditAmount} credit${creditAmount !== 1 ? 's' : ''})`,
        creditAmount,
        `£${(costPence / 100 / creditAmount).toFixed(2)}`,
        `£${(costPence / 100).toFixed(2)}`
      ]
    ];

    // Use autoTable plugin correctly
    autoTable(doc, {
      head: [tableColumn],
      body: tableRows,
      startY: 85,
      theme: 'grid',
      styles: { fontSize: 10, cellPadding: 5 },
      headStyles: { 
        fillColor: [41, 64, 195], // Brand blue
        textColor: [255, 255, 255] 
      },
      columnStyles: {
        0: { cellWidth: 90 },
        1: { cellWidth: 30, halign: 'center' },
        2: { cellWidth: 30, halign: 'right' },
        3: { cellWidth: 30, halign: 'right' }
      }
    });
    
    // Get the final Y position after the table
    const finalY = (doc as any).lastAutoTable.finalY || 120;
    
    doc.text("Subtotal:", 140, finalY + 10);
    doc.text(`£${total}`, 180, finalY + 10);
    
    doc.text("VAT (20%):", 140, finalY + 15);
    doc.text("£0.00", 180, finalY + 15);
    
    doc.setFont("helvetica", "bold");
    doc.text("TOTAL:", 140, finalY + 25);
    doc.text(`£${total}`, 180, finalY + 25);
    doc.setFont("helvetica", "normal");
    
    // Add footer
    doc.setFontSize(8);
    doc.setTextColor(120, 120, 120);
    doc.text("Source my Truck • www.sourcemytruck.co.uk", 20, 270);
    doc.text("Thank you for your business!", 20, 275);
    
    // Save the PDF
    doc.save(`Invoice-SMT-${invoiceNumber}.pdf`);
    
    return true;
  } catch (error) {
    console.error("Error generating invoice:", error);
    return false;
  }
};
