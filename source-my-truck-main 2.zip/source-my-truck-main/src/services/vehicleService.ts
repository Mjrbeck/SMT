
import { supabase } from "@/integrations/supabase/client";
import { 
  deleteVehicleById, 
  updateVehicleStatus, 
  reactivateVehicle as reactivateVehicleListing,
  saveVehicleListing
} from "./vehicles/vehicleManagementService";

import {
  getVehicleById,
  getSimilarVehicles,
  getFeaturedVehicles,
  getAllVehicles,
  getCurrentUserVehicles
} from "./vehicles/vehicleQueryService";

import {
  checkVehicleExpiration
} from "./vehicles/vehicleExpirationService";

import {
  recordVehicleView,
  getVehicleViewCount,
  getUserVehicleViews,
  getViewStatistics
} from "./vehicles/vehicleViewsService";

// SEO and sitemap related functions
export const submitSitemapToSearchEngines = async (sitemapUrl: string): Promise<{success: boolean, message: string}> => {
  try {
    // This would be an actual API call to search engines in production
    // For now, we'll just simulate it
    console.log(`Submitting sitemap to Google Search Console: ${sitemapUrl}`);
    console.log(`Submitting sitemap to Bing Webmaster Tools: ${sitemapUrl}`);
    
    // In production, you would use the Google Indexing API and Bing Webmaster API
    // Example Google API call using fetch:
    // await fetch('https://www.google.com/ping?sitemap=' + encodeURIComponent(sitemapUrl));
    
    // Example Bing API call using fetch:
    // await fetch('https://www.bing.com/ping?sitemap=' + encodeURIComponent(sitemapUrl));
    
    // Simulate different search engines
    await new Promise(resolve => setTimeout(resolve, 500)); // Simulate API delay
    
    // Check if the sitemap is valid before submitting
    try {
      const response = await fetch(sitemapUrl);
      if (!response.ok) {
        throw new Error(`HTTP error: ${response.status}`);
      }
      
      const contentType = response.headers.get('content-type');
      if (!contentType || !contentType.includes('application/xml') && !contentType.includes('text/xml')) {
        throw new Error(`Invalid content type: ${contentType}`);
      }
      
      // Basic validation succeeded
    } catch (error) {
      return {
        success: false,
        message: `Sitemap validation failed: ${error instanceof Error ? error.message : String(error)}`
      };
    }
    
    return {
      success: true,
      message: `Sitemap ${sitemapUrl} successfully submitted to search engines`
    };
  } catch (error) {
    console.error('Error submitting sitemap to search engines:', error);
    return {
      success: false,
      message: `Failed to submit sitemap: ${error instanceof Error ? error.message : String(error)}`
    };
  }
};

// Get sitemap URLs for different content types
export const getSitemapUrls = () => {
  const baseUrl = typeof window !== 'undefined' ? window.location.origin : 'https://source-my-truck.vercel.app';
  return {
    main: `${baseUrl}/sitemap.xml`,
    static: `${baseUrl}/sitemap-static.xml`,
    vehicles: `${baseUrl}/sitemap-vehicles.xml`,
    sellers: `${baseUrl}/sitemap-sellers.xml`,
    blog: `${baseUrl}/sitemap-blog.xml`
  };
};

// Generate sitemap for a specific vehicle
export const generateVehicleSitemapEntry = (vehicleId: string, lastMod: Date, priority: number = 0.8) => {
  const baseUrl = typeof window !== 'undefined' ? window.location.origin : 'https://source-my-truck.vercel.app';
  return {
    loc: `${baseUrl}/vehicle/${vehicleId}`,
    lastmod: lastMod.toISOString().split('T')[0],
    priority,
    changefreq: 'daily' as const
  };
};

// Generate sitemap for a specific seller
export const generateSellerSitemapEntry = (sellerId: string, customSlug: string | null, lastMod: Date, priority: number = 0.7) => {
  const baseUrl = typeof window !== 'undefined' ? window.location.origin : 'https://source-my-truck.vercel.app';
  const path = customSlug ? `seller/${customSlug}` : `seller/${sellerId}`;
  return {
    loc: `${baseUrl}/${path}`,
    lastmod: lastMod.toISOString().split('T')[0],
    priority,
    changefreq: 'weekly' as const
  };
};

// Export everything from vehicle management service except reactivateVehicle (renamed)
export {
  deleteVehicleById,
  updateVehicleStatus,
  saveVehicleListing
};

// Export renamed function to avoid conflict
export const reactivateVehicle = reactivateVehicleListing;

// Export vehicle query service functions
export {
  getVehicleById,
  getSimilarVehicles,
  getFeaturedVehicles,
  getAllVehicles,
  getCurrentUserVehicles
};

// Export vehicle expiration service functions
export {
  checkVehicleExpiration
};

// Export vehicle views service functions
export {
  recordVehicleView,
  getVehicleViewCount,
  getUserVehicleViews,
  getViewStatistics
};
