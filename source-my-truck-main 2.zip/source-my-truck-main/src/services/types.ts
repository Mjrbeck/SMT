// Types for the vehicle lookup data coming from the API
export interface VehicleLookupData {
  make: string;
  model: string;
  year: string | number;
  color?: string;
  fuelType?: string;
  transmission?: string;
  engineSize?: string;
  bodyType?: string;
  axleConfiguration?: string;
  registration?: string;
  mileage?: string | number;
  weight?: string | number;
  
  // New fields added recently
  cabType?: string;
  driverPosition?: string;
  enginePower?: string;
  emissionsClass?: string;
  numberOfSeats?: string | number;
  grossVehicleWeight?: string | number;
  volume?: string;
  internalLength?: string | number;
  internalWidth?: string | number;
  internalHeight?: string | number;
  externalLength?: string | number;
  externalWidth?: string | number;
  externalHeight?: string | number;
  isNew?: boolean;
  interiorCondition?: string;
  exteriorCondition?: string;
}

// Types for the vehicle service
export interface Vehicle {
  id: string;
  title: string;
  make: string;
  model: string;
  year: number;
  price: number;
  mileage: number;
  fuelType: string;
  transmission: string;
  bodyType: string;
  engineSize: string;
  registration?: string;
  description: string;
  features: string[];
  location?: string;
  status: string;
  images: VehicleImage[];
  isPOA: boolean;
  user_id: string;
  created_at: string;
  updated_at: string;
  
  // Additional fields
  cabType?: string;
  driverPosition?: string;
  enginePower?: string;
  emissionsClass?: string;
  numberOfSeats?: number;
  grossVehicleWeight?: number;
  volume?: string;
  internalLength?: number;
  internalWidth?: number;
  internalHeight?: number;
  externalLength?: number;
  externalWidth?: number;
  externalHeight?: number;
  isNew?: boolean;
  listingTier?: string;
  videoUrl?: string;
  youtubeUrl?: string; // Add this new property
  axleConfiguration?: string;
  color?: string;
  interiorCondition?: string;
  exteriorCondition?: string;
}

export interface VehicleImage {
  id: string;
  url: string;
  isMain: boolean;
  order: number;
}

// Interface representing vehicle data as it comes from the database
export interface VehicleWithImages {
  id: string;
  title: string;
  make: string;
  model: string;
  year: number;
  price: number;
  mileage: number;
  engine_size: string;
  fuel_type: string;
  transmission: string;
  body_type?: string;
  axle_configuration?: string;
  weight?: string | number;
  description?: string;
  features?: string[];
  location?: string;
  status?: string;
  is_poa?: boolean;
  user_id: string;
  created_at: string;
  updated_at: string;
  expires_at?: string;
  registration?: string;
  vehicle_images: Array<{
    id: string;
    image_url?: string;
    url?: string;
    is_main: boolean;
    order?: number;
  }>;
  
  // Additional fields with database column naming convention
  interior_condition?: string;
  exterior_condition?: string;
  cab_type?: string;
  driver_position?: string;
  engine_power?: string;
  emissions_class?: string;
  color?: string;
  number_of_seats?: number | string;
  gross_vehicle_weight?: number | string;
  volume?: string;
  internal_length?: number | string;
  internal_width?: number | string;
  internal_height?: number | string;
  external_length?: number | string;
  external_width?: number | string;
  external_height?: number | string;
  is_new?: boolean;
  listing_tier?: string; 
  video_url?: string;
  youtube_url?: string; // Add this new property with database naming convention
  [key: string]: any; // Add an index signature to allow for additional properties
}

export interface VehicleFilters {
  make?: string;
  model?: string;
  bodyType?: string;
  minPrice?: number;
  maxPrice?: number;
  minYear?: number;
  maxYear?: number;
  fuelType?: string;
  minMileage?: number;
  maxMileage?: number;
  transmission?: string;
  searchTerm?: string;
}
