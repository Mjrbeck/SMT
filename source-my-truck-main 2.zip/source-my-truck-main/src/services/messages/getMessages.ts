import { supabase } from "@/integrations/supabase/client";
import { Message } from "./types";
import { markMessageAsRead } from "./messageActions";

/**
 * Get all received messages for the current user
 */
export const getUserMessages = async (): Promise<{ messages: Message[]; error?: string }> => {
  try {
    const { data: userData, error: userError } = await supabase.auth.getUser();
    
    if (userError || !userData.user) {
      console.error("Auth error:", userError);
      return { messages: [], error: "Authentication required" };
    }
    
    // Only get received messages
    const { data, error } = await supabase
      .from("messages")
      .select("*")
      .eq("recipient_id", userData.user.id)
      .order("order", { ascending: true })
      .order("created_at", { ascending: false });

    if (error) {
      console.error("Error getting messages:", error);
      return { messages: [], error: error.message };
    }

    return { messages: data as Message[] };
  } catch (error) {
    console.error("Error in getUserMessages:", error);
    return { messages: [], error: "Failed to fetch messages" };
  }
};

/**
 * Get unread message count for the current user
 */
export const getUnreadMessageCount = async (): Promise<{ count: number; error?: string }> => {
  try {
    const { data: userData, error: userError } = await supabase.auth.getUser();
    
    if (userError || !userData.user) {
      console.error("Auth error:", userError);
      return { count: 0, error: "Authentication required" };
    }
    
    const { count, error } = await supabase
      .from("messages")
      .select("*", { count: "exact", head: true })
      .eq("recipient_id", userData.user.id)
      .eq("is_read", false);

    if (error) {
      console.error("Error getting unread count:", error);
      return { count: 0, error: error.message };
    }

    return { count: count || 0 };
  } catch (error) {
    console.error("Error in getUnreadMessageCount:", error);
    return { count: 0, error: "Failed to fetch unread count" };
  }
};

/**
 * Get a single message by ID
 */
export const getMessageById = async (messageId: string): Promise<{ message?: Message; error?: string }> => {
  try {
    const { data, error } = await supabase
      .from("messages")
      .select("*")
      .eq("id", messageId)
      .single();

    if (error) {
      console.error("Error getting message:", error);
      return { error: error.message };
    }

    // Since we can't join with profiles due to missing relationships,
    // we'll just use placeholder names
    const messageWithNames: Message = {
      ...data,
      sender_name: "Sender",
      recipient_name: "Recipient"
    };

    // If current user is recipient and message is unread, mark as read
    const { data: userData } = await supabase.auth.getUser();
    if (userData.user && data.recipient_id === userData.user.id && !data.is_read) {
      await markMessageAsRead(messageId);
    }

    return { message: messageWithNames };
  } catch (error) {
    console.error("Error in getMessageById:", error);
    return { error: "Failed to fetch message" };
  }
};
