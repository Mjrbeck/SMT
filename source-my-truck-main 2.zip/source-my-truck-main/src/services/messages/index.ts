
// Re-export types
export * from './types';

// Re-export functions from each module
export { sendMessage } from './sendMessage';
export { 
  getUserMessages, 
  getUnreadMessageCount, 
  getMessageById 
} from './getMessages';
export { 
  markMessageAsRead, 
  deleteMessage, 
  toggleMessageImportance 
} from './messageActions';
export { 
  updateMessageOrder, 
  reorderMessages 
} from './messageOrder';
