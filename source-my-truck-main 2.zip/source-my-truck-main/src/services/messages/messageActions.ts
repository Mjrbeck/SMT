
import { supabase } from "@/integrations/supabase/client";

/**
 * Mark a message as read
 */
export const markMessageAsRead = async (messageId: string): Promise<{ success: boolean; error?: string }> => {
  try {
    const { error } = await supabase
      .from("messages")
      .update({ is_read: true })
      .eq("id", messageId);

    if (error) {
      console.error("Error marking message as read:", error);
      return { success: false, error: error.message };
    }

    return { success: true };
  } catch (error) {
    console.error("Error in markMessageAsRead:", error);
    return { success: false, error: "Failed to update message" };
  }
};

/**
 * Delete a message by ID
 */
export const deleteMessage = async (messageId: string): Promise<{ success: boolean; error?: string }> => {
  try {
    const { error } = await supabase
      .from("messages")
      .delete()
      .eq("id", messageId);

    if (error) {
      console.error("Error deleting message:", error);
      return { success: false, error: error.message };
    }

    return { success: true };
  } catch (error) {
    console.error("Error in deleteMessage:", error);
    return { success: false, error: "Failed to delete message" };
  }
};

/**
 * Toggle message importance
 */
export const toggleMessageImportance = async (messageId: string, isImportant: boolean): Promise<{ success: boolean; error?: string }> => {
  try {
    const { error } = await supabase
      .from("messages")
      .update({ is_important: isImportant })
      .eq("id", messageId);

    if (error) {
      console.error("Error updating message importance:", error);
      return { success: false, error: error.message };
    }

    return { success: true };
  } catch (error) {
    console.error("Error in toggleMessageImportance:", error);
    return { success: false, error: "Failed to update message" };
  }
};
