
import { supabase } from "@/integrations/supabase/client";
import { MessageFormData } from "./types";

/**
 * Send a new message to a seller
 */
export const sendMessage = async (messageData: MessageFormData): Promise<{ success: boolean; error?: string }> => {
  try {
    // Validate recipient existence
    const { data: recipientData, error: recipientError } = await supabase
      .from("profiles")
      .select("id")
      .eq("id", messageData.recipient_id)
      .maybeSingle();
      
    if (recipientError || !recipientData) {
      console.error("Recipient validation error:", recipientError);
      return { success: false, error: "Recipient not found" };
    }
    
    // Get current user if authenticated
    const { data: userData } = await supabase.auth.getUser();
    
    // Message data to insert
    const messageToInsert = {
      sender_id: userData?.user?.id || null, // Use null for anonymous users
      recipient_id: messageData.recipient_id,
      subject: messageData.subject,
      content: messageData.content,
      vehicle_id: messageData.vehicle_id,
      is_read: false,
      // For anonymous users, add their info as extra fields
      anonymous_sender_name: userData?.user ? null : messageData.sender_name,
      anonymous_sender_email: userData?.user ? null : messageData.sender_email,
      anonymous_sender_phone: userData?.user ? null : messageData.sender_phone
    };
    
    console.log("Sending message with data:", messageToInsert);
    
    // Send message
    const { data, error } = await supabase
      .from("messages")
      .insert(messageToInsert)
      .select();

    if (error) {
      console.error("Error sending message:", error);
      return { success: false, error: error.message };
    }

    console.log("Message sent successfully:", data);
    return { success: true };
  } catch (error) {
    console.error("Error in sendMessage:", error);
    return { success: false, error: "Failed to send message" };
  }
};
