
import { supabase } from "@/integrations/supabase/client";

/**
 * Update message order
 */
export const updateMessageOrder = async (messageId: string, newOrder: number): Promise<{ success: boolean; error?: string }> => {
  try {
    const { error } = await supabase
      .from("messages")
      .update({ order: newOrder })
      .eq("id", messageId);

    if (error) {
      console.error("Error updating message order:", error);
      return { success: false, error: error.message };
    }

    return { success: true };
  } catch (error) {
    console.error("Error in updateMessageOrder:", error);
    return { success: false, error: "Failed to update message order" };
  }
};

/**
 * Reorder messages by updating their order values
 */
export const reorderMessages = async (messageIds: string[]): Promise<{ success: boolean; error?: string }> => {
  try {
    // Create an array of updates to be performed in a transaction
    const updates = messageIds.map((id, index) => {
      return supabase
        .from("messages")
        .update({ order: index })
        .eq("id", id);
    });
    
    // Execute all updates
    for (const updateOperation of updates) {
      const { error } = await updateOperation;
      if (error) {
        console.error("Error in batch reordering:", error);
        return { success: false, error: error.message };
      }
    }

    return { success: true };
  } catch (error) {
    console.error("Error in reorderMessages:", error);
    return { success: false, error: "Failed to reorder messages" };
  }
};
