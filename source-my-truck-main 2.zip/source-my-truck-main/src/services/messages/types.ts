
import { Tables } from "@/integrations/supabase/types";

export interface Message {
  id: string;
  sender_id: string | null;
  recipient_id: string;
  subject: string;
  content: string;
  vehicle_id?: string;
  is_read: boolean;
  created_at: string;
  updated_at: string;
  sender_name?: string;
  recipient_name?: string;
  is_important?: boolean;
  order?: number;
  anonymous_sender_name?: string | null;
  anonymous_sender_email?: string | null;
  anonymous_sender_phone?: string | null;
}

export interface MessageFormData {
  recipient_id: string;
  subject: string;
  content: string;
  vehicle_id?: string;
  sender_name?: string;
  sender_email?: string;
  sender_phone?: string;
}

export interface ContactFormData {
  name: string;
  email: string;
  phone: string;
  subject: string;
  message: string;
}
