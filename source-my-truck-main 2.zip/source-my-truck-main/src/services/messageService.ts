
// This file is kept for backward compatibility
// All functionality has been moved to the messages directory
// New code should import from @/services/messages instead

export * from './messages';
