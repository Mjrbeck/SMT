import { supabase } from "@/integrations/supabase/client";

export interface SellerTrustData {
  isTrusted: boolean;
  depotVerified: boolean;
  hasMultipleListings: boolean;
}

export const getSellerTrustData = async (sellerId: string): Promise<SellerTrustData> => {
  try {
    // Get seller's trust status from profiles
    const { data: profile } = await supabase
      .from('profiles')
      .select('is_trusted, depot_verified')
      .eq('id', sellerId)
      .single();

    // Count active vehicles for this seller
    const { count: vehicleCount } = await supabase
      .from('vehicles')
      .select('*', { count: 'exact', head: true })
      .eq('user_id', sellerId)
      .eq('status', 'active');

    return {
      isTrusted: profile?.is_trusted || false,
      depotVerified: profile?.depot_verified || false,
      hasMultipleListings: (vehicleCount || 0) > 5
    };
  } catch (error) {
    console.error('Error fetching seller trust data:', error);
    return {
      isTrusted: false,
      depotVerified: false,
      hasMultipleListings: false
    };
  }
};

export const getBulkSellerTrustData = async (sellerIds: string[]): Promise<Record<string, SellerTrustData>> => {
  try {
    if (sellerIds.length === 0) return {};

    // Get all seller profiles
    const { data: profiles } = await supabase
      .from('profiles')
      .select('id, is_trusted, depot_verified')
      .in('id', sellerIds);

    // Get vehicle counts for all sellers
    const { data: vehicleCounts } = await supabase
      .from('vehicles')
      .select('user_id')
      .in('user_id', sellerIds)
      .eq('status', 'active');

    // Count vehicles per seller
    const vehicleCountsByUser = vehicleCounts?.reduce((acc, vehicle) => {
      acc[vehicle.user_id] = (acc[vehicle.user_id] || 0) + 1;
      return acc;
    }, {} as Record<string, number>) || {};

    // Build result object
    const result: Record<string, SellerTrustData> = {};
    
    sellerIds.forEach(sellerId => {
      const profile = profiles?.find(p => p.id === sellerId);
      const vehicleCount = vehicleCountsByUser[sellerId] || 0;
      
      result[sellerId] = {
        isTrusted: profile?.is_trusted || false,
        depotVerified: profile?.depot_verified || false,
        hasMultipleListings: vehicleCount > 5
      };
    });

    return result;
  } catch (error) {
    console.error('Error fetching bulk seller trust data:', error);
    return {};
  }
};