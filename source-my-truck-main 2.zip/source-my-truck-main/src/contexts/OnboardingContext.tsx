
import { createContext, useContext, ReactNode, useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";

export type OnboardingStep = "profile" | "shop" | "listing" | "branding";

export interface OnboardingTask {
  id: OnboardingStep;
  title: string;
  description: string;
  completed: boolean;
  icon: string;
}

interface OnboardingContextType {
  tasks: OnboardingTask[];
  currentStep: OnboardingStep | null;
  isOnboardingComplete: boolean;
  isOnboardingVisible: boolean;
  markTaskComplete: (taskId: OnboardingStep) => void;
  setCurrentStep: (step: OnboardingStep | null) => void;
  dismissOnboarding: () => void;
  resetOnboarding: () => void;
  refreshTaskStatus: () => Promise<void>;
}

const OnboardingContext = createContext<OnboardingContextType | undefined>(undefined);

export const useOnboarding = () => {
  const context = useContext(OnboardingContext);
  if (context === undefined) {
    throw new Error("useOnboarding must be used within an OnboardingProvider");
  }
  return context;
};

export const OnboardingProvider = ({ children }: { children: ReactNode }) => {
  const [tasks, setTasks] = useState<OnboardingTask[]>([
    {
      id: "profile",
      title: "Complete your profile",
      description: "Add your company details and logo",
      completed: false,
      icon: "user"
    },
    {
      id: "shop",
      title: "Set up your seller shop",
      description: "Customize your public seller page",
      completed: false,
      icon: "store"
    },
    {
      id: "listing",
      title: "Create your first listing",
      description: "Add your first vehicle to your inventory",
      completed: false,
      icon: "truck"
    },
    {
      id: "branding",
      title: "Download brand assets",
      description: "Get logos and embed codes to promote your SourceMyTruck presence",
      completed: false,
      icon: "share2"
    }
  ]);
  
  const [currentStep, setCurrentStep] = useState<OnboardingStep | null>(null);
  const [isOnboardingVisible, setIsOnboardingVisible] = useState<boolean>(true);
  const [userHasDismissed, setUserHasDismissed] = useState<boolean>(false);
  
  // Check onboarding status function
  const checkOnboardingStatus = async () => {
    try {
      const { data: userData } = await supabase.auth.getUser();
      
      if (userData?.user) {
        // Check profile completion
        const { data: profile } = await supabase
          .from('profiles')
          .select('company_name, company_description, logo_url')
          .eq('id', userData.user.id)
          .single();
          
        // Check seller depot setup
        const { data: depot } = await supabase
          .from('seller_depots')
          .select('shop_name, description')
          .eq('id', userData.user.id)
          .maybeSingle();
          
        // Check if they have any vehicle listings
        const { data: vehicles, error: vehiclesError } = await supabase
          .from('vehicles')
          .select('id')
          .eq('user_id', userData.user.id)
          .limit(1);
          
        // Update task completion status
        const updatedTasks = [...tasks];
        
        // Task 1: Profile completion
        if (profile && profile.company_name && (profile.company_description || profile.logo_url)) {
          updatedTasks[0].completed = true;
        } else {
          updatedTasks[0].completed = false;
        }
        
        // Task 2: Seller depot setup
        if (depot && depot.shop_name) {
          updatedTasks[1].completed = true;
        } else {
          updatedTasks[1].completed = false;
        }
        
        // Task 3: First vehicle listing
        if (vehicles && vehicles.length > 0) {
          updatedTasks[2].completed = true;
        } else {
          updatedTasks[2].completed = false;
        }
        
        // Task 4: Brand assets interaction
        const brandAssetsViewed = localStorage.getItem('brandAssetsViewed');
        if (brandAssetsViewed === 'true') {
          updatedTasks[3].completed = true;
        } else {
          updatedTasks[3].completed = false;
        }
        
        setTasks(updatedTasks);
        
        // Set initial current step if not all are complete
        if (!updatedTasks.every(task => task.completed)) {
          const firstIncompleteTask = updatedTasks.find(task => !task.completed);
          if (firstIncompleteTask) {
            setCurrentStep(firstIncompleteTask.id);
          }
        } else {
          // All tasks complete
          setCurrentStep(null);
        }
      }
    } catch (error) {
      console.error("Error checking onboarding status:", error);
    }
  };
  
  // Check onboarding status on initial load
  useEffect(() => {
    checkOnboardingStatus();
  }, []);
  
  // Function to refresh task status - can be called when actions are completed
  const refreshTaskStatus = async () => {
    await checkOnboardingStatus();
  };
  
  const markTaskComplete = (taskId: OnboardingStep) => {
    setTasks(prev => 
      prev.map(task => 
        task.id === taskId ? { ...task, completed: true } : task
      )
    );
    
    // Move to next incomplete task if there is one
    const updatedTasks = tasks.map(task => 
      task.id === taskId ? { ...task, completed: true } : task
    );
    
    const nextIncompleteTask = updatedTasks.find(task => !task.completed);
    if (nextIncompleteTask) {
      setCurrentStep(nextIncompleteTask.id);
    } else {
      // All tasks complete
      setCurrentStep(null);
    }
  };
  
  const dismissOnboarding = () => {
    setIsOnboardingVisible(false);
    setUserHasDismissed(true);
    
    // Optionally, save dismissed state to localStorage
    localStorage.setItem('onboardingDismissed', 'true');
  };
  
  const resetOnboarding = () => {
    setTasks(prev => prev.map(task => ({ ...task, completed: false })));
    setCurrentStep("profile");
    setIsOnboardingVisible(true);
    setUserHasDismissed(false);
    
    // Clear dismissed state from localStorage
    localStorage.removeItem('onboardingDismissed');
  };
  
  const isOnboardingComplete = tasks.every(task => task.completed);
  
  // Check for stored dismiss state on component mount
  useEffect(() => {
    const dismissedState = localStorage.getItem('onboardingDismissed');
    if (dismissedState === 'true') {
      setUserHasDismissed(true);
      setIsOnboardingVisible(false);
    }
  }, []);
  
  // Only hide onboarding when complete OR user has explicitly dismissed it
  useEffect(() => {
    if (isOnboardingComplete || userHasDismissed) {
      setIsOnboardingVisible(false);
    }
  }, [isOnboardingComplete, userHasDismissed]);
  
  return (
    <OnboardingContext.Provider
      value={{
        tasks,
        currentStep,
        isOnboardingComplete,
        isOnboardingVisible,
        markTaskComplete,
        setCurrentStep,
        dismissOnboarding,
        resetOnboarding,
        refreshTaskStatus
      }}
    >
      {children}
    </OnboardingContext.Provider>
  );
};
