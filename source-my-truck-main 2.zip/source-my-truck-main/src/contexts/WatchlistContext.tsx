import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { watchlistStorage } from '@/utils/watchlistStorage';
import { toast } from 'sonner';

interface WatchlistContextType {
  watchedVehicles: string[];
  watchlistCount: number;
  isWatched: (vehicleId: string) => boolean;
  addToWatchlist: (vehicleId: string, vehicleTitle?: string) => Promise<boolean>;
  removeFromWatchlist: (vehicleId: string, vehicleTitle?: string) => Promise<boolean>;
  toggleWatchlist: (vehicleId: string, vehicleTitle?: string) => Promise<boolean>;
  clearWatchlist: () => void;
  checkWatchlistLimit: () => boolean;
  showLimitPrompt: () => void;
}

const WatchlistContext = createContext<WatchlistContextType | undefined>(undefined);

const WATCHLIST_LIMIT = 8; // Limit for non-logged users

export const WatchlistProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [watchedVehicles, setWatchedVehicles] = useState<string[]>([]);
  const [watchlistCount, setWatchlistCount] = useState(0);

  // Load watchlist from localStorage on mount
  useEffect(() => {
    const loadWatchlist = () => {
      const vehicles = watchlistStorage.getWatchedVehicles();
      setWatchedVehicles(vehicles);
      setWatchlistCount(vehicles.length);
    };

    loadWatchlist();
  }, []);

  const isWatched = useCallback((vehicleId: string): boolean => {
    return watchedVehicles.includes(vehicleId);
  }, [watchedVehicles]);

  const checkWatchlistLimit = useCallback((): boolean => {
    return watchlistCount >= WATCHLIST_LIMIT;
  }, [watchlistCount]);

  const showLimitPrompt = useCallback(() => {
    toast.error(
      `You've reached the limit of ${WATCHLIST_LIMIT} watched vehicles. Create an account to watch unlimited vehicles!`,
      {
        duration: 5000,
        action: {
          label: "Sign Up",
          onClick: () => {
            window.location.href = '/register';
          }
        }
      }
    );
  }, []);

  const addToWatchlist = useCallback(async (vehicleId: string, vehicleTitle = 'Vehicle'): Promise<boolean> => {
    // Check limit for non-logged users
    if (checkWatchlistLimit()) {
      showLimitPrompt();
      return false;
    }

    const success = watchlistStorage.addToWatchlist(vehicleId);
    
    if (success) {
      const updatedVehicles = watchlistStorage.getWatchedVehicles();
      setWatchedVehicles(updatedVehicles);
      setWatchlistCount(updatedVehicles.length);
      
      toast.success(`${vehicleTitle} added to your watchlist!`, {
        duration: 3000,
        action: {
          label: "View Watchlist",
          onClick: () => {
            window.location.href = '/watchlist';
          }
        }
      });
    }
    
    return success;
  }, [checkWatchlistLimit, showLimitPrompt]);

  const removeFromWatchlist = useCallback(async (vehicleId: string, vehicleTitle = 'Vehicle'): Promise<boolean> => {
    const success = watchlistStorage.removeFromWatchlist(vehicleId);
    
    if (success) {
      const updatedVehicles = watchlistStorage.getWatchedVehicles();
      setWatchedVehicles(updatedVehicles);
      setWatchlistCount(updatedVehicles.length);
      
      toast.success(`${vehicleTitle} removed from watchlist`);
    }
    
    return success;
  }, []);

  const toggleWatchlist = useCallback(async (vehicleId: string, vehicleTitle?: string): Promise<boolean> => {
    if (isWatched(vehicleId)) {
      return await removeFromWatchlist(vehicleId, vehicleTitle);
    } else {
      return await addToWatchlist(vehicleId, vehicleTitle);
    }
  }, [isWatched, addToWatchlist, removeFromWatchlist]);

  const clearWatchlist = useCallback(() => {
    watchlistStorage.clearWatchlist();
    setWatchedVehicles([]);
    setWatchlistCount(0);
    toast.success('Watchlist cleared');
  }, []);

  const value: WatchlistContextType = {
    watchedVehicles,
    watchlistCount,
    isWatched,
    addToWatchlist,
    removeFromWatchlist,
    toggleWatchlist,
    clearWatchlist,
    checkWatchlistLimit,
    showLimitPrompt
  };

  return (
    <WatchlistContext.Provider value={value}>
      {children}
    </WatchlistContext.Provider>
  );
};

export const useWatchlist = (): WatchlistContextType => {
  const context = useContext(WatchlistContext);
  if (context === undefined) {
    throw new Error('useWatchlist must be used within a WatchlistProvider');
  }
  return context;
};