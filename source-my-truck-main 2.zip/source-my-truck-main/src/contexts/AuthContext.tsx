import React, { createContext, useContext } from 'react';
import type { Session, User } from '@supabase/supabase-js';
import { useAuthState } from '@/hooks/auth/useAuthState';
import { useAuthActions } from '@/hooks/auth/useAuthActions';

interface AuthContextType {
  // State
  session: Session | null;
  user: User | null;
  userRole: 'buyer' | 'seller' | 'administrator' | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  
  // Actions
  signUp: (email: string, password: string, companyName: string, userType?: 'buyer' | 'seller') => Promise<{ success: boolean; requiresEmailConfirmation: boolean }>;
  signIn: (email: string, password: string) => Promise<{ success: boolean }>;
  signOut: () => Promise<void>;
  sendPasswordReset: (email: string) => Promise<{ success: boolean }>;
  resendEmailConfirmation: (email: string) => Promise<{ success: boolean }>;
  updatePassword: (newPassword: string) => Promise<{ success: boolean }>;
  isActionLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { session, user, isLoading, isAuthenticated } = useAuthState();
  const {
    signUp,
    signIn,
    signOut,
    sendPasswordReset,
    resendEmailConfirmation,
    updatePassword,
    isLoading: isActionLoading
  } = useAuthActions();

  // userRole will be handled separately by useUserRole hook in components that need it

  return (
    <AuthContext.Provider
      value={{
        session,
        user,
        userRole: null, // Role will be managed separately by useUserRole hook
        isLoading,
        isAuthenticated,
        signUp,
        signIn,
        signOut,
        sendPasswordReset,
        resendEmailConfirmation,
        updatePassword,
        isActionLoading
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};