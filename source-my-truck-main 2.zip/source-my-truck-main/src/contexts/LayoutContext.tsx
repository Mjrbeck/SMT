
import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import { useIsMobile } from '@/hooks/use-mobile';

interface LayoutContextType {
  sidebarOpen: boolean;
  toggleSidebar: () => void;
  isMobileView: boolean;
  setFontSize: (size: string) => void;
  fontSize: string;
}

const LayoutContext = createContext<LayoutContextType | undefined>(undefined);

export const LayoutProvider = ({ children }: { children: ReactNode }) => {
  const isMobileDevice = useIsMobile();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [fontSize, setFontSize] = useState('base');

  // Close sidebar automatically when switching to mobile view
  useEffect(() => {
    if (isMobileDevice && sidebarOpen) {
      setSidebarOpen(false);
    }
  }, [isMobileDevice, sidebarOpen]);

  // Apply font size to the root element
  useEffect(() => {
    const root = document.documentElement;
    
    if (fontSize === 'large') {
      root.style.fontSize = isMobileDevice ? '18px' : '18px';
    } else if (fontSize === 'small') {
      root.style.fontSize = isMobileDevice ? '14px' : '14px';
    } else {
      // Default/base size
      root.style.fontSize = isMobileDevice ? '16px' : '16px';
    }
    
    return () => {
      root.style.fontSize = '';
    };
  }, [fontSize, isMobileDevice]);

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  const changeFontSize = (size: string) => {
    setFontSize(size);
    // Store preference in localStorage
    localStorage.setItem('preferred-font-size', size);
  };

  return (
    <LayoutContext.Provider 
      value={{ 
        sidebarOpen, 
        toggleSidebar, 
        isMobileView: !!isMobileDevice,
        fontSize,
        setFontSize: changeFontSize
      }}
    >
      {children}
    </LayoutContext.Provider>
  );
};

export const useLayout = () => {
  const context = useContext(LayoutContext);
  if (context === undefined) {
    throw new Error('useLayout must be used within a LayoutProvider');
  }
  return context;
};

// Utility hook for font size preference
export const useFontSizePreference = () => {
  const { fontSize, setFontSize } = useLayout();
  
  useEffect(() => {
    // Load preference from localStorage on mount
    const savedSize = localStorage.getItem('preferred-font-size');
    if (savedSize) {
      setFontSize(savedSize);
    }
  }, [setFontSize]);
  
  return { fontSize, setFontSize };
};
