
import React, { createContext, useContext, useState, useEffect, useCallback, useRef } from "react";
import { VehicleWithImages } from "@/services/types";
import { useVehicleManagement } from "@/hooks/useVehicleManagement";
import { useAuth } from "./AuthContext";
import { getCurrentCredits, setCreditsLogging, invalidateCreditsCache } from "@/services/credits";
import { getCurrentUserVehicles } from "@/services/vehicles";
import { VehicleData } from "@/components/VehicleCard";
import { convertToVehicleData } from "@/utils/vehicleMapper";
import { toast } from "sonner";

interface InventoryContextType {
  vehicles: VehicleData[];
  isLoading: boolean;
  error: string | null;
  credits: number | null;
  refetchVehicles: () => Promise<void>;
  bulkUploadInProgress: boolean;
  setBulkUploadInProgress: (value: boolean) => void;
  deleteVehicle: (id: string) => Promise<boolean>;
  expireVehicle: (id: string) => Promise<boolean>;
  reactivateVehicle: (id: string) => Promise<boolean>;
  stats?: any;
  activeTab?: string;
  setActiveTab?: (tab: string) => void;
  fetchCredits?: () => Promise<void>;
  remainingCredits?: number;
}

const InventoryContext = createContext<InventoryContextType | undefined>(undefined);

export const InventoryProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  
  const [vehicles, setVehicles] = useState<VehicleData[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  const refetchVehicles = async () => {
    setIsLoading(true);
    try {
      if (user) {
        const result = await getCurrentUserVehicles();
        if (Array.isArray(result)) {
          setVehicles(result);
          setError(null);
        } else {
          console.error("Unexpected response format from getCurrentUserVehicles:", result);
          setError("Failed to fetch vehicles");
        }
      }
    } catch (err) {
      // Only log actual errors, not auth session missing errors for unauthenticated users
      if (err instanceof Error && !err.message.includes('Auth session missing')) {
        console.error("Error fetching vehicles:", err);
        setError(err.message);
      } else {
        // Silent fail for auth session missing - this is expected for unauthenticated users
        setError(null);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const vehicleManagement = useVehicleManagement({
    onSuccess: refetchVehicles
  });
  
  const deleteVehicleImpl = vehicleManagement.deleteVehicle;
  const changeVehicleStatus = vehicleManagement.changeVehicleStatus;
  const reactivateVehicleImpl = vehicleManagement.reactivateVehicleListing;
  
  const [credits, setCredits] = useState<number | null>(null);
  const [bulkUploadInProgress, setBulkUploadInProgress] = useState(false);
  const [activeTab, setActiveTab] = useState("all");
  const [stats, setStats] = useState({ 
    all: 0, 
    active: 0, 
    draft: 0, 
    expired: 0,
    sale_in_progress: 0,
    sold: 0,
    averagePrice: 0 
  });

  const fetchingCreditsRef = useRef(false);
  const creditsRetryCount = useRef(0);
  const maxRetries = 3;
  const lastFetchTimeRef = useRef(0);
  const fetchThrottleTime = 30000; // 30 seconds between credit fetches
  const visibilityChangeListenerRef = useRef<any>(null);

  const deleteVehicle = useCallback(async (id: string): Promise<boolean> => {
    try {
      setVehicles(prev => prev.filter(v => v.id !== id));
      await deleteVehicleImpl(id);
      return true;
    } catch (error) {
      console.error("Error deleting vehicle:", error);
      await refetchVehicles();
      return false;
    }
  }, [deleteVehicleImpl, refetchVehicles]);

  const expireVehicle = useCallback(async (id: string): Promise<boolean> => {
    try {
      setVehicles(prev => prev.map(v => 
        v.id === id ? { ...v, status: 'expired' } : v
      ));
      await changeVehicleStatus(id, 'expired');
      return true;
    } catch (error) {
      console.error("Error expiring vehicle:", error);
      await refetchVehicles();
      return false;
    }
  }, [changeVehicleStatus, refetchVehicles]);

  const reactivateVehicle = useCallback(async (id: string): Promise<boolean> => {
    try {
      await reactivateVehicleImpl(id);
      return true;
    } catch (error) {
      console.error("Error reactivating vehicle:", error);
      return false;
    }
  }, [reactivateVehicleImpl]);

  const fetchCredits = useCallback(async () => {
    if (!user || fetchingCreditsRef.current) {
      return;
    }
    
    // Apply time-based throttling
    const now = Date.now();
    if (now - lastFetchTimeRef.current < fetchThrottleTime && credits !== null) {
      return; // Skip this fetch as it's too soon after the last one
    }
    
    try {
      fetchingCreditsRef.current = true;
      lastFetchTimeRef.current = now;
      
      // Only enable detailed logging in development mode but at reduced frequency
      setCreditsLogging(false);
      
      const { credits: fetchedCredits, error } = await getCurrentCredits();
      
      if (!error && fetchedCredits !== null) {
        setCredits(fetchedCredits);
        creditsRetryCount.current = 0; // Reset retry counter on success
      } else {
        console.error("Error fetching credits:", error);
        
        // Implement retry logic
        if (creditsRetryCount.current < maxRetries) {
          creditsRetryCount.current++;
          
          // Wait a bit before retrying
          setTimeout(() => {
            fetchingCreditsRef.current = false;
            fetchCredits();
          }, 1000 * creditsRetryCount.current); // Increasing backoff
        } else {
          console.error("Max retries reached for fetching credits");
          // Show a toast only if we've exhausted retries
          toast.error("Error loading credits. Please refresh the page.", {
            id: "credits-error",
            duration: 5000,
          });
        }
      }
    } catch (error) {
      console.error("Unexpected error fetching credits:", error);
    } finally {
      fetchingCreditsRef.current = false;
      setCreditsLogging(false);
    }
  }, [user, credits]);

  useEffect(() => {
    if (vehicles) {
      const nonZeroPrices = vehicles
        .filter(v => v.price > 0)
        .map(v => v.price);
      
      const averagePrice = nonZeroPrices.length > 0
        ? Math.round(nonZeroPrices.reduce((acc, price) => acc + price, 0) / nonZeroPrices.length)
        : 0;
        
      const statCounts = {
        all: vehicles.length,
        active: vehicles.filter(v => v.status === 'active').length,
        draft: vehicles.filter(v => v.status === 'draft').length,
        expired: vehicles.filter(v => v.status === 'expired' || 
                                   (v.status === 'active' && v.expires_at && new Date(v.expires_at) < new Date())).length,
        sale_in_progress: vehicles.filter(v => v.status === 'sale_in_progress').length,
        sold: vehicles.filter(v => v.status === 'sold').length,
        averagePrice
      };
      setStats(statCounts);
    }
  }, [vehicles]);

  useEffect(() => {
    if (user) {
      refetchVehicles();
    }
  }, [user]);

  useEffect(() => {
    if (user) {
      // Immediately fetch credits when user changes
      fetchCredits();
      
      // Setup regular refresh interval (much less frequent)
      const intervalId = setInterval(() => {
        // Only fetch if the page is visible to the user
        if (document.visibilityState === 'visible') {
          fetchCredits();
        }
      }, 300000); // Refresh credits every 5 minutes
      
      return () => clearInterval(intervalId);
    }
  }, [user, fetchCredits]);

  return (
    <InventoryContext.Provider value={{
      vehicles,
      isLoading,
      error,
      credits,
      refetchVehicles,
      bulkUploadInProgress,
      setBulkUploadInProgress,
      deleteVehicle,
      expireVehicle,
      reactivateVehicle,
      stats,
      activeTab,
      setActiveTab,
      fetchCredits,
      remainingCredits: credits
    }}>
      {children}
    </InventoryContext.Provider>
  );
};

export const useInventory = () => {
  const context = useContext(InventoryContext);
  if (context === undefined) {
    throw new Error("useInventory must be used within an InventoryProvider");
  }
  return context;
};
