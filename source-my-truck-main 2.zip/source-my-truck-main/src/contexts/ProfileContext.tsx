
import { createContext, useContext, ReactNode, useState } from "react";
import { ProfileData, Transaction } from "@/components/profile/types";

interface ProfileContextType {
  profile: ProfileData | null;
  isLoading: boolean;
  isError: boolean;
  transactions: Transaction[];
  fetchProfile: () => Promise<ProfileData | undefined>;
  fetchTransactionHistory: () => Promise<void>;
  setProfile: (profile: ProfileData) => void;
  handleRefreshData: () => void;
  refreshProfileAfterPayment: () => Promise<ProfileData | undefined>;
  handleTestModeRecovery?: (amount: number) => Promise<boolean>;
}

const ProfileContext = createContext<ProfileContextType>({
  profile: null,
  isLoading: true,
  isError: false,
  transactions: [],
  fetchProfile: async () => undefined,
  fetchTransactionHistory: async () => {},
  setProfile: () => {},
  handleRefreshData: () => {},
  refreshProfileAfterPayment: async () => undefined,
});

export const useProfile = () => useContext(ProfileContext);

// Remove the dependency on useProfileProvider that uses useAuth
export const ProfileProvider = ({ children, profileData }: { children: ReactNode, profileData?: any }) => {
  // Use the provided profileData or a default empty state
  const contextValue = profileData || {
    profile: null,
    isLoading: true,
    isError: false,
    transactions: [],
    fetchProfile: async () => undefined,
    fetchTransactionHistory: async () => {},
    setProfile: () => {},
    handleRefreshData: () => {},
    refreshProfileAfterPayment: async () => undefined
  };
  
  return (
    <ProfileContext.Provider value={contextValue}>
      {children}
    </ProfileContext.Provider>
  );
};
