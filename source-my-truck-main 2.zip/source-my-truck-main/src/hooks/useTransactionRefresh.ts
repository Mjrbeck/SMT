
import { useRef, useCallback } from "react";
import { usePathTracker } from "./usePathTracker";

export const useTransactionRefresh = () => {
  const isFetchingRef = useRef(false);
  const lastFetchTimeRef = useRef(0);
  const requestCountRef = useRef(0);
  const MAX_REQUESTS = 20; // Limit to avoid spamming
  const MIN_INTERVAL = 300000; // 5 minutes (300 seconds)
  const userCheckedRef = useRef(false);
  const fetchBlockedRef = useRef(false);
  
  // Use our new path tracker
  const { 
    previousPathRef,
    setPageFetched,
    hasPageFetched
  } = usePathTracker();

  const canFetch = useCallback((hasFetched: boolean, force: boolean = false): boolean => {
    // Always allow if force flag is true (manual refresh)
    if (force) {
      return true;
    }
    
    // Prevent concurrent fetches
    if (isFetchingRef.current) {
      return false;
    }
    
    // If fetching is explicitly blocked, don't fetch
    if (fetchBlockedRef.current) {
      return false;
    }
    
    // Check if user is logged in
    if (!userCheckedRef.current) {
      return false;
    }
    
    // Limit the number of requests in a session
    if (requestCountRef.current >= MAX_REQUESTS && hasFetched) {
      return false;
    }
    
    // Throttle requests
    const now = Date.now();
    const timeSinceLastFetch = now - lastFetchTimeRef.current;
    
    if (timeSinceLastFetch < MIN_INTERVAL && hasFetched && !force) {
      // Only log throttling in development, and only once per 5 minutes to avoid spamming
      if (timeSinceLastFetch > MIN_INTERVAL - 60000 && 
          process.env.NODE_ENV === 'development' && 
          Math.random() < 0.1) { // Only log ~10% of the time
        const timeAgo = Math.round(timeSinceLastFetch / 1000);
        console.log(`Throttling transaction history fetch, last fetch was ${timeAgo}s ago (min interval: ${MIN_INTERVAL/1000}s)`);
      }
      return false;
    }
    
    return true;
  }, []);

  const startFetch = useCallback(() => {
    isFetchingRef.current = true;
    lastFetchTimeRef.current = Date.now();
    requestCountRef.current += 1;
  }, []);

  const endFetch = useCallback((mountedRef: React.MutableRefObject<boolean>) => {
    if (mountedRef.current) {
      isFetchingRef.current = false;
    }
  }, []);

  const resetRequestCount = useCallback(() => {
    requestCountRef.current = 0;
  }, []);

  const setUserChecked = useCallback((checked: boolean) => {
    // Only log user checked status changes when the value actually changes
    if (userCheckedRef.current !== checked && process.env.NODE_ENV === 'development' && Math.random() < 0.1) {
      console.log(`User checked status set to: ${checked}`);
    }
    userCheckedRef.current = checked;
  }, []);

  const isUserChecked = useCallback(() => {
    return userCheckedRef.current;
  }, []);

  const blockFetching = useCallback((block: boolean) => {
    fetchBlockedRef.current = block;
  }, []);

  const scheduleAggressiveRefreshes = useCallback((
    refreshFn: () => void,
    mountedRef: React.MutableRefObject<boolean>,
    user: any
  ) => {
    // Just a single refresh after 10 minutes if needed
    const timeoutId = setTimeout(() => {
      if (mountedRef.current && user) {
        refreshFn();
      }
    }, 600000); // 10 minutes
    
    return timeoutId;
  }, []);

  return {
    isFetchingRef,
    lastFetchTimeRef,
    requestCountRef,
    userCheckedRef,
    previousPathRef,
    canFetch,
    startFetch,
    endFetch,
    resetRequestCount,
    setUserChecked,
    isUserChecked,
    blockFetching,
    scheduleAggressiveRefreshes,
    setPageFetched,
    hasPageFetched
  };
};
