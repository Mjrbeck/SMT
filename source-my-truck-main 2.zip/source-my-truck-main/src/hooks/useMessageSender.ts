
import { useState } from "react";
import { sendMessage } from "@/services/messages";
import { toast } from "sonner";
import { MessageFormData } from "@/services/messages/types";

interface SendMessageParams {
  recipientId: string;
  subject: string;
  content: string;
  vehicleId?: string;
  senderName?: string;
  senderEmail?: string;
  senderPhone?: string;
}

export const useMessageSender = () => {
  const [isSending, setIsSending] = useState(false);

  const sendMessageToSeller = async (data: SendMessageParams): Promise<boolean> => {
    setIsSending(true);
    
    try {
      console.log("Sending message to seller:", data.recipientId, "Vehicle ID:", data.vehicleId);
      
      // Check for required recipient
      if (!data.recipientId) {
        toast.error("Recipient ID is required");
        return false;
      }
      
      // Prepare message data for the API
      const messageData: MessageFormData = {
        recipient_id: data.recipientId,
        subject: data.subject,
        content: data.content,
        vehicle_id: data.vehicleId,
        sender_name: data.senderName,
        sender_email: data.senderEmail,
        sender_phone: data.senderPhone
      };
      
      console.log("Message data:", messageData);
      
      const { success, error } = await sendMessage(messageData);
      
      if (success) {
        toast.success("Message sent successfully!");
        return true;
      } else {
        toast.error(error || "Failed to send message");
        console.error("Error sending message:", error);
        return false;
      }
    } catch (error) {
      toast.error("Failed to send message. Please try again.");
      console.error("Exception sending message:", error);
      return false;
    } finally {
      setIsSending(false);
    }
  };

  return {
    isSending,
    sendMessageToSeller
  };
};
