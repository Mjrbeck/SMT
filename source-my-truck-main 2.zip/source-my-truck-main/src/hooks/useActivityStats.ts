import { useState, useEffect, useRef } from "react";
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from "@/integrations/supabase/client";
import { ActivityStats, ProfileData } from "@/components/profile/types";
import { getUserVehicleViews } from "@/services/vehicles/vehicleViewsService";

const defaultStats: ActivityStats = {
  totalVehicles: 0,
  totalViews: 0,
  averagePrice: 0,
  accountAge: 0,
  lastActive: "",
};

export const useActivityStats = (profile: ProfileData | null) => {
  const { user } = useAuth();
  const [stats, setStats] = useState<ActivityStats>(defaultStats);
  const isFetchingRef = useRef(false);
  const previousProfileIdRef = useRef<string | null>(null);

  const fetchActivityStats = async () => {
    if (!user || !profile) return;
    
    // Prevent duplicate fetches
    if (isFetchingRef.current) {
      console.log("Already fetching activity stats, skipping duplicate request");
      return;
    }
    
    // Skip if we already fetched for this profile
    if (previousProfileIdRef.current === profile.id) {
      return;
    }
    
    isFetchingRef.current = true;
    previousProfileIdRef.current = profile.id;
    
    try {
      console.log("Fetching activity stats for user:", user.id);
      
      // Fetch vehicle listings
      const { data: vehicles, error: vehiclesError } = await supabase
        .from('vehicles')
        .select('id, price, created_at, updated_at, status')
        .eq('user_id', user.id);
        
      if (vehiclesError) throw vehiclesError;
      
      // Get active vehicles only
      const activeVehicles = vehicles?.filter(v => v.status === 'active') || [];
      const totalVehicles = activeVehicles.length;
      
      // Calculate average price
      let averagePrice = 0;
      if (totalVehicles > 0) {
        const sum = activeVehicles.reduce((acc, vehicle) => acc + (vehicle.price || 0), 0);
        averagePrice = Math.round(sum / totalVehicles);
      }
      
      // Calculate account age in days
      const accountCreation = new Date(profile?.created_at || new Date());
      const today = new Date();
      const diffTime = Math.abs(today.getTime() - accountCreation.getTime());
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      
      // Determine last active timestamp
      let lastActive = profile?.updated_at || profile?.created_at || "";
      if (vehicles && vehicles.length > 0) {
        const sortedByUpdated = [...vehicles].sort((a, b) => 
          new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime()
        );
        if (sortedByUpdated[0].updated_at) {
          const mostRecentVehicleUpdate = new Date(sortedByUpdated[0].updated_at);
          const profileLastUpdate = new Date(lastActive);
          
          if (mostRecentVehicleUpdate > profileLastUpdate) {
            lastActive = sortedByUpdated[0].updated_at;
          }
        }
      }
      
      // Get actual view data from the new vehicle_views table
      const totalViews = await getUserVehicleViews(user.id);
      
      console.log("Activity stats calculated:", { 
        totalVehicles, 
        totalViews,
        averagePrice,
        accountAge: diffDays
      });
      
      setStats({
        totalVehicles,
        totalViews,
        averagePrice,
        accountAge: diffDays,
        lastActive,
      });
      
    } catch (error) {
      console.error('Error fetching activity stats:', error);
      // Keep the current stats on error
    } finally {
      isFetchingRef.current = false;
    }
  };

  // Only fetch stats when profile changes and fetch hasn't been done yet
  useEffect(() => {
    if (user && profile && !isFetchingRef.current && previousProfileIdRef.current !== profile.id) {
      fetchActivityStats();
    }
    
    // Clean up when component unmounts
    return () => {
      isFetchingRef.current = false;
    };
  }, [user, profile]);

  return {
    stats,
    fetchActivityStats
  };
};
