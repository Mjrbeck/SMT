
import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useSearchParams } from "react-router-dom";
import { VehicleData } from "@/components/VehicleCard";
import { getAllVehicles } from "@/services/vehicleService";
import { getBodyTypeValue } from "@/utils/vehicleUtils";
import { geocodePostcode } from "@/services/vehicles/geocodingService";
import { parseCoordinates, calculateDistance } from "@/utils/locationUtils";

export interface VehicleFiltersState {
  yearRange: [number, number];
  selectedMakes: string[];
  selectedBodyTypes: string[];
  sortBy: string;
  searchCoordinates: { lat: number, lng: number } | null;
  isLocationSearching: boolean;
  locationError: string | null;
  trustedSellersOnly: boolean;
  depotVerifiedOnly: boolean;
}

export const useVehicleFilters = () => {
  const [searchParams] = useSearchParams();
  const [sortBy, setSortBy] = useState("newest");
  const [isLocationSearching, setIsLocationSearching] = useState(false);
  const [locationError, setLocationError] = useState<string | null>(null);
  const [searchCoordinates, setSearchCoordinates] = useState<{lat: number, lng: number} | null>(null);
  
  // Get search params
  const keyword = searchParams.get("keyword") || "";
  const make = searchParams.get("make") || "";
  const priceMax = searchParams.get("priceMax") ? parseInt(searchParams.get("priceMax") || "0") : 0;
  const bodyType = searchParams.get("bodyType") || "";
  const location = searchParams.get("location") || "";
  const radiusParam = searchParams.get("radius") || "50";
  const radius = radiusParam === "nationwide" ? 999999 : parseInt(radiusParam) || 50;

  // Set up filter state
  const [yearRange, setYearRange] = useState<[number, number]>([2000, 2025]);
  const [selectedMakes, setSelectedMakes] = useState<string[]>(make ? [make] : []);
  const [selectedBodyTypes, setSelectedBodyTypes] = useState<string[]>(bodyType ? [bodyType] : []);
  const [trustedSellersOnly, setTrustedSellersOnly] = useState(false);
  const [depotVerifiedOnly, setDepotVerifiedOnly] = useState(false);

  // Fetch vehicles data
  const { data: vehicles = [], isLoading, error } = useQuery({
    queryKey: ['vehicles', keyword, priceMax, selectedMakes, selectedBodyTypes, yearRange, sortBy, trustedSellersOnly, depotVerifiedOnly],
    queryFn: () => getAllVehicles(trustedSellersOnly, depotVerifiedOnly),
  });

  // Process location search
  useEffect(() => {
    const processLocation = async () => {
      if (!location) {
        setSearchCoordinates(null);
        return;
      }

      setIsLocationSearching(true);
      setLocationError(null);
      
      try {
        const result = await geocodePostcode(location);
        if (!result || !result.coordinates) {
          setLocationError("Could not find coordinates for the provided postcode.");
          setSearchCoordinates(null);
        } else {
          const coords = parseCoordinates(result.coordinates);
          setSearchCoordinates(coords);
        }
      } catch (error) {
        console.error("Error processing location:", error);
        setLocationError("An error occurred while processing the location search.");
        setSearchCoordinates(null);
      } finally {
        setIsLocationSearching(false);
      }
    };

    processLocation();
  }, [location]);

  // Filter vehicles based on all criteria
  const filteredVehicles = vehicles
    .filter((vehicle: VehicleData) => {
      if (keyword) {
        const searchTerm = keyword.toLowerCase();
        const matchesSearch = 
          vehicle.title.toLowerCase().includes(searchTerm) ||
          vehicle.make.toLowerCase().includes(searchTerm) ||
          vehicle.model.toLowerCase().includes(searchTerm) ||
          (vehicle.description || "").toLowerCase().includes(searchTerm);
        
        if (!matchesSearch) return false;
      }
      
      if (priceMax > 0 && vehicle.price > priceMax) {
        return false;
      }
      
      if (selectedMakes.length > 0 && !selectedMakes.includes(vehicle.make.toLowerCase())) {
        return false;
      }
      
      if (selectedBodyTypes.length > 0 && vehicle.bodyType) {
        const vehicleBodyTypeValue = getBodyTypeValue(vehicle.bodyType);
        if (!selectedBodyTypes.includes(vehicleBodyTypeValue)) {
          return false;
        }
      }
      
      if (vehicle.year < yearRange[0] || vehicle.year > yearRange[1]) {
        return false;
      }
      
      return true;
    })
    .map((vehicle: VehicleData) => {
      let distance: number | null = null;
      
      if (searchCoordinates && location) {
        const vehicleCoords = parseCoordinates(vehicle.location);
        if (vehicleCoords) {
          distance = calculateDistance(
            searchCoordinates.lat,
            searchCoordinates.lng,
            vehicleCoords.lat,
            vehicleCoords.lng
          );
          
          if (distance > radius) {
            return null;
          }
        } else if (radius < 200) {
          return null;
        }
      }
      
      return {
        ...vehicle,
        distance
      };
    })
    .filter(Boolean)
    .sort((a: any, b: any) => {
      if (location && (a.distance !== null || b.distance !== null)) {
        if (a.distance === null && b.distance !== null) return 1;
        if (a.distance !== null && b.distance === null) return -1;
        if (a.distance !== null && b.distance !== null) return a.distance - b.distance;
      }
      
      switch (sortBy) {
        case "newest":
          return b.year - a.year;
        case "oldest":
          return a.year - b.year;
        case "price-asc":
          return a.price - b.price;
        case "price-desc":
          return b.price - a.price;
        case "mileage-asc":
          return a.mileage - b.mileage;
        default:
          return 0;
      }
    });

  // Available filter options based on current vehicles
  const availableMakes = [...new Set(vehicles.map((v: VehicleData) => v.make.toLowerCase()))];
  
  const availableBodyTypes = [...new Set(
    vehicles
      .map((v: VehicleData) => v.bodyType ? getBodyTypeValue(v.bodyType) : null)
      .filter(Boolean) as string[]
  )];

  // Handler functions for filters
  const handleMakeChange = (make: string) => {
    setSelectedMakes((prev) => {
      if (prev.includes(make)) {
        return prev.filter((m) => m !== make);
      } else {
        return [...prev, make];
      }
    });
  };

  const handleBodyTypeChange = (bodyType: string) => {
    setSelectedBodyTypes((prev) => {
      if (prev.includes(bodyType)) {
        return prev.filter((b) => b !== bodyType);
      } else {
        return [...prev, bodyType];
      }
    });
  };

  return {
    // Filter state
    yearRange,
    setYearRange,
    selectedMakes,
    selectedBodyTypes,
    sortBy,
    setSortBy,
    location,
    radius,
    searchCoordinates,
    isLocationSearching,
    locationError,
    trustedSellersOnly,
    setTrustedSellersOnly,
    depotVerifiedOnly,
    setDepotVerifiedOnly,
    
    // Filtered data
    filteredVehicles,
    availableMakes,
    availableBodyTypes,
    isLoading,
    error,
    
    // Handler functions
    handleMakeChange,
    handleBodyTypeChange,
  };
};
