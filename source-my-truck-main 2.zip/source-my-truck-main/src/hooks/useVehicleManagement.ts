
import { useState } from "react";
import { toast } from "sonner";
import { 
  deleteVehicleById, 
  updateVehicleStatus, 
  reactivateVehicle 
} from "@/services/vehicles/vehicleManagementService";
import { useCallback } from "react";

interface UseVehicleManagementProps {
  onSuccess?: () => void;
  redirectPath?: string;
}

export const useVehicleManagement = ({ onSuccess, redirectPath }: UseVehicleManagementProps = {}) => {
  const [isDeleting, setIsDeleting] = useState(false);
  const [isUpdatingStatus, setIsUpdatingStatus] = useState(false);
  const [isReactivating, setIsReactivating] = useState(false);
  const [insufficientCredits, setInsufficientCredits] = useState(false);

  const deleteVehicle = useCallback(async (vehicleId: string) => {
    if (isDeleting) return false; // Prevent multiple delete operations
    
    try {
      setIsDeleting(true);
      const { success, error } = await deleteVehicleById(vehicleId);
      
      if (success) {
        toast.success("Vehicle deleted successfully");
        
        // Handle callbacks after successful deletion
        if (onSuccess) {
          // Call onSuccess but don't wait for it
          setTimeout(() => {
            onSuccess();
          }, 0);
        }
        
        // Don't redirect here if redirectPath is provided
        // Let the component handle navigation to avoid race conditions
        
        return true;
      } else {
        toast.error(`Failed to delete vehicle: ${error}`);
        return false;
      }
    } catch (error) {
      console.error("Error in delete handler:", error);
      toast.error("An unexpected error occurred");
      return false;
    } finally {
      // We'll set this with a small delay to ensure React has time to process state changes
      setTimeout(() => {
        setIsDeleting(false);
      }, 100);
    }
  }, [isDeleting, onSuccess, redirectPath]);

  const changeVehicleStatus = useCallback(async (vehicleId: string, newStatus: string) => {
    if (isUpdatingStatus) return false; // Prevent multiple status updates
    
    try {
      setIsUpdatingStatus(true);
      console.log(`Changing vehicle status: ${vehicleId} to ${newStatus}`);
      
      const { success, error } = await updateVehicleStatus(vehicleId, newStatus);
      
      if (success) {
        const statusMessages: Record<string, string> = {
          'active': 'activated',
          'draft': 'unpublished',
          'sale_in_progress': 'marked as sale in progress',
          'sold': 'marked as sold'
        };
        
        const statusMessage = statusMessages[newStatus] || 'updated';
        toast.success(`Vehicle ${statusMessage} successfully`);
        
        if (onSuccess) {
          // Call onSuccess but don't wait for it
          setTimeout(() => {
            onSuccess();
          }, 0);
        }
        
        return true;
      } else {
        toast.error(`Failed to update vehicle status: ${error}`);
        return false;
      }
    } catch (error) {
      console.error("Error changing vehicle status:", error);
      toast.error("Failed to update vehicle status");
      return false;
    } finally {
      setTimeout(() => {
        setIsUpdatingStatus(false);
      }, 100);
    }
  }, [isUpdatingStatus, onSuccess]);

  const reactivateVehicleListing = useCallback(async (vehicleId: string) => {
    if (isReactivating) return false; // Prevent multiple reactivation attempts
    
    try {
      setIsReactivating(true);
      const { success, error, insufficientCredits: notEnoughCredits } = await reactivateVehicle(vehicleId);
      
      if (success) {
        toast.success("Vehicle reactivated successfully for 30 days");
        
        if (onSuccess) {
          // Call onSuccess but don't wait for it
          setTimeout(() => {
            onSuccess();
          }, 0);
        }
        
        return true;
      } else {
        if (notEnoughCredits) {
          setInsufficientCredits(true);
          return false;
        } else {
          toast.error(`Failed to reactivate vehicle: ${error}`);
          return false;
        }
      }
    } catch (error) {
      console.error("Error reactivating vehicle:", error);
      toast.error("Failed to reactivate vehicle");
      return false;
    } finally {
      setTimeout(() => {
        setIsReactivating(false);
      }, 100);
    }
  }, [isReactivating, onSuccess]);

  return {
    deleteVehicle,
    changeVehicleStatus,
    reactivateVehicleListing,
    isDeleting,
    isUpdatingStatus,
    isReactivating,
    insufficientCredits,
    setInsufficientCredits
  };
};
