
import { useState } from "react";

export function useAsyncExecution(initialLoading: boolean = false) {
  const [isLoading, setIsLoading] = useState(initialLoading);

  const executeWithLoading = async <T>(asyncFunction: () => Promise<T>): Promise<T> => {
    setIsLoading(true);
    try {
      const result = await asyncFunction();
      return result;
    } finally {
      setIsLoading(false);
    }
  };

  const startLoading = () => setIsLoading(true);
  const stopLoading = () => setIsLoading(false);

  return {
    isLoading,
    executeWithLoading,
    startLoading,
    stopLoading
  };
}
