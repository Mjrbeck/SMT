
import { useRef } from "react";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useAsyncExecution } from "@/hooks/useAsyncExecution";

export function useAuthOperations() {
  const { toast } = useToast();
  const navigate = useNavigate();
  const { executeWithLoading } = useAsyncExecution();
  const isProcessingRef = useRef(false);

  const signIn = async (email: string, password: string, captchaToken: string | null = null) => {
    if (isProcessingRef.current) return;
    
    isProcessingRef.current = true;
    return executeWithLoading(async () => {
      try {
        console.log("Starting sign in with captchaToken:", captchaToken ? "Present" : "Missing");
        
        if (!captchaToken) {
          console.error("No captcha token provided when attempting login");
          throw new Error("hCaptcha verification required. Please complete the verification before logging in.");
        }
        
        // Skip server-side hCaptcha verification since it's managed client-side
        console.log("hCaptcha token provided for UI purposes only");
        
        // Proceed with Supabase auth without captcha token (since Supabase doesn't support hCaptcha)
        const { error, data } = await supabase.auth.signInWithPassword({
          email,
          password,
        });

        if (error) {
          console.error("Sign in error details:", error);
          
          if (error?.message?.includes("Email not confirmed")) {
            return { 
              success: false, 
              error: "email_not_confirmed",
              message: "Please verify your email before logging in."
            };
          }
          
          if (error.message?.toLowerCase().includes('captcha') || 
              error.message?.toLowerCase().includes('hcaptcha')) {
            throw new Error("hCaptcha verification failed. Please reload the page and try again.");
          }
          
          throw error;
        }

        return { success: true };
      } catch (error: any) {
        console.error("Sign in error:", error);
        
        // Special handling for captcha errors
        if (error.message?.toLowerCase().includes('captcha') || 
            error.message?.toLowerCase().includes('hcaptcha')) {
          throw new Error("hCaptcha verification failed. Please try again.");
        }
        
        toast({
          title: "Sign in failed",
          description: error.message || "An error occurred during sign in",
          variant: "destructive",
        });
        throw error;
      } finally {
        setTimeout(() => {
          isProcessingRef.current = false;
        }, 500);
      }
    });
  };

  const resendVerificationEmail = async (email: string, captchaToken: string | null = null) => {
    if (isProcessingRef.current) return;
    
    isProcessingRef.current = true;
    return executeWithLoading(async () => {
      try {
        const origin = window.location.origin;
        const redirectTo = `${origin}/login`;
        
        console.log("Resending verification email to:", email);
        console.log("Redirect URL:", redirectTo);
        
        const recaptchaConfigured = import.meta.env.VITE_RECAPTCHA_SITE_KEY;
        const options: { emailRedirectTo: string; captchaToken?: string } = {
          emailRedirectTo: redirectTo
        };
        
        if (recaptchaConfigured && captchaToken) {
          options.captchaToken = captchaToken;
        }
        
        const { error } = await supabase.auth.resend({
          type: 'signup',
          email,
          options
        });

        if (error) throw error;
        
        toast({
          title: "Verification email sent",
          description: "We've sent a new verification email. Please check your inbox."
        });
        
        return { success: true };
      } catch (error: any) {
        console.error("Resend verification email error:", error);
        toast({
          title: "Failed to resend verification email",
          description: error.message || "An error occurred when sending the verification email",
          variant: "destructive",
        });
        throw error;
      } finally {
        setTimeout(() => {
          isProcessingRef.current = false;
        }, 500);
      }
    });
  };

  const signUp = async (email: string, password: string, companyName: string, captchaToken: string | null = null, userType: string = "seller") => {
    if (isProcessingRef.current) return;
    
    isProcessingRef.current = true;
    return executeWithLoading(async () => {
      try {
        const origin = window.location.origin;
        const redirectTo = `${origin}/login`;
        
        console.log("Signup with redirect to:", redirectTo);
        console.log("Captcha token present:", !!captchaToken);
        
        if (!captchaToken) {
          console.error("No captcha token provided when attempting signup");
          throw new Error("hCaptcha verification required. Please complete the verification before registering.");
        }
        
        // Skip server-side hCaptcha verification since it's managed client-side
        console.log("hCaptcha token provided for UI purposes only");
        
        // Proceed with Supabase auth without captcha token (since Supabase doesn't support hCaptcha)
        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            data: { 
              company_name: companyName,
              user_type: userType
            },
            emailRedirectTo: redirectTo,
          },
        });

        if (error) {
          // Special handling for captcha errors
          if (error.message?.toLowerCase().includes('captcha') || 
              error.message?.toLowerCase().includes('hcaptcha')) {
            throw new Error("hCaptcha verification failed. Please try again.");
          }
          throw error;
        }
        
        const isEmailConfirmationRequired = 
          !data?.user?.email_confirmed_at && 
          !data?.user?.confirmed_at;
        
        console.log("Email confirmation required:", isEmailConfirmationRequired);
        
        if (isEmailConfirmationRequired) {
          toast({
            title: "Registration successful",
            description: "Please check your email to verify your account."
          });
          
          return { requiresEmailConfirmation: true };
        } else {
          // Auto sign-in after successful signup (without captcha since we already verified it)
          const { error: signInError } = await supabase.auth.signInWithPassword({
            email,
            password,
          });

          if (signInError) {
            console.error("Auto sign-in failed after signup:", signInError);
            toast({
              title: "Registration successful",
              description: "Your account has been created. You can now sign in.",
            });
            navigate("/login");
          } else {
            toast({
              title: "Welcome!",
              description: "Your account has been created and you are now signed in.",
            });
            navigate("/dashboard");
          }
          
          return { requiresEmailConfirmation: false };
        }
      } catch (error: any) {
        console.error("Sign up error:", error);
        toast({
          title: "Registration failed",
          description: error.message || "An error occurred during registration",
          variant: "destructive",
        });
        throw error;
      } finally {
        setTimeout(() => {
          isProcessingRef.current = false;
        }, 500);
      }
    });
  };

  const signOut = async () => {
    if (isProcessingRef.current) return;
    
    isProcessingRef.current = true;
    return executeWithLoading(async () => {
      try {
        const { error } = await supabase.auth.signOut();
        if (error) throw error;
      } catch (error: any) {
        console.error("Sign out error:", error);
        toast({
          title: "Sign out failed",
          description: error.message || "An error occurred during sign out",
          variant: "destructive",
        });
      } finally {
        setTimeout(() => {
          isProcessingRef.current = false;
        }, 500);
      }
    });
  };

  const sendPasswordResetEmail = async (email: string, captchaToken: string | null = null) => {
    if (isProcessingRef.current) return;
    
    isProcessingRef.current = true;
    return executeWithLoading(async () => {
      try {
        console.log("Sending password reset email to:", email);
        console.log("Captcha token present:", !!captchaToken);
        
        const origin = window.location.origin;
        const redirectUrl = `${origin}/reset-password`;
        
        console.log("Reset password redirect URL:", redirectUrl);
        
        // Skip server-side hCaptcha verification since it's managed client-side
        console.log("hCaptcha token provided for UI purposes only");
        
        const { error } = await supabase.auth.resetPasswordForEmail(email, {
          redirectTo: redirectUrl,
        });
        
        if (error) {
          console.error("Send reset password email error:", error);
          
          if (error.message?.toLowerCase().includes('captcha') || 
              error.message?.toLowerCase().includes('hcaptcha')) {
            throw new Error("hCaptcha verification failed. Please try again.");
          }
          
          throw error;
        }
        
        console.log("Password reset email sent successfully");
        toast({
          title: "Password reset email sent",
          description: "Please check your email for a link to reset your password. Please check your spam folder if you don't see it within a few minutes.",
        });
        return { success: true };
      } catch (error: any) {
        console.error("Send reset password email error:", error);
        toast({
          title: "Failed to send reset email",
          description: error.message || "An error occurred while sending the reset email. Please try again.",
          variant: "destructive",
        });
        throw error;
      } finally {
        setTimeout(() => {
          isProcessingRef.current = false;
        }, 500);
      }
    });
  };

  return {
    signIn,
    signUp,
    signOut,
    sendPasswordResetEmail,
    resendVerificationEmail
  };
}
