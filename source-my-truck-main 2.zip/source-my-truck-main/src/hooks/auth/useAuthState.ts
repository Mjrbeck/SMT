import { useState, useEffect, useRef } from 'react';
import type { Session, User } from '@supabase/supabase-js';
import { supabase } from '@/integrations/supabase/client';
import { clearUserData } from '@/utils/authUtils';

export const useAuthState = () => {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  
  const [isInPasswordRecovery, setIsInPasswordRecovery] = useState(false);
  const hasInitializedRef = useRef(false);

  useEffect(() => {
    let mounted = true;

    // Check if we're in a password recovery flow
    const checkPasswordRecovery = () => {
      const url = new URL(window.location.href);
      const isRecovery = url.hash.includes('type=recovery') || 
                        url.search.includes('type=recovery') ||
                        url.pathname === '/reset-password';
      setIsInPasswordRecovery(isRecovery);
      return isRecovery;
    };

    const getInitialSession = async () => {
      try {
        const isRecovery = checkPasswordRecovery();
        const { data: { session }, error } = await supabase.auth.getSession();
        
        if (mounted) {
          if (error) {
            console.error('Error getting initial session:', error);
            setSession(null);
            setUser(null);
          } else {
            // Only set session for non-recovery or if we're on reset-password page
            if (!isRecovery || window.location.pathname === '/reset-password') {
              setSession(session);
              setUser(session?.user ?? null);
            } else {
              // In recovery mode but not on reset page - don't authenticate
              setSession(null);
              setUser(null);
            }
          }
          
          setIsLoading(false);
          hasInitializedRef.current = true;
        }
      } catch (error) {
        console.error('Error in getInitialSession:', error);
        if (mounted) {
          setIsLoading(false);
          hasInitializedRef.current = true;
        }
      }
    };


    const handleAuthChange = async (event: string, currentSession: Session | null) => {
      if (!mounted || !hasInitializedRef.current) return;

      console.log('Auth event:', event);
      const isRecovery = checkPasswordRecovery();

      switch (event) {
        case 'SIGNED_IN':
          // Don't treat recovery sessions as regular sign-ins unless on reset page
          if (currentSession?.user && (!isRecovery || window.location.pathname === '/reset-password')) {
            setSession(currentSession);
            setUser(currentSession.user);
          }
          break;

        case 'SIGNED_OUT':
          clearUserData();
          setSession(null);
          setUser(null);
          break;

        case 'TOKEN_REFRESHED':
          // Only update session if not in recovery mode or on reset page
          if (currentSession && (!isRecovery || window.location.pathname === '/reset-password')) {
            setSession(currentSession);
            setUser(currentSession.user);
          }
          break;

        case 'USER_UPDATED':
          if (currentSession?.user) {
            setUser(currentSession.user);
          }
          break;
      }
    };

    // Set up auth state listener
    const { data: { subscription } } = supabase.auth.onAuthStateChange(handleAuthChange);

    // Get initial session
    getInitialSession();

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, []);

  return {
    session,
    user,
    isLoading,
    isAuthenticated: !!session?.user && !isInPasswordRecovery
  };
};