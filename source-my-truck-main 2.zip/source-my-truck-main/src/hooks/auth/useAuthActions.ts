import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

export const useAuthActions = () => {
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  const signUp = async (email: string, password: string, companyName: string, userType: 'buyer' | 'seller' = 'seller') => {
    setIsLoading(true);
    try {
      const redirectUrl = `${window.location.origin}/dashboard?emailConfirmed=true`;
      
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            company_name: companyName,
            user_type: userType
          },
          emailRedirectTo: redirectUrl
        }
      });

      if (error) {
        throw error;
      }

      // Check if email confirmation is required
      const requiresConfirmation = !data.user?.email_confirmed_at && !data.session;

      if (requiresConfirmation) {
        toast({
          title: "Account created successfully",
          description: "Please check your email to verify your account before signing in.",
        });
        return { success: true, requiresEmailConfirmation: true };
      } else {
        toast({
          title: "Account created and signed in",
          description: "Welcome to SourceMyTruck!",
        });
        navigate('/dashboard');
        return { success: true, requiresEmailConfirmation: false };
      }
    } catch (error: any) {
      console.error('Sign up error:', error);
      let errorMessage = 'Failed to create account. Please try again.';
      
      if (error.message?.includes('User already registered')) {
        errorMessage = 'An account with this email already exists.';
      } else if (error.message?.includes('Invalid email')) {
        errorMessage = 'Please enter a valid email address.';
      } else if (error.message?.includes('Password')) {
        errorMessage = error.message;
      }

      toast({
        title: "Registration failed",
        description: errorMessage,
        variant: "destructive",
      });
      
      throw new Error(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  const signIn = async (email: string, password: string) => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password
      });

      if (error) {
        throw error;
      }

      if (!data.user?.email_confirmed_at) {
        throw new Error('Please verify your email address before signing in. Check your inbox for a verification link.');
      }

      toast({
        title: "Welcome back!",
        description: "You have successfully signed in.",
      });
      
      navigate('/dashboard');
      return { success: true };
    } catch (error: any) {
      console.error('Sign in error:', error);
      let errorMessage = 'Invalid email or password.';
      
      if (error.message?.includes('Email not confirmed')) {
        errorMessage = 'Please verify your email address before signing in.';
      } else if (error.message?.includes('verify your email')) {
        errorMessage = error.message;
      } else if (error.message?.includes('Invalid login credentials')) {
        errorMessage = 'Invalid email or password. Please check your credentials.';
      }

      toast({
        title: "Sign in failed",
        description: errorMessage,
        variant: "destructive",
      });
      
      throw new Error(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  const signOut = async () => {
    setIsLoading(true);
    try {
      const { error } = await supabase.auth.signOut();
      if (error) throw error;

      toast({
        title: "Signed out",
        description: "You have been signed out successfully.",
      });
      
      navigate('/');
    } catch (error: any) {
      console.error('Sign out error:', error);
      toast({
        title: "Sign out failed",
        description: "There was an error signing out. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const sendPasswordReset = async (email: string) => {
    setIsLoading(true);
    try {
      const redirectUrl = `${window.location.origin}/auth/callback`;
      
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: redirectUrl
      });

      if (error) throw error;

      toast({
        title: "Password reset email sent",
        description: "Please check your email for a link to reset your password.",
      });
      
      return { success: true };
    } catch (error: any) {
      console.error('Password reset error:', error);
      const errorMessage = error.message || 'Failed to send password reset email. Please try again.';
      
      toast({
        title: "Password reset failed",
        description: errorMessage,
        variant: "destructive",
      });
      
      throw new Error(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  const resendEmailConfirmation = async (email: string) => {
    setIsLoading(true);
    try {
      const redirectUrl = `${window.location.origin}/dashboard?emailConfirmed=true`;
      
      const { error } = await supabase.auth.resend({
        type: 'signup',
        email,
        options: {
          emailRedirectTo: redirectUrl
        }
      });

      if (error) throw error;

      toast({
        title: "Confirmation email sent",
        description: "Please check your email for a new verification link.",
      });
      
      return { success: true };
    } catch (error: any) {
      console.error('Resend confirmation error:', error);
      const errorMessage = error.message || 'Failed to resend confirmation email. Please try again.';
      
      toast({
        title: "Resend failed",
        description: errorMessage,
        variant: "destructive",
      });
      
      throw new Error(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  const updatePassword = async (newPassword: string) => {
    setIsLoading(true);
    try {
      const { error } = await supabase.auth.updateUser({
        password: newPassword
      });

      if (error) throw error;

      toast({
        title: "Password updated",
        description: "Your password has been successfully updated.",
      });
      
      return { success: true };
    } catch (error: any) {
      console.error('Update password error:', error);
      const errorMessage = error.message || 'Failed to update password. Please try again.';
      
      toast({
        title: "Password update failed",
        description: errorMessage,
        variant: "destructive",
      });
      
      throw new Error(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  return {
    signUp,
    signIn,
    signOut,
    sendPasswordReset,
    resendEmailConfirmation,
    updatePassword,
    isLoading
  };
};