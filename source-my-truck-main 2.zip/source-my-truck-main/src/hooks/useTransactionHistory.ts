
import { useState, useEffect, useCallback, useRef } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { Transaction } from "@/components/profile/types";
import { getTransactionHistory } from "@/services/credits";
import { useLoadingState } from "@/hooks/useLoadingState";
import { useTransactionRefresh } from "@/hooks/useTransactionRefresh";
import { useTransactionRecovery } from "@/hooks/useTransactionRecovery";
import { useLocation, useSearchParams } from "react-router-dom";
import { toast } from "sonner";

export const useTransactionHistory = () => {
  const { user } = useAuth();
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [error, setError] = useState<string | null>(null);
  const { isLoading, startLoading, stopLoading } = useLoadingState(false);
  const [searchParams] = useSearchParams();
  const [hasFetched, setHasFetched] = useState(false);
  const mountedRef = useRef(true);
  const lastFetchAttemptRef = useRef<number>(0);
  const stripeRedirectProcessedRef = useRef(false);
  const initialFetchAttemptedRef = useRef(false);
  const userIdRef = useRef<string | null>(null);
  const location = useLocation();
  const fetchingInProgressRef = useRef(false);
  
  // Check if we're on the credits or invoices settings page
  const isCreditsPage = location.pathname === "/settings" && 
           (location.search.includes("tab=credits") || 
            location.search.includes("tab=invoices") || 
            !location.search);
  
  // Import utility hooks
  const {
    isFetchingRef,
    canFetch,
    startFetch,
    endFetch,
    resetRequestCount,
    setUserChecked,
    isUserChecked,
    setPageFetched,
    hasPageFetched
  } = useTransactionRefresh();

  // Cache transactions in localStorage for immediate display on next visit
  const cacheTransactions = useCallback((txs: Transaction[]) => {
    try {
      localStorage.setItem('cachedTransactions', JSON.stringify(txs));
      localStorage.setItem('transactionCacheTime', Date.now().toString());
    } catch (e) {
      console.warn('Could not cache transactions in localStorage');
    }
  }, []);

  // Load cached transactions from localStorage
  const loadCachedTransactions = useCallback(() => {
    try {
      const cached = localStorage.getItem('cachedTransactions');
      const cacheTime = localStorage.getItem('transactionCacheTime');
      
      if (cached && cacheTime) {
        const parsedCache = JSON.parse(cached) as Transaction[];
        const cacheAge = Date.now() - parseInt(cacheTime);
        
        // Only use cache if it's less than 30 minutes old
        if (cacheAge < 30 * 60 * 1000 && parsedCache.length > 0) {
          setTransactions(parsedCache);
          return true;
        }
      }
      return false;
    } catch (e) {
      console.warn('Could not load cached transactions from localStorage');
      return false;
    }
  }, []);

  // Update userIdRef when user changes
  useEffect(() => {
    if (user) {
      userIdRef.current = user.id;
      setUserChecked(true);
    } else {
      userIdRef.current = null;
      setUserChecked(false);
    }
  }, [user, setUserChecked]);

  const fetchTransactionHistory = useCallback(async (force = false): Promise<void> => {
    // Skip if fetch already in progress
    if (fetchingInProgressRef.current) {
      return;
    }
    
    // Skip if no user is available
    if (!user || !user.id) {
      return;
    }
    
    // Prevent too frequent fetch attempts
    const now = Date.now();
    if (!force && now - lastFetchAttemptRef.current < 2000) {
      return;
    }
    lastFetchAttemptRef.current = now;
    
    // Check if we can fetch (throttling/concurrency control)
    if (!canFetch(hasFetched, force)) {
      return;
    }
    
    // If we've already fetched for this page view, skip unless forced
    if (hasPageFetched(location.pathname + location.search) && !force) {
      return;
    }
    
    // Prevent further fetches while this one is in progress
    fetchingInProgressRef.current = true;
    startFetch();
    
    // Only show loading state on initial fetch, not on refreshes
    if (!hasFetched) {
      setError(null);
      startLoading();
    }
    
    try {
      // Log fetch attempt
      console.log('Fetching transaction history...');
      
      const response = await getTransactionHistory();
      
      // Check if component is still mounted before updating state
      if (!mountedRef.current) {
        return;
      }
      
      if (response.error) {
        console.error('Error fetching transactions:', response.error);
        setError(response.error);
      } else {
        // Only update state if transactions have changed
        const newTransactions = response.transactions || [];
        
        // Log transaction data for debugging
        console.log(`Received ${newTransactions.length} transactions`);
        if (newTransactions.length > 0) {
          console.log('First few transactions:', newTransactions.slice(0, 3));
        }
        
        setTransactions(newTransactions);
        cacheTransactions(newTransactions);
        
        // Mark that we've fetched for this page view
        if (isCreditsPage) {
          setPageFetched(true, location.pathname + location.search);
        }
        
        setHasFetched(true);
      }
    } catch (error) {
      // Check if component is still mounted before updating state
      if (!mountedRef.current) return;
      
      console.error('Error in fetchTransactionHistory:', error);
      setError("Failed to load transaction history");
    } finally {
      // Check if component is still mounted before updating state
      if (mountedRef.current) {
        stopLoading();
        endFetch(mountedRef);
      }
      // Always re-enable fetching
      fetchingInProgressRef.current = false;
    }
  }, [user, isLoading, startLoading, stopLoading, hasFetched, canFetch, startFetch, endFetch, 
      cacheTransactions, isCreditsPage, hasPageFetched, setPageFetched, location.pathname, location.search, 
      stopLoading]);

  // Import recovery logic
  const { 
    handleSuccessfulPayment,
    checkForPastRecoveryNeeded
  } = useTransactionRecovery(fetchTransactionHistory);

  // Check for success parameter from Stripe redirect
  useEffect(() => {
    const success = searchParams.get('success');
    const sessionId = searchParams.get('session_id');
    
    if (success === 'true' && sessionId && user && !stripeRedirectProcessedRef.current) {
      // Mark as processed immediately to prevent duplicate processing
      stripeRedirectProcessedRef.current = true;
      
      // Immediately refresh with force flag to bypass throttling
      fetchTransactionHistory(true);
      
      // Handle the successful payment (includes recovery setup)
      handleSuccessfulPayment(sessionId, user);
      
      // Clear any query parameters
      if (window.history && window.history.replaceState) {
        const cleanUrl = window.location.pathname + (location.search.includes('tab=') ? location.search : '?tab=credits');
        window.history.replaceState({}, document.title, cleanUrl);
      }
    }
  }, [searchParams, user, fetchTransactionHistory, handleSuccessfulPayment, location.search]);

  // Component lifecycle
  useEffect(() => {
    mountedRef.current = true;
    
    // Load cached transactions first for immediate UI display
    loadCachedTransactions();
    
    // Check for any stored session that might need recovery
    if (user) {
      checkForPastRecoveryNeeded(user);
    }
    
    // Reset page fetched status when location changes
    if (isCreditsPage) {
      // Only reset if the path has actually changed
      if (!hasPageFetched(location.pathname + location.search)) {
        setPageFetched(false);
      }
    }
    
    // Clean up on unmount
    return () => {
      mountedRef.current = false;
      isFetchingRef.current = false;
      fetchingInProgressRef.current = false;
    };
  }, [user, checkForPastRecoveryNeeded, loadCachedTransactions, isCreditsPage, setPageFetched, hasPageFetched, location.pathname, location.search, isFetchingRef]);

  // Initial fetch effect - only once when component mounts
  useEffect(() => {
    // Only fetch initially if we have a user and haven't fetched yet
    if (user && !initialFetchAttemptedRef.current && !fetchingInProgressRef.current) {
      initialFetchAttemptedRef.current = true;
      
      // Small delay to prevent immediate fetch
      setTimeout(() => {
        if (mountedRef.current && user && !fetchingInProgressRef.current) {
          console.log('Initial transaction history fetch triggered');
          fetchTransactionHistory(isCreditsPage);
        }
      }, 300);
    }
    
    // Reset request count when user changes
    return () => {
      resetRequestCount();
    };
  }, [user, fetchTransactionHistory, resetRequestCount, isCreditsPage]);

  // Force refresh when landing on the settings page (only once per navigation)
  useEffect(() => {
    if (isCreditsPage && user && hasFetched && !hasPageFetched(location.pathname + location.search) && !fetchingInProgressRef.current) {
      console.log("On credits/invoices page with new route, fetching fresh transaction data");
      
      setTimeout(() => {
        if (mountedRef.current && user && !fetchingInProgressRef.current) {
          fetchTransactionHistory(true); // Force fetch
        }
      }, 500);
    }
  }, [isCreditsPage, user, fetchTransactionHistory, hasFetched, hasPageFetched, location.pathname, location.search]);

  return {
    transactions,
    isLoading,
    error,
    fetchTransactionHistory,
    setHasFetched
  };
};
