import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { getErrorMessage } from '@/utils/errorHandling';

export const usePasswordResetForm = () => {
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formErrors, setFormErrors] = useState<{password?: string; confirmPassword?: string; general?: string}>({});
  const [resetComplete, setResetComplete] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  const validateForm = () => {
    const errors: {password?: string; confirmPassword?: string} = {};
    let isValid = true;

    if (!password) {
      errors.password = "Password is required";
      isValid = false;
    } else if (password.length < 6) {
      errors.password = "Password must be at least 6 characters";
      isValid = false;
    }

    if (!confirmPassword) {
      errors.confirmPassword = "Please confirm your password";
      isValid = false;
    } else if (password !== confirmPassword) {
      errors.confirmPassword = "Passwords do not match";
      isValid = false;
    }

    setFormErrors(errors);
    return isValid;
  };

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (isSubmitting) {
      return;
    }
    
    if (!validateForm()) {
      return;
    }
    
    try {
      setIsSubmitting(true);
      setFormErrors({});
      
      console.log("Starting password reset process...");
      
      // Try to get the current session first to see what's there
      const { data: { session: currentSession }, error: sessionError } = await supabase.auth.getSession();
      console.log("Current session before update:", currentSession ? `exists for ${currentSession.user?.email}` : "missing");
      console.log("Session error:", sessionError);
      
      if (!currentSession) {
        // If no session, try to re-establish it from URL tokens
        console.log("No session found, attempting to re-establish from URL...");
        const hash = window.location.hash;
        const params = new URLSearchParams(hash.replace('#', ''));
        const access_token = params.get('access_token');
        const refresh_token = params.get('refresh_token');
        
        if (access_token) {
          console.log("Re-establishing session with tokens...");
          const { data: { session: newSession }, error: reEstablishError } = await supabase.auth.setSession({
            access_token,
            refresh_token: refresh_token || ''
          });
          
          if (reEstablishError) {
            console.error("Failed to re-establish session:", reEstablishError);
            throw new Error("Failed to re-establish recovery session: " + reEstablishError.message);
          }
          
          console.log("Session re-established:", newSession ? `for ${newSession.user?.email}` : "failed");
        } else {
          throw new Error("No recovery tokens found in URL");
        }
      }
      
      console.log("Attempting password update...");
      const { error } = await supabase.auth.updateUser({ password: password });
      
      if (error) {
        console.error("Password update error:", error);
        // Handle specific Supabase errors
        if (error.message?.includes('session_not_found') || error.message?.includes('invalid_token')) {
          throw new Error("The password reset session has expired. Please request a new password reset link.");
        } else if (error.message?.includes('Password should be')) {
          throw new Error(error.message);
        } else {
          throw new Error(error.message || "Failed to update password. Please try again.");
        }
      }
      
      console.log("Password updated successfully!");
      setResetComplete(true);
      toast({
        title: "Password reset successful",
        description: "Your password has been reset successfully. You can now log in with your new password.",
      });
      
      // Clear URL parameters now that reset is complete
      window.history.replaceState(null, '', window.location.pathname);
      
      // Sign out and redirect to login after delay
      await supabase.auth.signOut();
      
      setTimeout(() => {
        navigate("/login");
      }, 3000);
    } catch (error: any) {
      console.error("Password reset error:", error);
      const errorMessage = getErrorMessage(error);
      setFormErrors({ 
        general: `Password reset failed: ${errorMessage}. Please try requesting a new reset link.` 
      });
      
      toast({
        title: "Password reset failed",
        description: "An unexpected error occurred. Please try again or request a new reset link.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleRequestNewLink = async (email?: string | null) => {
    if (email) {
      try {
        setIsSubmitting(true);
        
        const { error } = await supabase.auth.resetPasswordForEmail(email, {
          redirectTo: `${window.location.origin}/reset-password/recovery`,
        });
        
        if (error) {
          console.error("Error requesting new link:", error);
          toast({
            title: "Failed to send reset email",
            description: error.message || "An error occurred. Please try again.",
            variant: "destructive",
          });
          setIsSubmitting(false);
          return;
        }
        
        toast({
          title: "Reset link sent",
          description: `A new password reset link has been sent to ${email}. Please check your email.`,
        });
        
        setIsSubmitting(false);
      } catch (error: any) {
        console.error("Error requesting new link:", error);
        toast({
          title: "Failed to send reset email",
          description: error.message || "An error occurred. Please try again.",
          variant: "destructive",
        });
        setIsSubmitting(false);
      }
    } else {
      navigate("/login?forgotPassword=true");
    }
  };

  return {
    password,
    setPassword,
    confirmPassword,
    setConfirmPassword,
    isSubmitting,
    formErrors,
    resetComplete,
    handleResetPassword,
    handleRequestNewLink
  };
};