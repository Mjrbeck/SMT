
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';

export const useVehicleImages = (vehicleId: string) => {
  const [loading, setLoading] = useState<boolean>(false);
  const [isOwner, setIsOwner] = useState<boolean>(false);
  const { user } = useAuth();

  useEffect(() => {
    const checkOwnership = async () => {
      if (!user) {
        setIsOwner(false);
        return;
      }

      try {
        const { data, error } = await supabase
          .from('vehicles')
          .select('user_id')
          .eq('id', vehicleId)
          .single();

        if (error) {
          console.error('Error checking vehicle ownership:', error);
          setIsOwner(false);
          return;
        }

        setIsOwner(user.id === data.user_id);
      } catch (error) {
        console.error('Error checking ownership:', error);
        setIsOwner(false);
      }
    };

    checkOwnership();
  }, [vehicleId, user]);

  const reorderImages = async (orderedImageIds: string[]) => {
    if (!user || !isOwner) {
      toast.error("You don't have permission to reorder these images");
      return;
    }

    setLoading(true);

    try {
      // Fetch all existing vehicle images to get their IDs
      const { data: existingImages, error: fetchError } = await supabase
        .from('vehicle_images')
        .select('id, is_main')
        .eq('vehicle_id', vehicleId);

      if (fetchError) {
        throw fetchError;
      }

      // For each image in the ordered list, update its order
      const updates = orderedImageIds.map((imageId, index) => {
        const currentImage = existingImages?.find(img => img.id === imageId);
        return supabase
          .from('vehicle_images')
          .update({ order: index })
          .eq('id', imageId);
      });

      await Promise.all(updates);
      toast.success('Image order updated successfully');
    } catch (error) {
      console.error('Error updating image order:', error);
      toast.error('Failed to update image order');
    } finally {
      setLoading(false);
    }
  };

  const setMainImage = async (imageId: string): Promise<boolean> => {
    if (!user || !isOwner) {
      toast.error("You don't have permission to set the main image");
      return false;
    }

    setLoading(true);

    try {
      // First, set all images as non-main
      const { error: resetError } = await supabase
        .from('vehicle_images')
        .update({ is_main: false })
        .eq('vehicle_id', vehicleId);

      if (resetError) {
        console.error('Error resetting main image flags:', resetError);
        throw resetError;
      }

      // Then set the selected image as main
      const { error: setMainError } = await supabase
        .from('vehicle_images')
        .update({ is_main: true })
        .eq('id', imageId);

      if (setMainError) {
        console.error('Error setting main image:', setMainError);
        throw setMainError;
      }

      toast.success('Main image updated');
      
      // Instead of a page reload, return true to indicate success
      // This allows the parent component to handle refetching as needed
      return true;
    } catch (error) {
      console.error('Error setting main image:', error);
      toast.error('Failed to set main image');
      return false;
    } finally {
      setLoading(false);
    }
  };

  return {
    reorderImages,
    setMainImage,
    hasLoadingState: loading,
    isOwner
  };
};
