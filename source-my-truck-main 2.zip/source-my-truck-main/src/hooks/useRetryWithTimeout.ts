
import { useState, useCallback, useEffect, useRef } from "react";

interface UseRetryWithTimeoutOptions {
  onRetry: () => void;
  maxRetryDelay?: number;
  maxRetries?: number;
}

export const useRetryWithTimeout = ({ 
  onRetry, 
  maxRetryDelay = 30000,
  maxRetries = 5
}: UseRetryWithTimeoutOptions) => {
  const [refreshAttempts, setRefreshAttempts] = useState(0);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const retryTimerRef = useRef<NodeJS.Timeout | null>(null);
  const loadingTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const isMounted = useRef(true);

  const clearRetryTimer = useCallback(() => {
    if (retryTimerRef.current) {
      clearTimeout(retryTimerRef.current);
      retryTimerRef.current = null;
    }
  }, []);

  const clearLoadingTimeout = useCallback(() => {
    if (loadingTimeoutRef.current) {
      clearTimeout(loadingTimeoutRef.current);
      loadingTimeoutRef.current = null;
    }
  }, []);

  const setupRetry = useCallback(() => {
    if (isRefreshing || refreshAttempts >= maxRetries) return;
    
    clearRetryTimer();
    
    // Exponential backoff with max delay cap
    const retryDelay = Math.min(1000 * Math.pow(1.5, refreshAttempts), maxRetryDelay);
    
    retryTimerRef.current = setTimeout(() => {
      if (isMounted.current) {
        onRetry();
      }
    }, retryDelay);
  }, [isRefreshing, refreshAttempts, maxRetryDelay, clearRetryTimer, onRetry, maxRetries]);

  const setupLoadingTimeout = useCallback((callback: () => void, delay: number = 8000) => {
    clearLoadingTimeout();
    loadingTimeoutRef.current = setTimeout(() => {
      if (isMounted.current) {
        callback();
      }
    }, delay);
  }, [clearLoadingTimeout]);

  const incrementRetryAttempts = useCallback(() => {
    setRefreshAttempts(prev => prev + 1);
  }, []);

  const resetRetryAttempts = useCallback(() => {
    setRefreshAttempts(0);
  }, []);

  const setRefreshingState = useCallback((refreshing: boolean) => {
    setIsRefreshing(refreshing);
  }, []);

  // Cleanup timers on unmount
  useEffect(() => {
    return () => {
      isMounted.current = false;
      clearRetryTimer();
      clearLoadingTimeout();
    };
  }, [clearRetryTimer, clearLoadingTimeout]);

  return {
    refreshAttempts,
    isRefreshing,
    setupRetry,
    setupLoadingTimeout,
    incrementRetryAttempts,
    resetRetryAttempts,
    setRefreshingState,
    clearRetryTimer,
    clearLoadingTimeout,
    hasReachedMaxRetries: refreshAttempts >= maxRetries
  };
};
