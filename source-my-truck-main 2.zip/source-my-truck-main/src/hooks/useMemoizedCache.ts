
import { useCallback, useRef, useMemo } from 'react';

/**
 * A hook that provides memoized caching for expensive operations
 * @param computeFunc The expensive computation function
 * @param deps Dependencies that would trigger a recalculation
 * @returns The memoized result and a refresh function
 */
export function useMemoizedCache<T, Args extends any[]>(
  computeFunc: (...args: Args) => T,
  deps: React.DependencyList = []
): [T | undefined, (...args: Args) => T] {
  // Cache the last result
  const resultCache = useRef<T>();
  // Cache the last args
  const argsCache = useRef<Args>();
  
  // Function to compute and cache the result
  const compute = useCallback((...args: Args): T => {
    // Check if args are different from the last call
    const argsChanged = !argsCache.current || 
      !args.every((arg, i) => arg === argsCache.current?.[i]);
    
    // Compute only if needed
    if (argsChanged) {
      resultCache.current = computeFunc(...args);
      argsCache.current = args;
    }
    
    return resultCache.current as T;
  }, [computeFunc]);
  
  // Memoized result based on dependencies
  const result = useMemo(() => {
    if (argsCache.current) {
      return compute(...argsCache.current);
    }
    return resultCache.current;
  }, [compute, ...deps]);
  
  return [result, compute];
}
