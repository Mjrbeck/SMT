import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

export const usePasswordResetSession = () => {
  const [isTokenValid, setIsTokenValid] = useState<boolean | null>(null);
  const [expiredTokenError, setExpiredTokenError] = useState<string | null>(null);
  const [email, setEmail] = useState<string | null>(null);
  const navigate = useNavigate();
  const { toast } = useToast();
  const processedRef = useRef(false); // Prevent multiple processing

  useEffect(() => {
    const setupSession = async () => {
      // Prevent multiple processing
      if (processedRef.current) {
        return;
      }
      processedRef.current = true;
      
      console.log("Setting up password reset session...");
      console.log("Full URL:", window.location.href);
      
      const hash = window.location.hash;
      const search = window.location.search;
      console.log("Hash:", hash);
      console.log("Search:", search);
      
      // Extract parameters from both hash and search
      let params = new URLSearchParams();
      if (hash) {
        const hashParams = new URLSearchParams(hash.replace('#', ''));
        for (const [key, value] of hashParams.entries()) {
          params.append(key, value);
        }
      }
      if (search) {
        const searchParams = new URLSearchParams(search);
        for (const [key, value] of searchParams.entries()) {
          if (!params.has(key)) {
            params.append(key, value);
          }
        }
      }
      
      const access_token = params.get('access_token');
      const refresh_token = params.get('refresh_token');
      const type = params.get('type');
      
      console.log("Reset tokens found:", { 
        access_token: access_token ? `${access_token.substring(0, 20)}...` : null,
        refresh_token: refresh_token ? `${refresh_token.substring(0, 20)}...` : null,
        type,
        hash,
        search,
        all_params: Object.fromEntries(params.entries())
      });

      // Check for error parameters first
      if (params.has('error') || params.has('error_code')) {
        const errorDescription = params.get('error_description') || 'The password reset link has expired or is invalid.';
        console.log("Error in URL parameters:", errorDescription);
        setExpiredTokenError(errorDescription.replace(/\+/g, ' '));
        setIsTokenValid(false);
        return;
      }

      // Must have access_token and type=recovery for password reset
      if (!access_token || type !== 'recovery') {
        console.log("Missing required parameters for password reset");
        setExpiredTokenError("Invalid password reset link. Please request a new one.");
        setIsTokenValid(false);
        return;
      }

      try {
        console.log("Establishing recovery session with access token...");
        
        // Use setSession to restore the recovery session
        const { data: { session }, error: sessionError } = await supabase.auth.setSession({
          access_token,
          refresh_token: refresh_token || ''
        });
        
        if (sessionError) {
          console.error("Session error:", sessionError);
          throw new Error(sessionError.message);
        }
        
        if (!session?.user) {
          console.error("No session or user after setSession");
          throw new Error("Failed to establish recovery session");
        }
        
        console.log("Recovery session established successfully for:", session.user.email);
        setIsTokenValid(true);
        setEmail(session.user.email);
        
        // Keep URL parameters for the duration of the reset process
        // They will be cleared after successful password reset
        
      } catch (error: any) {
        console.error("Failed to establish recovery session:", error);
        setExpiredTokenError("The password reset link has expired or is invalid. Please request a new one.");
        setIsTokenValid(false);
      }
    };
    
    setupSession();
  }, []);

  return {
    isTokenValid,
    expiredTokenError,
    email
  };
};