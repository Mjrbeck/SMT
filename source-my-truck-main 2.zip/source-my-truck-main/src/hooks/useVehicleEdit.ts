
import { useState, useEffect, useCallback, useRef } from "react";
import { useParams, useSearchParams, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";
import { getErrorMessage } from "@/utils/errorHandling";

interface UploadedImage {
  url: string;
  isMain: boolean;
}

export const useVehicleEdit = () => {
  const [vehicleData, setVehicleData] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [existingVehicleId, setExistingVehicleId] = useState<string | null>(null);
  const [existingImages, setExistingImages] = useState<UploadedImage[]>([]);
  const [error, setError] = useState<string | null>(null);
  const isFetchingRef = useRef(false);
  const hasInitialFetchCompletedRef = useRef(false);
  const prevVehicleIdRef = useRef<string | null>(null);
  
  const navigate = useNavigate();
  const params = useParams();
  const [searchParams] = useSearchParams();
  const { user } = useAuth();

  useEffect(() => {
    const vehicleId = params.id || searchParams.get("edit");
    
    if (vehicleId && 
       (!hasInitialFetchCompletedRef.current || vehicleId !== prevVehicleIdRef.current)) {
      setIsEditMode(true);
      setExistingVehicleId(vehicleId);
      prevVehicleIdRef.current = vehicleId;
      fetchVehicleData(vehicleId);
    } else if (!vehicleId) {
      setIsEditMode(false);
      setExistingVehicleId(null);
      hasInitialFetchCompletedRef.current = false;
      prevVehicleIdRef.current = null;
    }
  }, [params, searchParams, user]);

  const fetchVehicleData = useCallback(async (vehicleId: string) => {
    if (!vehicleId) {
      setError("No vehicle ID provided");
      return;
    }
    
    if (isFetchingRef.current) {
      return;
    }
    
    try {
      isFetchingRef.current = true;
      setIsLoading(true);
      setError(null);
      
      if (!user) {
        setError("You must be logged in to edit a vehicle");
        navigate("/login");
        return;
      }
      
      const { data: vehicleData, error: vehicleError } = await supabase
        .from("vehicles")
        .select("*")
        .eq("id", vehicleId)
        .maybeSingle();

      if (vehicleError) {
        console.error("Error fetching vehicle data:", vehicleError);
        setError(getErrorMessage(vehicleError));
        return;
      }

      if (!vehicleData) {
        setError("Vehicle not found");
        return;
      }

      if (user && vehicleData.user_id !== user.id) {
        setError("You do not have permission to edit this vehicle");
        navigate("/inventory");
        return;
      }

      const { data: imageData, error: imageError } = await supabase
        .from("vehicle_images")
        .select("*")
        .eq("vehicle_id", vehicleId)
        .order('order', { ascending: true });

      if (imageError) {
        console.error("Error fetching vehicle images:", imageError);
      }

      // Explicitly convert mileage to string for the form
      let mileageStr = '';
      if (vehicleData.mileage !== null && vehicleData.mileage !== undefined) {
        mileageStr = vehicleData.mileage.toString();
      }

      // Explicitly convert model to string for the form
      const modelStr = vehicleData.model !== null && vehicleData.model !== undefined ? 
        vehicleData.model.toString() : '';

      // Ensure we have a video_url field - access as a property using bracket notation to avoid TypeScript errors
      const videoUrl = vehicleData['video_url'] || "";

      const formattedData = {
        id: vehicleData.id,
        make: vehicleData.make || "",
        model: modelStr,
        year: vehicleData.year?.toString() || "",
        registration: vehicleData.registration || "",
        bodyType: vehicleData.body_type || "",
        engineSize: vehicleData.engine_size || "",
        fuelType: vehicleData.fuel_type || "",
        transmission: vehicleData.transmission || "",
        axleConfiguration: vehicleData.axle_configuration || "",
        weight: vehicleData.weight?.toString() || "",
        location: vehicleData.location || "",
        description: vehicleData.description || "",
        price: vehicleData.price?.toString() || "",
        isPOA: vehicleData.is_poa || false,
        status: vehicleData.status || "active",
        features: vehicleData.features || [],
        color: vehicleData.color || "",
        interiorCondition: vehicleData.interior_condition || "",
        exteriorCondition: vehicleData.exterior_condition || "",
        mileage: mileageStr,
        
        cabType: vehicleData.cab_type || "",
        driverPosition: vehicleData.driver_position || "",
        enginePower: vehicleData.engine_power || "",
        emissionsClass: vehicleData.emissions_class || "",
        numberOfSeats: vehicleData.number_of_seats?.toString() || "",
        grossVehicleWeight: vehicleData.gross_vehicle_weight?.toString() || "",
        volume: vehicleData.volume || "",
        internalLength: vehicleData.internal_length?.toString() || "",
        internalWidth: vehicleData.internal_width?.toString() || "",
        internalHeight: vehicleData.internal_height?.toString() || "",
        externalLength: vehicleData.external_length?.toString() || "",
        externalWidth: vehicleData.external_width?.toString() || "",
        externalHeight: vehicleData.external_height?.toString() || "",
        isNew: vehicleData.is_new || false,
        listingTier: vehicleData.listing_tier || "standard",
        videoUrl: videoUrl
      };

      const formattedImages = (imageData || []).map((img: any) => ({
        url: img.image_url,
        isMain: !!img.is_main
      }));

      setVehicleData(formattedData);
      setExistingImages(formattedImages);
      hasInitialFetchCompletedRef.current = true;
    } catch (error) {
      console.error("Error in fetchVehicleData:", error);
      setError(getErrorMessage(error));
    } finally {
      setIsLoading(false);
      isFetchingRef.current = false;
    }
  }, [navigate, user]);

  const updateVehicleData = useCallback((newData: any) => {
    if (typeof newData === 'function') {
      console.error("Received function instead of data in updateVehicleData");
      return;
    }
    
    if (!newData || typeof newData !== 'object') {
      console.error("Invalid data received in updateVehicleData:", newData);
      return;
    }
    
    setVehicleData((prevData: any) => {
      if (!prevData) return newData;
      
      return { ...prevData, ...newData };
    });
  }, []);

  return {
    vehicleData,
    isLoading,
    isEditMode,
    existingVehicleId,
    existingImages,
    error,
    setVehicleData
  };
};
