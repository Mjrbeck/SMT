import { useState, useEffect } from 'react';

export const useSectionVisibility = (sectionId: string, defaultVisible: boolean = true) => {
  const storageKey = `dashboard-section-${sectionId}`;
  
  const [isVisible, setIsVisible] = useState(() => {
    const saved = localStorage.getItem(storageKey);
    return saved !== null ? JSON.parse(saved) : defaultVisible;
  });

  const toggleVisibility = () => {
    const newVisibility = !isVisible;
    setIsVisible(newVisibility);
    localStorage.setItem(storageKey, JSON.stringify(newVisibility));
  };

  useEffect(() => {
    localStorage.setItem(storageKey, JSON.stringify(isVisible));
  }, [isVisible, storageKey]);

  return { isVisible, toggleVisibility };
};