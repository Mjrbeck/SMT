import { useState, useEffect, useCallback, useRef } from "react";
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from "@/integrations/supabase/client";
import { ProfileData } from "@/components/profile/types";
import { useAsyncExecution } from "@/hooks/useAsyncExecution";
import { toast } from "@/hooks/use-toast";

export const useProfileData = () => {
  const { user } = useAuth();
  const [profile, setProfile] = useState<ProfileData | null>(null);
  const { isLoading, executeWithLoading, stopLoading, startLoading } = useAsyncExecution(true);
  const [retryCount, setRetryCount] = useState(0);
  const [fetchError, setFetchError] = useState<Error | null>(null);
  const isFetchingRef = useRef(false);
  const abortControllerRef = useRef<AbortController | null>(null);
  const lastFetchTimeRef = useRef<number>(0);
  const fetchThrottleTime = 30000; // 30 seconds throttle
  const MAX_RETRIES = 3;

  const fetchProfile = useCallback(async () => {
    if (!user) {
      console.log("No user found, skipping profile fetch");
      stopLoading();
      return undefined;
    }
    
    // Add throttling to prevent rapid consecutive fetches
    const now = Date.now();
    if (now - lastFetchTimeRef.current < fetchThrottleTime && profile !== null) {
      console.log("Throttling profile fetch, using cached data");
      return profile;
    }
    
    // Prevent multiple simultaneous fetches using a ref
    if (isFetchingRef.current) {
      console.log("Already fetching profile, skipping duplicate request");
      return undefined;
    }
    
    // Cancel any existing fetch
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    abortControllerRef.current = new AbortController();
    
    startLoading();
    isFetchingRef.current = true;
    lastFetchTimeRef.current = now;
    
    try {
      console.log('Fetching profile for user:', user.id);
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .maybeSingle();
        
      if (error) {
        console.error('Error fetching profile:', error);
        setFetchError(new Error(error.message));
        
        // Create a default profile if none exists
        if (error.code === 'PGRST116' && retryCount < MAX_RETRIES) {
          // Record not found, create one
          console.log("Profile not found, creating default profile...");
          setRetryCount(prev => prev + 1);
          
          const defaultProfile = {
            id: user.id,
            company_name: 'My Company',
            credits: 1,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString()
          };
          
          const { error: insertError } = await supabase
            .from('profiles')
            .insert(defaultProfile);
            
          if (insertError) {
            console.error('Error creating default profile:', insertError);
            setFetchError(new Error(insertError.message));
            toast({
              title: "Profile error",
              description: "Could not create default profile",
              variant: "destructive",
            });
            isFetchingRef.current = false;
            stopLoading();
            return undefined;
          }
          
          console.log("Default profile created:", defaultProfile);
          setProfile(defaultProfile as ProfileData);
          setFetchError(null);
          isFetchingRef.current = false;
          stopLoading();
          return defaultProfile as ProfileData;
        }
        
        if (retryCount >= MAX_RETRIES) {
          toast({
            title: "Profile error",
            description: "Failed to load profile data",
            variant: "destructive",
          });
        }
        isFetchingRef.current = false;
        stopLoading();
        return undefined;
      }
      
      // If we have data, use it
      if (data) {
        console.log("Profile fetched successfully:", data);
        setProfile(data);
        setFetchError(null);
        setRetryCount(0);
        isFetchingRef.current = false;
        stopLoading();
        return data;
      }
      
      // If no data and no error, create a default profile
      if (!data && retryCount < MAX_RETRIES) {
        console.log("No profile found, creating default profile...");
        setRetryCount(prev => prev + 1);
        
        const defaultProfile = {
          id: user.id,
          company_name: 'My Company',
          credits: 1,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        };
        
        const { error: insertError } = await supabase
          .from('profiles')
          .insert(defaultProfile);
          
        if (insertError) {
          console.error('Error creating default profile:', insertError);
          setFetchError(new Error(insertError.message));
          toast({
            title: "Profile error",
            description: "Could not create default profile",
            variant: "destructive",
          });
          isFetchingRef.current = false;
          stopLoading();
          return undefined;
        }
        
        console.log("Default profile created:", defaultProfile);
        setProfile(defaultProfile as ProfileData);
        setFetchError(null);
        isFetchingRef.current = false;
        stopLoading();
        return defaultProfile as ProfileData;
      }
      
      isFetchingRef.current = false;
      stopLoading();
      return undefined;
    } catch (error) {
      console.error('Error fetching profile:', error);
      setFetchError(error instanceof Error ? error : new Error(String(error)));
      if (retryCount >= MAX_RETRIES) {
        toast({
          title: "Connection error",
          description: "Could not connect to the server",
          variant: "destructive",
        });
      }
      isFetchingRef.current = false;
      stopLoading();
      return undefined;
    } finally {
      isFetchingRef.current = false;
      abortControllerRef.current = null;
    }
  }, [user, stopLoading, startLoading, retryCount, profile]);

  // Run this effect ONLY when user changes, not on every mount
  useEffect(() => {
    let mounted = true;

    if (user && mounted && !profile) {
      fetchProfile();
    } else {
      stopLoading();
    }

    return () => {
      mounted = false;
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      }
    };
  }, [user, fetchProfile, stopLoading, profile]);

  // Add a function to force refresh profile after Stripe payment
  const refreshProfileAfterPayment = useCallback(async () => {
    console.log("Force refreshing profile after Stripe payment");
    // Clear any fetch state
    isFetchingRef.current = false;
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
    
    // Reset retry count to ensure we get fresh data
    setRetryCount(0);
    lastFetchTimeRef.current = 0; // Reset throttling
    
    // Directly fetch profile with fresh request
    return await fetchProfile();
  }, [fetchProfile]);

  return {
    profile,
    isLoading,
    setProfile,
    fetchProfile,
    refreshProfileAfterPayment,
    error: fetchError
  };
};
