
import { useState, useEffect, useCallback, useRef, useMemo } from "react";
import { 
  getUserMessages, 
  getUnreadMessageCount, 
  markMessageAsRead, 
  deleteMessage,
  toggleMessageImportance,
  Message 
} from "@/services/messages";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export const useMessages = () => {
  const { isAuthenticated, user } = useAuth();
  const [messages, setMessages] = useState<Message[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const messagesCache = useRef<{[key: string]: Message[]}>({});
  const lastFetchTime = useRef<number>(0);
  const isFetching = useRef(false);

  // Cache messages in localStorage for immediate loading
  const saveMessagesToCache = useCallback((msgs: Message[]) => {
    try {
      if (user?.id) {
        const cache = {
          messages: msgs,
          timestamp: Date.now()
        };
        localStorage.setItem(`messages_${user.id}`, JSON.stringify(cache));
      }
    } catch (e) {
      console.warn("Failed to cache messages");
    }
  }, [user]);

  // Load cached messages 
  const loadCachedMessages = useCallback(() => {
    try {
      if (user?.id) {
        const cached = localStorage.getItem(`messages_${user.id}`);
        if (cached) {
          const { messages: cachedMessages, timestamp } = JSON.parse(cached);
          // Only use cache if less than 5 minutes old
          if (Date.now() - timestamp < 5 * 60 * 1000) {
            return cachedMessages;
          }
        }
      }
    } catch (e) {
      console.warn("Failed to load cached messages");
    }
    return null;
  }, [user]);

  const fetchMessages = useCallback(async (force = false) => {
    if (!isAuthenticated) return;
    
    // Prevent concurrent fetches
    if (isFetching.current) return;
    
    // Throttle requests (1 per second) unless forced
    const now = Date.now();
    if (!force && now - lastFetchTime.current < 1000) return;
    
    lastFetchTime.current = now;
    isFetching.current = true;
    
    // Use cached messages initially
    const cachedMessages = loadCachedMessages();
    if (cachedMessages && !force) {
      setMessages(cachedMessages);
    }
    
    // Only show loading indicator for first load or forced refresh
    const shouldShowLoading = !cachedMessages || force;
    if (shouldShowLoading) {
      setIsLoading(true);
    }
    
    setError(null);
    
    try {
      const { messages, error } = await getUserMessages();
      if (error) {
        setError(error);
      } else {
        setMessages(messages);
        saveMessagesToCache(messages);
      }
      
      const { count, error: countError } = await getUnreadMessageCount();
      if (!countError) {
        setUnreadCount(count);
      }
    } catch (err) {
      setError("Failed to load messages");
      console.error(err);
    } finally {
      setIsLoading(false);
      isFetching.current = false;
    }
  }, [isAuthenticated, loadCachedMessages, saveMessagesToCache]);

  const markAsRead = useCallback(async (messageId: string) => {
    if (!isAuthenticated) return;
    
    const { success } = await markMessageAsRead(messageId);
    if (success) {
      setMessages((prevMessages) =>
        prevMessages.map((msg) =>
          msg.id === messageId ? { ...msg, is_read: true } : msg
        )
      );
      
      setUnreadCount((prev) => Math.max(0, prev - 1));
    }
  }, [isAuthenticated]);

  const handleDeleteMessage = useCallback(async (messageId: string) => {
    if (!isAuthenticated) return false;
    
    const { success, error } = await deleteMessage(messageId);
    if (success) {
      // Immediately remove the message from state
      setMessages((prevMessages) => 
        prevMessages.filter((msg) => msg.id !== messageId)
      );
      
      // Update unread count if the deleted message was unread
      const wasUnread = messages.find(m => m.id === messageId)?.is_read === false;
      if (wasUnread) {
        setUnreadCount((prev) => Math.max(0, prev - 1));
      }
      
      toast.success("Message deleted successfully");
      return true;
    } else {
      toast.error(error || "Failed to delete message");
      return false;
    }
  }, [isAuthenticated, messages]);

  const handleToggleImportant = useCallback(async (messageId: string, isImportant: boolean) => {
    if (!isAuthenticated) return;
    
    const { success, error } = await toggleMessageImportance(messageId, isImportant);
    if (success) {
      setMessages((prevMessages) =>
        prevMessages.map((msg) =>
          msg.id === messageId ? { ...msg, is_important: isImportant } : msg
        )
      );
      toast.success(isImportant ? "Marked as important" : "Unmarked as important");
    } else {
      toast.error(error || "Failed to update message");
    }
  }, [isAuthenticated]);

  // Memoize messages to prevent unnecessary re-renders
  const memoizedMessages = useMemo(() => messages, [messages]);

  // Set up Supabase realtime subscription for new messages
  useEffect(() => {
    if (!isAuthenticated || !user?.id) return;

    const subscription = supabase
      .channel('public:messages')
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'messages',
        filter: `recipient_id=eq.${user.id}`,
      }, () => {
        fetchMessages(true);
      })
      .on('postgres_changes', {
        event: 'DELETE',
        schema: 'public',
        table: 'messages',
      }, () => {
        // Refresh messages when a message is deleted via another client
        fetchMessages(true);
      })
      .subscribe();

    return () => {
      supabase.removeChannel(subscription);
    };
  }, [isAuthenticated, user, fetchMessages]);

  // Initial fetch
  useEffect(() => {
    fetchMessages();
  }, [fetchMessages]);

  return {
    messages: memoizedMessages,
    unreadCount,
    isLoading,
    error,
    fetchMessages,
    markAsRead,
    deleteMessage: handleDeleteMessage,
    toggleImportant: handleToggleImportant,
  };
};
