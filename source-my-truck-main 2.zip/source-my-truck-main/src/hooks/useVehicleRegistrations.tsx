
import { useState, useEffect } from "react";
import { Message } from "@/services/messages";
import { getVehicleById } from "@/services/vehicles/vehicleQueryService";

export const useVehicleRegistrations = (messages: Message[]) => {
  const [vehicleRegistrations, setVehicleRegistrations] = useState<Record<string, string>>({});
  const [loadingVehicles, setLoadingVehicles] = useState(false);

  useEffect(() => {
    const fetchVehicleRegistrations = async () => {
      const vehicleIds = messages
        .map(msg => msg.vehicle_id)
        .filter((id): id is string => id !== undefined && id !== null);
      
      const uniqueVehicleIds = [...new Set(vehicleIds)];
      
      if (uniqueVehicleIds.length === 0) return;
      
      setLoadingVehicles(true);
      const registrationMap: Record<string, string> = {};
      
      try {
        for (const vehicleId of uniqueVehicleIds) {
          const vehicle = await getVehicleById(vehicleId);
          if (vehicle && vehicle.registration) {
            registrationMap[vehicleId] = vehicle.registration;
          } else {
            registrationMap[vehicleId] = "Unknown registration";
          }
        }
      } catch (error) {
        console.error("Error fetching vehicle registrations:", error);
      } finally {
        setLoadingVehicles(false);
      }
      
      setVehicleRegistrations(registrationMap);
    };
    
    if (messages.length > 0) {
      fetchVehicleRegistrations();
    }
  }, [messages]);

  return {
    vehicleRegistrations,
    loadingVehicles
  };
};
