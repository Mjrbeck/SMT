
import { useRef, useCallback } from "react";

/**
 * A hook to track page paths to avoid redundant fetches
 * when users navigate between different pages
 */
export const usePathTracker = () => {
  const previousPathRef = useRef("");
  const pageFetchedRef = useRef(false);
  
  /**
   * Set whether the current page has had data fetched
   */
  const setPageFetched = useCallback((fetched: boolean, path?: string) => {
    pageFetchedRef.current = fetched;
    if (path) {
      previousPathRef.current = path;
    }
  }, []);

  /**
   * Check if the current page has already fetched data
   * Returns false if the path has changed, true if fetched for current path
   */
  const hasPageFetched = useCallback((currentPath?: string) => {
    if (currentPath && previousPathRef.current !== currentPath) {
      // If the path has changed, consider it not fetched
      return false;
    }
    return pageFetchedRef.current;
  }, []);

  return {
    previousPathRef,
    pageFetchedRef,
    setPageFetched,
    hasPageFetched
  };
};
