import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { ProfileData } from "@/components/profile/types";
import { toast } from "@/hooks/use-toast";
import { useAsyncExecution } from "./useAsyncExecution";

export function useCompanyFormUpdate({
  profile,
  user,
  onProfileUpdate
}: {
  profile: ProfileData;
  user: { id: string; email?: string } | null;
  onProfileUpdate: (updatedProfile: ProfileData) => void;
}) {
  const [companyName, setCompanyName] = useState(profile.company_name);
  const [companyPhone, setCompanyPhone] = useState(profile.company_phone || "");
  const [companyAddress, setCompanyAddress] = useState(profile.company_address || "");
  const [companyDescription, setCompanyDescription] = useState(profile.company_description || "");
  const [logoUrl, setLogoUrl] = useState(profile.logo_url || "");
  const { isLoading, executeWithLoading } = useAsyncExecution();

  const resetForm = () => {
    setCompanyName(profile.company_name);
    setCompanyPhone(profile.company_phone || "");
    setCompanyAddress(profile.company_address || "");
    setCompanyDescription(profile.company_description || "");
    setLogoUrl(profile.logo_url || "");
  };

  const handleUpdateCompany = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user || !profile) return;
    
    await executeWithLoading(async () => {
      try {
        // Create a data object with all the fields, explicitly handling nullable fields
        const updateData = {
          company_name: companyName.trim(),
          company_phone: companyPhone.trim() || null,
          company_address: companyAddress.trim() || null,
          // Ensure description is properly formatted for database
          company_description: companyDescription.trim() || null,
          logo_url: logoUrl
        };
        
        console.log('Updating profile with data:', updateData);
        
        // Immediately show a loading toast
        toast({
          title: "Updating profile",
          description: "Saving your changes...",
        });
        
        // Perform the update operation separately
        const { error } = await supabase
          .from('profiles')
          .update(updateData)
          .eq('id', user.id);
          
        if (error) {
          console.error('Supabase error updating profile:', error);
          toast({
            title: "Update failed",
            description: error.message || "There was a problem updating your profile.",
            variant: "destructive",
          });
          throw error;
        }
        
        console.log('Profile updated successfully, fetching latest data');
        
        // If update was successful, fetch the latest data in a separate query
        const { data: updatedData, error: fetchError } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', user.id)
          .single();
          
        if (fetchError) {
          console.error('Error fetching updated profile:', fetchError);
          // Continue with local data even if fetch fails
          // Don't throw error here to allow the update to be considered successful
        } else {
          console.log('Profile fetched after update:', updatedData);
        }
        
        // Use either the fetched data or the local data
        const updatedProfile = updatedData || {
          ...profile,
          ...updateData
        };
        
        onProfileUpdate(updatedProfile);
        
        // Show success toast
        toast({
          title: "Profile updated",
          description: "Your company profile has been updated successfully.",
        });

        return true;
      } catch (error: any) {
        console.error('Error updating profile:', error);
        toast({
          title: "Update failed",
          description: error.message || "There was a problem updating your profile.",
          variant: "destructive",
        });
        return false;
      }
    });
  };

  return {
    formState: {
      companyName,
      companyPhone,
      companyAddress,
      companyDescription,
      logoUrl,
    },
    setters: {
      setCompanyName,
      setCompanyPhone,
      setCompanyAddress,
      setCompanyDescription,
      setLogoUrl,
    },
    isLoading,
    handleUpdateCompany,
    resetForm
  };
}
