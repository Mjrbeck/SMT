
import { useState, useCallback, useEffect, useRef } from "react";
import { ProfileData, Transaction } from "@/components/profile/types";
import { useProfileData } from "@/hooks/useProfileData";
import { useTransactionHistory } from "@/hooks/useTransactionHistory";
import { useRetryWithTimeout } from "@/hooks/useRetryWithTimeout";
import { toast } from "@/hooks/use-toast";
import { useSearchParams } from "react-router-dom";
import { forceUpdateCredits } from "@/services/credits";
import { useAuth } from "@/contexts/AuthContext";

export const useProfileProvider = () => {
  const { user } = useAuth();
  const { 
    profile, 
    isLoading: profileLoading, 
    setProfile, 
    fetchProfile,
    refreshProfileAfterPayment,
    error: profileError 
  } = useProfileData();
  
  const { 
    transactions, 
    isLoading: transactionsLoading,
    error: transactionsError,
    fetchTransactionHistory,
    setHasFetched
  } = useTransactionHistory();

  const [isError, setIsError] = useState(false);
  const initialLoadRef = useRef(true);
  const initialLoadAttemptedRef = useRef(false);
  const isMountedRef = useRef(true);
  const dataLoadTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const fetchingDataRef = useRef(false);
  const refreshTriggerCountRef = useRef(0);
  const stripeRedirectProcessedRef = useRef(false);
  const [searchParams] = useSearchParams();
  const testModeRecoveryAttemptedRef = useRef(false);
  const creditRecoveryCompletedRef = useRef(false);
  const refreshDebounceTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const lastRefreshTimeRef = useRef<number>(0);
  const REFRESH_THROTTLE_TIME = 60000; // 1 minute throttle

  const isLoading = profileLoading || transactionsLoading;

  const handleRefreshData = useCallback(async (force = false) => {
    const now = Date.now();
    if (!force && now - lastRefreshTimeRef.current < REFRESH_THROTTLE_TIME) {
      console.log("Throttling data refresh, too soon since last refresh");
      return;
    }
    
    if ((retryState.isRefreshing || fetchingDataRef.current) && !force) {
      console.log("Already refreshing data, skipping duplicate request");
      return;
    }

    if (refreshDebounceTimeoutRef.current) {
      clearTimeout(refreshDebounceTimeoutRef.current);
    }

    refreshDebounceTimeoutRef.current = setTimeout(async () => {
      const currentTriggerCount = ++refreshTriggerCountRef.current;
      console.log(`Refreshing profile data... (trigger #${currentTriggerCount})`);
      
      retryState.setRefreshingState(true);
      fetchingDataRef.current = true;
      lastRefreshTimeRef.current = now;
      setIsError(false);
      
      try {
        const profileData = await fetchProfile();
        
        if (profileData) {
          await fetchTransactionHistory(force);
          retryState.resetRetryAttempts();
        } else {
          retryState.incrementRetryAttempts();
          console.warn(`Failed to fetch profile data (attempt ${retryState.refreshAttempts + 1})`);
        }
      } catch (error) {
        console.error("Error refreshing data:", error);
        retryState.incrementRetryAttempts();
        
        if (retryState.refreshAttempts > 2) {
          setIsError(true);
          toast({
            title: "Connection issue",
            description: "Could not connect to the server. Please check your internet connection.",
            variant: "destructive",
          });
        }
      } finally {
        if (isMountedRef.current && currentTriggerCount === refreshTriggerCountRef.current) {
          retryState.setRefreshingState(false);
          fetchingDataRef.current = false;
        }
      }
    }, 500);
  }, [
    fetchProfile, 
    fetchTransactionHistory
  ]);

  const retryState = useRetryWithTimeout({
    onRetry: handleRefreshData
  });

  const handleTestModeRecovery = useCallback(async (amount: number): Promise<boolean> => {
    if (!user || testModeRecoveryAttemptedRef.current || !amount || creditRecoveryCompletedRef.current) return false;
    
    testModeRecoveryAttemptedRef.current = true;
    console.log("Test mode recovery initiated for amount:", amount);
    
    try {
      toast({
        title: "Processing test payment",
        description: "Adding credits directly in test mode...",
        duration: 3000,
      });
      
      const result = await forceUpdateCredits(amount);
      
      if (result.success) {
        console.log("Test mode credit update successful! New balance:", result.newBalance);
        
        if (profile) {
          setProfile({
            ...profile,
            credits: result.newBalance || 0
          });
        }
        
        toast({
          title: "Credits added",
          description: `${amount} credits have been added to your account.`,
          duration: 5000,
        });
        
        localStorage.removeItem('pendingTransactionId');
        localStorage.removeItem('pendingTransactionAmount');
        localStorage.removeItem('stripeSessionId');
        localStorage.removeItem('sessionTimestamp');
        
        creditRecoveryCompletedRef.current = true;
        
        await fetchProfile();
        await fetchTransactionHistory(true);
        
        return true;
      } else {
        console.error("Test mode credit update failed:", result.error);
      }
    } catch (error) {
      console.error("Error in test mode credit recovery:", error);
    }
    
    return false;
  }, [user, profile, setProfile, fetchProfile, fetchTransactionHistory]);

  useEffect(() => {
    const success = searchParams.get('success');
    const sessionId = searchParams.get('session_id');
    
    if (success === 'true' && sessionId && !stripeRedirectProcessedRef.current) {
      console.log("Payment success detected, scheduling refreshes");
      
      stripeRedirectProcessedRef.current = true;
      
      const purchasedAmount = parseInt(localStorage.getItem('pendingTransactionAmount') || '0');
      
      if (window.history && window.history.replaceState) {
        const cleanUrl = window.location.pathname + '?tab=credits';
        window.history.replaceState({}, document.title, cleanUrl);
      }
      
      if (purchasedAmount > 0 && !creditRecoveryCompletedRef.current) {
        setTimeout(() => {
          if (!creditRecoveryCompletedRef.current) {
            handleTestModeRecovery(purchasedAmount);
          }
        }, 1500);
      }
      
      refreshProfileAfterPayment();
      
      handleRefreshData(true);
      
      setTimeout(() => {
        if (isMountedRef.current) {
          console.log(`Final profile refresh after delay`);
          handleRefreshData(true);
        }
      }, 5000);
    }
  }, [searchParams, handleRefreshData, refreshProfileAfterPayment, handleTestModeRecovery]);

  useEffect(() => {
    if (profileError !== null || transactionsError !== null) {
      setIsError(true);
    }
  }, [profileError, transactionsError]);

  useEffect(() => {
    if (isError && profile === null && !retryState.isRefreshing) {
      retryState.setupRetry();
    }
  }, [isError, profile, retryState]);

  useEffect(() => {
    if (isLoading && !isError) {
      retryState.setupLoadingTimeout(() => {
        if (profileLoading) {
          console.warn("Profile loading timed out after 10 seconds");
        }
      }, 10000);
    }
  }, [isLoading, isError, profileLoading, retryState]);

  useEffect(() => {
    isMountedRef.current = true;

    if (initialLoadRef.current && !initialLoadAttemptedRef.current) {
      initialLoadAttemptedRef.current = true;
      console.log("Initial profile data load triggered");
      
      dataLoadTimeoutRef.current = setTimeout(() => {
        if (isMountedRef.current) {
          handleRefreshData();
          initialLoadRef.current = false;
        }
      }, 500);
    }

    return () => {
      isMountedRef.current = false;
      if (dataLoadTimeoutRef.current) {
        clearTimeout(dataLoadTimeoutRef.current);
      }
      if (refreshDebounceTimeoutRef.current) {
        clearTimeout(refreshDebounceTimeoutRef.current);
      }
      setHasFetched(false);
    };
  }, [handleRefreshData, setHasFetched]);

  return {
    profile,
    isLoading,
    isError,
    transactions: transactions || [],
    fetchProfile,
    fetchTransactionHistory,
    setProfile,
    handleRefreshData,
    refreshProfileAfterPayment,
    handleTestModeRecovery,
  };
};
