
import * as React from "react"

const MOBILE_BREAKPOINT = 768

export function useIsMobile() {
  const [isMobile, setIsMobile] = React.useState<boolean | null>(null)

  React.useEffect(() => {
    // Initial check based on window width
    const checkMobile = () => setIsMobile(window.innerWidth < MOBILE_BREAKPOINT)
    
    // Set initial value
    checkMobile()
    
    // Add event listener for resize
    const mql = window.matchMedia(`(max-width: ${MOBILE_BREAKPOINT - 1}px)`)
    
    // Modern event listener approach
    try {
      // Modern browsers
      mql.addEventListener("change", checkMobile)
      return () => mql.removeEventListener("change", checkMobile)
    } catch (e) {
      // Fallback for older browsers
      console.warn("Using legacy matchMedia API", e)
      mql.addListener(checkMobile)
      return () => mql.removeListener(checkMobile)
    }
  }, [])

  // Return true as fallback until we know for sure
  return isMobile === null ? true : isMobile
}

// Export the breakpoint for reuse
export const MOBILE_BREAKPOINT_PX = MOBILE_BREAKPOINT
