
import { useState, useEffect, useRef } from "react";
import { clearUserData } from '@/utils/authUtils';
import { useNavigate } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import type { Session, User, AuthChangeEvent } from "@supabase/supabase-js";
import { useLoadingState } from "@/hooks/useLoadingState";
import { isTokenExpired, handleExpiredToken } from "@/services/credits/authService";

export function useAuthSession() {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const { isLoading, setIsLoading } = useLoadingState(true);
  const { toast } = useToast();
  const navigate = useNavigate();
  const initialAuthCheckDoneRef = useRef(false);
  const isNavigatingRef = useRef(false);
  const pendingNavigationRef = useRef<string | null>(null);
  const hasUserChangedRef = useRef(false);
  const isPasswordResetFlowRef = useRef(false);
  const isTokenExpiredRef = useRef(false);
  const hasShownExpiredToastRef = useRef(false);

  useEffect(() => {
    // Function to detect if current URL is a password reset flow or has expired token errors
    const isPasswordResetFlow = () => {
      const url = new URL(window.location.href);
      
      // Check if we're on the reset-password page or it has reset tokens
      const isReset = 
        url.pathname === '/reset-password' || 
        url.pathname === '/auth/callback' ||
        url.search.includes('type=recovery') || 
        url.search.includes('type=reset') || 
        url.hash.includes('type=recovery') || 
        url.hash.includes('type=reset') ||
        url.search.includes('access_token') ||
        url.hash.includes('access_token');
      
      // Check for expired token errors
      const hasExpiredToken = 
        url.hash.includes('error=access_denied') || 
        url.hash.includes('error_code=otp_expired') ||
        url.search.includes('error=access_denied') || 
        url.search.includes('error_code=otp_expired');
      
      if (hasExpiredToken) {
        isTokenExpiredRef.current = true;
      }
      
      return isReset || hasExpiredToken;
    };
    
    isPasswordResetFlowRef.current = isPasswordResetFlow();
    
    // If we detect recovery tokens on any page, immediately redirect to reset password page
    if (isPasswordResetFlowRef.current) {
      const url = new URL(window.location.href);
      if ((url.hash.includes('access_token') || url.search.includes('access_token') ||
           url.hash.includes('type=recovery') || url.search.includes('type=recovery')) && 
          url.pathname !== '/reset-password') {
        
        // Redirect to reset password page and let Supabase handle the recovery session
        const resetUrl = `/reset-password${url.hash}${url.search}`;
        navigate(resetUrl, { replace: true });
        return;
      }
    }
    
    // Set up initial session
    const getInitialSession = async () => {
      try {
        // If we detect expired tokens, sign out, but not for valid recovery flows on reset page
        if (isTokenExpiredRef.current && window.location.pathname !== '/reset-password') {
          await supabase.auth.signOut();
          setSession(null);
          setUser(null);
          initialAuthCheckDoneRef.current = true;
          setIsLoading(false);
          
          // If URL has access_token in hash but we're not on reset-password page, redirect there
          const url = new URL(window.location.href);
          if ((url.hash.includes('access_token') || url.search.includes('access_token')) && 
              url.pathname !== '/reset-password') {
            
            // Extract token and parameters
            const params = new URLSearchParams();
            
            // From hash
            if (url.hash) {
              const hashParams = new URLSearchParams(url.hash.substring(1));
              for (const [key, value] of hashParams.entries()) {
                params.append(key, value);
              }
            }
            
            // From search
            if (url.search) {
              const searchParams = new URLSearchParams(url.search);
              for (const [key, value] of searchParams.entries()) {
                if (!params.has(key)) {
                  params.append(key, value);
                }
              }
            }
            
            const resetUrl = `/reset-password?${params.toString()}`;
            navigate(resetUrl);
            return;
          }
          
          // If we have an expired token, redirect to reset-password with error
          if (isTokenExpiredRef.current && window.location.pathname !== '/reset-password') {
            const url = new URL(window.location.href);
            const errorParams = new URLSearchParams();
            
            const hashParams = new URLSearchParams(url.hash.substring(1));
            const searchParams = new URLSearchParams(url.search);
            
            // Extract error info from hash or search
            const errorSource = hashParams.has('error') ? hashParams : searchParams;
            
            if (errorSource.has('error')) {
              errorParams.set('error', errorSource.get('error') || '');
            }
            
            if (errorSource.has('error_code')) {
              errorParams.set('error_code', errorSource.get('error_code') || '');
            }
            
            if (errorSource.has('error_description')) {
              errorParams.set('error_description', errorSource.get('error_description') || '');
            }
            
            const resetUrl = `/reset-password?${errorParams.toString()}`;
            
            navigate(resetUrl);
          }
          
          return;
        }
        
        // For normal flows, get the session
        const { data, error } = await supabase.auth.getSession();
        
        if (error) {
          if (isTokenExpired(error)) {
            // Handle expired token
            await handleExpiredToken();
            if (!hasShownExpiredToastRef.current) {
              hasShownExpiredToastRef.current = true;
              toast({
                title: "Session expired",
                description: "Your session has expired. Please sign in again.",
              });
            }
          }
          setSession(null);
          setUser(null);
        } else {
          setSession(data.session);
          setUser(data.session?.user ?? null);
        }
        
        initialAuthCheckDoneRef.current = true;
        setIsLoading(false);
      } catch (error) {
        console.error("Error getting initial session:", error);
        setIsLoading(false);
      }
    };

    getInitialSession();

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, currentSession) => {
        // If we're on the reset-password page, allow password recovery flow to work normally
        if (window.location.pathname === '/reset-password') {
          console.log("useAuthSession: On reset page, event:", event);
          
          // For PASSWORD_RECOVERY and SIGNED_IN events, update the session
          if (event === "PASSWORD_RECOVERY" || event === "SIGNED_IN" || event === "TOKEN_REFRESHED") {
            console.log("useAuthSession: Updating session on reset page");
            setSession(currentSession);
            setUser(currentSession?.user ?? null);
            setIsLoading(false);
            return;
          }
          
          // CRITICAL: Ignore ALL SIGNED_OUT events on reset page to preserve recovery session
          if (event === "SIGNED_OUT") {
            console.log("useAuthSession: Ignoring SIGNED_OUT on reset page to preserve recovery session");
            return; // Don't clear the session!
          }
          
          // For other events on reset page, just ignore
          console.log("useAuthSession: Ignoring auth state change during password reset:", event);
          return;
        }
        
        // Handle token expired and user deleted events
        if ((event === "TOKEN_REFRESHED" && !currentSession) || event === ("USER_DELETED" as AuthChangeEvent)) {
          await supabase.auth.signOut();
          setSession(null);
          setUser(null);
          return;
        }
        
        // For non-reset pages, handle PASSWORD_RECOVERY by signing out
        if (event === "PASSWORD_RECOVERY") {
          await supabase.auth.signOut();
          setSession(null);
          setUser(null);
          return;
        }
        
        // Don't interfere with SIGNED_IN events from password recovery when not on reset page
        if (event === "SIGNED_IN" && (isPasswordResetFlowRef.current || isTokenExpiredRef.current)) {
          // Sign out to prevent confusion - user should be on reset page for recovery
          await supabase.auth.signOut();
          setSession(null);
          setUser(null);
          return;
        }
        // Handle token refreshes
        if (event === "TOKEN_REFRESHED") {
          // Session refreshed successfully
          hasShownExpiredToastRef.current = false;
        }
        
        // Check if user has actually changed to avoid unnecessary state updates
        const currentUser = currentSession?.user;
        const hasUserChanged = Boolean(
          (!user && currentUser) || 
          (user && !currentUser) || 
          (user?.id !== currentUser?.id)
        );
        
        // Only update if the session/user has actually changed
        if (hasUserChanged || event === "TOKEN_REFRESHED") {
          hasUserChangedRef.current = hasUserChanged;
          
          // Update the session and user state
          setSession(currentSession);
          setUser(currentSession?.user ?? null);
          setIsLoading(false);
        }
        
        // Only handle navigation and toasts on explicit sign in/out events,
        // not on initial session check, refreshes or token refreshes
        if (event === "SIGNED_IN" && initialAuthCheckDoneRef.current && 
            hasUserChanged && !isPasswordResetFlowRef.current && !isTokenExpiredRef.current) {
          if (isNavigatingRef.current) {
            pendingNavigationRef.current = "/dashboard";
            return;
          }
          
          isNavigatingRef.current = true;
          navigate("/dashboard");
          toast({
            title: "Signed in",
            description: "You have successfully signed in",
          });
          
          // Reset the flag after navigation
          setTimeout(() => {
            isNavigatingRef.current = false;
            if (pendingNavigationRef.current) {
              const destination = pendingNavigationRef.current;
              pendingNavigationRef.current = null;
              navigate(destination);
            }
          }, 500);
        } else if (event === "SIGNED_OUT" && hasUserChanged && window.location.pathname !== '/reset-password') {
          // Clear all user-specific cached data
          clearUserData();
          
          if (isNavigatingRef.current) {
            pendingNavigationRef.current = "/";
            return;
          }
          
          isNavigatingRef.current = true;
          
          // Only navigate to home page if not handling a password reset
          if (!isPasswordResetFlowRef.current && !isTokenExpiredRef.current) {
            navigate("/");
            
            // Only show the signed out toast for explicit user sign-outs,
            // not for token expirations or auto-logouts
            if (!hasShownExpiredToastRef.current) {
              toast({
                title: "Signed out",
                description: "You have been signed out",
              });
            }
          }
          
          // Reset the flag after navigation
          setTimeout(() => {
            isNavigatingRef.current = false;
            if (pendingNavigationRef.current) {
              const destination = pendingNavigationRef.current;
              pendingNavigationRef.current = null;
              navigate(destination);
            }
          }, 500);
        }
      }
    );

    return () => {
      subscription.unsubscribe();
    };
  }, [toast, navigate, setIsLoading, user]);

  return {
    session,
    user,
    isLoading,
    isAuthenticated: !!session
  };
}
