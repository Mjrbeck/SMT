
import { useQuery } from "@tanstack/react-query";
import { getVehicleById } from "@/services/vehicleService";
import { VehicleData } from "@/components/VehicleCard";
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export interface SellerDetails {
  name: string;
  initials: string;
  phone: string;
  location: string;
  isVerified: boolean;
  logoUrl?: string;
  id?: string;  // Add seller ID to interface
}

interface UseVehicleDetailsReturn {
  vehicle: VehicleData | null;
  sellerDetails: SellerDetails;
  isLoading: boolean;
  error: Error | null;
  refetch: () => Promise<any>; // Add the refetch function to the interface
}

const DEFAULT_SELLER: SellerDetails = {
  name: "Unknown Seller",
  initials: "?",
  phone: "Contact seller for details",
  location: "Location not available",
  isVerified: false
};

/**
 * Custom hook to fetch vehicle details and seller information
 */
export const useVehicleDetails = (id: string): UseVehicleDetailsReturn => {
  const [sellerDetails, setSellerDetails] = useState<SellerDetails>(DEFAULT_SELLER);

  // Validate the ID to prevent queries with invalid parameters
  const isValidId = id && id.trim() !== '' && id !== ':id' && !id.includes(':');

  // Use React Query v5 with proper error handling
  const result = useQuery({
    queryKey: ["vehicle", id],
    queryFn: async () => {
      if (!isValidId) {
        throw new Error('Invalid vehicle ID provided');
      }
      // Fetch vehicle
      const vehicle = await getVehicleById(id);
      return vehicle;
    },
    enabled: isValidId,
    staleTime: 300000, // 5 minutes
    retry: 2,
  });
  
  // Handle errors outside the useQuery options
  useEffect(() => {
    if (result.error) {
      console.error("Error fetching vehicle details:", result.error);
      toast.error("Could not load vehicle details");
    }
  }, [result.error]);

  useEffect(() => {
    const fetchSellerDetails = async () => {
      if (result.data?.user_id) {
        try {
          const { data: profileData, error: profileError } = await supabase
            .from("profiles")
            .select("company_name, company_phone, company_address, logo_url, id")
            .eq("id", result.data.user_id)
            .maybeSingle();
          
          if (profileError) {
            console.error("Error fetching seller details:", profileError);
            return;
          }
          
          if (profileData) {
            const companyName = profileData.company_name || "Unknown Seller";
            const initials = companyName
              .split(' ')
              .map(word => word[0])
              .join('')
              .substring(0, 2)
              .toUpperCase();
              
            setSellerDetails({
              name: companyName,
              initials: initials,
              phone: profileData.company_phone || "Contact seller for details",
              location: profileData.company_address || "Location not available",
              isVerified: true,
              logoUrl: profileData.logo_url || undefined,
              id: profileData.id  // Include seller's ID
            });
          }
        } catch (err) {
          console.error("Unexpected error fetching seller details:", err);
        }
      }
    };
    
    fetchSellerDetails();
  }, [result.data]);

  return {
    vehicle: result.data || null,
    sellerDetails,
    isLoading: result.isLoading,
    error: result.error,
    refetch: result.refetch // Expose the refetch function from the query result
  };
};
