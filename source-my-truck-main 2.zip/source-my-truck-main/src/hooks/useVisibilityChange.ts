
import { useEffect, useRef, useState } from 'react';

type VisibilityChangeHandler = (isVisible: boolean) => void;

/**
 * A hook to detect document visibility changes (when users switch tabs or minimize the browser)
 * without causing the app to refresh or reset form state. Also supports social media crawlers.
 * 
 * @param onVisibilityChange - Optional callback that fires when visibility changes
 * @returns Object containing the current visibility state
 */
export const useVisibilityChange = (onVisibilityChange?: VisibilityChangeHandler) => {
  const [isVisible, setIsVisible] = useState(true);
  const firstRenderRef = useRef(true);

  useEffect(() => {
    // Set initial state based on current visibility
    const initialState = document.visibilityState === 'visible';
    
    // Only update state if this isn't the first render
    if (!firstRenderRef.current) {
      setIsVisible(initialState);
    }
    firstRenderRef.current = false;
    
    const handleVisibilityChange = () => {
      const newVisibility = document.visibilityState === 'visible';
      
      // Update the visible state
      setIsVisible(newVisibility);
      
      // Call the callback if provided
      if (onVisibilityChange) {
        onVisibilityChange(newVisibility);
      }
      
      // Prevent default behavior that might interfere with sharing
      return false;
    };

    // Add event listener with passive option to not interfere with default behavior
    // This is important for social media crawlers
    document.addEventListener('visibilitychange', handleVisibilityChange, { passive: true });
    
    // Clean up
    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [onVisibilityChange]);

  return { isVisible };
};
