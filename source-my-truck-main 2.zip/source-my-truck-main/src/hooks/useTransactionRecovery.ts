
import { useState, useCallback, useRef } from 'react';
import { toast } from '@/hooks/use-toast';
import { checkTransactionStatus } from '@/services/credits/transactionService';

export const useTransactionRecovery = (refreshCallback: () => Promise<void>) => {
  const [isRecovering, setIsRecovering] = useState(false);
  const recoveryAttemptedRef = useRef(false);
  const recoveryCompletedRef = useRef(false);

  // Handle successful payment, including storing session info for recovery
  const handleSuccessfulPayment = useCallback((sessionId: string, user: any) => {
    console.log("Payment successful, session ID:", sessionId);
    
    // Store info in localStorage for potential recovery
    const pendingAmount = parseInt(localStorage.getItem('pendingTransactionAmount') || '0');
    if (pendingAmount > 0) {
      localStorage.setItem('stripeSessionId', sessionId);
      localStorage.setItem('sessionTimestamp', Date.now().toString());
    }
    
    // Recovery will be handled by the regular profile refresh mechanisms
    // Don't attempt direct recovery here to avoid double-crediting
  }, []);

  // Check if there's a stored session from a past payment that needs recovery
  const checkForPastRecoveryNeeded = useCallback((user: any) => {
    if (!user || recoveryAttemptedRef.current || recoveryCompletedRef.current) return;
    
    const storedSessionId = localStorage.getItem('stripeSessionId');
    const sessionTimestamp = parseInt(localStorage.getItem('sessionTimestamp') || '0');
    const pendingTransactionId = localStorage.getItem('pendingTransactionId');
    const pendingAmount = parseInt(localStorage.getItem('pendingTransactionAmount') || '0');
    
    // Only attempt recovery if we have a stored session that's less than 1 hour old
    const isRecent = Date.now() - sessionTimestamp < 60 * 60 * 1000; // 1 hour
    
    if (storedSessionId && isRecent && pendingAmount > 0) {
      // Mark that we've attempted recovery
      recoveryAttemptedRef.current = true;
      
      console.log("Found stored session, will check transaction status:", {
        sessionId: storedSessionId,
        timestamp: new Date(sessionTimestamp).toISOString(),
        transactionId: pendingTransactionId,
        amount: pendingAmount
      });
      
      // Only log, don't attempt direct recovery to avoid double-crediting
      // The regular profile refresh will handle this
      toast({
        title: "Payment verification in progress",
        description: "We're verifying your recent payment...",
        duration: 5000,
      });
      
      // If we have a transaction ID, check its status
      if (pendingTransactionId) {
        checkTransactionStatusAndCleanup(pendingTransactionId);
      } else {
        // If no transaction ID, just clean up after refresh
        setTimeout(() => {
          refreshCallback().then(() => {
            cleanupStoredPaymentData();
            recoveryCompletedRef.current = true;
          });
        }, 1000);
      }
    }
  }, [refreshCallback]);

  // Check transaction status and clean up localStorage
  const checkTransactionStatusAndCleanup = useCallback(async (transactionId: string) => {
    try {
      setIsRecovering(true);
      const result = await checkTransactionStatus(transactionId);
      console.log(`Transaction ${transactionId} status check result:`, result);
      
      if (result.transaction && result.transaction.status === 'completed') {
        console.log("Transaction already completed, clearing stored data");
        toast({
          title: "Payment verified",
          description: "Your payment has been processed successfully.",
          duration: 3000,
        });
        cleanupStoredPaymentData();
        recoveryCompletedRef.current = true;
      } else if (result.transaction && result.transaction.status === 'pending') {
        console.log("Transaction still pending, will keep stored data for recovery");
        // Will be handled by the webhook eventually
      }
      
      // Refresh after checking status
      await refreshCallback();
      setIsRecovering(false);
    } catch (error) {
      console.error("Error checking transaction status:", error);
      setIsRecovering(false);
    }
  }, [refreshCallback]);

  // Clean up localStorage payment data
  const cleanupStoredPaymentData = useCallback(() => {
    console.log("Cleaning up stored payment data");
    localStorage.removeItem('stripeSessionId');
    localStorage.removeItem('sessionTimestamp');
    localStorage.removeItem('pendingTransactionId');
    localStorage.removeItem('pendingTransactionAmount');
  }, []);

  return {
    isRecovering,
    handleSuccessfulPayment,
    checkForPastRecoveryNeeded,
    cleanupStoredPaymentData
  };
};
