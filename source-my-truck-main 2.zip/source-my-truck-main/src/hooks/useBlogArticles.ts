
import { useQuery } from "@tanstack/react-query";
import { fetchBlogArticles, fetchBlogArticlesByCategory } from "@/services/blog/blogService";
import { BlogArticle } from "@/services/blog/types";

export const useBlogArticles = () => {
  return useQuery<BlogArticle[], Error>({
    queryKey: ["blogArticles"],
    queryFn: () => fetchBlogArticles(),
  });
};

export const useBlogArticlesByCategory = (category: string) => {
  return useQuery<BlogArticle[], Error>({
    queryKey: ["blogArticles", category],
    queryFn: () => fetchBlogArticlesByCategory(category),
    enabled: category !== "all", // Don't run this query if the category is "all"
  });
};
