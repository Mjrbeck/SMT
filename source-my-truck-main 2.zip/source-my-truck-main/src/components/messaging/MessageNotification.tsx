
import { useEffect } from "react";
import { Link } from "react-router-dom";
import { Mail } from "lucide-react";
import { useMessages } from "@/hooks/useMessages";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";

const MessageNotification = () => {
  const { isAuthenticated } = useAuth();
  const { unreadCount, fetchMessages } = useMessages();

  useEffect(() => {
    if (isAuthenticated) {
      fetchMessages();
    }
  }, [isAuthenticated, fetchMessages]);

  if (!isAuthenticated) return null;

  return (
    <Link to="/messages" className="relative">
      <Button 
        variant="ghost" 
        size="icon" 
        className="relative"
        aria-label={`Messages${unreadCount > 0 ? ` (${unreadCount} unread)` : ''}`}
      >
        <Mail className="h-5 w-5" />
        {unreadCount > 0 && (
          <span className="absolute -top-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full bg-red-500 text-xs text-white">
            {unreadCount > 9 ? '9+' : unreadCount}
          </span>
        )}
      </Button>
    </Link>
  );
};

export default MessageNotification;
