
import { useNavigate } from "react-router-dom";
import { Message } from "@/services/messages";
import { useMessages } from "@/hooks/useMessages";
import { useState, useEffect } from "react";
import MessageItem from "./MessageItem";
import EmptyMessages from "./EmptyMessages";
import MessagesSkeleton from "./MessagesSkeleton";
import DeleteMessageDialog from "./DeleteMessageDialog";
import { useVehicleRegistrations } from "@/hooks/useVehicleRegistrations";

interface MessagesListProps {
  messages: Message[];
  isLoading: boolean;
  onMessageDeleted?: () => void;
}

const MessagesList = ({ messages, isLoading, onMessageDeleted }: MessagesListProps) => {
  const navigate = useNavigate();
  const { deleteMessage, toggleImportant } = useMessages();
  const [messageToDelete, setMessageToDelete] = useState<string | null>(null);
  const [displayMessages, setDisplayMessages] = useState<Message[]>(messages);
  
  // Update displayMessages when the messages prop changes
  useEffect(() => {
    setDisplayMessages(messages);
  }, [messages]);
  
  // Fetch vehicle registrations for all messages
  const { vehicleRegistrations, loadingVehicles } = useVehicleRegistrations(displayMessages);

  if (isLoading) {
    return <MessagesSkeleton />;
  }

  if (displayMessages.length === 0) {
    return <EmptyMessages />;
  }

  const handleMessageClick = (messageId: string, e: React.MouseEvent) => {
    if ((e.target as HTMLElement).closest('.message-action')) {
      e.preventDefault();
      e.stopPropagation();
      return;
    }
    navigate(`/messages/${messageId}`);
  };

  const handleDeleteConfirm = (messageId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setMessageToDelete(messageId);
  };

  const handleDeleteMessage = async () => {
    if (!messageToDelete) return;
    
    try {
      const result = await deleteMessage(messageToDelete);
      if (result) {
        // Remove from local state immediately for better UX
        setDisplayMessages(prev => prev.filter(msg => msg.id !== messageToDelete));
        
        // Notify parent component that a message was deleted
        if (onMessageDeleted) {
          onMessageDeleted();
        }
      }
    } finally {
      setMessageToDelete(null);
    }
  };

  const handleToggleImportant = (messageId: string, isCurrentlyImportant: boolean | undefined, e: React.MouseEvent) => {
    e.stopPropagation();
    toggleImportant(messageId, !isCurrentlyImportant);
  };

  return (
    <>
      <ul className="divide-y divide-gray-200">
        {displayMessages.map((message) => (
          <MessageItem
            key={message.id}
            message={message}
            vehicleRegistration={message.vehicle_id ? vehicleRegistrations[message.vehicle_id] : null}
            loadingVehicle={loadingVehicles}
            onMessageClick={handleMessageClick}
            onDeleteClick={handleDeleteConfirm}
            onToggleImportant={handleToggleImportant}
          />
        ))}
      </ul>

      <DeleteMessageDialog
        isOpen={!!messageToDelete}
        onClose={() => setMessageToDelete(null)}
        onConfirm={handleDeleteMessage}
      />
    </>
  );
};

export default MessagesList;
