
import React from "react";

const MessagesSkeleton = () => {
  return (
    <div className="space-y-4 animate-in fade-in duration-200">
      {[...Array(3)].map((_, i) => (
        <div 
          key={i} 
          className="h-20 bg-gray-100 animate-pulse rounded-md transition-opacity"
          style={{ 
            animationDelay: `${i * 100}ms`,
            opacity: 0.9 - (i * 0.2)
          }}
        />
      ))}
    </div>
  );
};

export default React.memo(MessagesSkeleton);
