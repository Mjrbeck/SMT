import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { sendMessage } from "@/services/messages";
import { toast } from "sonner";
import { Reply } from "lucide-react";

interface ReplyMessageFormProps {
  originalMessage: {
    id: string;
    sender_id: string | null;
    subject: string;
    vehicle_id?: string | null;
    anonymous_sender_name?: string | null;
    anonymous_sender_email?: string | null;
  };
  onSuccess: () => void;
  onCancel: () => void;
}

const ReplyMessageForm = ({ originalMessage, onSuccess, onCancel }: ReplyMessageFormProps) => {
  const [replyContent, setReplyContent] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!replyContent.trim()) {
      toast.error("Please enter a reply message");
      return;
    }

    // Can't reply to anonymous messages (no sender_id)
    if (!originalMessage.sender_id) {
      toast.error("Cannot reply to anonymous messages");
      return;
    }

    setIsSubmitting(true);
    try {
      const { success, error } = await sendMessage({
        recipient_id: originalMessage.sender_id,
        subject: originalMessage.subject.startsWith("Re:") 
          ? originalMessage.subject 
          : `Re: ${originalMessage.subject}`,
        content: replyContent,
        vehicle_id: originalMessage.vehicle_id || undefined
      });

      if (success) {
        toast.success("Reply sent successfully!");
        onSuccess();
      } else {
        toast.error(error || "Failed to send reply");
      }
    } catch (error) {
      console.error("Error sending reply:", error);
      toast.error("An unexpected error occurred");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="border-t border-gray-200 mt-8">
      <div className="bg-gray-50 p-6 rounded-lg mt-6">
        <h3 className="text-lg font-semibold mb-6 flex items-center gap-2 text-gray-900">
          <Reply className="h-5 w-5 text-brand-blue" />
          Reply to this message
        </h3>
        
        {originalMessage.anonymous_sender_name && (
          <div className="mb-6 p-4 bg-amber-50 border border-amber-200 rounded-lg">
            <p className="text-sm text-amber-800">
              <strong>Note:</strong> This message was sent by an anonymous user ({originalMessage.anonymous_sender_name}). 
              They won&apos;t receive your reply through the internal messaging system.
            </p>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="reply-content" className="block text-sm font-medium text-gray-700 mb-3">
              Your Reply
            </label>
            <Textarea
              id="reply-content"
              value={replyContent}
              onChange={(e) => setReplyContent(e.target.value)}
              placeholder="Type your reply here..."
              rows={6}
              required
              disabled={!originalMessage.sender_id}
              className="min-h-[150px] resize-none"
            />
          </div>

          <div className="flex justify-end gap-3 pt-2">
            <Button type="button" variant="outline" onClick={onCancel} size="default">
              Cancel
            </Button>
            <Button 
              type="submit" 
              disabled={isSubmitting || !originalMessage.sender_id}
              className="bg-brand-blue hover:bg-brand-blue/90"
              size="default"
            >
              {isSubmitting ? "Sending..." : "Send Reply"}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ReplyMessageForm;