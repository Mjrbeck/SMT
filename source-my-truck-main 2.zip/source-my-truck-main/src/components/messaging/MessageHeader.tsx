
import React, { useState, useEffect } from "react";
import { format } from "date-fns";
import { Message } from "@/services/messages";
import { getVehicleById } from "@/services/vehicles/vehicleQueryService";

interface MessageHeaderProps {
  message: Message;
}

const MessageHeader = ({ message }: MessageHeaderProps) => {
  const [vehicleRegistration, setVehicleRegistration] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  
  useEffect(() => {
    const fetchVehicleDetails = async () => {
      if (message.vehicle_id) {
        setIsLoading(true);
        try {
          const vehicle = await getVehicleById(message.vehicle_id);
          if (vehicle && vehicle.registration && 
              vehicle.registration !== "Unknown" && 
              vehicle.registration !== "Unknown registration") {
            setVehicleRegistration(vehicle.registration);
          } else {
            setVehicleRegistration(null);
          }
        } catch (error) {
          console.error("Error fetching vehicle details:", error);
          setVehicleRegistration(null);
        } finally {
          setIsLoading(false);
        }
      }
    };
    
    fetchVehicleDetails();
  }, [message.vehicle_id]);
  
  return (
    <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
      <h3 className="text-lg leading-6 font-medium text-gray-900">{message.subject}</h3>
      <div className="mt-1 flex justify-between">
        <p className="max-w-2xl text-sm text-gray-500">
          {message.sender_name}
        </p>
        <p className="text-sm text-gray-500">
          {format(new Date(message.created_at), "MMM d, yyyy 'at' h:mm a")}
        </p>
      </div>
      {message.vehicle_id && vehicleRegistration && !isLoading && (
        <p className="mt-1 text-sm text-gray-500">
          Vehicle: {vehicleRegistration}
        </p>
      )}
      {message.vehicle_id && isLoading && (
        <p className="mt-1 text-sm text-gray-500">
          Vehicle: Loading...
        </p>
      )}
    </div>
  );
};

export default MessageHeader;
