
import React from "react";
import { ChevronLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import SEO from "@/components/seo/SEO";

interface MessageDetailErrorProps {
  error: string | null;
  onBack: () => void;
}

const MessageDetailError = ({ error, onBack }: MessageDetailErrorProps) => {
  return (
    <div className="max-w-3xl mx-auto p-4">
      <SEO 
        title="Message Not Found - Source my Truck"
        description="The message you're looking for doesn't exist or has been removed."
        noindex={true}
      />
      
      <Button variant="ghost" onClick={onBack} className="mb-4 flex items-center gap-2">
        <ChevronLeft className="h-4 w-4" />
        Back to Messages
      </Button>
      
      <div className="text-center py-10 border rounded-lg bg-white shadow-sm">
        <h3 className="mt-2 text-xl font-semibold text-gray-900">Message not found</h3>
        <p className="mt-3 text-gray-500">{error || "The message could not be loaded."}</p>
        
        <div className="mt-6">
          <Link to="/messages">
            <Button>View All Messages</Button>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default MessageDetailError;
