
import React from "react";
import { Mail } from "lucide-react";

const EmptyMessages = () => {
  return (
    <div className="text-center py-10">
      <Mail className="mx-auto h-12 w-12 text-gray-400" />
      <h3 className="mt-2 text-sm font-semibold text-gray-900">No messages</h3>
      <p className="mt-1 text-sm text-gray-500">Your inbox is empty.</p>
    </div>
  );
};

export default EmptyMessages;
