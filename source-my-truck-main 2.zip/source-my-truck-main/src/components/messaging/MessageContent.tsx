
import React, { useState, useEffect } from "react";
import { getVehicleById } from "@/services/vehicles/vehicleQueryService";
import { Message } from "@/services/messages/types";

interface MessageContentProps {
  content: string;
  isImportant?: boolean;
  vehicleId?: string;
  message: Message;
}

const MessageContent = ({ content, isImportant, vehicleId, message }: MessageContentProps) => {
  const [vehicleRegistration, setVehicleRegistration] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  
  useEffect(() => {
    const fetchVehicleDetails = async () => {
      if (vehicleId) {
        setIsLoading(true);
        try {
          const vehicle = await getVehicleById(vehicleId);
          if (vehicle && vehicle.registration) {
            setVehicleRegistration(vehicle.registration);
          } else {
            setVehicleRegistration("Unknown registration");
          }
        } catch (error) {
          console.error("Error fetching vehicle details:", error);
          setVehicleRegistration("Unknown registration");
        } finally {
          setIsLoading(false);
        }
      }
    };
    
    fetchVehicleDetails();
  }, [vehicleId]);
  
  // Replace vehicle ID mentions with registration number if available
  const formatContent = (content: string) => {
    if (vehicleId && vehicleRegistration) {
      return content.replace(
        new RegExp(`Vehicle ID: ${vehicleId}`, 'g'), 
        `Vehicle: ${vehicleRegistration}`
      );
    }
    return content;
  };

  const formattedContent = formatContent(content);

  // Check if contact info exists in the message object
  const hasContactInfo = message.anonymous_sender_name || 
                         message.anonymous_sender_email || 
                         message.anonymous_sender_phone;

  return (
    <div className="px-4 py-5 sm:p-6">
      {isImportant && (
        <div className="mb-4 inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-yellow-100 text-yellow-800">
          Important
        </div>
      )}
      
      {hasContactInfo && (
        <div className="mb-4 p-4 bg-gray-50 rounded-lg">
          <h4 className="text-sm font-medium text-gray-900 mb-2">Contact Information</h4>
          {message.anonymous_sender_name && (
            <p className="text-sm text-gray-700">Name: {message.anonymous_sender_name}</p>
          )}
          {message.anonymous_sender_email && (
            <p className="text-sm text-gray-700">Email: {message.anonymous_sender_email}</p>
          )}
          {message.anonymous_sender_phone && (
            <p className="text-sm text-gray-700">Phone: {message.anonymous_sender_phone}</p>
          )}
        </div>
      )}
      <div className="whitespace-pre-wrap">
        <p className="text-sm text-gray-700">{formattedContent}</p>
      </div>
    </div>
  );
};

export default MessageContent;
