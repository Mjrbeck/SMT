
import { useState } from "react";
import { format } from "date-fns";
import { Mail, MailOpen, Star, Trash2 } from "lucide-react";
import { Message } from "@/services/messages";
import { useAuth } from "@/contexts/AuthContext";

interface MessageItemProps {
  message: Message;
  vehicleRegistration: string | null;
  loadingVehicle: boolean;
  onMessageClick: (messageId: string, e: React.MouseEvent) => void;
  onDeleteClick: (messageId: string, e: React.MouseEvent) => void;
  onToggleImportant: (messageId: string, isCurrentlyImportant: boolean | undefined, e: React.MouseEvent) => void;
}

const MessageItem = ({ 
  message, 
  vehicleRegistration, 
  loadingVehicle,
  onMessageClick, 
  onDeleteClick, 
  onToggleImportant 
}: MessageItemProps) => {
  const { user } = useAuth();
  const isCurrentUserRecipient = user?.id === message.recipient_id;
  const displayName = isCurrentUserRecipient 
    ? message.sender_name
    : `To: ${message.recipient_name}`;
  
  let vehicleInfo = "";
  if (message.vehicle_id) {
    if (loadingVehicle) {
      vehicleInfo = "Loading vehicle...";
    } else {
      vehicleInfo = vehicleRegistration || "Unknown registration";
    }
  }
  
  return (
    <li 
      key={message.id}
      onClick={(e) => onMessageClick(message.id, e)}
      className={`
        relative p-4 hover:bg-gray-50 cursor-pointer rounded-md
        ${!message.is_read && isCurrentUserRecipient ? 'bg-indigo-50 hover:bg-indigo-100 font-medium' : ''}
        ${message.is_important ? 'border-l-4 border-yellow-400 pl-3' : ''}
      `}
    >
      <div className="flex items-start space-x-3">
        <div className="flex-shrink-0 pt-0.5">
          {message.is_read || !isCurrentUserRecipient ? (
            <MailOpen className="h-5 w-5 text-gray-400" />
          ) : (
            <Mail className="h-5 w-5 text-brand-blue" />
          )}
        </div>
        <div className="min-w-0 flex-1">
          <p className="text-sm font-medium text-gray-900 truncate">{message.subject}</p>
          <p className="text-sm text-gray-500 truncate">{displayName}</p>
          {message.vehicle_id && (
            <p className="text-xs text-gray-500">
              Vehicle: {vehicleInfo}
            </p>
          )}
          <p className="mt-1 text-xs text-gray-500 truncate">{message.content}</p>
          <p className="mt-1 text-xs text-gray-400">
            {format(new Date(message.created_at), "MMM d, yyyy 'at' h:mm a")}
          </p>
        </div>
        {isCurrentUserRecipient && (
          <div className="flex-shrink-0 flex items-center space-x-2">
            <button 
              onClick={(e) => onToggleImportant(message.id, message.is_important, e)}
              className="message-action text-gray-400 hover:text-yellow-500"
              title={message.is_important ? "Unmark as important" : "Mark as important"}
            >
              <Star className={`h-5 w-5 ${message.is_important ? 'text-yellow-500 fill-yellow-500' : ''}`} />
            </button>
            <button 
              onClick={(e) => onDeleteClick(message.id, e)}
              className="message-action text-gray-400 hover:text-red-500"
              title="Delete message"
            >
              <Trash2 className="h-5 w-5" />
            </button>
          </div>
        )}
      </div>
    </li>
  );
};

export default MessageItem;
