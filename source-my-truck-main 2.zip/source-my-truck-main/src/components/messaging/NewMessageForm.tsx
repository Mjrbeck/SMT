
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { sendMessage, MessageFormData } from "@/services/messageService";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";

interface NewMessageFormProps {
  recipientId?: string;
  initialSubject?: string;
  vehicleId?: string;
  onSuccess?: () => void;
  onCancel?: () => void;
}

const NewMessageForm = ({ 
  recipientId, 
  initialSubject = "", 
  vehicleId,
  onSuccess,
  onCancel
}: NewMessageFormProps) => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState<MessageFormData>({
    recipient_id: recipientId || "",
    subject: initialSubject,
    content: "",
    vehicle_id: vehicleId
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const { success, error } = await sendMessage(formData);
      
      if (success) {
        toast.success("Message sent successfully");
        if (onSuccess) {
          onSuccess();
        } else {
          navigate("/messages");
        }
      } else {
        toast.error(error || "Failed to send message");
      }
    } catch (error) {
      console.error("Error sending message:", error);
      toast.error("An unexpected error occurred");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {!recipientId && (
        <div>
          <label htmlFor="recipient_id" className="block text-sm font-medium text-gray-700">
            Recipient ID
          </label>
          <Input
            id="recipient_id"
            name="recipient_id"
            value={formData.recipient_id}
            onChange={handleChange}
            required
            className="mt-1"
          />
          <p className="text-xs text-gray-500 mt-1">
            Enter the ID of the user you want to message
          </p>
        </div>
      )}
      
      <div>
        <label htmlFor="subject" className="block text-sm font-medium text-gray-700">
          Subject
        </label>
        <Input
          id="subject"
          name="subject"
          value={formData.subject}
          onChange={handleChange}
          required
          className="mt-1"
        />
      </div>
      
      <div>
        <label htmlFor="content" className="block text-sm font-medium text-gray-700">
          Message
        </label>
        <Textarea
          id="content"
          name="content"
          value={formData.content}
          onChange={handleChange}
          required
          rows={5}
          className="mt-1"
        />
      </div>
      
      <div className="flex justify-end space-x-2">
        {onCancel && (
          <Button 
            type="button" 
            variant="outline" 
            onClick={onCancel}
            disabled={isSubmitting}
          >
            Cancel
          </Button>
        )}
        <Button 
          type="submit" 
          disabled={isSubmitting}
          className="bg-brand-blue hover:bg-brand-blue/90"
        >
          {isSubmitting ? "Sending..." : "Send Message"}
        </Button>
      </div>
    </form>
  );
};

export default NewMessageForm;
