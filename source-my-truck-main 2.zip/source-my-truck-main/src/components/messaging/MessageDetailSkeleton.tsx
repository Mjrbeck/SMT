
import React from "react";

const MessageDetailSkeleton = () => {
  return (
    <div className="max-w-3xl mx-auto p-4 animate-in fade-in duration-200">
      <div className="animate-pulse space-y-4">
        <div className="h-8 w-32 bg-gray-200 rounded transition-opacity duration-300" />
        <div className="h-6 w-full bg-gray-200 rounded transition-opacity duration-300" />
        <div className="h-4 w-48 bg-gray-200 rounded transition-opacity duration-300" />
        <div className="space-y-2">
          {[...Array(3)].map((_, i) => (
            <div 
              key={i} 
              className="h-4 w-full bg-gray-200 rounded transition-opacity duration-300"
              style={{ 
                animationDelay: `${i * 150}ms`,
                width: `${100 - (i * 15)}%`
              }}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default React.memo(MessageDetailSkeleton);
