import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { sendMessage } from "@/services/messages";
import { toast } from "sonner";
import { Search, User } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

interface ComposeMessageDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  recipientId?: string;
  recipientName?: string;
}

interface UserProfile {
  id: string;
  company_name: string;
  role: string;
}

const ComposeMessageDialog = ({
  isOpen,
  onClose,
  onSuccess,
  recipientId,
  recipientName
}: ComposeMessageDialogProps) => {
  const [formData, setFormData] = useState({
    recipient_id: recipientId || "",
    subject: "",
    content: ""
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [searchResults, setSearchResults] = useState<UserProfile[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [selectedRecipient, setSelectedRecipient] = useState<UserProfile | null>(
    recipientId && recipientName ? { id: recipientId, company_name: recipientName, role: 'seller' } : null
  );

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const searchUsers = async () => {
    if (!searchTerm.trim()) {
      setSearchResults([]);
      return;
    }

    setIsSearching(true);
    try {
      const { data, error } = await supabase
        .from("profiles")
        .select("id, company_name, role")
        .or(`company_name.ilike.%${searchTerm}%`)
        .limit(10);

      if (error) {
        console.error("Search error:", error);
        toast.error("Error searching users");
        return;
      }

      setSearchResults(data || []);
    } catch (error) {
      console.error("Search error:", error);
      toast.error("Error searching users");
    } finally {
      setIsSearching(false);
    }
  };

  const selectRecipient = (user: UserProfile) => {
    setSelectedRecipient(user);
    setFormData(prev => ({ ...prev, recipient_id: user.id }));
    setSearchResults([]);
    setSearchTerm("");
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.recipient_id || !formData.subject || !formData.content) {
      toast.error("Please fill in all fields");
      return;
    }

    setIsSubmitting(true);
    try {
      const { success, error } = await sendMessage({
        recipient_id: formData.recipient_id,
        subject: formData.subject,
        content: formData.content
      });

      if (success) {
        toast.success("Message sent successfully!");
        setFormData({ recipient_id: "", subject: "", content: "" });
        setSelectedRecipient(null);
        onSuccess();
      } else {
        toast.error(error || "Failed to send message");
      }
    } catch (error) {
      console.error("Error sending message:", error);
      toast.error("An unexpected error occurred");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleClose = () => {
    setFormData({ recipient_id: "", subject: "", content: "" });
    setSelectedRecipient(null);
    setSearchResults([]);
    setSearchTerm("");
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>Compose New Message</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Recipient Selection */}
          <div className="space-y-2">
            <Label htmlFor="recipient">To:</Label>
            {selectedRecipient ? (
              <div className="flex items-center justify-between p-3 border rounded-md bg-gray-50">
                <div className="flex items-center gap-2">
                  <User className="h-4 w-4 text-gray-500" />
                  <span className="font-medium">{selectedRecipient.company_name}</span>
                  <span className="text-sm text-gray-500">({selectedRecipient.role})</span>
                </div>
                <Button 
                  type="button" 
                  variant="ghost" 
                  size="sm"
                  onClick={() => {
                    setSelectedRecipient(null);
                    setFormData(prev => ({ ...prev, recipient_id: "" }));
                  }}
                >
                  Change
                </Button>
              </div>
            ) : (
              <div className="space-y-2">
                <div className="flex gap-2">
                  <Input
                    placeholder="Search for a user or company..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        searchUsers();
                      }
                    }}
                  />
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={searchUsers}
                    disabled={isSearching}
                  >
                    <Search className="h-4 w-4" />
                  </Button>
                </div>

                {/* Search Results */}
                {searchResults.length > 0 && (
                  <div className="border rounded-md max-h-40 overflow-y-auto">
                    {searchResults.map((user) => (
                      <button
                        key={user.id}
                        type="button"
                        onClick={() => selectRecipient(user)}
                        className="w-full p-3 text-left hover:bg-gray-50 flex items-center gap-2 border-b border-gray-100 last:border-b-0"
                      >
                        <User className="h-4 w-4 text-gray-500" />
                        <div>
                          <div className="font-medium">{user.company_name}</div>
                          <div className="text-sm text-gray-500 capitalize">{user.role}</div>
                        </div>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Subject */}
          <div className="space-y-2">
            <Label htmlFor="subject">Subject</Label>
            <Input
              id="subject"
              name="subject"
              value={formData.subject}
              onChange={handleChange}
              placeholder="Enter message subject"
              required
            />
          </div>

          {/* Message Content */}
          <div className="space-y-2">
            <Label htmlFor="content">Message</Label>
            <Textarea
              id="content"
              name="content"
              value={formData.content}
              onChange={handleChange}
              placeholder="Type your message here..."
              rows={6}
              required
            />
          </div>

          {/* Actions */}
          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={handleClose}>
              Cancel
            </Button>
            <Button 
              type="submit" 
              disabled={isSubmitting || !selectedRecipient}
              className="bg-brand-blue hover:bg-brand-blue/90"
            >
              {isSubmitting ? "Sending..." : "Send Message"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default ComposeMessageDialog;