
import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ChevronLeft, Trash2, Reply } from "lucide-react";
import { getMessageById, Message } from "@/services/messages";
import MessageDetailSkeleton from "./MessageDetailSkeleton";
import MessageDetailError from "./MessageDetailError";
import MessageHeader from "./MessageHeader";
import MessageContent from "./MessageContent";
import DeleteMessageDialog from "./DeleteMessageDialog";
import ReplyMessageForm from "./ReplyMessageForm";
import { toast } from "sonner";
import { useMessages } from "@/hooks/useMessages";

const MessageDetail = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { deleteMessage } = useMessages(); // Use the hook instead of direct API call
  const [message, setMessage] = useState<Message | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [showReplyForm, setShowReplyForm] = useState(false);

  useEffect(() => {
    const fetchMessage = async () => {
      if (!id) return;
      
      setIsLoading(true);
      try {
        const { message, error } = await getMessageById(id);
        if (error) {
          setError(error);
        } else if (message) {
          setMessage(message);
        }
      } catch (err) {
        setError("Failed to load message");
        console.error(err);
      } finally {
        setIsLoading(false);
      }
    };

    fetchMessage();
  }, [id]);

  const handleBack = () => {
    navigate("/messages");
  };

  const handleDelete = async () => {
    if (!id) return;
    
    setIsDeleting(true);
    try {
      // Use the deleteMessage from useMessages hook
      const success = await deleteMessage(id);
      if (success) {
        toast.success("Message deleted successfully");
        navigate("/messages");
      }
    } catch (err) {
      toast.error("An error occurred while deleting the message");
      console.error(err);
    } finally {
      setIsDeleting(false);
      setIsDeleteDialogOpen(false);
    }
  };

  if (isLoading) {
    return <MessageDetailSkeleton />;
  }

  if (error || !message) {
    return <MessageDetailError error={error} onBack={handleBack} />;
  }

  return (
    <div className="max-w-3xl mx-auto p-4">
      <div className="flex justify-between items-center mb-4">
        <Button variant="ghost" onClick={handleBack} className="flex items-center gap-2">
          <ChevronLeft className="h-4 w-4" />
          Back to Messages
        </Button>
        
        <div className="flex gap-2">
          {message.sender_id && (
            <Button 
              variant="outline"
              onClick={() => setShowReplyForm(!showReplyForm)}
              className="text-brand-blue hover:text-brand-blue/90 hover:bg-brand-blue/10"
            >
              <Reply className="h-4 w-4 mr-2" />
              Reply
            </Button>
          )}
          <Button 
            variant="outline" 
            className="text-red-500 hover:text-red-700 hover:bg-red-50"
            onClick={() => setIsDeleteDialogOpen(true)}
          >
            <Trash2 className="h-4 w-4 mr-2" />
            Delete
          </Button>
        </div>
      </div>
      
      <div className="bg-white shadow overflow-hidden rounded-lg">
        <MessageHeader message={message} />
        <MessageContent 
          content={message.content} 
          isImportant={message.is_important} 
          vehicleId={message.vehicle_id}
          message={message}
        />
        
        {showReplyForm && (
          <ReplyMessageForm
            originalMessage={message}
            onSuccess={() => {
              setShowReplyForm(false);
              toast.success("Reply sent successfully!");
            }}
            onCancel={() => setShowReplyForm(false)}
          />
        )}
      </div>

      <DeleteMessageDialog
        isOpen={isDeleteDialogOpen}
        onClose={() => setIsDeleteDialogOpen(false)}
        onConfirm={handleDelete}
        isDeleting={isDeleting}
      />
    </div>
  );
};

export default MessageDetail;
