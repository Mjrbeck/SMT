import React, { useState, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Heart, HeartHandshake } from 'lucide-react';
import { useWatchlist } from '@/contexts/WatchlistContext';
import { cn } from '@/lib/utils';

interface WatchButtonProps {
  vehicleId: string;
  vehicleTitle?: string;
  variant?: 'default' | 'ghost' | 'outline';
  size?: 'default' | 'sm' | 'lg' | 'icon';
  className?: string;
  showText?: boolean;
}

export const WatchButton: React.FC<WatchButtonProps> = ({
  vehicleId,
  vehicleTitle,
  variant = 'outline',
  size = 'default',
  className,
  showText = true
}) => {
  const { isWatched, toggleWatchlist } = useWatchlist();
  const [isLoading, setIsLoading] = useState(false);
  
  const watched = isWatched(vehicleId);

  const handleClick = useCallback(async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    setIsLoading(true);
    
    try {
      await toggleWatchlist(vehicleId, vehicleTitle);
    } catch (error) {
      console.error('Error toggling watchlist:', error);
    } finally {
      setIsLoading(false);
    }
  }, [vehicleId, vehicleTitle, toggleWatchlist]);

  const IconComponent = watched ? HeartHandshake : Heart;
  
  return (
    <Button
      variant={variant}
      size={size}
      onClick={handleClick}
      disabled={isLoading}
      className={cn(
        'transition-all duration-200',
        watched && variant === 'outline' && 'border-red-500 text-red-600 bg-red-50 hover:bg-red-100',
        watched && variant === 'default' && 'bg-red-600 hover:bg-red-700',
        className
      )}
    >
      <IconComponent 
        className={cn(
          'transition-all duration-200',
          size === 'icon' ? 'h-4 w-4' : 'h-4 w-4 mr-2',
          watched && 'fill-current text-red-600'
        )} 
      />
      {showText && size !== 'icon' && (
        <span>{watched ? 'Watching' : 'Watch'}</span>
      )}
    </Button>
  );
};