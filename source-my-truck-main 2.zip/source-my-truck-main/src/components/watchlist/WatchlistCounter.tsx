import React from 'react';
import { Link } from 'react-router-dom';
import { Heart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useWatchlist } from '@/contexts/WatchlistContext';
import { cn } from '@/lib/utils';

interface WatchlistCounterProps {
  variant?: 'button' | 'badge' | 'icon';
  className?: string;
}

export const WatchlistCounter: React.FC<WatchlistCounterProps> = ({
  variant = 'button',
  className
}) => {
  const { watchlistCount } = useWatchlist();

  if (watchlistCount === 0) {
    return null;
  }

  if (variant === 'badge') {
    return (
      <Link to="/watchlist">
        <Badge 
          variant="secondary" 
          className={cn(
            'cursor-pointer hover:bg-secondary/80 transition-colors',
            className
          )}
        >
          <Heart className="h-3 w-3 mr-1" />
          {watchlistCount}
        </Badge>
      </Link>
    );
  }

  if (variant === 'icon') {
    return (
      <Link to="/watchlist" className="relative">
        <Button
          variant="ghost"
          size="icon"
          className={cn('relative', className)}
        >
          <Heart className="h-5 w-5" />
          {watchlistCount > 0 && (
            <Badge 
              variant="destructive" 
              className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs"
            >
              {watchlistCount > 9 ? '9+' : watchlistCount}
            </Badge>
          )}
        </Button>
      </Link>
    );
  }

  return (
    <Link to="/watchlist">
      <Button 
        variant="ghost" 
        size="sm" 
        className={cn(
          'gap-2 hover:bg-accent/50',
          className
        )}
      >
        <Heart className="h-4 w-4" />
        <span>Watchlist ({watchlistCount})</span>
      </Button>
    </Link>
  );
};