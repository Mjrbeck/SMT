
import React from "react";
import { cn } from "@/lib/utils";

interface PageHeaderProps {
  title: string;
  subtitle?: string;
  action?: React.ReactNode;
  variant?: "default" | "dark";
  className?: string;
}

/**
 * Consistent page header component that displays the provided title
 */
const PageHeader = ({ 
  title, 
  subtitle, 
  action,
  variant = "default",
  className
}: PageHeaderProps) => {
  const isDark = variant === "dark";
  
  return (
    <div className={cn(`py-6 px-4 relative z-10 ${isDark ? 'bg-brand-darkBlue text-white shadow-md' : ''}`, className)}>
      <div className="container mx-auto">
        <div className="flex justify-between items-center">
          <div>
            {isDark ? (
              <h1 className="text-3xl font-bold text-white">{title}</h1>
            ) : (
              <h1 className="text-3xl font-bold text-primary-foreground bg-brand-darkBlue inline-block px-4 py-2 rounded-md shadow-lg">
                {title}
              </h1>
            )}
            
            {subtitle && (
              <p className={`mt-2 ${isDark ? 'text-gray-300' : 'text-muted-foreground'}`}>
                {subtitle}
              </p>
            )}
          </div>
          
          {action && (
            <div>
              {action}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default PageHeader;
