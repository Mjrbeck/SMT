
import React from "react";
import NavBar from "@/components/NavBar";
import Footer from "@/components/Footer";
import SEO from "@/components/seo/SEO";
import { useIsMobile } from "@/hooks/use-mobile";

interface PageLayoutProps {
  children: React.ReactNode;
  title?: string;
  subtitle?: string;
  description?: string;
  keywords?: string;
  noindex?: boolean;
}

/**
 * Reusable page layout component that includes the navbar and footer
 * with consistent styling matching the Create Listing page
 */
const PageLayout = ({ 
  children, 
  title, 
  subtitle, 
  description,
  keywords,
  noindex 
}: PageLayoutProps) => {
  const isMobile = useIsMobile();
  
  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      {title && (
        <SEO 
          title={title}
          description={description || subtitle}
          keywords={keywords}
          noindex={noindex}
        />
      )}
      
      <NavBar />
      
      {title && (
        <div className="bg-brand-darkBlue py-4 md:py-6 px-4 shadow-md relative z-10">
          <div className="mx-auto max-w-7xl">
            <h1 className="text-2xl md:text-3xl font-bold text-white">{title}</h1>
            {subtitle && (
              <p className="text-sm md:text-base text-gray-300 mt-2">{subtitle}</p>
            )}
          </div>
        </div>
      )}
      
      <main className={`flex-grow px-4 py-6 md:py-8 mx-auto max-w-7xl relative z-0 ${isMobile ? 'text-base' : ''}`}>
        {children}
      </main>
      
      <div className="mt-auto">
        <Footer />
      </div>
    </div>
  );
};

export default PageLayout;
