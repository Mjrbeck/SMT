import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { KeyRound } from "lucide-react";

interface ResetPasswordFormProps {
  password: string;
  setPassword: (password: string) => void;
  confirmPassword: string;
  setConfirmPassword: (password: string) => void;
  isSubmitting: boolean;
  formErrors: {
    password?: string;
    confirmPassword?: string;
    general?: string;
  };
  onSubmit: (e: React.FormEvent) => void;
}

const ResetPasswordForm = ({
  password,
  setPassword,
  confirmPassword,
  setConfirmPassword,
  isSubmitting,
  formErrors,
  onSubmit
}: ResetPasswordFormProps) => {
  return (
    <form onSubmit={onSubmit} className="space-y-4">
      {formErrors.general && (
        <div className="p-3 bg-red-50 border border-red-200 text-red-700 rounded-md text-sm">
          {formErrors.general}
        </div>
      )}
      
      <div className="space-y-2">
        <Label htmlFor="password">New Password</Label>
        <Input 
          id="password"
          type="password" 
          placeholder="••••••••" 
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
          disabled={isSubmitting}
          autoComplete="new-password"
          className={`transition-all duration-300 focus:ring-2 focus:ring-brand-blue ${formErrors.password ? 'border-red-500' : ''}`}
          aria-invalid={!!formErrors.password}
          aria-describedby={formErrors.password ? "password-error" : undefined}
        />
        {formErrors.password && (
          <p id="password-error" className="text-sm text-red-500">{formErrors.password}</p>
        )}
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="confirmPassword">Confirm New Password</Label>
        <Input 
          id="confirmPassword"
          type="password" 
          placeholder="••••••••" 
          value={confirmPassword}
          onChange={(e) => setConfirmPassword(e.target.value)}
          required
          disabled={isSubmitting}
          autoComplete="new-password"
          className={`transition-all duration-300 focus:ring-2 focus:ring-brand-blue ${formErrors.confirmPassword ? 'border-red-500' : ''}`}
          aria-invalid={!!formErrors.confirmPassword}
          aria-describedby={formErrors.confirmPassword ? "confirmPassword-error" : undefined}
        />
        {formErrors.confirmPassword && (
          <p id="confirmPassword-error" className="text-sm text-red-500">{formErrors.confirmPassword}</p>
        )}
      </div>
      
      <Button
        type="submit"
        className="w-full bg-brand-blue hover:bg-brand-blue/90 transition-all duration-300 mt-4"
        disabled={isSubmitting}
      >
        {isSubmitting ? (
          <span className="flex items-center justify-center">
            <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
            Resetting Password...
          </span>
        ) : (
          <span className="flex items-center justify-center">
            <KeyRound className="mr-2 h-4 w-4" />
            Reset Password
          </span>
        )}
      </Button>
    </form>
  );
};

export default ResetPasswordForm;