import TruckAnimation from "@/components/TruckAnimation";

const ResetPasswordLoading = () => {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-gray-50 to-gray-100 px-4 py-12">
      <div className="w-full max-w-md space-y-8 text-center">
        <TruckAnimation size={80} className="mx-auto" />
        <h2 className="text-xl font-semibold">Validating your reset link...</h2>
        <div className="animate-pulse w-full h-2 bg-brand-blue/30 rounded-full"></div>
      </div>
    </div>
  );
};

export default ResetPasswordLoading;