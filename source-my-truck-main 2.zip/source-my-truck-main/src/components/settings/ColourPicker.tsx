
import { useState, useRef, useEffect } from 'react';
import { HexColorPicker } from 'react-colorful';
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Input } from "@/components/ui/input";

interface ColourPickerProps {
  colour: string;
  onChange: (colour: string) => void;
  label?: string;
  description?: string;
  placeholder?: string;
}

export const ColourPicker = ({ colour, onChange, label, description, placeholder }: ColourPickerProps) => {
  const [inputValue, setInputValue] = useState(colour || '');
  const isValidHex = /^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/.test(inputValue);
  
  // Update input when colour prop changes
  useEffect(() => {
    setInputValue(colour || '');
  }, [colour]);
  
  // Update parent component when input changes and is valid
  const handleInputChange = (value: string) => {
    setInputValue(value);
    
    // Only update if it's a valid hex colour
    if (/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/.test(value)) {
      onChange(value);
    }
  };
  
  // Ensure # is added if user types without it
  const formatHexInput = (value: string) => {
    if (value.startsWith('#')) {
      return value;
    }
    return `#${value}`;
  };

  return (
    <div className="space-y-1.5">
      {label && <div className="text-sm font-medium">{label}</div>}
      
      <div className="flex gap-2">
        <Popover>
          <PopoverTrigger asChild>
            <div 
              className="h-10 w-10 rounded-md border cursor-pointer"
              style={{ backgroundColor: isValidHex ? inputValue : '#cccccc' }}
            />
          </PopoverTrigger>
          <PopoverContent className="w-auto p-3">
            <HexColorPicker 
              color={isValidHex ? inputValue : '#cccccc'} 
              onChange={(color) => handleInputChange(color)}
            />
          </PopoverContent>
        </Popover>
        
        <Input
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          onBlur={() => handleInputChange(formatHexInput(inputValue))}
          placeholder={placeholder || "#000000"}
          className={!isValidHex && inputValue ? "border-red-500" : ""}
        />
      </div>
      
      {description && (
        <p className="text-sm text-muted-foreground">{description}</p>
      )}
      
      {!isValidHex && inputValue && (
        <p className="text-xs text-red-500">Please enter a valid hex colour (e.g., #FF0000)</p>
      )}
    </div>
  );
};
