
// Pre-made colour themes for shop customization
export interface ColourTheme {
  name: string;
  themeColour: string;
  buttonColour: string | null;
  textColour: string;
  backgroundColour: string;
}

export const colourThemes: ColourTheme[] = [
  {
    name: "Ocean Blue",
    themeColour: "#0284c7",
    buttonColour: null, // Use theme colour
    textColour: "#1e293b",
    backgroundColour: "#f8fafc"
  },
  {
    name: "Forest Green",
    themeColour: "#15803d",
    buttonColour: "#16a34a",
    textColour: "#1e293b",
    backgroundColour: "#f0fdf4"
  },
  {
    name: "Sunset Orange",
    themeColour: "#ea580c",
    buttonColour: "#f97316",
    textColour: "#1e293b",
    backgroundColour: "#fff7ed"
  },
  {
    name: "Royal Purple",
    themeColour: "#7e22ce",
    buttonColour: "#9333ea",
    textColour: "#1e293b",
    backgroundColour: "#faf5ff"
  },
  {
    name: "Ruby Red",
    themeColour: "#b91c1c",
    buttonColour: "#dc2626",
    textColour: "#1e293b",
    backgroundColour: "#fef2f2"
  },
  {
    name: "Dark Mode",
    themeColour: "#3b82f6",
    buttonColour: "#60a5fa",
    textColour: "#f8fafc",
    backgroundColour: "#1e293b"
  }
];
