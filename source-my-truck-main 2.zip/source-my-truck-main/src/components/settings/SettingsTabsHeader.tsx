
import { TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useNavigate } from "react-router-dom";
import { CreditCard, Shield, FileText } from "lucide-react";
import { useUserRole } from "@/hooks/useUserRole";

interface SettingsTabsHeaderProps {
  activeTab: string;
  handleTabChange: (tab: string) => void;
}

export const SettingsTabsHeader = ({ 
  activeTab, 
  handleTabChange 
}: SettingsTabsHeaderProps) => {
  const navigate = useNavigate();
  const { isSeller } = useUserRole();
  
  const changeTab = (tab: string) => {
    handleTabChange(tab);
    navigate(`/settings?tab=${tab}`);
  };
  
  return (
    <div>
      <div className="mb-6">
        <p className="text-gray-500">
          {isSeller ? "Manage your credits, invoices, and security settings" : "Manage your security settings"}
        </p>
      </div>
      <TabsList className={`grid w-full md:w-auto md:inline-grid ${isSeller ? 'grid-cols-3' : 'grid-cols-1'} h-auto gap-4 bg-gray-50 p-1 rounded-lg`}>
        {isSeller && (
          <TabsTrigger 
            value="credits" 
            onClick={() => changeTab("credits")}
            className="flex items-center gap-2 px-4 py-2"
          >
            <div className="w-7 h-7 rounded-full bg-gray-100 flex items-center justify-center">
              <CreditCard className="h-3 w-3 text-brand-blue" />
            </div>
            <span>Credits</span>
          </TabsTrigger>
        )}
        
        {isSeller && (
          <TabsTrigger 
            value="invoices" 
            onClick={() => changeTab("invoices")}
            className="flex items-center gap-2 px-4 py-2"
          >
            <div className="w-7 h-7 rounded-full bg-gray-100 flex items-center justify-center">
              <FileText className="h-3 w-3 text-brand-blue" />
            </div>
            <span>Invoices</span>
          </TabsTrigger>
        )}
        
        <TabsTrigger 
          value="security" 
          onClick={() => changeTab("security")}
          className="flex items-center gap-2 px-4 py-2"
        >
          <div className="w-7 h-7 rounded-full bg-gray-100 flex items-center justify-center">
            <Shield className="h-3 w-3 text-brand-blue" />
          </div>
          <span>Security</span>
        </TabsTrigger>
      </TabsList>
    </div>
  );
};
