
import React from "react";
import { Truck, BarChart, Tag, Activity } from "lucide-react";
import { ActivityStats } from "./types";

interface ActivityOverviewProps {
  stats: ActivityStats;
}

const ActivityOverview = ({ stats }: ActivityOverviewProps) => {
  return (
    <div className="grid grid-cols-2 gap-4">
      <div className="bg-gray-50 p-4 rounded-lg">
        <div className="flex items-center">
          <Truck className="h-5 w-5 text-blue-500 mr-2" />
          <span className="text-sm text-gray-500">Total Vehicles</span>
        </div>
        <p className="text-2xl font-bold mt-2">{stats.totalVehicles}</p>
      </div>
      
      <div className="bg-gray-50 p-4 rounded-lg">
        <div className="flex items-center">
          <BarChart className="h-5 w-5 text-green-500 mr-2" />
          <span className="text-sm text-gray-500">Vehicle Views</span>
        </div>
        <p className="text-2xl font-bold mt-2">{stats.totalViews}</p>
      </div>
      
      <div className="bg-gray-50 p-4 rounded-lg">
        <div className="flex items-center">
          <Tag className="h-5 w-5 text-purple-500 mr-2" />
          <span className="text-sm text-gray-500">Avg. Price</span>
        </div>
        <p className="text-2xl font-bold mt-2">£{stats.averagePrice.toLocaleString()}</p>
      </div>
      
      <div className="bg-gray-50 p-4 rounded-lg">
        <div className="flex items-center">
          <Activity className="h-5 w-5 text-orange-500 mr-2" />
          <span className="text-sm text-gray-500">Account Age</span>
        </div>
        <p className="text-2xl font-bold mt-2">{stats.accountAge} days</p>
      </div>
    </div>
  );
};

export default ActivityOverview;
