import { useState, useEffect } from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { HexColorPicker } from "react-colorful";
import { 
  Check, ExternalLink, Info, Link, Loader2, Store, 
  Upload, X, Building, Edit, Image, Globe, MapPin, Eye
} from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Separator } from "@/components/ui/separator";
import { 
  SellerDepot, 
  upsertSellerDepot, 
  uploadHeaderImage,
  checkSlugAvailability
} from "@/services/sellers/sellerDepotService";
import { colourThemes } from "@/components/settings/ColourThemes";
import isURL from "url-validator";
import { useAuth } from "@/contexts/AuthContext";
import { Badge } from "@/components/ui/badge";
import { FormSection } from "@/components/ui/form-section";
import ShopPreview from "./ShopPreview";
import { useProfile } from "@/contexts/ProfileContext";
import { StyledButton } from "@/components/ui/styled-button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

const sellerDepotSchema = z.object({
  shop_name: z.string().min(2, "Shop name must be at least 2 characters").max(50, "Shop name must be less than 50 characters"),
  tagline: z.string().max(100, "Tagline must be less than 100 characters").optional(),
  description: z.string().max(500, "Description must be less than 500 characters").optional(),
  website_url: z.string().refine(val => !val || isURL(val), "Please enter a valid URL (including http:// or https://)").optional(),
  custom_url_slug: z.string()
    .min(3, "URL slug must be at least 3 characters")
    .max(30, "URL slug must be less than 30 characters")
    .regex(/^[a-z0-9-]+$/, "URL slug can only contain lowercase letters, numbers, and hyphens")
    .optional(),
  is_public: z.boolean().default(false),
  theme_color: z.string().regex(/^#[0-9A-Fa-f]{6}$/, "Must be a valid hex color").default("#0284c7"),
  button_color: z.string().regex(/^#[0-9A-Fa-f]{6}$/, "Must be a valid hex color").optional(),
  text_color: z.string().regex(/^#[0-9A-Fa-f]{6}$/, "Must be a valid hex color").default("#1e293b"),
  background_color: z.string().regex(/^#[0-9A-Fa-f]{6}$/, "Must be a valid hex color").default("#f8fafc"),
});

type FormValues = z.infer<typeof sellerDepotSchema>;

interface SellerDepotFormProps {
  initialData: SellerDepot | null;
  onSuccess?: () => void;
}

const SellerDepotForm = ({ initialData, onSuccess }: SellerDepotFormProps) => {
  const { toast } = useToast();
  const { user } = useAuth();
  const { profile } = useProfile();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [headerFile, setHeaderFile] = useState<File | null>(null);
  const [headerPreview, setHeaderPreview] = useState<string | null>(initialData?.header_image_url || null);
  const [colorPickerOpen, setColorPickerOpen] = useState("");
  const [slugStatus, setSlugStatus] = useState<{
    checking: boolean;
    available: boolean;
    message?: string;
  }>({ checking: false, available: true });

  const form = useForm<FormValues>({
    resolver: zodResolver(sellerDepotSchema),
    defaultValues: {
      shop_name: initialData?.shop_name || "",
      tagline: initialData?.tagline || "",
      description: initialData?.description || "",
      website_url: initialData?.website_url || "",
      custom_url_slug: initialData?.custom_url_slug || "",
      is_public: initialData?.is_public || false,
      theme_color: initialData?.theme_color || "#0284c7",
      button_color: initialData?.button_color || "",
      text_color: initialData?.text_color || "#1e293b",
      background_color: initialData?.background_color || "#f8fafc",
    },
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      
      if (!file.type.startsWith('image/')) {
        toast({
          title: "Invalid file type",
          description: "Please upload an image file (JPEG, PNG, etc.)",
          variant: "destructive",
        });
        return;
      }
      
      if (file.size > 5 * 1024 * 1024) {
        toast({
          title: "File too large",
          description: "Please upload an image less than 5MB",
          variant: "destructive",
        });
        return;
      }
      
      setHeaderFile(file);
      setHeaderPreview(URL.createObjectURL(file));
    }
  };
  
  const clearHeaderImage = () => {
    setHeaderFile(null);
    setHeaderPreview(null);
  };

  const currentSlug = form.watch("custom_url_slug");
  
  useEffect(() => {
    if (!currentSlug) {
      setSlugStatus({ checking: false, available: true });
      return;
    }
    
    if (initialData?.custom_url_slug === currentSlug) {
      setSlugStatus({ checking: false, available: true });
      return;
    }

    const checkSlug = async () => {
      setSlugStatus({ checking: true, available: false });
      
      try {
        const result = await checkSlugAvailability(currentSlug, user?.id);
        setSlugStatus({ 
          checking: false, 
          available: result.available,
          message: result.message
        });
      } catch (error) {
        console.error("Error checking slug availability:", error);
        setSlugStatus({ 
          checking: false, 
          available: false,
          message: "Error checking availability"
        });
      }
    };
    
    const timer = setTimeout(checkSlug, 500);
    return () => clearTimeout(timer);
  }, [currentSlug, initialData?.custom_url_slug, user?.id]);

  const onSubmit = async (data: FormValues) => {
    if (data.custom_url_slug && !slugStatus.available) {
      toast({
        title: "Invalid URL slug",
        description: slugStatus.message || "This URL is already taken. Please choose another.",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);
    
    try {
      let headerImageUrl = initialData?.header_image_url || null;
      
      if (headerFile) {
        const uploadedUrl = await uploadHeaderImage(headerFile);
        if (uploadedUrl) {
          headerImageUrl = uploadedUrl;
        } else {
          toast({
            title: "Image upload failed",
            description: "Failed to upload header image. The rest of your settings will be saved.",
            variant: "destructive",
          });
        }
      } else if (headerPreview === null && initialData?.header_image_url) {
        headerImageUrl = null;
      }
      
      const buttonColor = data.button_color || data.theme_color;
      
      const depotData: Partial<SellerDepot> = {
        shop_name: data.shop_name,
        tagline: data.tagline || null,
        description: data.description || null,
        website_url: data.website_url || null,
        custom_url_slug: data.custom_url_slug || null,
        is_public: data.is_public,
        theme_color: data.theme_color,
        button_color: buttonColor,
        text_color: data.text_color,
        background_color: data.background_color,
        header_image_url: headerImageUrl,
      };
      
      const result = await upsertSellerDepot(depotData);
      
      if (result) {
        toast({
          title: "Shop settings saved",
          description: "Your shop settings have been updated successfully.",
        });
        
        if (onSuccess) {
          onSuccess();
        }
      } else {
        throw new Error("Failed to save shop settings");
      }
    } catch (error) {
      console.error("Error saving shop settings:", error);
      toast({
        title: "Update failed",
        description: "There was an error saving your shop settings. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const shopName = form.watch("shop_name");
  const shopTagline = form.watch("tagline");
  const customUrlSlug = form.watch("custom_url_slug");
  const previewThemeColor = form.watch("theme_color");
  const previewButtonColor = form.watch("button_color") || previewThemeColor;
  const previewTextColor = form.watch("text_color");
  const previewBackgroundColor = form.watch("background_color");
  const isPublic = form.watch("is_public");
  const websiteUrl = form.watch("website_url");

  const shopUrl = customUrlSlug ? `/seller/${customUrlSlug}` : null;
  
  const applyColorTheme = (theme: typeof colourThemes[0]) => {
    form.setValue("theme_color", theme.themeColour);
    form.setValue("button_color", theme.buttonColour || "");
    form.setValue("text_color", theme.textColour);
    form.setValue("background_color", theme.backgroundColour);
  };

  const [previewDialogOpen, setPreviewDialogOpen] = useState(false);

  return (
    <div className="space-y-6">
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
          <div className="grid md:grid-cols-2 gap-8">
            <div className="space-y-6">
              <FormSection 
                title="Basic Shop Information" 
                description="These details will be displayed on your shop page."
                icon={<Building className="h-5 w-5" />}
              >
                <div className="space-y-4">
                  <FormField
                    control={form.control}
                    name="shop_name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Shop Name <span className="text-red-500">*</span></FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="Enter your shop name" 
                            {...field} 
                            className="focus:ring-2 focus:ring-brand-blue"
                          />
                        </FormControl>
                        <FormDescription>
                          This is the name that will be displayed on your shop page.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="tagline"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Tagline</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="A short tagline for your shop" 
                            {...field} 
                            value={field.value || ""}
                            className="focus:ring-2 focus:ring-brand-blue"
                          />
                        </FormControl>
                        <FormDescription>
                          A brief tagline or slogan for your shop (optional).
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Description</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Describe your shop" 
                            className="min-h-[100px] focus:ring-2 focus:ring-brand-blue" 
                            {...field} 
                            value={field.value || ""}
                          />
                        </FormControl>
                        <FormDescription>
                          A detailed description of your business (optional, max 500 characters).
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="website_url"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Company Website</FormLabel>
                        <FormControl>
                          <div className="flex items-center space-x-2">
                            <div className="bg-muted p-2 rounded-l-md">
                              <Globe className="h-4 w-4 text-muted-foreground" />
                            </div>
                            <Input 
                              placeholder="https://your-website.com" 
                              className="rounded-l-none focus:ring-2 focus:ring-brand-blue" 
                              {...field} 
                              value={field.value || ""}
                            />
                          </div>
                        </FormControl>
                        <FormDescription>
                          Your company's website URL (optional, include http:// or https://).
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </FormSection>
              
              <FormSection
                title="Shop URL & Visibility"
                description="Configure how customers can find your shop."
                icon={<Link className="h-5 w-5" />}
              >
                <div className="space-y-4">
                  <FormField
                    control={form.control}
                    name="custom_url_slug"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Custom URL</FormLabel>
                        <FormControl>
                          <div className="flex items-center space-x-2">
                            <div className="bg-muted py-2 px-3 rounded-l-md text-xs text-muted-foreground whitespace-nowrap">
                              yoursite.com/seller/
                            </div>
                            <div className="relative flex-1">
                              <Input 
                                placeholder="your-shop-name" 
                                className={`rounded-l-none focus:ring-2 focus:ring-brand-blue ${!slugStatus.available && field.value ? 'border-red-500 pr-10' : ''}`}
                                {...field} 
                                value={field.value || ""}
                              />
                              {field.value && (
                                <div className="absolute inset-y-0 right-0 pr-3 flex items-center">
                                  {slugStatus.checking ? (
                                    <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
                                  ) : slugStatus.available ? (
                                    <Check className="h-4 w-4 text-green-500" />
                                  ) : (
                                    <X className="h-4 w-4 text-red-500" />
                                  )}
                                </div>
                              )}
                            </div>
                          </div>
                        </FormControl>
                        <div className="mt-1 min-h-6">
                          {field.value && !slugStatus.checking && !slugStatus.available && (
                            <p className="text-sm font-medium text-red-500">{slugStatus.message}</p>
                          )}
                          {field.value && !slugStatus.checking && slugStatus.available && (
                            <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                              <Check className="h-3 w-3 mr-1" />
                              URL Available
                            </Badge>
                          )}
                        </div>
                        <FormDescription>
                          Choose a custom URL for your shop page (lowercase letters, numbers, and hyphens only).
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="is_public"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4 bg-card">
                        <div className="space-y-0.5">
                          <FormLabel className="text-base">Public Shop</FormLabel>
                          <FormDescription>
                            Make your shop page visible to potential customers.
                          </FormDescription>
                        </div>
                        <FormControl>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  
                  {!isPublic && (
                    <Alert variant="destructive" className="bg-amber-50 text-amber-900 border-amber-200">
                      <Info className="h-4 w-4" />
                      <AlertTitle>Private Shop</AlertTitle>
                      <AlertDescription>
                        Your shop page is currently private. Enable "Public Shop" to make it visible to customers.
                      </AlertDescription>
                    </Alert>
                  )}
                </div>
              </FormSection>
            </div>
            
            <div className="space-y-6">
              <FormSection
                title="Header Image"
                description="Add a banner image to the top of your shop page."
                icon={<Image className="h-5 w-5" />}
              >
                <div className="space-y-2">
                  <Label htmlFor="header-image">Shop Header Image (optional)</Label>
                  
                  {headerPreview ? (
                    <div className="relative rounded-md overflow-hidden border border-input">
                      <img 
                        src={headerPreview} 
                        alt="Header preview" 
                        className="w-full h-40 object-cover"
                      />
                      <Button
                        type="button"
                        variant="destructive"
                        size="icon"
                        className="absolute top-2 right-2 h-8 w-8 rounded-full opacity-90"
                        onClick={clearHeaderImage}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  ) : (
                    <div className="border border-dashed border-input rounded-md p-6 flex flex-col items-center justify-center bg-muted/30 hover:bg-muted/50 transition-colors">
                      <Upload className="h-8 w-8 text-muted-foreground mb-2" />
                      <p className="text-sm text-muted-foreground mb-1">
                        Drag & drop or click to upload
                      </p>
                      <p className="text-xs text-muted-foreground">
                        Recommended size: 1200×240px (5:1 ratio)
                      </p>
                      
                      <Input
                        id="header-image"
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={handleFileChange}
                      />
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        className="mt-4"
                        onClick={() => document.getElementById('header-image')?.click()}
                      >
                        Select image
                      </Button>
                    </div>
                  )}
                  <p className="text-sm text-muted-foreground">
                    Upload a banner image to display at the top of your shop page.
                  </p>
                </div>
              </FormSection>
              
              <FormSection
                title="Shop Theme Colors"
                description="Customize the colors of your shop page."
                icon={<Edit className="h-5 w-5" />}
              >
                <div className="mb-4">
                  <h4 className="text-sm font-medium mb-2">Preset Color Themes</h4>
                  <div className="flex flex-wrap gap-2">
                    {colourThemes.map((theme, index) => (
                      <button
                        key={index}
                        type="button"
                        className="w-8 h-8 rounded-full border-2 border-gray-200 transition-all hover:scale-110 focus:outline-none focus:ring-2 focus:ring-primary"
                        style={{ backgroundColor: theme.themeColour }}
                        title={theme.name}
                        onClick={() => applyColorTheme(theme)}
                      />
                    ))}
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="theme_color"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Primary Color</FormLabel>
                        <FormControl>
                          <div className="flex items-center space-x-2">
                            <Popover open={colorPickerOpen === "theme"} onOpenChange={(open) => open ? setColorPickerOpen("theme") : setColorPickerOpen("")}>
                              <PopoverTrigger asChild>
                                <Button
                                  type="button"
                                  variant="outline"
                                  className="w-full justify-start text-left font-normal"
                                >
                                  <div className="flex items-center space-x-2">
                                    <div 
                                      className="h-5 w-5 rounded-full border"
                                      style={{ backgroundColor: field.value }}
                                    />
                                    <span>{field.value}</span>
                                  </div>
                                </Button>
                              </PopoverTrigger>
                              <PopoverContent className="w-auto p-3">
                                <HexColorPicker color={field.value} onChange={field.onChange} />
                              </PopoverContent>
                            </Popover>
                          </div>
                        </FormControl>
                        <FormDescription>
                          Main color theme for your shop.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="button_color"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Button Color (Optional)</FormLabel>
                        <FormControl>
                          <div className="flex items-center space-x-2">
                            <Popover open={colorPickerOpen === "button"} onOpenChange={(open) => open ? setColorPickerOpen("button") : setColorPickerOpen("")}>
                              <PopoverTrigger asChild>
                                <Button
                                  type="button"
                                  variant="outline"
                                  className="w-full justify-start text-left font-normal"
                                >
                                  <div className="flex items-center space-x-2">
                                    <div 
                                      className="h-5 w-5 rounded-full border"
                                      style={{ backgroundColor: field.value || previewThemeColor }}
                                    />
                                    <span>{field.value || "Same as Primary"}</span>
                                  </div>
                                </Button>
                              </PopoverTrigger>
                              <PopoverContent className="w-auto p-3">
                                <HexColorPicker 
                                  color={field.value || previewThemeColor} 
                                  onChange={field.onChange} 
                                />
                                {field.value && (
                                  <Button
                                    type="button"
                                    variant="ghost"
                                    size="sm"
                                    className="mt-2 w-full"
                                    onClick={() => field.onChange("")}
                                  >
                                    Reset to Primary Color
                                  </Button>
                                )}
                              </PopoverContent>
                            </Popover>
                          </div>
                        </FormControl>
                        <FormDescription>
                          Custom color for buttons (defaults to Primary Color if not set).
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="text_color"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Text Color</FormLabel>
                        <FormControl>
                          <div className="flex items-center space-x-2">
                            <Popover open={colorPickerOpen === "text"} onOpenChange={(open) => open ? setColorPickerOpen("text") : setColorPickerOpen("")}>
                              <PopoverTrigger asChild>
                                <Button
                                  type="button"
                                  variant="outline"
                                  className="w-full justify-start text-left font-normal"
                                >
                                  <div className="flex items-center space-x-2">
                                    <div 
                                      className="h-5 w-5 rounded-full border"
                                      style={{ backgroundColor: field.value }}
                                    />
                                    <span>{field.value}</span>
                                  </div>
                                </Button>
                              </PopoverTrigger>
                              <PopoverContent className="w-auto p-3">
                                <HexColorPicker color={field.value} onChange={field.onChange} />
                              </PopoverContent>
                            </Popover>
                          </div>
                        </FormControl>
                        <FormDescription>
                          Color for text on your shop page.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="background_color"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Background Color</FormLabel>
                        <FormControl>
                          <div className="flex items-center space-x-2">
                            <Popover open={colorPickerOpen === "background"} onOpenChange={(open) => open ? setColorPickerOpen("background") : setColorPickerOpen("")}>
                              <PopoverTrigger asChild>
                                <Button
                                  type="button"
                                  variant="outline"
                                  className="w-full justify-start text-left font-normal"
                                >
                                  <div className="flex items-center space-x-2">
                                    <div 
                                      className="h-5 w-5 rounded-full border"
                                      style={{ backgroundColor: field.value }}
                                    />
                                    <span>{field.value}</span>
                                  </div>
                                </Button>
                              </PopoverTrigger>
                              <PopoverContent className="w-auto p-3">
                                <HexColorPicker color={field.value} onChange={field.onChange} />
                              </PopoverContent>
                            </Popover>
                          </div>
                        </FormControl>
                        <FormDescription>
                          Background color for your shop page.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </FormSection>
            </div>
          </div>
          
          <div className="mt-8">
            <h3 className="text-lg font-semibold text-primary mb-4">Shop Preview</h3>
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <ShopPreview 
                  shopName={shopName || "Your Shop Name"}
                  tagline={shopTagline}
                  logoUrl={profile?.logo_url}
                  themeColor={previewThemeColor}
                  buttonColor={previewButtonColor}
                  textColor={previewTextColor}
                  backgroundColor={previewBackgroundColor}
                  websiteUrl={websiteUrl}
                  location={profile?.company_address}
                />
              </div>
              <div className="bg-gray-50 p-4 rounded-md border">
                <h4 className="text-sm font-medium mb-2">About This Preview</h4>
                <p className="text-sm text-muted-foreground mb-3">
                  This is a simplified preview of how your shop will appear to customers. The actual 
                  shop page will display your full inventory and more details about your company.
                </p>
                
                {isPublic && customUrlSlug && slugStatus.available ? (
                  <div className="border-t pt-3">
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full gap-2"
                      asChild
                    >
                      <a href={`/seller/${customUrlSlug}`} target="_blank" rel="noopener noreferrer">
                        <Store className="h-4 w-4" />
                        <span>View Your Live Shop Page</span>
                        <ExternalLink className="h-3 w-3 ml-1 opacity-70" />
                      </a>
                    </Button>
                  </div>
                ) : (
                  <div className="text-sm text-muted-foreground border-t pt-3">
                    {!customUrlSlug ? (
                      <p>Add a custom URL and make your shop public to view your live shop page.</p>
                    ) : !isPublic ? (
                      <p>Make your shop public to view your live shop page.</p>
                    ) : (
                      <p>Your custom URL is not available. Please choose another.</p>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
          
          <div className="flex justify-between items-center pt-6 border-t">
            <div className="flex gap-2 ml-auto">
              <Button 
                type="button" 
                variant="outline"
                className="gap-2"
                onClick={() => setPreviewDialogOpen(true)}
              >
                <Eye className="h-4 w-4" />
                Preview Shop
              </Button>
              
              <Button 
                type="submit" 
                disabled={isSubmitting || (!!currentSlug && !slugStatus.available)}
                className="min-w-[140px]"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Saving...
                  </>
                ) : (
                  <>
                    <Check className="mr-2 h-4 w-4" />
                    Save Shop Settings
                  </>
                )}
              </Button>
            </div>
          </div>
        </form>
      </Form>
      
      {/* Preview Dialog */}
      <Dialog open={previewDialogOpen} onOpenChange={setPreviewDialogOpen}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Store className="h-5 w-5" />
              Shop Preview
            </DialogTitle>
            <DialogDescription>
              This is how your shop will appear to visitors
            </DialogDescription>
          </DialogHeader>
          
          <div className="p-4 bg-gray-50 rounded-md border">
            <div className="max-w-2xl mx-auto">
              <ShopPreview 
                shopName={shopName || "Your Shop Name"}
                tagline={shopTagline}
                logoUrl={profile?.logo_url}
                themeColor={previewThemeColor}
                buttonColor={previewButtonColor}
                textColor={previewTextColor}
                backgroundColor={previewBackgroundColor}
                websiteUrl={websiteUrl}
                location={profile?.company_address}
              />
            </div>
          </div>
          
          <div className="flex justify-end">
            <Button
              type="button"
              variant="outline"
              onClick={() => setPreviewDialogOpen(false)}
            >
              Close Preview
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default SellerDepotForm;
