
import React from "react";
import { Button } from "@/components/ui/button";
import { LoadingSpinner } from "@/components/ui/loading-spinner";

interface CompanyFormActionsProps {
  isEditing: boolean;
  isLoading: boolean;
  onCancel: () => void;
  onEdit: () => void;
}

const CompanyFormActions: React.FC<CompanyFormActionsProps> = ({
  isEditing,
  isLoading,
  onCancel,
  onEdit
}) => {
  if (isEditing) {
    return (
      <div className="flex gap-2 justify-end">
        <Button 
          type="button" 
          variant="outline"
          disabled={isLoading}
          onClick={onCancel}
        >
          Cancel
        </Button>
        <Button 
          type="submit"
          disabled={isLoading}
          className="relative"
        >
          {isLoading ? (
            <>
              <LoadingSpinner size={16} className="mr-2" />
              <span>Saving...</span>
            </>
          ) : (
            "Save Changes"
          )}
        </Button>
      </div>
    );
  }

  return (
    <div className="flex justify-end">
      <Button 
        variant="outline" 
        onClick={onEdit}
      >
        Edit Company
      </Button>
    </div>
  );
};

export default CompanyFormActions;
