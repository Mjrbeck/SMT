
import { useEffect, useState } from "react";

interface CardElementProps {
  stripe: any;
  onStripeReady: (stripe: any, cardElement: any) => void;
  error?: string | null;
}

const CardElement = ({ stripe, onStripeReady, error }: CardElementProps) => {
  const [cardElement, setCardElement] = useState<any>(null);
  const [mounted, setMounted] = useState(false);
  
  // Initialize Stripe Elements once Stripe.js is loaded
  useEffect(() => {
    if (!stripe) {
      console.log("Stripe not loaded yet, waiting...");
      return;
    }
    
    console.log("Creating Stripe card element");
    const elements = stripe.elements();
    const card = elements.create('card', {
      style: {
        base: {
          color: '#32325d',
          fontFamily: '"Helvetica Neue", Helvetica, sans-serif',
          fontSmoothing: 'antialiased',
          fontSize: '16px',
          '::placeholder': {
            color: '#aab7c4'
          }
        },
        invalid: {
          color: '#fa755a',
          iconColor: '#fa755a'
        }
      }
    });
    
    setCardElement(card);
    
    return () => {
      console.log("Cleaning up card element");
      if (card) {
        try {
          card.unmount();
        } catch (e) {
          console.log("Error unmounting card", e);
        }
      }
    };
  }, [stripe]);
  
  // Mount the card element to the DOM when it's available
  useEffect(() => {
    if (!cardElement || !stripe) {
      console.log("Card element or stripe not available yet");
      return;
    }
    
    // Set a short delay to ensure DOM is ready
    const mountTimer = setTimeout(() => {
      try {
        const cardElementContainer = document.getElementById('card-element');
        if (!cardElementContainer) {
          console.error("Could not find #card-element container");
          return;
        }
        
        // First try to unmount to prevent errors when re-mounting
        try {
          cardElement.unmount();
        } catch (e) {
          // It's okay if it's not mounted yet
          console.log("Card wasn't mounted yet, no need to unmount");
        }
        
        console.log("Mounting card element to DOM");
        cardElement.mount('#card-element');
        setMounted(true);
        onStripeReady(stripe, cardElement);
        console.log("Stripe card element mounted successfully");
      } catch (error) {
        console.error("Error mounting Stripe element:", error);
      }
    }, 50); // Shorter delay for faster mounting
    
    return () => clearTimeout(mountTimer);
  }, [cardElement, onStripeReady, stripe]);

  return (
    <div className="mb-4">
      {error && (
        <div className="text-red-500 text-sm mb-2">{error}</div>
      )}
      <div 
        id="card-element" 
        className="p-3 bg-white border border-gray-300 rounded-md relative"
        style={{ minHeight: '40px' }}
      >
        {!mounted && stripe && <div className="text-gray-400 text-sm">Loading payment form...</div>}
        {/* Stripe Card Element will mount here */}
      </div>
      <div className="text-xs text-gray-500 mt-2">
        Enter your card details to complete the purchase.
      </div>
    </div>
  );
};

export default CardElement;
