
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import CardElement from "./CardElement";
import { CreditCard, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { purchaseCredits } from "@/services/credits";

interface PaymentFormProps {
  onSuccess?: () => void;
}

const PaymentForm = ({ onSuccess }: PaymentFormProps) => {
  const [creditAmount, setCreditAmount] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handlePayment = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (creditAmount < 1) {
      toast({
        title: "Invalid amount",
        description: "Please enter at least 1 credit",
        variant: "destructive",
      });
      return;
    }
    
    setIsLoading(true);
    
    try {
      console.log("Processing payment for", creditAmount, "credits");
      const result = await purchaseCredits(creditAmount);
      
      if (!result.success) {
        throw new Error(result.error || "Failed to process payment");
      }
      
      // This will not actually execute because the page redirects to Stripe
      if (onSuccess) {
        onSuccess();
      }
    } catch (error) {
      console.error("Payment error:", error);
      toast({
        title: "Payment failed",
        description: error instanceof Error ? error.message : "Could not process payment",
        variant: "destructive",
      });
      setIsLoading(false);
    }
  };

  return (
    <form onSubmit={handlePayment} className="space-y-4">
      <div>
        <label htmlFor="credit-amount" className="block text-sm font-medium mb-1">
          Number of credits
        </label>
        <Input
          id="credit-amount"
          type="number"
          min={1}
          value={creditAmount}
          onChange={(e) => setCreditAmount(parseInt(e.target.value) || 0)}
          disabled={isLoading}
        />
        <p className="text-sm text-muted-foreground mt-1">
          1 credit = £10.00
        </p>
      </div>

      {/* Remove CardElement - use default Stripe checkout instead */}
      <p className="text-sm text-muted-foreground">
        You'll be redirected to Stripe's secure payment page to complete your purchase.
      </p>

      <Button 
        type="submit" 
        disabled={isLoading} 
        className="w-full"
      >
        {isLoading ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Processing...
          </>
        ) : (
          <>
            <CreditCard className="mr-2 h-4 w-4" />
            Pay £{(creditAmount * 10.00).toFixed(2)}
          </>
        )}
      </Button>
    </form>
  );
};

export default PaymentForm;
