
import { Plus, Info, Loader2, CreditCard } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

interface CreditAmountFormProps {
  creditAmount: number;
  setCreditAmount: (amount: number) => void;
  onPurchase: () => void;
  isLoading: boolean;
}

const CreditAmountForm = ({ 
  creditAmount, 
  setCreditAmount, 
  onPurchase, 
  isLoading 
}: CreditAmountFormProps) => {
  // This component is deprecated as Stripe has been removed
  return (
    <div className="text-center p-4 text-gray-500">
      Credit purchases are currently disabled
    </div>
  );
};

export default CreditAmountForm;
