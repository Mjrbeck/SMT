
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import CompanyInfoForm from "./CompanyInfoForm";
import AccountSummary from "./AccountSummary";
import { useAuth } from "@/contexts/AuthContext";
import { useProfile } from "@/contexts/ProfileContext";

const ProfileContent = () => {
  const { user } = useAuth();
  const { profile, setProfile } = useProfile();

  if (!profile) return null;

  return (
    <div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>Company Information</CardTitle>
            <CardDescription>
              Manage your company details
            </CardDescription>
          </CardHeader>
          <CardContent>
            <CompanyInfoForm 
              profile={profile} 
              user={user} 
              onProfileUpdate={setProfile} 
            />
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Account Summary</CardTitle>
            <CardDescription>
              Overview of your account
            </CardDescription>
          </CardHeader>
          <CardContent>
            <AccountSummary />
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default ProfileContent;
