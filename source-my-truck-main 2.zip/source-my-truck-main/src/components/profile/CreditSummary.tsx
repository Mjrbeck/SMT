
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Info } from "lucide-react";

interface CreditSummaryProps {
  currentCredits: number;
  subscription?: {
    name: string;
    credits: number;
  } | null;
}

const CreditSummary = ({
  currentCredits,
  subscription
}: CreditSummaryProps) => {
  const getSubscriptionPlanName = () => {
    if (!subscription) return "No Subscription";
    return subscription.name || "Active Subscription";
  };

  return (
    <Card className="overflow-hidden border-0 shadow-md bg-white">
      <CardHeader className="relative pb-2 border-b bg-gradient-to-r from-brand-blue to-brand-lightBlue text-white">
        <CardTitle className="flex items-center text-xl">
          <Info className="mr-2 h-5 w-5 text-white" />
          Credit Information
        </CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        <div className="flex flex-col space-y-4">
          {/* Subscription Status */}
          <div className="px-4 py-3 bg-gray-50 rounded-lg border border-gray-100">
            <div className="flex items-center justify-between">
              <span className="font-medium text-gray-700">Subscription Plan</span>
              <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                subscription ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-700'
              }`}>
                {getSubscriptionPlanName()}
              </span>
            </div>
            
            {subscription && (
              <div className="mt-2 text-sm text-gray-600">
                {subscription.credits} credits per month
              </div>
            )}
          </div>
          
          {/* Credit Value Info */}
          <div className="px-4 py-3 bg-gray-50 rounded-lg border border-gray-100">
            <h4 className="font-medium text-gray-700 mb-2">Credit Information</h4>
            <div className="space-y-2">
              <div className="flex justify-between items-center text-sm">
                <span className="text-gray-600">Value per credit</span>
                <span className="font-medium">£10.00</span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className="text-gray-600">Duration per listing</span>
                <span className="font-medium">30 days</span>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default CreditSummary;
