
import { TabsList, TabsTrigger } from "@/components/ui/tabs";

interface ProfileTabsHeaderProps {
  activeTab: string;
  handleTabChange: (tab: string) => void;
}

const ProfileTabsHeader = ({ activeTab, handleTabChange }: ProfileTabsHeaderProps) => {
  return (
    <TabsList className="grid w-full grid-cols-1 sm:grid-cols-2 h-auto">
      <TabsTrigger
        value="account"
        className={`${
          activeTab === "account" ? "border-b-2 border-brand-blue" : ""
        } py-2`}
        onClick={() => handleTabChange("account")}
      >
        Account
      </TabsTrigger>
      <TabsTrigger
        value="seller-depot"
        className={`${
          activeTab === "seller-depot" ? "border-b-2 border-brand-blue" : ""
        } py-2`}
        onClick={() => handleTabChange("seller-depot")}
      >
        Seller Depot
      </TabsTrigger>
    </TabsList>
  );
};

export default ProfileTabsHeader;
