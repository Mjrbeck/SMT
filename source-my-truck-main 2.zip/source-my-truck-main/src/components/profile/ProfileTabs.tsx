
import React, { useState, useCallback, useRef, useEffect } from "react";
import { Tabs, TabsContent } from "@/components/ui/tabs";
import { AccountForm } from "@/components/profile/AccountForm";
import { useProfile } from "@/contexts/ProfileContext";
import ProfileTabsHeader from "./ProfileTabsHeader";
import SellerDepotManager from "./SellerDepotManager";

interface ProfileTabsProps {
  activeTab: string;
  handleTabChange: (tab: string) => void;
}

const ProfileTabs = ({ activeTab, handleTabChange }: ProfileTabsProps) => {
  const { profile } = useProfile();
  const initialRenderRef = useRef(true);
  const tabChangeRef = useRef(false);

  // Only update the active tab without triggering any fetches
  useEffect(() => {
    if (initialRenderRef.current) {
      initialRenderRef.current = false;
      return;
    }
    
    // Mark that we've processed a tab change
    tabChangeRef.current = true;
  }, [activeTab]);

  // No fetch on tab change
  const handleAccountUpdate = useCallback(() => {
    // Intentionally empty - profile is updated by form submission
  }, []);

  return (
    <Tabs defaultValue={activeTab} className="w-full" onValueChange={handleTabChange}>
      <ProfileTabsHeader activeTab={activeTab} handleTabChange={handleTabChange} />
      
      <TabsContent value="account" className="mt-6">
        <AccountForm 
          profile={profile} 
          onProfileUpdate={handleAccountUpdate} 
        />
      </TabsContent>
      
      <TabsContent value="seller-depot" className="mt-6">
        <SellerDepotManager />
      </TabsContent>
    </Tabs>
  );
};

export default ProfileTabs;
