
import React from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Building, Phone, MapPin, Mail, Calendar, FileText } from "lucide-react";
import { RequiredLabel } from "@/components/forms/RequiredLabel";
import { Textarea } from "@/components/ui/textarea";

interface CompanyDetailsProps {
  isEditing: boolean;
  companyName: string;
  setCompanyName: (name: string) => void;
  companyPhone: string;
  setCompanyPhone: (phone: string) => void;
  companyAddress: string;
  setCompanyAddress: (address: string) => void;
  companyDescription: string;
  setCompanyDescription: (description: string) => void;
  email?: string;
  createdAt: string;
}

const MAX_DESCRIPTION_LENGTH = 500;

const CompanyDetails = ({
  isEditing,
  companyName,
  setCompanyName,
  companyPhone,
  setCompanyPhone,
  companyAddress,
  setCompanyAddress,
  companyDescription,
  setCompanyDescription,
  email,
  createdAt
}: CompanyDetailsProps) => {
  
  if (isEditing) {
    return (
      <>
        <div className="space-y-2">
          <RequiredLabel htmlFor="companyName">Company Name</RequiredLabel>
          <Input 
            id="companyName"
            value={companyName}
            onChange={(e) => setCompanyName(e.target.value)}
            placeholder="Your company name"
            required
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="companyDescription">Company Description</Label>
          <Textarea 
            id="companyDescription"
            value={companyDescription}
            onChange={(e) => {
              // Limit the description length to MAX_DESCRIPTION_LENGTH characters
              if (e.target.value.length <= MAX_DESCRIPTION_LENGTH) {
                setCompanyDescription(e.target.value);
              }
            }}
            placeholder="Describe your company (max 500 characters)"
            className="resize-none"
            rows={4}
          />
          <div className="text-xs text-muted-foreground text-right">
            {companyDescription.length}/{MAX_DESCRIPTION_LENGTH} characters
          </div>
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="companyPhone">Company Phone</Label>
          <Input 
            id="companyPhone"
            type="tel"
            value={companyPhone}
            onChange={(e) => setCompanyPhone(e.target.value)}
            placeholder="Your company phone number"
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="companyAddress">Company Address</Label>
          <Input 
            id="companyAddress"
            value={companyAddress}
            onChange={(e) => setCompanyAddress(e.target.value)}
            placeholder="Your company address"
          />
        </div>
      </>
    );
  }
  
  return (
    <>
      <div className="flex items-center border-b pb-4">
        <Building className="h-5 w-5 text-gray-500 mr-3" />
        <div>
          <p className="text-sm text-gray-500">Company Name</p>
          <p className="font-medium">{companyName}</p>
        </div>
      </div>
      
      <div className="flex items-start border-b pb-4">
        <FileText className="h-5 w-5 text-gray-500 mr-3 mt-0.5" />
        <div>
          <p className="text-sm text-gray-500">Company Description</p>
          {companyDescription ? (
            <p className="font-medium">{companyDescription}</p>
          ) : (
            <p className="text-gray-400 italic">No description provided</p>
          )}
        </div>
      </div>
      
      <div className="flex items-center border-b pb-4">
        <Phone className="h-5 w-5 text-gray-500 mr-3" />
        <div>
          <p className="text-sm text-gray-500">Company Phone</p>
          <p className="font-medium">
            {companyPhone ? companyPhone : 
              <span className="text-gray-400 italic">Not provided</span>}
          </p>
        </div>
      </div>
      
      <div className="flex items-center border-b pb-4">
        <MapPin className="h-5 w-5 text-gray-500 mr-3" />
        <div>
          <p className="text-sm text-gray-500">Company Address</p>
          <p className="font-medium">
            {companyAddress ? companyAddress : 
              <span className="text-gray-400 italic">Not provided</span>}
          </p>
        </div>
      </div>
      
      <div className="flex items-center border-b pb-4">
        <Mail className="h-5 w-5 text-gray-500 mr-3" />
        <div>
          <p className="text-sm text-gray-500">Email Address</p>
          <p className="font-medium">{email}</p>
        </div>
      </div>
      
      <div className="flex items-center pb-4">
        <Calendar className="h-5 w-5 text-gray-500 mr-3" />
        <div>
          <p className="text-sm text-gray-500">Account Created</p>
          <p className="font-medium">{new Date(createdAt).toLocaleDateString()}</p>
        </div>
      </div>
    </>
  );
};

export default CompanyDetails;
