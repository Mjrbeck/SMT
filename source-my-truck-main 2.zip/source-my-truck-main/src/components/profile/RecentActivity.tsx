
import React from "react";
import { Activity } from "lucide-react";
import { Button } from "@/components/ui/button";

interface ProfileData {
  created_at: string;
  updated_at: string;
}

interface RecentActivityProps {
  totalVehicles: number;
  profile: ProfileData | null;
}

const RecentActivity = ({ totalVehicles, profile }: RecentActivityProps) => {
  if (totalVehicles > 0) {
    return (
      <div className="space-y-4">
        <div className="flex justify-between items-center pb-2 border-b">
          <div className="flex items-center">
            <Activity className="h-4 w-4 text-green-500 mr-2" />
            <span>Vehicle listed</span>
          </div>
          <span className="text-sm text-gray-500">{new Date().toLocaleDateString()}</span>
        </div>
        
        <div className="flex justify-between items-center pb-2 border-b">
          <div className="flex items-center">
            <Activity className="h-4 w-4 text-blue-500 mr-2" />
            <span>Profile updated</span>
          </div>
          <span className="text-sm text-gray-500">{new Date(profile?.updated_at || "").toLocaleDateString()}</span>
        </div>
        
        <div className="flex justify-between items-center pb-2">
          <div className="flex items-center">
            <Activity className="h-4 w-4 text-purple-500 mr-2" />
            <span>Account created</span>
          </div>
          <span className="text-sm text-gray-500">{new Date(profile?.created_at || "").toLocaleDateString()}</span>
        </div>
      </div>
    );
  }
  
  return (
    <div className="text-center py-6">
      <p className="text-gray-500 mb-4">No recent activity</p>
      <Button variant="outline" asChild>
        <a href="/create-listing">Create Your First Listing</a>
      </Button>
    </div>
  );
};

export default RecentActivity;
