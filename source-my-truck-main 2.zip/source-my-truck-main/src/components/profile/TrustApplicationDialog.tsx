import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import TrustApplicationForm from "./TrustApplicationForm";

interface TrustApplicationDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: () => void;
}

const TrustApplicationDialog = ({ isOpen, onClose, onSuccess }: TrustApplicationDialogProps) => {
  const handleSuccess = () => {
    onSuccess?.();
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="sr-only">Trusted Seller Application</DialogTitle>
        </DialogHeader>
        <TrustApplicationForm onSuccess={handleSuccess} onCancel={onClose} />
      </DialogContent>
    </Dialog>
  );
};

export default TrustApplicationDialog;