
import React from "react";
import { RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface LoadingFallbackProps {
  isLoading: boolean;
  handleRefreshData: () => void;
  defaultTab: string;
}

const LoadingFallback = ({ isLoading, handleRefreshData, defaultTab }: LoadingFallbackProps) => {
  return (
    <div className="bg-white p-6 rounded-lg shadow-sm">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold">Loading Profile...</h2>
          <p className="text-gray-600 text-sm">
            Please wait while we load your profile information
          </p>
        </div>
        <Button 
          onClick={handleRefreshData} 
          size="sm"
          variant="outline"
          disabled={isLoading}
        >
          {isLoading ? (
            <>
              <RefreshCw className="mr-2 h-4 w-4 animate-spin" /> Loading...
            </>
          ) : (
            <>
              <RefreshCw className="mr-2 h-4 w-4" /> Refresh
            </>
          )}
        </Button>
      </div>
      
      <Tabs defaultValue={defaultTab} className="w-full">
        <TabsList className="mb-6">
          <TabsTrigger value="profile">Profile</TabsTrigger>
          <TabsTrigger value="credits">Credits</TabsTrigger>
        </TabsList>
        
        <TabsContent value="profile">
          <div className="p-6 bg-gray-50 rounded-lg">
            <div className="animate-pulse space-y-4">
              <div className="h-10 bg-gray-200 rounded w-1/3"></div>
              <div className="h-4 bg-gray-200 rounded w-1/2"></div>
              <div className="h-4 bg-gray-200 rounded w-3/4"></div>
              <div className="h-4 bg-gray-200 rounded w-1/2"></div>
            </div>
          </div>
        </TabsContent>
        
        <TabsContent value="credits">
          <div className="p-6 bg-gray-50 rounded-lg">
            <div className="animate-pulse space-y-4">
              <div className="h-10 bg-gray-200 rounded w-1/3"></div>
              <div className="h-4 bg-gray-200 rounded w-1/2"></div>
              <div className="h-4 bg-gray-200 rounded w-3/4"></div>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default LoadingFallback;
