
import { Transaction } from "./types";
import CreditSummary from "./CreditSummary";
import PurchaseForm from "./PurchaseForm";

interface CreditsManagerProps {
  currentCredits: number;
  transactions: Transaction[];
  onPurchase?: () => void;
}

const CreditsManager = ({ 
  currentCredits, 
  onPurchase 
}: CreditsManagerProps) => {
  return (
    <div className="space-y-6">
      <CreditSummary currentCredits={currentCredits} />
      <PurchaseForm onPurchase={onPurchase} />
    </div>
  );
};

export default CreditsManager;
