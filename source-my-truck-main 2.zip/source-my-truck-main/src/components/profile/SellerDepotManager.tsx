
import { useState } from "react";
import { Store, Building, ExternalLink } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { getSellerDepotById, getSellerProfileById } from "@/services/sellers/sellerDepotService";
import { useQuery } from "@tanstack/react-query";
import SellerDepotForm from "./SellerDepotForm";
import { Skeleton } from "@/components/ui/skeleton";
import { StyledCard } from "@/components/ui/consistent-ui";
import LogoDisplay from "./LogoDisplay";
import { Badge } from "@/components/ui/badge";
import { TrustBadges } from "@/components/ui/trust-badges";
import { getSellerTrustData, type SellerTrustData } from "@/services/trustBadgeService";

const SellerDepotManager = () => {
  const { user } = useAuth();
  const [refreshKey, setRefreshKey] = useState(0);

  // Fetch trust data for the current user
  const { data: trustData } = useQuery({
    queryKey: ["sellerTrust", user?.id, refreshKey],
    queryFn: () => getSellerTrustData(user?.id || ""),
    enabled: !!user?.id,
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  // Optimize the query with increased staleTime and proper caching
  const { data: sellerDepot, isLoading: isDepotLoading, isError: isDepotError } = useQuery({
    queryKey: ["sellerDepot", user?.id, refreshKey],
    queryFn: () => getSellerDepotById(user?.id || ""),
    enabled: !!user?.id,
    staleTime: 30 * 60 * 1000, // 30 minutes
    gcTime: 60 * 60 * 1000, // 60 minutes
    refetchOnMount: false,
    refetchOnWindowFocus: false,
    retry: 1,
  });

  // Fetch seller profile to get the logo URL
  const { data: sellerProfile, isLoading: isProfileLoading, isError: isProfileError } = useQuery({
    queryKey: ["sellerProfile", user?.id, refreshKey],
    queryFn: () => getSellerProfileById(user?.id || ""),
    enabled: !!user?.id,
    staleTime: 30 * 60 * 1000, // 30 minutes
    gcTime: 60 * 60 * 1000, // 60 minutes
    refetchOnMount: false,
    refetchOnWindowFocus: false,
    retry: 1,
  });

  const isLoading = isDepotLoading || isProfileLoading;
  const isError = isDepotError || isProfileError;

  const handleSuccess = () => {
    // Refresh the data after a successful update
    setRefreshKey(prev => prev + 1);
  };

  if (!user) {
    return null;
  }

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex justify-center py-6">
          <Skeleton className="h-32 w-32 rounded-md" />
        </div>
        <Skeleton className="h-8 w-1/3" />
        <Skeleton className="h-4 w-1/2" />
        <div className="grid gap-6 mt-6">
          <div className="space-y-2">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-4 w-2/3" />
          </div>
          <div className="space-y-2">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-4 w-2/3" />
          </div>
          <div className="space-y-2">
            <Skeleton className="h-20 w-full" />
            <Skeleton className="h-4 w-2/3" />
          </div>
        </div>
        <Skeleton className="h-10 w-32 mt-6 ml-auto" />
      </div>
    );
  }

  if (isError) {
    return (
      <Alert variant="destructive">
        <AlertTitle>Error</AlertTitle>
        <AlertDescription>
          Failed to load seller depot information. Please try again later.
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <div className="space-y-6">
      <StyledCard
        icon={<Building className="h-5 w-5" />}
        title="Your Digital Storefront"
        description="Create a professional shop page to showcase your vehicles and brand to potential buyers"
        contentClassName="pt-4"
        className="overflow-hidden relative"
      >
        <div className="absolute top-0 right-0 w-40 h-40 -mt-20 -mr-20 bg-gradient-to-l from-blue-50 to-indigo-50 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-0 w-40 h-40 -mb-20 -ml-20 bg-gradient-to-r from-indigo-50 to-purple-50 rounded-full blur-3xl"></div>
        
        {sellerDepot?.shop_name && (
          <div className="mb-6 text-center relative z-10">
            <div className="flex flex-col items-center">
              <LogoDisplay 
                logoUrl={sellerProfile?.logo_url || ""}
                size="lg"
                className="mb-2"
              />
              <h2 className="text-xl font-semibold mt-3">{sellerDepot.shop_name}</h2>
              {sellerDepot.tagline && (
                <p className="text-muted-foreground">{sellerDepot.tagline}</p>
              )}
              
              {trustData && (
                <TrustBadges 
                  isTrusted={trustData.isTrusted}
                  depotVerified={trustData.depotVerified}
                  hasMultipleListings={trustData.hasMultipleListings}
                  size="md"
                  className="mt-3 justify-center"
                />
              )}
              
              {sellerDepot.is_public && sellerDepot.custom_url_slug && (
                <div className="mt-3">
                  <Badge variant="outline" className="px-3 py-1 bg-green-50 text-green-700 border-green-200 hover:bg-green-100 transition-colors">
                    <span className="flex items-center">
                      <Store className="h-3 w-3 mr-1" />
                      Shop Active
                    </span>
                  </Badge>
                  <div className="mt-2">
                    <a 
                      href={`/seller/${sellerDepot.custom_url_slug}`} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-sm text-brand-blue hover:text-brand-orange flex items-center justify-center gap-1 transition-colors"
                    >
                      <span>View Your Shop</span>
                      <ExternalLink className="h-3 w-3" />
                    </a>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
        
        <div className="relative z-10">
          <SellerDepotForm 
            initialData={sellerDepot} 
            onSuccess={handleSuccess}
          />
        </div>
      </StyledCard>
    </div>
  );
};

export default SellerDepotManager;
