import { useState, useEffect, useRef } from "react";
import { useTransactionHistory } from "@/hooks/useTransactionHistory";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileText, Download, ReceiptText, RefreshCcw } from "lucide-react";
import { generateInvoice } from "@/services/credits/invoiceService";
import { Transaction } from "./types";
import { format } from "date-fns";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";

const InvoicesList = () => {
  const { transactions, isLoading, error, fetchTransactionHistory } = useTransactionHistory();
  const { user } = useAuth();
  const [downloadingId, setDownloadingId] = useState<string | null>(null);
  const initialFetchDone = useRef(false);
  const manualRefreshClickedRef = useRef(false);
  const mountedRef = useRef(true);
  const refreshTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    mountedRef.current = true;
    
    if (user && !initialFetchDone.current) {
      fetchTransactionHistory(true);
      initialFetchDone.current = true;
    }
    
    return () => {
      mountedRef.current = false;
      if (refreshTimeoutRef.current) {
        clearTimeout(refreshTimeoutRef.current);
      }
    };
  }, [user, fetchTransactionHistory]);

  // Filter only completed transactions and exclude test transactions
  const completedTransactions = transactions.filter(tx => {
    const isCompleted = tx.status === 'completed';
    // Only exclude actual test transactions (test_ prefix), but allow manual completions
    const isTestTransaction = tx.payment_intent_id && tx.payment_intent_id.includes('test_');
    
    // Only log transaction status for debugging
    if (process.env.NODE_ENV === 'development') {
      console.log(`Transaction ${tx.id.substring(0, 8)}: status=${tx.status}, isTest=${isTestTransaction}`);
    }
    
    return isCompleted && !isTestTransaction;
  });

  // Only log once when component mounts, not on every render
  useEffect(() => {
    if (process.env.NODE_ENV === 'development') {
      console.log(`InvoicesList Debug - Total transactions: ${transactions.length}`);
      console.log(`InvoicesList Debug - Filtered to ${completedTransactions.length} completed real transactions`);
      // Log all transaction statuses for debugging
      transactions.forEach(tx => {
        console.log(`InvoicesList Debug - Transaction ${tx.id.substring(0, 8)}: status=${tx.status}, payment_intent=${tx.payment_intent_id?.substring(0, 8) || 'null'}, isTest=${tx.payment_intent_id && tx.payment_intent_id.includes('test_')}`);
      });
    }
  }, [transactions.length, completedTransactions.length, transactions]);

  const handleDownloadInvoice = async (transaction: Transaction) => {
    try {
      setDownloadingId(transaction.id);
      
      const transactionWithDefaultCost = {
        ...transaction,
        cost_pence: transaction.cost_pence === 0 ? transaction.amount * 100 : transaction.cost_pence
      };
      
      const success = await generateInvoice(transactionWithDefaultCost);
      
      if (success) {
        toast(`Invoice for transaction #${transaction.id.substring(0, 8)} has been downloaded`, {
          description: "Your invoice has been downloaded successfully",
        });
      } else {
        toast.error("Download failed", {
          description: "Unable to generate invoice. Please try again later.",
        });
      }
    } catch (error) {
      console.error("Error downloading invoice:", error);
      toast.error("Download failed", {
        description: "An error occurred while generating your invoice.",
      });
    } finally {
      setDownloadingId(null);
    }
  };

  const handleRefresh = () => {
    if (!user) {
      toast("Not logged in", {
        description: "Please log in to view your invoices."
      });
      return;
    }

    if (manualRefreshClickedRef.current) {
      return;
    }
    
    manualRefreshClickedRef.current = true;
    
    toast("Refreshing invoices", {
      description: "Fetching your latest transaction data..."
    });
    
    fetchTransactionHistory(true);
    
    refreshTimeoutRef.current = setTimeout(() => {
      if (mountedRef.current) {
        manualRefreshClickedRef.current = false;
      }
    }, 3000);
  };

  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), 'dd MMM yyyy');
    } catch (error) {
      console.error("Invalid date format:", dateString);
      return "Unknown date";
    }
  };

  const formatAmount = (transaction: Transaction) => {
    const pence = transaction.cost_pence === 0 ? transaction.amount * 100 : transaction.cost_pence;
    return `£${(pence / 100).toFixed(2)}`;
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ReceiptText className="h-5 w-5 text-brand-blue" />
            <span>Invoices & Receipts</span>
          </CardTitle>
          <CardDescription>
            Download invoices for your credit purchases
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-40 flex items-center justify-center">
            <div className="animate-pulse flex space-x-2">
              <div className="h-3 w-3 bg-gray-300 rounded-full"></div>
              <div className="h-3 w-3 bg-gray-300 rounded-full"></div>
              <div className="h-3 w-3 bg-gray-300 rounded-full"></div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ReceiptText className="h-5 w-5 text-brand-blue" />
            <span>Invoices & Receipts</span>
          </CardTitle>
          <CardDescription>
            Download invoices for your credit purchases
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="p-4 text-center text-red-500">
            <p>Error loading your transactions. Please try again later.</p>
            <Button 
              variant="outline" 
              className="mt-2"
              onClick={() => fetchTransactionHistory(true)}
            >
              Retry
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle className="flex items-center gap-2">
            <ReceiptText className="h-5 w-5 text-brand-blue" />
            <span>Invoices & Receipts</span>
          </CardTitle>
          <CardDescription>
            Download invoices for your credit purchases
          </CardDescription>
        </div>
        <Button 
          variant="outline" 
          size="sm" 
          onClick={handleRefresh}
          className="flex items-center gap-2"
          disabled={manualRefreshClickedRef.current}
        >
          <RefreshCcw className="h-4 w-4" />
          <span>Refresh</span>
        </Button>
      </CardHeader>
      <CardContent>
        {completedTransactions.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <FileText className="h-12 w-12 mx-auto mb-2 text-gray-300" />
            <p>No completed transactions found</p>
            <p className="text-sm mt-1">Completed credit purchases will appear here</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Reference</TableHead>
                  <TableHead>Credits</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead className="text-right">Invoice</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {completedTransactions.map((transaction) => (
                  <TableRow key={transaction.id}>
                    <TableCell>{formatDate(transaction.created_at)}</TableCell>
                    <TableCell className="font-mono text-xs">
                      {transaction.id.substring(0, 8)}
                    </TableCell>
                    <TableCell>{transaction.amount}</TableCell>
                    <TableCell>{formatAmount(transaction)}</TableCell>
                    <TableCell className="text-right">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDownloadInvoice(transaction)}
                        disabled={downloadingId === transaction.id}
                        className="hover:bg-gray-100"
                      >
                        {downloadingId === transaction.id ? (
                          <div className="h-4 w-4 border-2 border-gray-600 border-t-transparent rounded-full animate-spin mr-2"></div>
                        ) : (
                          <Download className="h-4 w-4 mr-2" />
                        )}
                        Download
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default InvoicesList;
