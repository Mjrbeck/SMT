
export interface ProfileData {
  id: string;
  company_name: string;
  company_phone?: string;
  company_address?: string;
  company_description?: string;
  logo_url?: string;
  credits: number;
  created_at: string;
  updated_at: string;
  is_trusted?: boolean;
  depot_verified?: boolean;
}

export interface ActivityStats {
  totalVehicles: number;
  totalViews: number;
  averagePrice: number;
  accountAge: number; // in days
  lastActive: string;
}

export interface CompanyInfoProps {
  profile: ProfileData;
  user: { id: string; email?: string } | null;
  onProfileUpdate: (updatedProfile: ProfileData) => void;
}

export interface Transaction {
  id: string;
  user_id: string;
  amount: number;
  cost_pence: number;
  status: string; // Changed from union type to string to match DB
  created_at: string;
  payment_intent_id: string | null;
}
