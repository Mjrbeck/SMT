
import { Coins, AlertCircle, CheckCircle2, Calendar } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import CreditSummary from "./CreditSummary";
import CreditPurchaseOptions from "./CreditPurchaseOptions";
import TransactionHistory from "./TransactionHistory";
import { Transaction } from "./types";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";

interface CreditBalanceProps {
  credits: number | null;
  transactions?: Transaction[];
  onPurchase?: () => void;
}

export const CreditBalance = ({
  credits = 0,
  transactions = [],
  onPurchase
}: CreditBalanceProps) => {
  const [activeSubscription, setActiveSubscription] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isCancelDialogOpen, setIsCancelDialogOpen] = useState(false);
  const { toast } = useToast();

  useState(() => {
    const fetchSubscriptionStatus = async () => {
      setIsLoading(true);
      try {
        const { data, error } = await supabase.functions.invoke('stripe-subscription', {
          body: { 
            checkStatus: true
          }
        });
        
        if (error) throw error;
        
        if (data?.subscription) {
          setActiveSubscription(data.subscription);
        }
      } catch (error) {
        console.error("Error fetching subscription status:", error);
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchSubscriptionStatus();
  });

  const handleCancelSubscription = async () => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('stripe-subscription', {
        body: { 
          action: 'cancel',
          subscriptionId: activeSubscription?.id
        }
      });
      
      if (error) throw error;
      
      toast({
        title: "Subscription cancelled",
        description: "Your subscription has been cancelled but will remain active until the end of the current billing period.",
        duration: 5000,
      });
      
      if (data?.subscription) {
        setActiveSubscription({
          ...activeSubscription,
          status: 'canceled',
          cancelAtPeriodEnd: true
        });
      }
      
      setIsCancelDialogOpen(false);
    } catch (error) {
      console.error("Error cancelling subscription:", error);
      toast({
        title: "Error",
        description: "Failed to cancel subscription. Please try again later.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-8">
      <div className="relative overflow-hidden rounded-xl bg-gradient-to-r from-brand-darkBlue to-brand-blue p-8 text-white shadow-lg">
        <div className="absolute top-0 right-0 opacity-10">
          <Coins className="h-64 w-64 text-white" strokeWidth={0.5} />
        </div>
        <div className="flex flex-col md:flex-row justify-between gap-6">
          <div>
            <h2 className="text-3xl font-bold mb-2 flex items-center">
              <Coins className="mr-3 h-8 w-8" />
              Your Credit Balance
            </h2>
            <p className="text-blue-100 max-w-xl">
              Credits are used to create vehicle listings. Each credit gives you one listing for 30 days.
            </p>
          </div>
          <div className="text-center bg-white/20 backdrop-blur-sm rounded-lg p-4 flex flex-col items-center justify-center min-w-[160px]">
            <span className="text-5xl font-bold">{credits || 0}</span>
            <span className="text-blue-100 mt-1">Available Credits</span>
          </div>
        </div>
      </div>

      {activeSubscription && (
        <Alert className={`${
          activeSubscription.cancelAtPeriodEnd ? 'bg-amber-50 border-amber-200' : 'bg-green-50 border-green-200'
        } shadow-sm`}>
          <div className="flex flex-col md:flex-row md:items-center justify-between w-full gap-4">
            <div className="flex items-center gap-2">
              {activeSubscription.cancelAtPeriodEnd ? (
                <AlertCircle className="h-5 w-5 text-amber-500" />
              ) : (
                <CheckCircle2 className="h-5 w-5 text-green-500" />
              )}
              <AlertDescription className="text-sm font-medium">
                {activeSubscription.cancelAtPeriodEnd ? (
                  <span>
                    Your <span className="font-semibold">{activeSubscription.plan.name}</span> subscription has been cancelled but will remain active until {new Date(activeSubscription.currentPeriodEnd * 1000).toLocaleDateString()}.
                  </span>
                ) : (
                  <span>
                    You are currently subscribed to the <span className="font-semibold">{activeSubscription.plan.name}</span> plan. You receive {activeSubscription.plan.credits} credits every month.
                  </span>
                )}
              </AlertDescription>
            </div>
            
            {!activeSubscription.cancelAtPeriodEnd && (
              <Button 
                variant="outline" 
                className="shrink-0 border-red-300 text-red-600 hover:bg-red-50 hover:text-red-700" 
                size="sm"
                onClick={() => setIsCancelDialogOpen(true)}
              >
                <Calendar className="h-4 w-4 mr-2" />
                Cancel Subscription
              </Button>
            )}
          </div>
        </Alert>
      )}

      <div className="grid grid-cols-1 md:grid-cols-1 gap-4">
        <CreditSummary 
          currentCredits={credits || 0} 
          subscription={activeSubscription?.plan}
        />
      </div>

      <CreditPurchaseOptions 
        onPurchase={onPurchase} 
        disabled={!!activeSubscription}
      />
      
      {transactions.length > 0 && (
        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <TransactionHistory transactions={transactions} />
        </div>
      )}

      <AlertDialog open={isCancelDialogOpen} onOpenChange={setIsCancelDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Cancel Subscription?</AlertDialogTitle>
            <AlertDialogDescription>
              Your subscription will remain active until the end of your current billing period ({activeSubscription ? new Date(activeSubscription.currentPeriodEnd * 1000).toLocaleDateString() : ''}). After this date, you'll no longer receive monthly credits.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isLoading}>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={(e) => {
                e.preventDefault();
                handleCancelSubscription();
              }}
              disabled={isLoading}
              className="bg-red-600 hover:bg-red-700 focus:ring-red-600"
            >
              {isLoading ? 'Cancelling...' : 'Yes, cancel subscription'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};
