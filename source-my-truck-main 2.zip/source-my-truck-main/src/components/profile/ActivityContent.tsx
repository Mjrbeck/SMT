
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import ActivityOverview from "./ActivityOverview";
import RecentActivity from "./RecentActivity";
import { ActivityStats, ProfileData } from "./types";

interface ActivityContentProps {
  stats: ActivityStats;
  profile: ProfileData | null;
}

const ActivityContent = ({ stats, profile }: ActivityContentProps) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <Card>
        <CardHeader>
          <CardTitle>Activity Overview</CardTitle>
          <CardDescription>
            Summary of your account and vehicle activity
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ActivityOverview stats={stats} />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Recent Activity</CardTitle>
          <CardDescription>
            Your recent account activity
          </CardDescription>
        </CardHeader>
        <CardContent>
          <RecentActivity 
            totalVehicles={stats.totalVehicles} 
            profile={profile} 
          />
        </CardContent>
      </Card>
    </div>
  );
};

export default ActivityContent;
