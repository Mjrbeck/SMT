
import React from "react";
import { Button } from "@/components/ui/button";
import { Trash2, Upload } from "lucide-react";

interface LogoPreviewProps {
  logoUrl: string;
  onUpload: () => void;
  onRemove: () => void;
  isUploading: boolean;
}

const LogoPreview = ({ logoUrl, onUpload, onRemove, isUploading }: LogoPreviewProps) => {
  return (
    <div className="flex items-center gap-4">
      {logoUrl && (
        <div className="relative h-20 w-20 rounded-md overflow-hidden border">
          <img 
            src={logoUrl} 
            alt="Company logo" 
            className="h-full w-full object-cover"
          />
        </div>
      )}
      
      <div className="flex flex-col gap-2">
        <div className="flex gap-2">
          <Button
            type="button"
            variant="outline"
            size="sm"
            className="relative"
            disabled={isUploading}
            onClick={onUpload}
          >
            <Upload className="h-4 w-4 mr-1" />
            {logoUrl ? "Change Logo" : "Upload Logo"}
          </Button>
          
          {logoUrl && (
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={onRemove}
              disabled={isUploading}
            >
              <Trash2 className="h-4 w-4 mr-1" />
              Remove
            </Button>
          )}
        </div>
        
        <p className="text-xs text-muted-foreground">
          Supported formats: JPG, PNG, WebP. Max size: 500KB
        </p>
      </div>
    </div>
  );
};

export default LogoPreview;
