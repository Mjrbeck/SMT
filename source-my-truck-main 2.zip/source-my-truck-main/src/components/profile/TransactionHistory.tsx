import { BadgeDollarSign, Check, Loader2, X, AlertCircle, Clock } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Transaction } from "./types";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

interface TransactionHistoryProps {
  transactions: Transaction[];
}

const TransactionHistory = ({ transactions }: TransactionHistoryProps) => {
  // Filter out dummy/test transactions and old pending transactions
  const filteredTransactions = transactions.filter(transaction => {
    // Check if payment_intent_id starts with test_ or manual_ (dummy transactions)
    const isDummyTransaction = transaction.payment_intent_id && 
      (transaction.payment_intent_id.startsWith('test_') || 
       transaction.payment_intent_id.startsWith('manual_'));
    
    // Filter out old pending transactions (older than 30 minutes)
    const isPendingTransaction = transaction.status === 'pending';
    if (isPendingTransaction) {
      const createdAt = new Date(transaction.created_at);
      const thirtyMinutesAgo = new Date();
      thirtyMinutesAgo.setMinutes(thirtyMinutesAgo.getMinutes() - 30);
      
      // Keep only recent pending transactions
      if (createdAt < thirtyMinutesAgo) {
        return false;
      }
    }
       
    // Keep transactions that are not dummy transactions
    return !isDummyTransaction;
  });
  
  // Don't render if no transactions
  if (filteredTransactions.length === 0) {
    return null;
  }

  // Format utilities
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-GB', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
    });
  };

  const formatTime = (dateString: string) => {
    return new Date(dateString).toLocaleTimeString('en-GB', {
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const formatAmount = (pence: number) => {
    return `£${(pence / 100).toFixed(2)}`;
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <Check className="h-4 w-4 text-green-500" />;
      case 'pending':
        return <Clock className="h-4 w-4 text-yellow-500" />;
      case 'failed':
        return <X className="h-4 w-4 text-red-500" />;
      default:
        return <AlertCircle className="h-4 w-4 text-gray-500" />;
    }
  };

  const getStatusClass = (status: string) => {
    switch (status) {
      case 'completed':
        return "bg-green-100 text-green-800 border-green-200";
      case 'pending':
        return "bg-yellow-100 text-yellow-800 border-yellow-200";
      case 'failed':
        return "bg-red-100 text-red-800 border-red-200";
      default:
        return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  // Calculate if a pending transaction is recent (less than 5 minutes old)
  const isRecentPending = (transaction: Transaction) => {
    if (transaction.status !== 'pending') return false;
    
    const createdAt = new Date(transaction.created_at);
    const fiveMinutesAgo = new Date();
    fiveMinutesAgo.setMinutes(fiveMinutesAgo.getMinutes() - 5);
    
    return createdAt > fiveMinutesAgo;
  };

  return (
    <Card className="overflow-hidden border-0 shadow-md">
      <CardHeader>
        <div className="flex items-center gap-2">
          <BadgeDollarSign className="h-6 w-6 text-brand-blue" />
          <CardTitle>Transaction History</CardTitle>
        </div>
        <CardDescription>
          Your recent credit purchases
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {filteredTransactions.map((transaction) => (
            <div key={transaction.id} className="flex items-center justify-between border-b pb-4 last:border-0 last:pb-0">
              <div className="flex items-center gap-3">
                <div className="flex items-center justify-center w-8 h-8 rounded-full bg-gradient-to-br from-indigo-100 to-white">
                  <BadgeDollarSign className="h-4 w-4 text-indigo-600" />
                </div>
                <div>
                  <p className="font-medium">
                    {transaction.amount} credit{transaction.amount !== 1 ? 's' : ''}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {formatDate(transaction.created_at)} {formatTime(transaction.created_at)}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-muted-foreground">
                  {formatAmount(transaction.cost_pence)}
                </span>
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Badge className={`${getStatusClass(transaction.status)} flex items-center gap-1`} variant="outline">
                        {getStatusIcon(transaction.status)}
                        <span className="capitalize">{transaction.status}</span>
                      </Badge>
                    </TooltipTrigger>
                    <TooltipContent>
                      {transaction.status === 'pending' && isRecentPending(transaction) ? 
                        "Payment processing. Will disappear after 5 minutes if not completed." : 
                        `Transaction ${transaction.status}`}
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default TransactionHistory;
