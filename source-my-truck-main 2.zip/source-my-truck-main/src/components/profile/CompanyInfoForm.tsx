
import React, { useState } from "react";
import { CompanyInfoProps } from "./types";
import CompanyLogoUpload from "./CompanyLogoUpload";
import CompanyDetails from "./CompanyDetails";
import CompanyFormActions from "./CompanyFormActions";
import { useCompanyFormUpdate } from "@/hooks/useCompanyFormUpdate";

const CompanyInfoForm = ({ profile, user, onProfileUpdate }: CompanyInfoProps) => {
  const [isEditing, setIsEditing] = useState(false);
  
  const {
    formState,
    setters,
    isLoading,
    handleUpdateCompany,
    resetForm
  } = useCompanyFormUpdate({
    profile,
    user,
    onProfileUpdate
  });
  
  const handleCancel = () => {
    setIsEditing(false);
    resetForm();
  };
  
  const handleEdit = () => {
    setIsEditing(true);
  };
  
  const handleSubmitSuccess = () => {
    setIsEditing(false);
  };

  if (isEditing) {
    return (
      <form onSubmit={async (e) => {
        await handleUpdateCompany(e);
        handleSubmitSuccess();
      }} className="space-y-4">
        <CompanyLogoUpload
          logoUrl={formState.logoUrl}
          setLogoUrl={setters.setLogoUrl}
          isEditing={isEditing}
          user={user}
          profile={profile}
          onProfileUpdate={onProfileUpdate}
        />
        
        <CompanyDetails
          isEditing={isEditing}
          companyName={formState.companyName}
          setCompanyName={setters.setCompanyName}
          companyPhone={formState.companyPhone}
          setCompanyPhone={setters.setCompanyPhone}
          companyAddress={formState.companyAddress}
          setCompanyAddress={setters.setCompanyAddress}
          companyDescription={formState.companyDescription}
          setCompanyDescription={setters.setCompanyDescription}
          email={user?.email}
          createdAt={profile.created_at}
        />
        
        <CompanyFormActions
          isEditing={isEditing}
          isLoading={isLoading}
          onCancel={handleCancel}
          onEdit={handleEdit}
        />
      </form>
    );
  }

  return (
    <div className="space-y-4">
      <CompanyLogoUpload
        logoUrl={formState.logoUrl}
        setLogoUrl={setters.setLogoUrl}
        isEditing={isEditing}
        user={user}
        profile={profile}
        onProfileUpdate={onProfileUpdate}
      />
      
      <CompanyDetails
        isEditing={isEditing}
        companyName={profile.company_name}
        setCompanyName={setters.setCompanyName}
        companyPhone={profile.company_phone || ""}
        setCompanyPhone={setters.setCompanyPhone}
        companyAddress={profile.company_address || ""}
        setCompanyAddress={setters.setCompanyAddress}
        companyDescription={profile.company_description || ""}
        setCompanyDescription={setters.setCompanyDescription}
        email={user?.email}
        createdAt={profile.created_at}
      />
      
      <CompanyFormActions
        isEditing={isEditing}
        isLoading={isLoading}
        onCancel={handleCancel}
        onEdit={handleEdit}
      />
    </div>
  );
};

export default CompanyInfoForm;
