
import React from "react";
import { AlertCircle, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";

interface ErrorStateProps {
  isLoading: boolean;
  handleRefreshData: () => void;
}

const ErrorState = ({ isLoading, handleRefreshData }: ErrorStateProps) => {
  return (
    <div className="bg-white p-6 rounded-lg shadow-sm">
      <div className="flex flex-col items-center justify-center space-y-4 py-8">
        <AlertCircle className="h-12 w-12 text-red-500" />
        <h2 className="text-xl font-semibold text-center">Connection Error</h2>
        <p className="text-gray-600 text-center max-w-md">
          We couldn't load your profile information. This could be due to a network issue or server problem.
        </p>
        <Button 
          onClick={handleRefreshData} 
          className="mt-4"
          variant="outline"
          disabled={isLoading}
        >
          {isLoading ? (
            <>
              <RefreshCw className="mr-2 h-4 w-4 animate-spin" /> Trying...
            </>
          ) : (
            <>
              <RefreshCw className="mr-2 h-4 w-4" /> Try Again
            </>
          )}
        </Button>
      </div>
    </div>
  );
};

export default ErrorState;
