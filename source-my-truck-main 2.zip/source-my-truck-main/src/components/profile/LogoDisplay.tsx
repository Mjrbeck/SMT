
import React, { useState, useEffect } from "react";
import { AspectRatio } from "@/components/ui/aspect-ratio";
import { cn } from "@/lib/utils";
import { Store } from "lucide-react";
import { preloadImage } from "@/utils/imageUtils";

interface LogoDisplayProps {
  logoUrl: string;
  size?: "sm" | "md" | "lg";
  className?: string;
  showPlaceholder?: boolean;
}

const LogoDisplay = ({ 
  logoUrl, 
  size = "md", 
  className,
  showPlaceholder = true 
}: LogoDisplayProps) => {
  const [isLoading, setIsLoading] = useState(!!logoUrl);
  const [hasError, setHasError] = useState(false);
  
  useEffect(() => {
    if (!logoUrl) {
      setIsLoading(false);
      setHasError(false);
      return;
    }
    
    setIsLoading(true);
    setHasError(false);
    
    const timer = setTimeout(() => {
      if (isLoading) {
        setHasError(true);
        setIsLoading(false);
      }
    }, 3000);
    
    preloadImage(logoUrl)
      .then(() => {
        setIsLoading(false);
        setHasError(false);
      })
      .catch(() => {
        setHasError(true);
        setIsLoading(false);
      })
      .finally(() => {
        clearTimeout(timer);
      });
      
    return () => clearTimeout(timer);
  }, [logoUrl]);
  
  const sizes = {
    sm: "h-20 w-24",
    md: "h-32 w-40",
    lg: "h-40 w-52"
  };
  
  if (!logoUrl && !showPlaceholder) return null;
  
  return (
    <div className={cn("flex justify-center", className)}>
      <div className={cn(
        sizes[size],
        "rounded-md overflow-hidden border shadow-sm bg-white/80 backdrop-blur-sm transform transition-all duration-300 hover:shadow-md hover:scale-105"
      )}>
        <AspectRatio ratio={4/3}>
          {logoUrl && !hasError ? (
            <>
              {isLoading && (
                <div className="h-full w-full flex items-center justify-center bg-gray-50 animate-pulse">
                  <span className="text-sm text-gray-400">Loading...</span>
                </div>
              )}
              <img 
                src={logoUrl} 
                alt="Company logo" 
                className={`h-full w-full object-contain p-2 transition-all duration-300 hover:scale-105 ${isLoading ? 'opacity-0' : 'opacity-100'}`}
                onLoad={() => setIsLoading(false)}
                onError={() => {
                  setHasError(true);
                  setIsLoading(false);
                }}
              />
            </>
          ) : showPlaceholder ? (
            <div className="h-full w-full flex items-center justify-center bg-gray-50">
              <Store className="h-12 w-12 text-muted-foreground opacity-40" />
            </div>
          ) : null}
        </AspectRatio>
      </div>
    </div>
  );
};

export default LogoDisplay;
