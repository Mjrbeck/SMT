
import { useState } from "react";
import PurchaseForm from "./PurchaseForm";
import TransactionHistory from "./TransactionHistory";
import { Transaction } from "./types";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Coins, CreditCard } from "lucide-react";
import SubscriptionForm from "./SubscriptionForm";
import CreditSummary from "./CreditSummary";

interface CreditsContentProps {
  currentCredits: number | null;
  transactions: Transaction[];
  onPurchase?: () => void;
  currentSubscription?: {
    tier: string;
    status: string;
    expiresAt?: string;
  } | null;
}

const CreditsContent = ({
  currentCredits,
  transactions,
  onPurchase,
  currentSubscription
}: CreditsContentProps) => {
  const [activeTab, setActiveTab] = useState<string>("purchase");

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        <div className="lg:col-span-2">
          <CreditSummary currentCredits={currentCredits || 0} />
        </div>
        
        <Card className="overflow-hidden border-0 shadow-md lg:col-span-3">
          <CardHeader className="bg-gradient-to-r from-brand-blue to-brand-darkBlue text-white">
            <div className="flex items-center justify-between">
              <CardTitle className="text-xl flex items-center">
                <Coins className="mr-2 h-5 w-5" />
                Credit Balance
              </CardTitle>
              <div className="text-2xl font-bold">
                {currentCredits !== null ? (
                  <>{currentCredits} <span className="text-sm">credits</span></>
                ) : (
                  <div className="h-8 w-16 rounded bg-white/20 animate-pulse"></div>
                )}
              </div>
            </div>
          </CardHeader>

          <CardContent className="p-0">
            <Tabs defaultValue={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="purchase">One-time Purchase</TabsTrigger>
                <TabsTrigger value="subscription">Monthly Subscription</TabsTrigger>
              </TabsList>
              
              <TabsContent value="purchase" className="p-0">
                <PurchaseForm onPurchase={onPurchase} />
              </TabsContent>
              
              <TabsContent value="subscription" className="p-0">
                <SubscriptionForm onSubscribe={onPurchase} currentSubscription={currentSubscription} />
              </TabsContent>
            </Tabs>
          </CardContent>
          
          <CardFooter className="bg-muted/20 py-3 px-6 border-t">
            <p className="text-xs text-muted-foreground">
              <CreditCard className="inline h-3 w-3 mr-1" />
              Secure payments processed by Stripe
            </p>
          </CardFooter>
        </Card>
      </div>

      {transactions.length > 0 && <TransactionHistory transactions={transactions} />}
    </div>
  );
};

export default CreditsContent;
