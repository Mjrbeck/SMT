import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { BadgeCheck, Loader2, Building, TruckIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useLoadingState } from "@/hooks/useLoadingState";
import { useSearchParams } from "react-router-dom";
import { useProfile } from "@/contexts/ProfileContext";
import { invalidateCreditsCache } from "@/services/credits";

interface SubscriptionFormProps {
  onSubscribe?: () => void;
  currentSubscription?: {
    tier: string;
    status: string;
    expiresAt?: string;
  } | null;
}

interface SubscriptionTier {
  id: string;
  productId: string;
  name: string;
  credits: number;
  price: number;
  description: string;
}

const SUBSCRIPTION_TIERS: SubscriptionTier[] = [
  { 
    id: "small", 
    productId: "prod_S1ee849250Bu1O",
    name: "Small Fleet", 
    credits: 10, 
    price: 80, 
    description: "10 credits per month" 
  },
  { 
    id: "medium", 
    productId: "prod_S1efVBjWyMYccn",
    name: "Medium Fleet", 
    credits: 30, 
    price: 240, 
    description: "30 credits per month" 
  },
  { 
    id: "large", 
    productId: "prod_S1eg2ymiG7zU8z",
    name: "Large Fleet", 
    credits: 50, 
    price: 390, 
    description: "50 credits per month" 
  }
];

const SubscriptionForm = ({ onSubscribe, currentSubscription }: SubscriptionFormProps) => {
  const [selectedTier, setSelectedTier] = useState<string>("small");
  const { isLoading, startLoading, stopLoading } = useLoadingState();
  const { toast } = useToast();
  const [searchParams, setSearchParams] = useSearchParams();
  const [error, setError] = useState<string | null>(null);
  const { refreshProfileAfterPayment } = useProfile();
  
  const handleSubscribe = async () => {
    setError(null);
    startLoading();
    
    try {
      const tier = SUBSCRIPTION_TIERS.find(t => t.id === selectedTier);
      if (!tier) {
        throw new Error("Please select a subscription tier");
      }
      
      const timestamp = new Date().getTime();
      
      const { data, error } = await supabase.functions.invoke('stripe-subscription', {
        body: { 
          tierId: selectedTier,
          productId: tier.productId,
          timestamp
        }
      });
      
      if (error) {
        console.error("Error invoking stripe-subscription function:", error);
        throw new Error("Failed to start subscription process");
      }
      
      if (!data || !data.url) {
        console.error("Invalid response from stripe-subscription:", data);
        throw new Error("Received invalid checkout URL");
      }
      
      console.log("Redirecting to Stripe checkout:", data.url);
      console.log("Subscription ID created:", data.subscriptionId);
      
      if (data.subscriptionId) {
        localStorage.setItem('pendingSubscriptionId', data.subscriptionId);
        localStorage.setItem('pendingSubscriptionCreated', new Date().toISOString());
        localStorage.setItem('pendingSubscriptionTier', selectedTier);
      }
      
      window.location.href = data.url;
      
    } catch (error) {
      console.error("Error in handleSubscribe:", error);
      setError(error instanceof Error ? error.message : "Failed to process subscription");
      toast({
        title: "Subscription failed",
        description: error instanceof Error ? error.message : "Could not process subscription",
        variant: "destructive",
      });
      stopLoading();
    }
  };

  const handleSubscriptionRedirect = () => {
    const success = searchParams.get('subscription_success');
    const canceled = searchParams.get('subscription_canceled');
    
    if (success === 'true') {
      toast({
        title: "Subscription successful",
        description: "Your subscription has been activated",
        duration: 5000,
      });
      
      invalidateCreditsCache();
      if (refreshProfileAfterPayment) {
        refreshProfileAfterPayment();
      }
      
      if (onSubscribe) onSubscribe();
      
      const newParams = new URLSearchParams();
      newParams.set('tab', 'credits');
      setSearchParams(newParams);
    } 
    else if (canceled === 'true') {
      toast({
        title: "Subscription canceled",
        description: "Your subscription setup was canceled",
        variant: "destructive",
      });
      
      const newParams = new URLSearchParams();
      newParams.set('tab', 'credits');
      setSearchParams(newParams);
    }
  };
  
  useState(() => {
    handleSubscriptionRedirect();
  });
  
  if (currentSubscription && currentSubscription.status === 'active') {
    const tier = SUBSCRIPTION_TIERS.find(t => t.id === currentSubscription.tier) || {
      name: "Unknown",
      credits: 0,
      price: 0
    };
    
    return (
      <Card className="overflow-hidden border-0 shadow-md bg-gradient-to-br from-card to-green-50/50">
        <CardHeader>
          <div className="flex items-center gap-2">
            <BadgeCheck className="h-6 w-6 text-green-600" />
            <CardTitle>Active Subscription</CardTitle>
          </div>
          <CardDescription>
            Your current credits subscription
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="bg-green-50 border border-green-100 rounded-lg p-4 mb-4">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="font-semibold text-lg">{tier.name}</h3>
                <p className="text-sm text-muted-foreground">{tier.credits} credits per month</p>
              </div>
              <div className="text-right">
                <p className="font-bold text-lg">£{tier.price}</p>
                <p className="text-xs text-muted-foreground">per month</p>
              </div>
            </div>
            
            {currentSubscription.expiresAt && (
              <p className="text-sm mt-2 text-muted-foreground">
                Next billing date: {new Date(currentSubscription.expiresAt).toLocaleDateString()}
              </p>
            )}
          </div>
          
          <Button 
            variant="outline" 
            className="w-full"
            onClick={() => window.open('https://billing.stripe.com/p/login/cN24gMeR49Dg8bS5kk', '_blank')}
          >
            Manage Subscription
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="overflow-hidden border-0 shadow-md bg-gradient-to-br from-card to-indigo-50/50">
      <CardHeader>
        <div className="flex items-center gap-2">
          <Building className="h-6 w-6 text-brand-blue" />
          <CardTitle>Credit Subscription</CardTitle>
        </div>
        <CardDescription>
          Subscribe to receive credits automatically each month
        </CardDescription>
      </CardHeader>
      <CardContent>
        {error && (
          <Alert variant="destructive" className="mb-4">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}
        
        <div className="grid gap-4 mb-6">
          <RadioGroup 
            value={selectedTier} 
            onValueChange={setSelectedTier}
            className="grid gap-3"
          >
            {SUBSCRIPTION_TIERS.map((tier) => (
              <div 
                key={tier.id} 
                className={`relative flex items-center space-x-3 rounded-md border p-4 cursor-pointer transition-all ${
                  selectedTier === tier.id ? 'border-brand-blue bg-brand-blue/5' : 'hover:bg-slate-50'
                }`}
                onClick={() => setSelectedTier(tier.id)}
              >
                <RadioGroupItem value={tier.id} id={tier.id} className="border-gray-300" />
                <div className="flex-1">
                  <Label 
                    htmlFor={tier.id} 
                    className={`block text-sm font-medium ${selectedTier === tier.id ? 'text-brand-blue' : ''}`}
                  >
                    {tier.name}
                  </Label>
                  <div className="flex justify-between items-center">
                    <span className="text-xs text-gray-500">{tier.description}</span>
                    <div className="text-sm font-medium">
                      £{tier.price}/month
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </RadioGroup>
        </div>
        
        <Button 
          onClick={handleSubscribe} 
          disabled={isLoading}
          className="w-full bg-brand-blue hover:bg-brand-darkBlue text-white"
        >
          {isLoading ? (
            <>
              <span className="mr-2">Processing...</span>
              <Loader2 className="h-4 w-4 animate-spin" />
            </>
          ) : (
            <>
              <TruckIcon className="mr-2 h-4 w-4" />
              Subscribe Now
            </>
          )}
        </Button>
        
        <p className="text-xs text-muted-foreground mt-4 text-center">
          Cancel anytime. Your subscription will automatically renew each month.
        </p>
      </CardContent>
    </Card>
  );
};

export default SubscriptionForm;
