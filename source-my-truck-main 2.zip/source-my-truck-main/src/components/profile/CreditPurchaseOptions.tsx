
import { useState } from "react";
import { CreditCard, Clock, CheckCircle2, Tag, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import PurchaseForm from "./PurchaseForm";
import { supabase } from "@/integrations/supabase/client";

interface CreditPurchaseOptionsProps {
  onPurchase?: () => void;
  disabled?: boolean;
}

export const CreditPurchaseOptions = ({ 
  onPurchase, 
  disabled = false 
}: CreditPurchaseOptionsProps) => {
  const [isLoading, setIsLoading] = useState(false);
  
  const handleSubscribe = async (tier: string, productId: string) => {
    if (disabled) return;
    
    setIsLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('stripe-subscription', {
        body: { 
          tierId: tier,
          productId: productId
        }
      });
      
      if (error) throw error;
      if (data?.url) window.location.href = data.url;
    } catch (error) {
      console.error("Error starting subscription:", error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-md overflow-hidden mt-8">
      <div className="bg-gradient-to-r from-brand-blue to-brand-lightBlue text-white px-6 py-4">
        <h2 className="text-xl font-semibold flex items-center">
          <CreditCard className="mr-3 h-5 w-5" />
          Purchase Credits
        </h2>
      </div>
      
      <div className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* One-time Purchase Section */}
          <div className="rounded-lg border border-gray-200 overflow-hidden shadow-sm">
            <div className="bg-white px-5 py-4 border-b border-gray-200">
              <h3 className="text-lg font-medium flex items-center text-gray-800">
                <Tag className="h-5 w-5 mr-2 text-brand-blue" />
                One-time Purchase
              </h3>
            </div>
            <div className="bg-gray-50 p-5">
              <PurchaseForm onPurchase={onPurchase} simplified={true} />
            </div>
          </div>
          
          {/* Subscription Plans Section */}
          <div className="rounded-lg border border-gray-200 overflow-hidden shadow-sm">
            <div className="bg-white px-5 py-4 border-b border-gray-200">
              <h3 className="text-lg font-medium flex items-center text-gray-800">
                <Clock className="h-5 w-5 mr-2 text-brand-blue" />
                Monthly Subscription Plans
              </h3>
            </div>
            <div className="bg-gray-50 p-5 space-y-4">
              {/* Small Fleet Plan */}
              <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
                <div className="p-4">
                  <div className="flex justify-between items-center">
                    <div>
                      <h4 className="font-medium text-gray-800">Small Fleet</h4>
                      <div className="mt-1 flex items-baseline">
                        <span className="text-xl font-bold text-brand-blue">£80</span>
                        <span className="ml-1 text-sm text-gray-500">/month</span>
                      </div>
                      <div className="mt-1">
                        <span className="font-medium">10 credits</span> monthly
                      </div>
                      <div className="mt-1 flex items-center text-xs text-gray-500">
                        <CheckCircle2 className="h-3 w-3 mr-1 text-green-500" />
                        £8.00 per credit
                      </div>
                    </div>
                    <Button
                      onClick={() => handleSubscribe("small", "prod_S1ee849250Bu1O")}
                      disabled={disabled || isLoading}
                      variant="outline"
                      className="bg-gray-100 hover:bg-gray-200 text-gray-800"
                    >
                      Subscribe
                    </Button>
                  </div>
                </div>
              </div>
              
              {/* Medium Fleet Plan */}
              <div className="bg-white rounded-lg border border-blue-200 overflow-hidden relative shadow-sm">
                <div className="p-4">
                  <div className="absolute top-0 right-0 bg-brand-blue text-white px-2 py-1 text-xs font-semibold">
                    POPULAR
                  </div>
                  <div className="flex justify-between items-center pt-4">
                    <div>
                      <h4 className="font-medium text-gray-800">Medium Fleet</h4>
                      <div className="mt-1 flex items-baseline">
                        <span className="text-xl font-bold text-brand-blue">£240</span>
                        <span className="ml-1 text-sm text-gray-500">/month</span>
                      </div>
                      <div className="mt-1">
                        <span className="font-medium">30 credits</span> monthly
                      </div>
                      <div className="mt-1 flex items-center text-xs text-gray-500">
                        <CheckCircle2 className="h-3 w-3 mr-1 text-green-500" />
                        £8.00 per credit
                      </div>
                    </div>
                    <Button
                      onClick={() => handleSubscribe("medium", "prod_S1efVBjWyMYccn")}
                      disabled={disabled || isLoading}
                      className="bg-brand-blue hover:bg-brand-blue/90 text-white"
                    >
                      Subscribe
                    </Button>
                  </div>
                </div>
              </div>
              
              {/* Large Fleet Plan */}
              <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
                <div className="p-4">
                  <div className="flex justify-between items-center">
                    <div>
                      <h4 className="font-medium text-gray-800">Large Fleet</h4>
                      <div className="mt-1 flex items-baseline">
                        <span className="text-xl font-bold text-brand-blue">£390</span>
                        <span className="ml-1 text-sm text-gray-500">/month</span>
                      </div>
                      <div className="mt-1">
                        <span className="font-medium">50 credits</span> monthly
                      </div>
                      <div className="mt-1 flex items-center text-xs text-gray-500">
                        <CheckCircle2 className="h-3 w-3 mr-1 text-green-500" />
                        £7.80 per credit
                      </div>
                    </div>
                    <Button
                      onClick={() => handleSubscribe("large", "prod_S1eg2ymiG7zU8z")}
                      disabled={disabled || isLoading}
                      variant="outline"
                      className="bg-gray-100 hover:bg-gray-200 text-gray-800"
                    >
                      Subscribe
                    </Button>
                  </div>
                </div>
              </div>
              
              <p className="text-xs text-center text-gray-500 pt-2">
                All subscriptions automatically renew each month. Cancel anytime.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CreditPurchaseOptions;
