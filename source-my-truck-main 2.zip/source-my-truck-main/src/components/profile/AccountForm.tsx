
import { memo } from "react";
import ProfileContent from "./ProfileContent";
import { ProfileData } from "./types";

interface AccountFormProps {
  profile: ProfileData | null;
  onProfileUpdate: (updatedProfile: ProfileData) => void;
}

// Memoize with a custom equality function to prevent re-renders
export const AccountForm = memo(({ profile, onProfileUpdate }: AccountFormProps) => {
  if (!profile) {
    return <div>Loading profile information...</div>;
  }

  return <ProfileContent />;
}, (prevProps, nextProps) => {
  // Only re-render if the profile id changes (deep comparison is expensive)
  return prevProps.profile?.id === nextProps.profile?.id;
});

AccountForm.displayName = "AccountForm";
