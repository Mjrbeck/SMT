
import React, { useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Label } from "@/components/ui/label";
import { toast } from "@/hooks/use-toast";
import { ProfileData } from "./types";
import { validateFile, uploadToStorage, deleteFromStorage } from "@/utils/uploadUtils";
import LogoPreview from "./LogoPreview";
import LogoDisplay from "./LogoDisplay";

interface CompanyLogoUploadProps {
  logoUrl: string;
  setLogoUrl: (url: string) => void;
  isEditing: boolean;
  user: { id: string; email?: string } | null;
  profile: ProfileData;
  onProfileUpdate: (updatedProfile: ProfileData) => void;
}

const CompanyLogoUpload = ({
  logoUrl,
  setLogoUrl,
  isEditing,
  user,
  profile,
  onProfileUpdate
}: CompanyLogoUploadProps) => {
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;

    // Pass isLogo=true to enforce the 500KB limit for logos
    if (!validateFile(file, 5, true)) return;

    setIsUploading(true);
    try {
      const { url } = await uploadToStorage(file, user.id, 'company-logos');
      
      setLogoUrl(url);
      
      toast({
        title: "Logo uploaded",
        description: "Your company logo has been uploaded successfully.",
      });
    } catch (error) {
      console.error('Error uploading logo:', error);
      toast({
        title: "Upload failed",
        description: "There was a problem uploading your company logo.",
        variant: "destructive",
      });
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const handleRemoveLogo = async () => {
    if (!user || !logoUrl) return;
    
    try {
      await deleteFromStorage('company-logos', logoUrl);
      
      // Update profile in database
      const { error: updateError } = await supabase
        .from('profiles')
        .update({ logo_url: null })
        .eq('id', user.id);
      
      if (updateError) throw updateError;
      
      setLogoUrl('');
      onProfileUpdate({
        ...profile,
        logo_url: undefined
      });
      
      toast({
        title: "Logo removed",
        description: "Your company logo has been removed.",
      });
    } catch (error) {
      console.error('Error removing logo:', error);
      toast({
        title: "Removal failed",
        description: "There was a problem removing your company logo.",
        variant: "destructive",
      });
    }
  };

  if (isEditing) {
    return (
      <div className="space-y-2">
        <Label>Company Logo</Label>
        <LogoPreview
          logoUrl={logoUrl}
          onUpload={() => fileInputRef.current?.click()}
          onRemove={handleRemoveLogo}
          isUploading={isUploading}
        />
        <input
          ref={fileInputRef}
          type="file"
          accept="image/jpeg,image/png,image/webp"
          className="sr-only"
          onChange={handleLogoUpload}
          disabled={isUploading}
        />
      </div>
    );
  }

  return <LogoDisplay logoUrl={logoUrl} />;
};

export default CompanyLogoUpload;
