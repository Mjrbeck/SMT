
import React from "react";
import { Store, ExternalLink, Globe, MapPin, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

interface ShopPreviewProps {
  shopName: string;
  tagline?: string;
  logoUrl?: string;
  themeColor: string;
  buttonColor: string;
  textColor: string;
  backgroundColor: string;
  websiteUrl?: string;
  location?: string;
}

const ShopPreview = ({
  shopName,
  tagline,
  logoUrl,
  themeColor,
  buttonColor,
  textColor,
  backgroundColor,
  websiteUrl,
  location = "Your Location"
}: ShopPreviewProps) => {
  return (
    <div 
      className="rounded-md overflow-hidden border border-input shadow-sm"
      style={{ 
        backgroundColor,
        color: textColor
      }}
    >
      <div className="h-16 w-full" style={{ backgroundColor: `${themeColor}20` }} />
      
      <div className="p-4">
        <div className="flex items-center gap-3 mb-3">
          {logoUrl ? (
            <div className="w-10 h-10 rounded-md overflow-hidden border border-gray-100">
              <img 
                src={logoUrl} 
                alt={shopName} 
                className="w-full h-full object-contain bg-white p-1"
              />
            </div>
          ) : (
            <div 
              className="w-10 h-10 rounded-md flex items-center justify-center text-xl font-semibold"
              style={{ 
                backgroundColor: `${themeColor}30`,
                color: themeColor
              }}
            >
              {shopName.substring(0, 2).toUpperCase()}
            </div>
          )}
          
          <div>
            <h3 className="font-semibold">{shopName || "Your Shop Name"}</h3>
            <p className="text-sm opacity-70">{tagline || "Your shop tagline"}</p>
          </div>
        </div>
        
        <div className="space-y-3 mb-4">
          {location && (
            <div className="flex items-center gap-2 text-sm" style={{ color: `${textColor}99` }}>
              <MapPin className="h-4 w-4" style={{ color: themeColor }} />
              <span>{location}</span>
            </div>
          )}
          
          {websiteUrl && (
            <div className="flex items-center gap-2 text-sm" style={{ color: `${textColor}99` }}>
              <Globe className="h-4 w-4" style={{ color: themeColor }} />
              <span>{websiteUrl.replace(/^https?:\/\//, '')}</span>
            </div>
          )}
        </div>
        
        <div className="flex gap-2">
          <Button
            variant="default"
            size="sm"
            className="text-white"
            style={{ 
              backgroundColor: buttonColor,
            }}
          >
            <span className="flex items-center gap-1">
              View Inventory
              <ArrowRight className="h-3 w-3 ml-1" />
            </span>
          </Button>
          
          {websiteUrl && (
            <Button
              variant="outline"
              size="sm"
              style={{ 
                borderColor: buttonColor,
                color: buttonColor
              }}
            >
              <span className="flex items-center gap-1">
                <Globe className="h-3 w-3" />
                Visit Website
              </span>
            </Button>
          )}
        </div>
      </div>
    </div>
  );
};

export default ShopPreview;
