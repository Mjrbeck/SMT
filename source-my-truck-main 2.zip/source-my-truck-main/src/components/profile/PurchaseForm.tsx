import { useState, useEffect, useRef } from "react";
import { AlertCircle, CreditCard, Coins } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { purchaseCredits } from "@/services/credits";
import { useSearchParams } from "react-router-dom";
import { useLoadingState } from "@/hooks/useLoadingState";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useProfile } from "@/contexts/ProfileContext";
import { supabase } from "@/integrations/supabase/client";
import { invalidateCreditsCache } from "@/services/credits";
import { cn } from "@/lib/utils";

interface PurchaseFormProps {
  onPurchase?: () => void;
  simplified?: boolean;
}

const PurchaseForm = ({ onPurchase, simplified = false }: PurchaseFormProps) => {
  const [creditAmount, setCreditAmount] = useState(1);
  const { isLoading, startLoading, stopLoading } = useLoadingState();
  const { toast } = useToast();
  const [searchParams, setSearchParams] = useSearchParams();
  const [purchaseError, setPurchaseError] = useState<string | null>(null);
  const successfulRedirectProcessedRef = useRef(false);
  const { refreshProfileAfterPayment, handleTestModeRecovery } = useProfile();
  const [isTestMode, setIsTestMode] = useState<boolean | null>(null);
  
  const calculateTotal = () => {
    return creditAmount * 10.00;
  };

  // Quick selection amounts
  const quickAmounts = [1, 5, 10, 25, 50];
  
  useEffect(() => {
    const checkTestMode = async () => {
      try {
        const { data, error } = await supabase.functions.invoke('stripe-checkout', {
          body: { 
            checkTestMode: true
          }
        });
        
        if (data && typeof data.isTest === 'boolean') {
          setIsTestMode(data.isTest);
        }
      } catch (error) {
        console.error("Error checking test mode:", error);
      }
    };
    
    checkTestMode();
  }, []);
  
  useEffect(() => {
    const success = searchParams.get('success');
    const canceled = searchParams.get('canceled');
    const sessionId = searchParams.get('session_id');
    
    if (success === 'true' && sessionId && !successfulRedirectProcessedRef.current) {
      successfulRedirectProcessedRef.current = true;
      
      console.log("Payment successful redirect detected with sessionId:", sessionId);
      invalidateCreditsCache(); // Invalidate cache immediately
      
      const purchasedAmount = parseInt(localStorage.getItem('pendingTransactionAmount') || '0');
      
      toast({
        title: "Payment successful",
        description: "Your payment was successful. Your credits will be added shortly.",
        duration: 5000,
      });
      
      refreshProfileAfterPayment();
      
      if (onPurchase) {
        if (handleTestModeRecovery) {
          setTimeout(() => {
            handleTestModeRecovery(purchasedAmount);
          }, 500);
        }
        
        onPurchase();
      }
      
      // Do a second refresh after a delay to ensure we have the latest data
      setTimeout(() => {
        invalidateCreditsCache();
        refreshProfileAfterPayment();
        if (onPurchase) onPurchase();
      }, 2500);
      
      localStorage.setItem('lastSuccessfulSession', sessionId);
      localStorage.setItem('paymentSuccessTime', new Date().toISOString());
      
      // Redirect to settings page with credits tab
      window.location.href = '/settings?tab=credits';
    } else if (canceled === 'true') {
      toast({
        title: "Purchase canceled",
        description: "Your credit purchase was canceled.",
        variant: "destructive",
      });
      
      // Redirect to settings page with credits tab
      window.location.href = '/settings?tab=credits';
    }
  }, [searchParams, setSearchParams, toast, onPurchase, refreshProfileAfterPayment, handleTestModeRecovery]);
  
  const handlePurchase = async () => {
    setPurchaseError(null);
    startLoading();
    
    try {
      localStorage.setItem('pendingTransactionAmount', creditAmount.toString());
      
      const result = await purchaseCredits(creditAmount, "custom");
      
      if (!result.success) {
        setPurchaseError(result.error || "An error occurred while processing your purchase");
        toast({
          title: "Purchase failed",
          description: result.error || "An error occurred while processing your purchase",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Error in handlePurchase:", error);
      setPurchaseError("An unexpected error occurred");
      toast({
        title: "Purchase failed",
        description: "An unexpected error occurred",
        variant: "destructive",
      });
    } finally {
      stopLoading();
    }
  };

  return (
    <div className={simplified ? "" : "p-6"}>
      {isTestMode && !simplified && (
        <Alert className="mb-4 bg-amber-50 text-amber-800 border-amber-200">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            You are in test mode. Use card number 4242 4242 4242 4242 with any future expiry date and any CVC.
          </AlertDescription>
        </Alert>
      )}
      
      {purchaseError && (
        <Alert variant="destructive" className="mb-4">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            {purchaseError}
          </AlertDescription>
        </Alert>
      )}
      
      <div className="space-y-4">
        <div>
          <Label htmlFor="credit-amount" className="text-sm font-medium mb-2 block">
            Number of credits
          </Label>
          
          {/* Quick selection buttons */}
          <div className="grid grid-cols-5 gap-2 mb-3">
            {quickAmounts.map(amount => (
              <Button 
                key={amount}
                type="button"
                variant={creditAmount === amount ? "default" : "outline"}
                size="sm"
                className={cn(
                  "h-9",
                  creditAmount === amount && "bg-brand-blue hover:bg-brand-blue/90"
                )}
                onClick={() => setCreditAmount(amount)}
              >
                {amount}
              </Button>
            ))}
          </div>

          <div className="relative">
            <Input
              id="credit-amount"
              type="number"
              min={1}
              value={creditAmount}
              onChange={(e) => setCreditAmount(parseInt(e.target.value) || 0)}
              className="pr-16 focus:border-brand-blue"
            />
            <div className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500">
              credits
            </div>
          </div>
        </div>
        
        <div className="flex justify-between items-center p-3 bg-gray-50 rounded-md">
          <div>
            <span className="text-sm text-muted-foreground">Total:</span>
            <span className="block text-xl font-bold text-brand-blue">
              £{calculateTotal().toFixed(2)}
            </span>
          </div>
          <div className="text-xs text-right text-gray-500">
            <p>£10.00 per credit</p>
            <p>30 days per listing</p>
          </div>
        </div>

        <Button 
          onClick={handlePurchase} 
          disabled={isLoading || creditAmount < 1}
          className={`w-full ${simplified ? 'h-10' : 'h-12 text-lg'} bg-brand-orange hover:bg-brand-orange/90 text-white`}
        >
          {isLoading ? (
            <>
              <span className="mr-2">Processing...</span>
              <div className="h-5 w-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
            </>
          ) : (
            <>
              <Coins className="mr-2 h-5 w-5" />
              <span>Purchase {creditAmount} {creditAmount === 1 ? 'Credit' : 'Credits'}</span>
            </>
          )}
        </Button>

        {!simplified && (
          <div className="text-center mt-2">
            <p className="text-sm text-gray-500 flex items-center justify-center">
              <CreditCard className="h-3 w-3 mr-1 inline" />
              Secure payment processed by Stripe
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default PurchaseForm;
