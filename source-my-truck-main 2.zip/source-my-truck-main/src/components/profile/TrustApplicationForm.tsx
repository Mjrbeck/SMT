import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Upload, Shield, Award } from "lucide-react";

const trustApplicationSchema = z.object({
  fullName: z.string().min(2, "Full name is required"),
  companyName: z.string().optional(),
  businessEmail: z.string().email("Please enter a valid email address"),
  companyRegistrationNumber: z.string().optional(),
  yearsInBusiness: z.number().min(0, "Please enter a valid number").max(100, "Please enter a realistic number"),
  websiteOrSocialLinks: z.string().optional(),
  phoneNumber: z.string().optional(),
  reason: z.string().min(10, "Please provide a reason (minimum 10 characters)"),
});

type TrustApplicationFormData = z.infer<typeof trustApplicationSchema>;

interface TrustApplicationFormProps {
  onSuccess: () => void;
  onCancel: () => void;
}

const TrustApplicationForm = ({ onSuccess, onCancel }: TrustApplicationFormProps) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);

  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    watch
  } = useForm<TrustApplicationFormData>({
    resolver: zodResolver(trustApplicationSchema),
  });

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      // Validate file type and size
      const validTypes = ['image/jpeg', 'image/png', 'image/jpg', 'application/pdf'];
      const maxSize = 5 * 1024 * 1024; // 5MB

      if (!validTypes.includes(file.type)) {
        toast({
          title: "Invalid file type",
          description: "Please upload a JPG, PNG, or PDF file",
          variant: "destructive",
        });
        return;
      }

      if (file.size > maxSize) {
        toast({
          title: "File too large",
          description: "Please upload a file smaller than 5MB",
          variant: "destructive",
        });
        return;
      }

      setUploadedFile(file);
    }
  };

  const uploadDocument = async (file: File): Promise<string | null> => {
    try {
      const fileName = `trust-documents/${user?.id}/${Date.now()}-${file.name}`;
      
      const { data, error } = await supabase.storage
        .from('documents')
        .upload(fileName, file);

      if (error) {
        console.error('Error uploading file:', error);
        return null;
      }

      const { data: { publicUrl } } = supabase.storage
        .from('documents')
        .getPublicUrl(data.path);

      return publicUrl;
    } catch (error) {
      console.error('Error uploading document:', error);
      return null;
    }
  };

  const onSubmit = async (data: TrustApplicationFormData) => {
    if (!user) return;

    setIsSubmitting(true);
    try {
      let documentUrl = null;
      
      if (uploadedFile) {
        documentUrl = await uploadDocument(uploadedFile);
        if (!documentUrl) {
          throw new Error('Failed to upload document');
        }
      }

      const { data: applicationData, error } = await supabase
        .from('trust_applications')
        .insert({
          user_id: user.id,
          full_name: data.fullName,
          company_name: data.companyName || null,
          business_email: data.businessEmail,
          company_registration_number: data.companyRegistrationNumber || null,
          years_in_business: data.yearsInBusiness,
          website_or_social_links: data.websiteOrSocialLinks || null,
          phone_number: data.phoneNumber || null,
          document_url: documentUrl,
          reason: data.reason,
        })
        .select('id')
        .single();

      if (error) throw error;

      // Send email notification to support
      try {
        const { error: emailError } = await supabase.functions.invoke('send-trust-application-notification', {
          body: {
            applicationId: applicationData?.id || 'unknown',
            userId: user.id,
            fullName: data.fullName,
            companyName: data.companyName,
            businessEmail: data.businessEmail,
            companyRegistrationNumber: data.companyRegistrationNumber,
            yearsInBusiness: data.yearsInBusiness,
            websiteOrSocialLinks: data.websiteOrSocialLinks,
            phoneNumber: data.phoneNumber,
            reason: data.reason,
            documentUrl: documentUrl,
          },
        });

        if (emailError) {
          console.error('Failed to send notification email:', emailError);
          // Don't throw here - we still want to show success to user even if email fails
        }
      } catch (emailError) {
        console.error('Error sending notification email:', emailError);
        // Don't throw here - application was still submitted successfully
      }

      toast({
        title: "✅ Application submitted successfully!",
        description: "Your trusted seller application has been sent to our team. We'll review your application and get back to you within 2-3 business days via email.",
      });

      onSuccess();
    } catch (error) {
      console.error('Error submitting application:', error);
      toast({
        title: "Error submitting application",
        description: "Please try again later or contact support if the problem persists.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="text-center space-y-2">
        <div className="flex items-center justify-center gap-2 mb-4">
          <Shield className="h-6 w-6 text-blue-600" />
          <Award className="h-6 w-6 text-amber-500" />
        </div>
        <h2 className="text-2xl font-bold">Apply for Trusted Seller Status</h2>
        <p className="text-gray-600">
          Become a verified trusted seller to build credibility and attract more customers
        </p>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="fullName">Full Name *</Label>
            <Input
              id="fullName"
              {...register("fullName")}
              placeholder="Enter your full name"
            />
            {errors.fullName && (
              <p className="text-sm text-red-600">{errors.fullName.message}</p>
            )}
          </div>

          <div>
            <Label htmlFor="companyName">Company Name</Label>
            <Input
              id="companyName"
              {...register("companyName")}
              placeholder="Enter your company name"
            />
          </div>
        </div>

        <div>
          <Label htmlFor="businessEmail">Business Email Address *</Label>
          <Input
            id="businessEmail"
            type="email"
            {...register("businessEmail")}
            placeholder="Enter your business email"
          />
          {errors.businessEmail && (
            <p className="text-sm text-red-600">{errors.businessEmail.message}</p>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="companyRegistrationNumber">Company Registration Number (UK)</Label>
            <Input
              id="companyRegistrationNumber"
              {...register("companyRegistrationNumber")}
              placeholder="Enter your company registration number"
            />
          </div>

          <div>
            <Label htmlFor="yearsInBusiness">Years in Business *</Label>
            <Input
              id="yearsInBusiness"
              type="number"
              {...register("yearsInBusiness", { valueAsNumber: true })}
              placeholder="Enter years in business"
            />
            {errors.yearsInBusiness && (
              <p className="text-sm text-red-600">{errors.yearsInBusiness.message}</p>
            )}
          </div>
        </div>

        <div>
          <Label htmlFor="websiteOrSocialLinks">Website or Social Media Links</Label>
          <Input
            id="websiteOrSocialLinks"
            {...register("websiteOrSocialLinks")}
            placeholder="Enter your website or social media links"
          />
        </div>

        <div>
          <Label htmlFor="phoneNumber">Phone Number</Label>
          <Input
            id="phoneNumber"
            {...register("phoneNumber")}
            placeholder="Enter your phone number"
          />
        </div>

        <div>
          <Label htmlFor="document">Upload ID or Business Certificate (Optional)</Label>
          <div className="mt-1">
            <input
              type="file"
              id="document"
              accept=".jpg,.jpeg,.png,.pdf"
              onChange={handleFileUpload}
              className="hidden"
            />
            <Button
              type="button"
              variant="outline"
              onClick={() => document.getElementById('document')?.click()}
              className="w-full"
            >
              <Upload className="h-4 w-4 mr-2" />
              {uploadedFile ? uploadedFile.name : "Choose file (JPG, PNG, PDF - Max 5MB)"}
            </Button>
          </div>
        </div>

        <div>
          <Label htmlFor="reason">Why do you want to become a Trusted Seller? *</Label>
          <Textarea
            id="reason"
            {...register("reason")}
            placeholder="Tell us why you want to become a trusted seller..."
            rows={4}
          />
          {errors.reason && (
            <p className="text-sm text-red-600">{errors.reason.message}</p>
          )}
        </div>

        <div className="flex gap-3 pt-4">
          <Button
            type="button"
            variant="outline"
            onClick={onCancel}
            disabled={isSubmitting}
            className="flex-1"
          >
            Cancel
          </Button>
          <Button
            type="submit"
            disabled={isSubmitting}
            className="flex-1"
          >
            {isSubmitting ? "Submitting..." : "Submit Application"}
          </Button>
        </div>
      </form>
    </div>
  );
};

export default TrustApplicationForm;