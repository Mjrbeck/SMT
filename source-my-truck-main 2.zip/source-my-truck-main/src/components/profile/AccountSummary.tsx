
import React from "react";
import { Truck, Activity, Clock } from "lucide-react";
import { ActivityStats } from "./types";

interface AccountSummaryProps {
  stats?: ActivityStats;
}

const AccountSummary = ({ stats }: AccountSummaryProps) => {
  // Default values if stats is not provided
  const defaultStats: ActivityStats = {
    totalVehicles: 0,
    totalViews: 0,
    averagePrice: 0,
    accountAge: 0,
    lastActive: new Date().toISOString()
  };

  // Use provided stats or fallback to defaults
  const displayStats = stats || defaultStats;

  return (
    <div className="space-y-4">
      <div className="flex items-center">
        <Truck className="h-5 w-5 text-gray-500 mr-3" />
        <div>
          <p className="text-sm text-gray-500">Active Vehicles</p>
          <p className="font-medium">{displayStats.totalVehicles}</p>
        </div>
      </div>
      
      <div className="flex items-center">
        <Activity className="h-5 w-5 text-gray-500 mr-3" />
        <div>
          <p className="text-sm text-gray-500">Account Age</p>
          <p className="font-medium">{displayStats.accountAge} days</p>
        </div>
      </div>
      
      <div className="flex items-center">
        <Clock className="h-5 w-5 text-gray-500 mr-3" />
        <div>
          <p className="text-sm text-gray-500">Last Activity</p>
          <p className="font-medium">{new Date(displayStats.lastActive).toLocaleDateString()}</p>
        </div>
      </div>
    </div>
  );
};

export default AccountSummary;
