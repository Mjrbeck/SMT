import { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { 
  Truck, 
  Menu, 
  X, 
  LogIn, 
  UserPlus, 
  LogOut, 
  CreditCard, 
  Newspaper, 
  Phone,
  LayoutDashboard, 
  MessageSquare, 
  Building, 
  Settings
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useAuth } from "@/contexts/AuthContext";
import { useUserRole } from "@/hooks/useUserRole";
import { WatchlistCounter } from "@/components/watchlist/WatchlistCounter";

const NavBar = () => {
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { isAuthenticated, signOut, isLoading, user } = useAuth();
  const { isSeller, isBuyer } = useUserRole();

  useEffect(() => {
    setMobileMenuOpen(false);
  }, [location.pathname]);

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  return (
    <nav className="bg-white shadow-md relative overflow-hidden sticky top-0 z-50">
      <div className="absolute top-0 right-0 w-48 h-48 -mt-24 -mr-24 bg-brand-lightBlue/5 rounded-full blur-3xl"></div>
      <div className="container mx-auto px-4 py-3 relative z-10">
        <div className="flex justify-between items-center">
          <Link to="/" className="flex items-center space-x-2">
            <Truck className="h-8 w-8 text-brand-blue" />
            <span className="text-xl font-bold text-brand-blue">Source my <span className="text-brand-orange">Truck</span></span>
          </Link>

          <div className="hidden md:flex items-center space-x-6">
            <Link to="/listings" className="text-gray-600 hover:text-brand-orange transition-colors font-medium">
              Browse Trucks
            </Link>
            
            <Link to="/blog" className="text-gray-600 hover:text-brand-orange transition-colors font-medium flex items-center">
              <Newspaper className="mr-1 h-4 w-4" />
              Industry Info
            </Link>
            
            {isAuthenticated ? (
              <div className="flex items-center space-x-2">
                <WatchlistCounter variant="icon" />
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button 
                      variant="outline" 
                      className="flex items-center gap-2 border-indigo-100 hover:bg-indigo-50/70"
                    >
                      <span className="max-w-[100px] truncate">Account</span>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-56 border-0 shadow-md bg-white/95 backdrop-blur-sm">
                    <DropdownMenuLabel>
                      {isSeller ? (user?.user_metadata?.company_name || "My Company") : "My Account"}
                    </DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem asChild>
                      <Link to="/dashboard" className={`w-full cursor-pointer flex items-center ${location.pathname === "/dashboard" ? "text-brand-lightBlue" : ""}`}>
                        <LayoutDashboard className="mr-2 h-4 w-4 text-brand-lightBlue" />
                        Dashboard
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link to="/messages" className={`w-full cursor-pointer flex items-center ${location.pathname === "/messages" || location.pathname.startsWith("/messages/") ? "text-brand-lightBlue" : ""}`}>
                        <MessageSquare className="mr-2 h-4 w-4 text-brand-lightBlue" />
                        Messages
                      </Link>
                    </DropdownMenuItem>
                    {isSeller && (
                      <>
                        <DropdownMenuItem asChild>
                          <Link to="/inventory" className={`w-full cursor-pointer flex items-center ${location.pathname === "/inventory" ? "text-brand-lightBlue" : ""}`}>
                            <Truck className="mr-2 h-4 w-4 text-brand-lightBlue" />
                            My Inventory
                          </Link>
                        </DropdownMenuItem>
                        <DropdownMenuItem asChild>
                          <Link to="/profile" className={`w-full cursor-pointer flex items-center ${location.pathname === "/profile" ? "text-brand-lightBlue" : ""}`}>
                            <Building className="mr-2 h-4 w-4 text-brand-lightBlue" />
                            Company Profile
                          </Link>
                        </DropdownMenuItem>
                      </>
                    )}
                    <DropdownMenuItem asChild>
                      <Link to="/settings" className={`w-full cursor-pointer flex items-center ${location.pathname === "/settings" ? "text-brand-lightBlue" : ""}`}>
                        <Settings className="mr-2 h-4 w-4 text-brand-lightBlue" />
                        Settings
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem 
                      className="text-red-500 cursor-pointer"
                      onClick={() => signOut()}
                    >
                      <LogOut className="mr-2 h-4 w-4" />
                      Sign out
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            ) : (
              <div className="flex items-center space-x-2">
                <WatchlistCounter variant="icon" />
                <Link to="/login">
                  <Button variant="outline" className="flex items-center gap-2 border-indigo-100 hover:bg-indigo-50/70">
                    <LogIn className="h-4 w-4" />
                    <span>Sign In</span>
                  </Button>
                </Link>
                <Link to="/register">
                  <Button className="bg-gradient-to-r from-brand-blue to-brand-lightBlue hover:from-brand-lightBlue hover:to-brand-blue transition-all duration-300 flex items-center gap-2">
                    <UserPlus className="h-4 w-4" />
                    <span>Register</span>
                  </Button>
                </Link>
              </div>
            )}
          </div>

          <div className="md:hidden">
            <Button variant="ghost" size="icon" onClick={toggleMobileMenu}>
              {mobileMenuOpen ? <X /> : <Menu />}
            </Button>
          </div>
        </div>

        {mobileMenuOpen && (
          <div className="md:hidden pt-4 pb-2 space-y-2 bg-white/95 backdrop-blur-sm rounded-md mt-2 shadow-sm">
            <Link 
              to="/listings"
              className="block px-2 py-2 text-gray-600 hover:bg-gray-100 rounded flex items-center"
              onClick={() => setMobileMenuOpen(false)}
            >
              <Truck className="h-5 w-5 mr-3 flex-shrink-0 text-brand-lightBlue" />
              <span>Browse Trucks</span>
            </Link>
            
            <Link 
              to="/blog"
              className="block px-2 py-2 text-gray-600 hover:bg-gray-100 rounded flex items-center"
              onClick={() => setMobileMenuOpen(false)}
            >
              <Newspaper className="h-5 w-5 mr-3 flex-shrink-0 text-brand-lightBlue" />
              <span>Industry Info</span>
            </Link>
            
            <Link 
              to="/contact"
              className="block px-2 py-2 text-gray-600 hover:bg-gray-100 rounded flex items-center"
              onClick={() => setMobileMenuOpen(false)}
            >
              <Phone className="h-5 w-5 mr-3 flex-shrink-0 text-brand-lightBlue" />
              <span>Contact Us</span>
            </Link>
            
            <WatchlistCounter variant="button" className="mx-2" />
            
            {isAuthenticated ? (
              <>
                <Link 
                  to="/dashboard"
                  className={`block px-2 py-2 hover:bg-gray-100 rounded flex items-center ${
                    location.pathname === "/dashboard" ? "text-brand-lightBlue" : "text-gray-600"
                  }`}
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <LayoutDashboard className="h-5 w-5 mr-3 flex-shrink-0 text-brand-lightBlue" />
                  <span>Dashboard</span>
                </Link>
                <Link 
                  to="/messages"
                  className={`block px-2 py-2 hover:bg-gray-100 rounded flex items-center ${
                    location.pathname === "/messages" || location.pathname.startsWith("/messages/") ? "text-brand-lightBlue" : "text-gray-600"
                  }`}
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <MessageSquare className="h-5 w-5 mr-3 flex-shrink-0 text-brand-lightBlue" />
                  <span>Messages</span>
                </Link>
                {isSeller && (
                  <>
                    <Link 
                      to="/inventory"
                      className={`block px-2 py-2 hover:bg-gray-100 rounded flex items-center ${
                        location.pathname === "/inventory" ? "text-brand-lightBlue" : "text-gray-600"
                      }`}
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      <Truck className="h-5 w-5 mr-3 flex-shrink-0 text-brand-lightBlue" />
                      <span>My Inventory</span>
                    </Link>
                    <Link 
                      to="/profile"
                      className={`block px-2 py-2 hover:bg-gray-100 rounded flex items-center ${
                        location.pathname === "/profile" ? "text-brand-lightBlue" : "text-gray-600"
                      }`}
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      <Building className="h-5 w-5 mr-3 flex-shrink-0 text-brand-lightBlue" />
                      <span>Company Profile</span>
                    </Link>
                  </>
                )}
                <Link 
                  to="/settings"
                  className={`block px-2 py-2 hover:bg-gray-100 rounded flex items-center ${
                    location.pathname === "/settings" ? "text-brand-lightBlue" : "text-gray-600"
                  }`}
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <Settings className="h-5 w-5 mr-3 flex-shrink-0 text-brand-lightBlue" />
                  <span>Settings</span>
                </Link>
                <button
                  className="w-full text-left block px-2 py-2 text-red-500 hover:bg-gray-100 rounded flex items-center"
                  onClick={() => {
                    setMobileMenuOpen(false);
                    signOut();
                  }}
                >
                  <LogOut className="h-5 w-5 mr-3 flex-shrink-0" />
                  <span>Sign out</span>
                </button>
              </>
            ) : (
              <>
                <Link 
                  to="/login"
                  className="block px-2 py-2 text-gray-600 hover:bg-gray-100 rounded flex items-center"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <LogIn className="h-5 w-5 mr-3 flex-shrink-0 text-brand-lightBlue" />
                  <span>Sign In</span>
                </Link>
                <Link 
                  to="/register"
                  className="block px-2 py-2 text-gray-600 hover:bg-gray-100 rounded flex items-center"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <UserPlus className="h-5 w-5 mr-3 flex-shrink-0 text-brand-lightBlue" />
                  <span>Register</span>
                </Link>
              </>
            )}
          </div>
        )}
      </div>
    </nav>
  );
};

export default NavBar;
