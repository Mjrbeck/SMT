
import { useEffect } from "react";

// Helper component to suppress specific React warnings in development mode
const WarningSupressor = () => {
  useEffect(() => {
    if (process.env.NODE_ENV === 'development') {
      // Store the original console.error
      const originalConsoleError = console.error;
      
      // Override console.error to filter out specific warnings
      console.error = (...args: any[]) => {
        // Filter out the UNSAFE_componentWillMount warning for SideEffect
        if (
          typeof args[0] === 'string' && 
          args[0].includes('Warning: Using UNSAFE_componentWillMount in strict mode') &&
          args[0].includes('SideEffect')
        ) {
          return;
        }
        
        // Pass through all other console errors
        originalConsoleError.apply(console, args);
      };
      
      // Return a cleanup function to restore the original console.error
      return () => {
        console.error = originalConsoleError;
      };
    }
    
    return () => {}; // No-op for production
  }, []);
  
  return null; // This component doesn't render anything
};

export default WarningSupressor;
