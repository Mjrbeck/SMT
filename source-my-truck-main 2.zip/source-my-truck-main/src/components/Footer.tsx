
import { Link } from "react-router-dom";
import { Truck, Mail } from "lucide-react";

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gray-900 text-white pt-10 pb-6">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Logo and Description */}
          <div className="col-span-1">
            <div className="flex items-center space-x-2 mb-4">
              <Truck className="h-6 w-6 text-brand-orange" />
              <span className="text-lg font-bold">Source my Truck</span>
            </div>
            <p className="text-gray-400 text-sm">
              The leading marketplace for commercial trucks and vehicles. 
              Connecting sellers and buyers in the transportation industry.
            </p>
          </div>

          {/* Quick Links */}
          <div className="col-span-1">
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-gray-400 hover:text-brand-orange transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/listings" className="text-gray-400 hover:text-brand-orange transition-colors">
                  Browse Trucks
                </Link>
              </li>
              <li>
                <Link to="/pricing" className="text-gray-400 hover:text-brand-orange transition-colors">
                  Pricing
                </Link>
              </li>
              <li>
                <Link to="/blog" className="text-gray-400 hover:text-brand-orange transition-colors">
                  Industry Info
                </Link>
              </li>
              <li>
                <Link to="/about" className="text-gray-400 hover:text-brand-orange transition-colors">
                  About Us
                </Link>
              </li>
            </ul>
          </div>

          {/* Seller Resources */}
          <div className="col-span-1">
            <h3 className="text-lg font-semibold mb-4">Seller Resources</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/login" className="text-gray-400 hover:text-brand-orange transition-colors">
                  Seller Login
                </Link>
              </li>
              <li>
                <Link to="/register" className="text-gray-400 hover:text-brand-orange transition-colors">
                  Create Account
                </Link>
              </li>
              <li>
                <Link to="/seller-guide" className="text-gray-400 hover:text-brand-orange transition-colors">
                  Selling Guide
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact Information */}
          <div className="col-span-1">
            <h3 className="text-lg font-semibold mb-4">Contact Us</h3>
            <ul className="space-y-3">
              <li className="flex items-center">
                <Mail className="h-5 w-5 text-gray-400 mr-2" />
                <a href="mailto:support@sourcemytruck.com" className="text-gray-400 hover:text-brand-orange transition-colors">
                  support@sourcemytruck.com
                </a>
              </li>
              <li>
                <Link to="/contact" className="text-brand-orange hover:text-white transition-colors">
                  Contact Form →
                </Link>
              </li>
            </ul>
          </div>
        </div>

        {/* Legal Links */}
        <div className="border-t border-gray-800 mt-8 pt-6 flex flex-col md:flex-row justify-between items-center">
          <p className="text-sm text-gray-500">&copy; {currentYear} Source my Truck. All rights reserved.</p>
          <div className="mt-4 md:mt-0 flex space-x-4 text-sm">
            <Link to="/terms" className="text-gray-500 hover:text-brand-orange transition-colors">
              Terms & Conditions
            </Link>
            <Link to="/privacy" className="text-gray-500 hover:text-brand-orange transition-colors">
              Privacy Policy
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
