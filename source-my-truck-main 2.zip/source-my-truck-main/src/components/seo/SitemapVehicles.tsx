import { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';

const SitemapVehicles = () => {
  const [xmlContent, setXmlContent] = useState<string>('');
  const [isLoading, setIsLoading] = useState(true);
  const location = useLocation();

  useEffect(() => {
    const fetchSitemap = async () => {
      try {
        // Get the current pathname to determine which sitemap to fetch
        const pathname = location.pathname;
        
        // Fetch the sitemap from the new proxy function
        const response = await fetch(`https://xfpokywrvoshtwtevyaz.supabase.co/functions/v1/sitemap-proxy${pathname}`);
        
        if (!response.ok) {
          throw new Error(`Failed to fetch sitemap: ${response.status}`);
        }
        
        const content = await response.text();
        setXmlContent(content);
        
        // Set content type in document head
        const existingMeta = document.querySelector('meta[http-equiv="Content-Type"]');
        if (existingMeta) {
          existingMeta.setAttribute('content', 'application/xml; charset=utf-8');
        } else {
          const meta = document.createElement('meta');
          meta.httpEquiv = 'Content-Type';
          meta.content = 'application/xml; charset=utf-8';
          document.head.appendChild(meta);
        }
        setIsLoading(false);
        
      } catch (error) {
        console.error('Error fetching vehicles sitemap:', error);
        
        // Fallback XML content
        const fallbackXml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>https://source-my-truck.vercel.app/listings</loc>
    <lastmod>${new Date().toISOString().split('T')[0]}</lastmod>
    <changefreq>daily</changefreq>
    <priority>0.9</priority>
  </url>
</urlset>`;
        
        setXmlContent(fallbackXml);
        setIsLoading(false);
      }
    };
    
    fetchSitemap();
  }, [location.pathname]);

  if (isLoading) {
    return <div>Loading sitemap...</div>;
  }

  // Return raw XML content
  return (
    <div
      style={{
        whiteSpace: 'pre',
        fontFamily: 'monospace',
        fontSize: '12px',
        lineHeight: '1.4'
      }}
      dangerouslySetInnerHTML={{ __html: xmlContent }}
    />
  );
};

export default SitemapVehicles;