import { useEffect } from 'react';
import { useParams } from 'react-router-dom';

const BotRedirector = () => {
  const { id } = useParams<{ id: string }>();

  useEffect(() => {
    // Only run on client side
    if (typeof window === 'undefined') return;
    
    const userAgent = navigator.userAgent || '';
    
    // Detect crawlers with improved Facebook detection
    const isCrawlerBot = /((google|bing|yandex)?bot|crawler|spider|facebookexternalhit|facebookcatalog|facebot|slackbot|discord|twitter|linkedin|whatsapp)/i.test(userAgent);
    
    console.log('🔍 User Agent:', userAgent);
    console.log('🤖 Is Crawler Bot:', isCrawlerBot);
    
    // If this is a bot and we have a vehicle ID, redirect to prerendered version
    if (isCrawlerBot && id) {
      const prerenderUrl = `https://xfpokywrvoshtwtevyaz.supabase.co/functions/v1/vehicle-meta-prerender/${id}`;
      
      // Redirect immediately without adding to browser history
      window.location.replace(prerenderUrl);
      return;
    }
  }, [id]);

  // This component doesn't render anything
  return null;
};

export default BotRedirector;