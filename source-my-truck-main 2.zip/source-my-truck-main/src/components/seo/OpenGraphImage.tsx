
import React, { memo, useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { getSocialSharingImage } from '@/utils/imageUtils';
import { useIsMobile } from '@/hooks/use-mobile';

interface OpenGraphImageProps {
  title?: string;
  description?: string;
  imageUrl?: string;
  type?: 'website' | 'article' | 'product';
}

const OpenGraphImage: React.FC<OpenGraphImageProps> = memo(({
  title = "Source my Truck - Find Commercial Trucks in the UK",
  description = "The UK's leading marketplace for buying and selling commercial trucks and vehicles.",
  imageUrl = "/source-my-truck-logo.png",
  type = "website"
}) => {
  const location = useLocation();
  const isMobile = useIsMobile();
  const baseUrl = typeof window !== 'undefined' ? window.location.origin : "https://source-my-truck.vercel.app";
  const currentUrl = `${baseUrl}${location.pathname}`;
  const [imageLoaded, setImageLoaded] = useState(false);
  
  const finalImageUrl = getSocialSharingImage(imageUrl);
  
  const isVehiclePage = location.pathname.startsWith('/vehicle/');
  const vehicleId = isVehiclePage ? location.pathname.split('/').pop() : null;
  const prerenderUrl = vehicleId ? `${baseUrl}/social-prerender/${vehicleId}` : null;
  
  useEffect(() => {
    // Preload the image to ensure it's in the browser cache
    const img = new Image();
    img.onload = () => {
      setImageLoaded(true);
      if (process.env.NODE_ENV === 'development') {
        console.log(`✅ [OpenGraphImage] Image loaded successfully: ${finalImageUrl}`);
      }
    };
    img.onerror = (error) => {
      console.error(`❌ [OpenGraphImage] Image failed to load: ${finalImageUrl}`, error);
      // Fall back to the site logo if the main image fails
      if (finalImageUrl !== `${baseUrl}/source-my-truck-logo.png`) {
        const fallbackImg = new Image();
        fallbackImg.src = `${baseUrl}/source-my-truck-logo.png`;
      }
    };
    img.src = finalImageUrl;
    
    // Cleanup
    return () => {
      img.onload = null;
      img.onerror = null;
    };
  }, [finalImageUrl, baseUrl]);

  return (
    <Helmet>
      {/* Basic meta tags */}
      <meta property="og:title" content={title} />
      <meta property="og:description" content={description} />
      <meta property="og:url" content={currentUrl} />
      <meta property="og:type" content={type} />
      
      {/* Image meta tags */}
      <meta property="og:image" content={finalImageUrl} />
      <meta property="og:image:secure_url" content={finalImageUrl} />
      <meta property="og:image:width" content="1200" />
      <meta property="og:image:height" content="630" />
      <meta property="og:image:alt" content={title} />
      <meta property="og:site_name" content="Source my Truck" />
      
      {/* Twitter meta tags */}
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:site" content="@sourcemytruck" />
      <meta name="twitter:title" content={title} />
      <meta name="twitter:description" content={description} />
      <meta name="twitter:image" content={finalImageUrl} />
      <meta name="twitter:image:alt" content={title} />
      
      {/* Mobile specific meta tags */}
      <meta name="format-detection" content="telephone=no" />
      <meta name="apple-mobile-web-app-capable" content="yes" />
      <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
      
      {/* Prerender related tags */}
      {isVehiclePage && (
        <>
          <meta name="fragment" content="!" />
          {prerenderUrl && <link rel="prerender" href={prerenderUrl} />}
        </>
      )}
    </Helmet>
  );
});

OpenGraphImage.displayName = 'OpenGraphImage';

export default OpenGraphImage;
