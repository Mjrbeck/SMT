
import React, { useEffect } from 'react';
import { useLocation } from 'react-router-dom';

interface NotFoundHandlerProps {
  children: React.ReactNode;
}

/**
 * Component that handles 404 errors and logs them for analysis
 */
const NotFoundHandler: React.FC<NotFoundHandlerProps> = ({ children }) => {
  const location = useLocation();

  useEffect(() => {
    // Check if this is a 404 page
    if (location.pathname.endsWith('/not-found') || location.pathname === '*') {
      // Log the 404 error for analysis
      console.error(`404 Error encountered: ${location.pathname}`);
      
      // If we have a referrer, log it to help identify broken links
      const referrer = document.referrer;
      if (referrer) {
        console.error(`Referrer for 404: ${referrer}`);
      }
      
      // Get the original URL that was being accessed
      const originalPath = location.state?.from || location.pathname;
      console.error(`Original path before 404: ${originalPath}`);
    }
  }, [location]);

  return <>{children}</>;
};

export default NotFoundHandler;
