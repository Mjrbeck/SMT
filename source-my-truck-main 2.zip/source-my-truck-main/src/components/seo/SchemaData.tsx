
import { VehicleData } from "@/components/VehicleCard";
import { SellerDetails } from "@/hooks/useVehicleDetails";

interface SchemaDataProps {
  type: 'vehicle' | 'seller' | 'organization' | 'website';
  data: any;
}

/**
 * Component for adding structured data (Schema.org) to pages
 * Improves how search engines understand and display content
 */
const SchemaData = ({ type, data }: SchemaDataProps) => {
  let schemaData = {};

  switch (type) {
    case 'vehicle':
      schemaData = generateVehicleSchema(data);
      break;
    case 'seller':
      schemaData = generateSellerSchema(data);
      break;
    case 'organization':
      schemaData = generateOrganizationSchema(data);
      break;
    case 'website':
      schemaData = generateWebsiteSchema();
      break;
    default:
      schemaData = {};
  }

  return (
    <script 
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(schemaData) }}
    />
  );
};

// Generate schema for vehicle listings
const generateVehicleSchema = (vehicle: VehicleData) => {
  return {
    "@context": "https://schema.org/",
    "@type": "Vehicle",
    "name": `${vehicle.year} ${vehicle.make} ${vehicle.model}`,
    "brand": {
      "@type": "Brand",
      "name": vehicle.make
    },
    "model": vehicle.model,
    "vehicleModelDate": vehicle.year,
    "vehicleConfiguration": vehicle.bodyType || "", // Changed from 'trim' to 'bodyType' which exists in VehicleData
    "vehicleIdentificationNumber": vehicle.registration || "",
    "mileageFromOdometer": {
      "@type": "QuantitativeValue",
      "value": vehicle.mileage || 0,
      "unitCode": "SMI"
    },
    "fuelType": vehicle.fuelType || "",
    "driveWheelConfiguration": vehicle.axleConfiguration || "", // Changed from 'driveType' to 'axleConfiguration'
    "vehicleTransmission": vehicle.transmission || "",
    "description": vehicle.description || `${vehicle.year} ${vehicle.make} ${vehicle.model} for sale`,
    "offers": {
      "@type": "Offer",
      "price": vehicle.price || 0,
      "priceCurrency": "GBP",
      "availability": "https://schema.org/InStock"
    },
    "image": vehicle.imageUrl || (vehicle.additionalImages && vehicle.additionalImages.length > 0 
      ? vehicle.additionalImages[0] 
      : "https://source-my-truck.vercel.app/og-image.png")
  };
};

// Generate schema for seller information
const generateSellerSchema = (sellerDetails: SellerDetails) => {
  return {
    "@context": "https://schema.org/",
    "@type": "AutoDealer",
    "name": sellerDetails.name,
    "telephone": sellerDetails.phone,
    "address": {
      "@type": "PostalAddress",
      "addressLocality": sellerDetails.location
    },
    "image": sellerDetails.logoUrl || "https://source-my-truck.vercel.app/og-image.png"
  };
};

// Generate schema for the organization (Source my Truck)
const generateOrganizationSchema = (data: any = {}) => {
  return {
    "@context": "https://schema.org/",
    "@type": "Organization",
    "name": "Source my Truck",
    "url": "https://source-my-truck.vercel.app",
    "logo": "https://source-my-truck.vercel.app/og-image.png",
    "sameAs": data.socialLinks || [],
    "description": "The UK's leading marketplace for buying and selling commercial trucks and vehicles."
  };
};

// Generate schema for the website
const generateWebsiteSchema = () => {
  return {
    "@context": "https://schema.org/",
    "@type": "WebSite",
    "name": "Source my Truck",
    "url": "https://source-my-truck.vercel.app",
    "potentialAction": {
      "@type": "SearchAction",
      "target": {
        "@type": "EntryPoint",
        "urlTemplate": "https://source-my-truck.vercel.app/listings?search={search_term_string}"
      },
      "query-input": "required name=search_term_string"
    }
  };
};

export default SchemaData;
