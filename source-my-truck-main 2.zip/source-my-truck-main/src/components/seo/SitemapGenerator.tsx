
import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface SitemapGeneratorProps {
  type: 'vehicles' | 'sellers' | 'blog';
}

interface SitemapItem {
  loc: string;
  lastmod: string;
  priority: number;
  changefreq: 'always' | 'hourly' | 'daily' | 'weekly' | 'monthly' | 'yearly' | 'never';
}

/**
 * This component would typically be used on the server side
 * In a real production environment, you would generate sitemaps using a server-side process
 * This is a simplified client-side implementation for demonstration purposes
 */
const SitemapGenerator = ({ type }: SitemapGeneratorProps) => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedItems, setGeneratedItems] = useState<number>(0);
  const baseUrl = 'https://source-my-truck.vercel.app';

  useEffect(() => {
    // Use a reference to track if the component is mounted
    let isMounted = true;
    
    const generateSitemap = async () => {
      // Don't start generating if already in progress
      if (isGenerating) return;
      
      // Set the generating state to true
      setIsGenerating(true);
      setGeneratedItems(0);
      
      // Start with an empty items array that we'll fill based on type
      let items: SitemapItem[] = [];
      
      try {
        switch (type) {
          case 'vehicles':
            // Use pagination to reduce memory usage
            const pageSize = 100;
            let page = 0;
            let hasMoreVehicles = true;
            
            while (hasMoreVehicles) {
              // Fetch active vehicle IDs with pagination
              const { data: vehicles, error: vehiclesError } = await supabase
                .from('vehicles')
                .select('id, created_at, make, model, year, body_type')
                .eq('status', 'active')
                .range(page * pageSize, (page + 1) * pageSize - 1);
              
              if (vehiclesError) {
                console.error('Error fetching vehicles for sitemap:', vehiclesError);
                toast.error(`Failed to generate vehicles sitemap: ${vehiclesError.message}`);
                return;
              }
              
              if (!vehicles || vehicles.length === 0) {
                hasMoreVehicles = false;
                break;
              }
              
              // Generate individual vehicle URLs
              const vehicleItems = vehicles.map(vehicle => ({
                loc: `${baseUrl}/vehicle/${vehicle.id}`,
                lastmod: new Date(vehicle.created_at).toISOString().split('T')[0],
                priority: 0.8,
                changefreq: 'daily' as const
              }));
              
              items = [...items, ...vehicleItems];
              
              // Collect unique makes and body types for listing pages
              if (page === 0) {
                // Only do this on the first page to avoid duplicate work
                // Generate make-specific listing pages
                const makes = [...new Set(vehicles.map(v => v.make))];
                makes.forEach(make => {
                  items.push({
                    loc: `${baseUrl}/listings?make=${encodeURIComponent(make)}`,
                    lastmod: new Date().toISOString().split('T')[0],
                    priority: 0.7,
                    changefreq: 'daily'
                  });
                });
                
                // Generate body_type-specific listing pages
                const bodyTypes = [...new Set(vehicles.filter(v => v.body_type).map(v => v.body_type))];
                bodyTypes.forEach(bodyType => {
                  if (bodyType) {
                    items.push({
                      loc: `${baseUrl}/listings?bodyType=${encodeURIComponent(bodyType)}`,
                      lastmod: new Date().toISOString().split('T')[0],
                      priority: 0.7,
                      changefreq: 'daily'
                    });
                  }
                });
                
                // Add year-based listings (limited to most recent 5 years)
                const years = [...new Set(vehicles.map(v => v.year))].sort((a, b) => b - a);
                years.slice(0, 5).forEach(year => {
                  items.push({
                    loc: `${baseUrl}/listings?year=${year}`,
                    lastmod: new Date().toISOString().split('T')[0],
                    priority: 0.6,
                    changefreq: 'daily'
                  });
                });
                
                // Add the listings page as well
                items.unshift({
                  loc: `${baseUrl}/listings`,
                  lastmod: new Date().toISOString().split('T')[0],
                  priority: 0.9,
                  changefreq: 'daily'
                });
              }
              
              page++;
              
              // Update the count if component is still mounted
              if (isMounted) {
                setGeneratedItems(items.length);
              }
            }
            break;
            
          case 'sellers':
            // Use pagination for sellers too
            const { data: sellers, error: sellersError } = await supabase
              .from('seller_depots')
              .select('id, updated_at, shop_name, custom_url_slug')
              .eq('is_public', true)
              .limit(500); // Add a reasonable limit
            
            if (sellersError) {
              console.error('Error fetching sellers for sitemap:', sellersError);
              toast.error(`Failed to generate sellers sitemap: ${sellersError.message}`);
              return;
            }
            
            if (sellers) {
              // Generate URL for each seller, using custom slug if available
              sellers.forEach(seller => {
                const sellerPath = seller.custom_url_slug ? 
                  `seller/${seller.custom_url_slug}` : 
                  `seller/${seller.id}`;
                  
                items.push({
                  loc: `${baseUrl}/${sellerPath}`,
                  lastmod: new Date(seller.updated_at).toISOString().split('T')[0],
                  priority: 0.7,
                  changefreq: 'weekly'
                });
              });
              
              // Add sellers index page
              items.unshift({
                loc: `${baseUrl}/sellers`,
                lastmod: new Date().toISOString().split('T')[0],
                priority: 0.8,
                changefreq: 'weekly'
              });
              
              if (isMounted) {
                setGeneratedItems(items.length);
              }
            }
            break;
            
          case 'blog':
            // Fetch blog posts with pagination and limit
            const { data: posts, error: postsError } = await supabase
              .from('blog_articles')
              .select('id, created_at, title, category, tags')
              .eq('published', true)
              .limit(200); // Add a reasonable limit
            
            if (postsError) {
              console.error('Error fetching blog posts for sitemap:', postsError);
              toast.error(`Failed to generate blog sitemap: ${postsError.message}`);
              return;
            }
            
            if (posts) {
              // Generate URL for each blog post
              posts.forEach(post => {
                items.push({
                  loc: `${baseUrl}/blog/${post.id}`,
                  lastmod: new Date(post.created_at).toISOString().split('T')[0],
                  priority: 0.6,
                  changefreq: 'monthly'
                });
              });
              
              // Use an object to count tag occurrences more efficiently
              const tagCounts: Record<string, number> = {};
              
              posts.forEach(post => {
                const tags = post.tags || [];
                tags.forEach(tag => {
                  tagCounts[tag] = (tagCounts[tag] || 0) + 1;
                });
              });
              
              // Get unique categories more efficiently
              const categories = [...new Set(posts.filter(p => p.category).map(p => p.category))];
              
              // Generate category pages
              categories.forEach(category => {
                if (category) {
                  items.push({
                    loc: `${baseUrl}/blog/categories/${encodeURIComponent(category.toLowerCase().replace(/\s+/g, '-'))}`,
                    lastmod: new Date().toISOString().split('T')[0],
                    priority: 0.7,
                    changefreq: 'weekly'
                  });
                }
              });
              
              // Get the top 10 tags more efficiently
              const topTags = Object.entries(tagCounts)
                .sort((a, b) => b[1] - a[1])
                .slice(0, 10)
                .map(([tag]) => tag);
              
              topTags.forEach(tag => {
                items.push({
                  loc: `${baseUrl}/blog/tags/${encodeURIComponent(tag.toLowerCase().replace(/\s+/g, '-'))}`,
                  lastmod: new Date().toISOString().split('T')[0],
                  priority: 0.6,
                  changefreq: 'weekly'
                });
              });
              
              // Add the blog index page
              items.unshift({
                loc: `${baseUrl}/blog`,
                lastmod: new Date().toISOString().split('T')[0],
                priority: 0.8,
                changefreq: 'weekly'
              });
              
              if (isMounted) {
                setGeneratedItems(items.length);
              }
            }
            break;
        }

        if (items.length === 0) {
          console.log(`No items found for ${type} sitemap`);
          toast.warning(`No items found for ${type} sitemap`);
          return;
        }

        console.log(`Generated ${type} sitemap with ${items.length} items`);
        
        // For development, display a simplified message instead of creating the full XML
        if (process.env.NODE_ENV === 'development') {
          console.log(`SITEMAP ${type}: Generated ${items.length} URLs`);
          toast.success(`Generated ${type} sitemap with ${items.length} items.`);
        }
        
        // Instead of building the entire XML in memory, just return the count
        return items.length;
      } catch (error) {
        console.error(`Error generating ${type} sitemap:`, error);
        toast.error(`Error generating ${type} sitemap: ${error instanceof Error ? error.message : String(error)}`);
      } finally {
        // Only update state if component is still mounted
        if (isMounted) {
          setIsGenerating(false);
        }
      }
    };

    // Use requestIdleCallback or setTimeout to delay non-critical operations
    const timeoutId = setTimeout(() => {
      if (isMounted) {
        generateSitemap();
      }
    }, 2000); // Delay sitemap generation by 2 seconds
    
    // Clean up function
    return () => {
      isMounted = false;
      clearTimeout(timeoutId);
    };
  }, [type, baseUrl, isGenerating]);

  // This component doesn't render anything visual
  return null;
};

export default SitemapGenerator;
