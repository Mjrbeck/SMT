
import React, { memo, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { useLocation } from 'react-router-dom';
import { getSocialSharingImage } from '@/utils/imageUtils';

interface SEOProps {
  title?: string;
  description?: string;
  keywords?: string;
  ogImage?: string;
  ogType?: 'website' | 'article' | 'product';
  noindex?: boolean;
  twitterCardType?: 'summary' | 'summary_large_image' | 'app' | 'player';
}

// Use React.memo to prevent unnecessary re-renders
const SEO: React.FC<SEOProps> = memo(({
  title = "Source my Truck - Find Commercial Trucks in the UK",
  description = "The UK's leading marketplace for buying and selling commercial trucks and vehicles.",
  keywords = "commercial trucks, truck marketplace, buy trucks, sell trucks, commercial vehicles, UK trucks",
  ogImage = "/source-my-truck-logo.png",
  ogType = "website",
  noindex = false,
  twitterCardType = "summary_large_image"
}) => {
  const location = useLocation();
  
  // Use window.location.origin if available for more accurate base URL
  const baseUrl = typeof window !== 'undefined' ? window.location.origin : "https://source-my-truck.vercel.app";
  const currentUrl = `${baseUrl}${location.pathname}`;
  
  // Process image URL to ensure it's absolute and optimized for social sharing
  const secureImageUrl = getSocialSharingImage(ogImage);
  
  // Log diagnostic information about the image used for sharing (development only)
  useEffect(() => {
    if (process.env.NODE_ENV === 'development') {
      console.log("[SEO] Social image URL for meta tags:", secureImageUrl);
      console.log("[SEO] Current URL for sharing:", currentUrl);
    }
    
    // Test image loading to verify accessibility
    const img = new Image();
    img.onload = () => {
      if (process.env.NODE_ENV === 'development') {
        console.log(`✅ [SEO] Image loaded successfully: ${secureImageUrl} (${img.width}x${img.height})`);
      }
    };
    img.onerror = () => {
      console.warn(`❌ [SEO] Image failed to load: ${secureImageUrl}`);
      if (secureImageUrl.includes('source-my-truck-logo.png')) {
        console.log(`ℹ️ [SEO] Using fallback logo for social sharing`);
      }
    };
    img.src = secureImageUrl;
  }, [secureImageUrl, currentUrl]);

  return (
    <Helmet>
      {/* Basic Meta Tags */}
      <title>{title}</title>
      <meta name="description" content={description} />
      {keywords && <meta name="keywords" content={keywords} />}
      
      {/* Canonical URL */}
      <link rel="canonical" href={currentUrl} />
      
      {/* Robots meta tag - control indexing */}
      {noindex && <meta name="robots" content="noindex, nofollow" />}
      
      {/* OpenGraph Meta Tags - absolutely crucial for social sharing */}
      <meta property="og:title" content={title} />
      <meta property="og:description" content={description} />
      <meta property="og:url" content={currentUrl} />
      <meta property="og:type" content={ogType} />
      <meta property="og:image" content={secureImageUrl} />
      <meta property="og:image:secure_url" content={secureImageUrl} />
      <meta property="og:image:alt" content={`Source my Truck - ${title}`} />
      <meta property="og:image:width" content="1200" />
      <meta property="og:image:height" content="628" />
      <meta property="og:site_name" content="Source my Truck" />
      
      {/* Twitter Card Meta Tags */}
      <meta name="twitter:card" content={twitterCardType} />
      <meta name="twitter:site" content="@sourcemytruck" />
      <meta name="twitter:title" content={title} />
      <meta name="twitter:description" content={description} />
      <meta name="twitter:url" content={currentUrl} />
      <meta name="twitter:image" content={secureImageUrl} />
      <meta name="twitter:image:alt" content={`Source my Truck - ${title}`} />
      
      {/* Add a pre-connect hint to improve loading performance */}
      <link rel="preconnect" href={baseUrl} />
      <link rel="dns-prefetch" href={baseUrl} />
    </Helmet>
  );
});

SEO.displayName = 'SEO';

export default SEO;
