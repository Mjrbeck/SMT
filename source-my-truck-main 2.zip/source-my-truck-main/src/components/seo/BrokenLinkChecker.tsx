import React, { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import { useLocation } from 'react-router-dom';

interface BrokenLinkCheckerProps {
  onlyCheckInternal?: boolean;
}

interface LinkReport {
  url: string;
  source: string;
  status?: number;
  error?: string;
  suggestion?: string;
}

const BrokenLinkChecker: React.FC<BrokenLinkCheckerProps> = ({ onlyCheckInternal = true }) => {
  const [isChecking, setIsChecking] = useState(false);
  const [brokenLinks, setBrokenLinks] = useState<LinkReport[]>([]);
  const [validRoutes, setValidRoutes] = useState<string[]>([]);
  const location = useLocation();

  // Extract valid routes from App.tsx route definitions
  useEffect(() => {
    // These are the valid routes defined in App.tsx
    const appRoutes = [
      '/',
      '/register',
      '/login',
      '/reset-password',
      '/forgot-password',
      '/listings',
      '/vehicle/:id',
      '/seller/:slug',
      '/blog',
      '/blog/:id',
      '/auth/callback',
      '/dashboard',
      '/inventory',
      '/profile',
      '/settings',
      '/messages',
      '/messages/:id',
      '/create-listing',
      '/edit-listing/:id',
      '/seller-dashboard',
      '/pricing',
      '/seller-guide',
      '/terms',
      '/privacy',
      '/seo-tools',
      '/about',
      '/contact',
      '/privacy-policy',
      '/browse-trucks',
      '/all-trucks',
      '/dealer/:id',
      '/truck/:id',
      '/vehicles/:id',
      '/vehicles',
      '/browse/*',
    ];

    setValidRoutes(appRoutes);
  }, []);

  const findAllLinks = () => {
    // Get all links in the document
    const links = document.querySelectorAll('a');
    const foundLinks: { url: string; source: string }[] = [];

    links.forEach((link) => {
      const href = link.getAttribute('href');
      if (!href) return;

      // Skip empty links, anchors, or JavaScript links
      if (href === '#' || href.startsWith('javascript:') || href === '') return;

      // Skip external links if onlyCheckInternal is true
      if (onlyCheckInternal && (href.startsWith('http://') || href.startsWith('https://'))) {
        if (!href.includes('sourcemytruck.com')) return;
      }

      // Get the source element text or path for reference
      const linkText = link.textContent || link.innerHTML;
      const source = linkText ? linkText.substring(0, 30) : 'Unknown';

      foundLinks.push({
        url: href,
        source: source + (linkText && linkText.length > 30 ? '...' : '')
      });
    });

    return foundLinks;
  };

  const isValidRoute = (path: string): boolean => {
    // Remove query parameters for matching
    const cleanPath = path.split('?')[0].split('#')[0];
    
    // Direct match
    if (validRoutes.includes(cleanPath)) return true;
    
    // Check for parameterized routes
    return validRoutes.some(route => {
      if (!route.includes(':')) return false;
      
      const routeParts = route.split('/');
      const pathParts = cleanPath.split('/');
      
      if (routeParts.length !== pathParts.length) return false;
      
      return routeParts.every((part, i) => {
        if (part.startsWith(':')) return true; // Parameter matches anything
        return part === pathParts[i];
      });
    });
  };

  const getSuggestionForInvalidPath = (path: string): string | null => {
    // Common patterns that might lead to 404s
    if (path.startsWith('/truck/')) {
      return path.replace('/truck/', '/vehicle/');
    }
    if (path.startsWith('/dealer/')) {
      return path.replace('/dealer/', '/seller/');
    }
    if (path.startsWith('/browse/')) {
      return path.replace('/browse/', '/listings/');
    }
    if (path === '/browse-trucks' || path === '/all-trucks') {
      return '/listings';
    }
    return null;
  };

  const checkLinks = async () => {
    setIsChecking(true);
    setBrokenLinks([]);
    
    try {
      const links = findAllLinks();
      console.log(`Found ${links.length} links to check`);
      toast.info(`Checking ${links.length} links for potential 404s...`);
      
      const brokenLinksList: LinkReport[] = [];
      
      // Check internal links for route validity
      for (const link of links) {
        try {
          let url = link.url;
          
          // Convert to relative URL for internal checking if it's an absolute URL to our site
          if (url.includes('sourcemytruck.com')) {
            const urlObj = new URL(url);
            url = urlObj.pathname;
          }
          
          // Skip anchors and query params for route validation
          const baseUrl = url.split('#')[0].split('?')[0];
          
          // Check if it's an internal link that doesn't match our routes
          if (url.startsWith('/') && !isValidRoute(baseUrl)) {
            const suggestion = getSuggestionForInvalidPath(baseUrl);
            brokenLinksList.push({
              ...link,
              error: 'Not in route definitions',
              status: 404,
              suggestion: suggestion || undefined
            });
            continue;
          }
          
          // Also check for known problematic patterns
          if (url.startsWith('/truck/')) {
            brokenLinksList.push({
              ...link, 
              error: 'Incorrect URL pattern - should be /vehicle/',
              status: 404,
              suggestion: url.replace('/truck/', '/vehicle/')
            });
          } else if (url.startsWith('/dealer/')) {
            brokenLinksList.push({
              ...link, 
              error: 'Incorrect URL pattern - should be /seller/',
              status: 404,
              suggestion: url.replace('/dealer/', '/seller/')
            });
          } else if (url.startsWith('/browse/')) {
            brokenLinksList.push({
              ...link, 
              error: 'Incorrect URL pattern - should be /listings/',
              status: 404,
              suggestion: url.replace('/browse/', '/listings/')
            });
          }
        } catch (error) {
          brokenLinksList.push({
            ...link,
            error: error instanceof Error ? error.message : 'Unknown error'
          });
        }
      }
      
      setBrokenLinks(brokenLinksList);
      
      if (brokenLinksList.length === 0) {
        toast.success('No potential 404 links found!');
      } else {
        toast.error(`Found ${brokenLinksList.length} potential broken links`);
      }
    } catch (error) {
      console.error('Error checking links:', error);
      toast.error('Error checking links: ' + (error instanceof Error ? error.message : String(error)));
    } finally {
      setIsChecking(false);
    }
  };

  return (
    <div className="p-4 border rounded-lg shadow-sm bg-white mb-8">
      <h2 className="text-xl font-semibold mb-4">Broken Link Checker</h2>
      <p className="mb-4 text-gray-600">
        This tool scans the current page for links that might lead to 404 errors.
      </p>
      
      <Button 
        onClick={checkLinks} 
        disabled={isChecking}
        className="mb-4"
      >
        {isChecking ? 'Checking...' : 'Check for Broken Links'}
      </Button>
      
      {brokenLinks.length > 0 && (
        <div className="mt-4">
          <h3 className="font-medium text-lg mb-2">Potential 404 URLs ({brokenLinks.length}):</h3>
          <div className="overflow-x-auto">
            <table className="min-w-full border-collapse">
              <thead>
                <tr className="bg-gray-100">
                  <th className="p-2 border text-left">URL</th>
                  <th className="p-2 border text-left">Source</th>
                  <th className="p-2 border text-left">Status</th>
                  <th className="p-2 border text-left">Issue</th>
                  <th className="p-2 border text-left">Suggestion</th>
                </tr>
              </thead>
              <tbody>
                {brokenLinks.map((link, index) => (
                  <tr key={index} className="border-b">
                    <td className="p-2 border">{link.url}</td>
                    <td className="p-2 border">{link.source}</td>
                    <td className="p-2 border">{link.status || 'Unknown'}</td>
                    <td className="p-2 border">{link.error || 'Potentially broken'}</td>
                    <td className="p-2 border">
                      {link.suggestion && (
                        <span className="text-green-600">{link.suggestion}</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
      
      <div className="mt-4 text-sm text-gray-500">
        <p>Common causes of 404 errors in this application:</p>
        <ul className="list-disc pl-5 mt-2">
          <li>Using '/truck/:id' instead of '/vehicle/:id'</li>
          <li>Using '/dealer/:id' instead of '/seller/:id'</li>
          <li>Using '/browse/*' instead of '/listings/*'</li>
          <li>Links to outdated pages like '/browse-trucks' or '/all-trucks'</li>
          <li>Links to pages that aren't defined in App.tsx routes</li>
        </ul>
      </div>
    </div>
  );
};

export default BrokenLinkChecker;
