
import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { submitSitemapToSearchEngines } from '@/services/vehicleService';
import { toast } from 'sonner';

interface SearchEngineSubmissionProps {
  sitemapUrl: string;
  additionalSitemaps?: string[];
}

/**
 * Component to handle search engine sitemap submission
 * This is mostly informational as actual submissions would need to be done
 * through search engine webmaster tools or API calls from a backend
 */
const SearchEngineSubmission = ({ sitemapUrl, additionalSitemaps = [] }: SearchEngineSubmissionProps) => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [lastSubmission, setLastSubmission] = useState<Date | null>(null);
  const [submissionResults, setSubmissionResults] = useState<{url: string, success: boolean}[]>([]);

  useEffect(() => {
    // Log the sitemap URLs for reference
    console.log(`Main sitemap for submission: ${sitemapUrl}`);
    if (additionalSitemaps.length > 0) {
      console.log(`Additional sitemaps: ${additionalSitemaps.join(', ')}`);
    }
  }, [sitemapUrl, additionalSitemaps]);

  const handleSubmit = async () => {
    setIsSubmitting(true);
    setSubmissionResults([]);
    
    try {
      // First submit the main sitemap
      const mainResult = await submitSitemapToSearchEngines(sitemapUrl);
      
      let results = [{
        url: sitemapUrl,
        success: mainResult.success
      }];
      
      // Then submit any additional sitemaps
      if (additionalSitemaps.length > 0) {
        const additionalResults = await Promise.all(
          additionalSitemaps.map(async (url) => {
            const result = await submitSitemapToSearchEngines(url);
            return {
              url,
              success: result.success
            };
          })
        );
        
        results = [...results, ...additionalResults];
      }
      
      setSubmissionResults(results);
      
      // Count successful submissions
      const successCount = results.filter(r => r.success).length;
      
      if (successCount === results.length) {
        toast.success(`All ${results.length} sitemaps successfully submitted to search engines`);
      } else if (successCount > 0) {
        toast.warning(`${successCount} of ${results.length} sitemaps submitted successfully. Check console for details.`);
      } else {
        toast.error('Failed to submit any sitemaps to search engines');
      }
      
      setLastSubmission(new Date());
    } catch (error) {
      console.error('Error submitting sitemaps:', error);
      toast.error(`Error submitting sitemaps: ${error instanceof Error ? error.message : String(error)}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="p-4 border rounded-md">
      <h3 className="text-lg font-medium mb-2">Search Engine Submission</h3>
      <p className="mb-2">Main Sitemap: {sitemapUrl}</p>
      
      {additionalSitemaps.length > 0 && (
        <div className="mb-2">
          <p className="mb-1">Additional Sitemaps:</p>
          <ul className="list-disc ml-5 text-sm text-gray-600">
            {additionalSitemaps.map((url, index) => (
              <li key={index}>{url}</li>
            ))}
          </ul>
        </div>
      )}
      
      <Button 
        onClick={handleSubmit} 
        disabled={isSubmitting}
      >
        {isSubmitting ? 'Submitting...' : 'Submit to Search Engines'}
      </Button>
      
      {lastSubmission && (
        <p className="mt-2 text-sm text-gray-600">
          Last submitted: {lastSubmission.toLocaleString()}
        </p>
      )}
      
      {submissionResults.length > 0 && (
        <div className="mt-2">
          <p className="text-sm font-medium">Submission Results:</p>
          <ul className="list-disc ml-5 mt-1 text-sm">
            {submissionResults.map((result, index) => (
              <li key={index} className={result.success ? "text-green-600" : "text-red-600"}>
                {result.url.split('/').pop()}: {result.success ? 'Success' : 'Failed'}
              </li>
            ))}
          </ul>
        </div>
      )}
      
      <div className="mt-4 text-sm text-gray-600">
        <p>Note: For more reliable submission, use:</p>
        <ul className="list-disc ml-5 mt-1">
          <li>
            <a 
              href="https://search.google.com/search-console" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-blue-600 hover:underline"
            >
              Google Search Console
            </a>
          </li>
          <li>
            <a 
              href="https://www.bing.com/webmasters/about" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-blue-600 hover:underline"
            >
              Bing Webmaster Tools
            </a>
          </li>
        </ul>
      </div>
    </div>
  );
};

export default SearchEngineSubmission;
