
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

interface SitemapVerifierProps {
  sitemapUrl: string;
}

/**
 * A component to verify that a sitemap is accessible and valid
 */
const SitemapVerifier: React.FC<SitemapVerifierProps> = ({ sitemapUrl }) => {
  const [isVerifying, setIsVerifying] = useState(false);
  const [verificationResult, setVerificationResult] = useState<'success' | 'error' | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [urlCount, setUrlCount] = useState<number | null>(null);

  const verifySitemap = async () => {
    setIsVerifying(true);
    setVerificationResult(null);
    setErrorMessage(null);
    setUrlCount(null);

    try {
      const response = await fetch(sitemapUrl);
      
      if (!response.ok) {
        throw new Error(`HTTP error: ${response.status} ${response.statusText}`);
      }

      const contentType = response.headers.get('content-type');
      if (!contentType || (!contentType.includes('application/xml') && !contentType.includes('text/xml'))) {
        throw new Error(`Invalid content type: ${contentType}. Expected XML.`);
      }

      const xmlText = await response.text();
      
      // Trim whitespace to help detect issues
      const trimmedXml = xmlText.trim();
      
      // Check if the XML declaration is exactly at the start of the document
      if (!trimmedXml.startsWith('<?xml')) {
        // Get first few characters to help debug
        const firstChars = xmlText.substring(0, 20).replace(/\n/g, '\\n').replace(/\r/g, '\\r');
        throw new Error(`XML declaration is not at the start of the document. Document starts with: ${firstChars}`);
      }
      
      // Basic validation - check if it has the XML declaration and urlset or sitemapindex elements
      if (!trimmedXml.includes('<urlset') && !trimmedXml.includes('<sitemapindex')) {
        throw new Error('Invalid sitemap format. Missing urlset or sitemapindex element.');
      }

      // Count URLs in sitemap
      const count = (trimmedXml.match(/<url>|<sitemap>/g) || []).length;
      setUrlCount(count);
      
      setVerificationResult('success');
      toast.success(`Sitemap is valid and contains ${count} URLs/sitemaps`);
    } catch (error) {
      setVerificationResult('error');
      const message = error instanceof Error ? error.message : String(error);
      setErrorMessage(message);
      toast.error(`Sitemap verification failed: ${message}`);
    } finally {
      setIsVerifying(false);
    }
  };

  return (
    <div className="p-4 border rounded-md mb-4">
      <h3 className="text-lg font-medium mb-2">Sitemap Verification</h3>
      <p className="mb-2">URL: {sitemapUrl}</p>
      
      <Button 
        onClick={verifySitemap} 
        disabled={isVerifying}
        variant={verificationResult === 'success' ? 'default' : verificationResult === 'error' ? 'destructive' : 'default'}
        className={verificationResult === 'success' ? 'bg-green-600 hover:bg-green-700' : ''}
      >
        {isVerifying ? 'Verifying...' : 'Verify Sitemap'}
      </Button>
      
      {verificationResult === 'success' && (
        <p className="mt-2 text-green-600">✓ Sitemap is valid with {urlCount} URLs</p>
      )}
      
      {verificationResult === 'error' && errorMessage && (
        <p className="mt-2 text-red-600">✗ {errorMessage}</p>
      )}
    </div>
  );
};

export default SitemapVerifier;
