import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';

const SocialPreviewRedirect = () => {
  const { id } = useParams<{ id: string }>();
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    const handlePreviewRequest = async () => {
      if (!id) return;
      
      try {
        // Always fetch the HTML content from the edge function
        const response = await fetch(`https://xfpokywrvoshtwtevyaz.supabase.co/functions/v1/vehicle-prerender/${id}`);
        const html = await response.text();
        
        // For any request to this route, serve the HTML content directly
        // This ensures crawlers get proper OG tags immediately
        document.open();
        document.write(html);
        document.close();
      } catch (error) {
        console.error('Error fetching preview HTML:', error);
        // Fallback: redirect to vehicle page
        window.location.replace(`/vehicle/${id}`);
      } finally {
        setLoading(false);
      }
    };
    
    handlePreviewRequest();
  }, [id]);

  // Show minimal loading state 
  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="text-center">
          <div className="mb-4">
            <div className="w-16 h-16 border-4 border-t-brand-blue border-r-transparent border-b-brand-orange border-l-transparent rounded-full animate-spin mx-auto"></div>
          </div>
          <p className="text-lg font-medium">Loading vehicle preview...</p>
        </div>
      </div>
    );
  }

  return null;
};

export default SocialPreviewRedirect;