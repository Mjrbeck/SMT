
import React from 'react';
import { Helmet } from 'react-helmet';
import SEO from './SEO';
import SchemaData from './SchemaData';

interface BlogSEOProps {
  title?: string;
  description?: string;
  keywords?: string;
  ogImage?: string;
  isBlogPost?: boolean;
  articleData?: {
    title: string;
    description: string;
    publishedAt: string;
    updatedAt?: string;
    author: string;
    imageUrl: string;
    tags?: string[];
  };
}

/**
 * Specialized SEO component for blog content
 * Includes blog-specific schema.org markup
 */
const BlogSEO: React.FC<BlogSEOProps> = ({
  title = "Commercial Vehicle Blog | Source my Truck",
  description = "Expert insights, guides, and news about commercial vehicles and the transport industry in the UK.",
  keywords = "commercial vehicle blog, truck industry news, transport industry insights, fleet management",
  ogImage = "/source-my-truck-logo.png",
  isBlogPost = false,
  articleData
}) => {
  // Generate blog-specific schema data
  const generateBlogSchema = () => {
    if (!isBlogPost || !articleData) {
      // Blog index page schema
      return {
        "@context": "https://schema.org/",
        "@type": "Blog",
        "headline": "Source my Truck Commercial Vehicle Blog",
        "description": description,
        "publisher": {
          "@type": "Organization",
          "name": "Source my Truck",
          "logo": {
            "@type": "ImageObject",
            "url": "https://sourcemytruck.com/source-my-truck-logo.png"
          }
        }
      };
    }
    
    // Blog post schema
    return {
      "@context": "https://schema.org/",
      "@type": "BlogPosting",
      "headline": articleData.title,
      "description": articleData.description,
      "image": articleData.imageUrl,
      "datePublished": articleData.publishedAt,
      "dateModified": articleData.updatedAt || articleData.publishedAt,
      "author": {
        "@type": "Person",
        "name": articleData.author
      },
      "publisher": {
        "@type": "Organization",
        "name": "Source my Truck",
        "logo": {
          "@type": "ImageObject",
          "url": "https://sourcemytruck.com/source-my-truck-logo.png"
        }
      },
      "keywords": articleData.tags ? articleData.tags.join(", ") : keywords
    };
  };

  return (
    <>
      <SEO
        title={title}
        description={description}
        keywords={keywords}
        ogImage={ogImage}
        ogType={isBlogPost ? "article" : "website"}
      />
      <Helmet>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify(generateBlogSchema())
          }}
        />
      </Helmet>
    </>
  );
};

export default BlogSEO;
