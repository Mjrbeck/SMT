
import { Link } from "react-router-dom";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CalendarRange, Fuel, Clock, Sparkle, Tag, Truck } from "lucide-react";
import { formatPrice, formatExpirationDate, formatPriceOrPOA } from "@/utils/formatters";
import VehicleActions from "./VehicleActions";
import { VehicleData } from "@/components/VehicleCard";
import { isToday } from "date-fns";

interface InventoryVehicleCardProps {
  vehicle: VehicleData;
  onStatusChange: (id: string, status: string) => Promise<boolean>;
  onDeleteClick: (id: string) => Promise<boolean>;
  onReactivateClick?: (id: string) => void;
}

const InventoryVehicleCard = ({ 
  vehicle, 
  onStatusChange, 
  onDeleteClick,
  onReactivateClick
}: InventoryVehicleCardProps) => {
  const isExpired = vehicle.expires_at && new Date(vehicle.expires_at) < new Date() && vehicle.status === 'active';
  const isActive = vehicle.status === 'active' && !isExpired;
  const isNewArrival = vehicle.created_at && isToday(new Date(vehicle.created_at));
  
  const daysUntilExpiration = vehicle.expires_at && isActive ? 
    Math.ceil((new Date(vehicle.expires_at).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24)) : 0;
  
  const expiringSoon = daysUntilExpiration > 0 && daysUntilExpiration <= 3;

  const displayTitle = vehicle.title || `${vehicle.year} ${vehicle.make} ${vehicle.model || ''}`.trim();
  
  return (
    <Card className={`overflow-hidden border ${expiringSoon && !isExpired ? "border-amber-200 bg-amber-50/30" : ""}`}>
      <div className="relative">
        <Link to={`/vehicle/${vehicle.id}`}>
          {vehicle.imageUrl ? (
            <div>
              <img 
                src={vehicle.imageUrl} 
                alt={displayTitle}
                className="w-full h-48 object-cover"
              />
            </div>
          ) : (
            <div className="w-full h-48 bg-gray-100 flex items-center justify-center">
              <Truck size={64} className="text-gray-300" />
            </div>
          )}
        </Link>
        
        <div className="absolute top-2 right-2 flex flex-col gap-2">
          <StatusBadge status={vehicle.status} isExpired={isExpired} />
          
          {isNewArrival && (
            <Badge className="bg-brand-orange font-medium text-xs flex items-center gap-1">
              <Sparkle className="h-3 w-3" />
              New Arrival
            </Badge>
          )}
        </div>
      </div>
      
      <CardContent className="p-4">
        <h3 className="text-lg font-semibold mb-2 line-clamp-2">{displayTitle}</h3>
        
        <div className="flex justify-between mb-2">
          <div className="flex items-center text-sm text-muted-foreground">
            <CalendarRange className="h-4 w-4 mr-1" />
            {vehicle.year}
          </div>
          <div className="font-semibold text-brand-blue">
            {formatPriceOrPOA(vehicle.price, vehicle.isPOA || false)}
          </div>
        </div>

        {vehicle.mileage !== undefined && (
          <div className="flex items-center text-sm text-muted-foreground mt-2">
            <Truck className="h-4 w-4 mr-1" />
            {vehicle.mileage.toLocaleString()} miles
          </div>
        )}
        
        {vehicle.expires_at && vehicle.status === 'active' && !isExpired && (
          <div className={`flex items-center text-sm ${expiringSoon ? 'text-amber-600 font-medium' : 'text-muted-foreground'} mt-2`}>
            <Clock className={`h-4 w-4 mr-1 ${expiringSoon ? 'text-amber-600' : ''}`} />
            {formatExpirationDate(vehicle.expires_at)}
            {expiringSoon && (
              <span className="ml-1">({daysUntilExpiration} day{daysUntilExpiration !== 1 ? 's' : ''} left)</span>
            )}
          </div>
        )}
        
        {isExpired && (
          <div className="mt-2 p-2 bg-amber-50 border border-amber-200 rounded text-sm text-amber-800">
            This listing has expired. Use 1 credit to reactivate it for another 30 days.
          </div>
        )}
      </CardContent>
      
      <CardFooter className="p-4 border-t">
        <VehicleActions 
          vehicleId={vehicle.id} 
          status={vehicle.status || 'active'}
          isExpired={isExpired}
          onStatusChange={onStatusChange}
          onDeleteClick={onDeleteClick}
          onReactivateClick={onReactivateClick}
        />
      </CardFooter>
    </Card>
  );
};

export const StatusBadge = ({ status, isExpired = false }: { status: string, isExpired?: boolean }) => {
  if (isExpired) {
    return <Badge variant="outline" className="text-amber-600 border-amber-300 bg-amber-50">Expired</Badge>;
  }
  
  switch (status) {
    case 'active':
      return <Badge className="bg-green-500">Active</Badge>;
    case 'draft':
      return <Badge variant="outline">Draft</Badge>;
    case 'sale_in_progress':
      return <Badge className="bg-blue-500 whitespace-nowrap">Sale in Progress</Badge>;
    case 'sold':
      return <Badge className="bg-purple-600">Sold</Badge>;
    default:
      return <Badge variant="outline">{status}</Badge>;
  }
};

export default InventoryVehicleCard;
