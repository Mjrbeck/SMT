import React, { memo } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import InventoryVehicleList from "@/components/inventory/InventoryVehicleList";
import { Tag, Clock, CheckCircle, FilePenLine, AlertCircle, ShoppingCart } from "lucide-react";

interface InventoryTabsProps {
  activeTab: string;
  setActiveTab: (value: string) => void;
  stats: any;
  onDeleteClick: (id: string) => Promise<boolean>;
  onReactivateClick: (id: string) => void;
  onStatusChange: (id: string, status: string) => Promise<boolean>;
}

// Memoized inventory tabs component
const InventoryTabs = memo(({
  activeTab,
  setActiveTab,
  stats,
  onDeleteClick,
  onReactivateClick,
  onStatusChange
}: InventoryTabsProps) => {
  return (
    <Tabs 
      defaultValue={activeTab} 
      value={activeTab}
      className="w-full"
      onValueChange={setActiveTab}
    >
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-4 gap-3">
        <TabsList className="flex overflow-x-auto w-full md:w-auto justify-start p-1 bg-gray-100/50 rounded-lg">
          <TabsTrigger value="all" className="flex items-center gap-1">
            <ShoppingCart className="h-4 w-4" />
            All Vehicles
            {stats?.all > 0 && (
              <span className="ml-1 bg-gray-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                {stats.all}
              </span>
            )}
          </TabsTrigger>
          
          <TabsTrigger value="active" className="flex items-center gap-1">
            <CheckCircle className="h-4 w-4" />
            Active
            {stats?.active > 0 && (
              <span className="ml-1 bg-green-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                {stats.active}
              </span>
            )}
          </TabsTrigger>
          
          <TabsTrigger value="draft" className="flex items-center gap-1">
            <FilePenLine className="h-4 w-4" />
            Draft
            {stats?.draft > 0 && (
              <span className="ml-1 bg-amber-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                {stats.draft}
              </span>
            )}
          </TabsTrigger>
          
          <TabsTrigger value="sale_in_progress" className="flex items-center gap-1">
            <Clock className="h-4 w-4" />
            Sale in Progress
            {stats?.sale_in_progress > 0 && (
              <span className="ml-1 bg-blue-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                {stats.sale_in_progress}
              </span>
            )}
          </TabsTrigger>
          
          <TabsTrigger value="sold" className="flex items-center gap-1">
            <Tag className="h-4 w-4" />
            Sold
            {stats?.sold > 0 && (
              <span className="ml-1 bg-purple-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                {stats.sold}
              </span>
            )}
          </TabsTrigger>
          
          <TabsTrigger value="expired" className="flex items-center gap-1">
            <AlertCircle className="h-4 w-4" />
            Expired
            {stats?.expired > 0 && (
              <span className="ml-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                {stats.expired}
              </span>
            )}
          </TabsTrigger>
        </TabsList>
        
        {stats && (
          <div className="flex items-center gap-4 text-sm whitespace-nowrap md:pl-4">
            {stats.all > 0 && (
              <span className="flex items-center gap-1 text-muted-foreground">
                <ShoppingCart className="h-4 w-4 text-brand-blue" />
                <span className="font-medium text-gray-700">{stats.all}</span> Total Vehicles
              </span>
            )}
            {stats.averagePrice > 0 && (
              <span className="flex items-center gap-1 text-muted-foreground">
                <span className="font-medium text-gray-700">£{stats.averagePrice.toLocaleString()}</span> Average Price
              </span>
            )}
          </div>
        )}
      </div>

      {activeTab === "all" && (
        <TabsContent value="all" className="mt-0">
          <InventoryVehicleList 
            onDeleteClick={onDeleteClick}
            onReactivateClick={onReactivateClick}
            onStatusChange={onStatusChange}
          />
        </TabsContent>
      )}
      
      {activeTab === "active" && (
        <TabsContent value="active" className="mt-0">
          <InventoryVehicleList 
            onDeleteClick={onDeleteClick}
            onReactivateClick={onReactivateClick}
            onStatusChange={onStatusChange}
          />
        </TabsContent>
      )}
      
      {activeTab === "draft" && (
        <TabsContent value="draft" className="mt-0">
          <InventoryVehicleList 
            onDeleteClick={onDeleteClick}
            onReactivateClick={onReactivateClick}
            onStatusChange={onStatusChange}
          />
        </TabsContent>
      )}
      
      {activeTab === "expired" && (
        <TabsContent value="expired" className="mt-0">
          <InventoryVehicleList 
            onDeleteClick={onDeleteClick}
            onReactivateClick={onReactivateClick}
            onStatusChange={onStatusChange}
          />
        </TabsContent>
      )}
      
      {activeTab === "sale_in_progress" && (
        <TabsContent value="sale_in_progress" className="mt-0">
          <InventoryVehicleList 
            onDeleteClick={onDeleteClick}
            onReactivateClick={onReactivateClick}
            onStatusChange={onStatusChange}
          />
        </TabsContent>
      )}
      
      {activeTab === "sold" && (
        <TabsContent value="sold" className="mt-0">
          <InventoryVehicleList 
            onDeleteClick={onDeleteClick}
            onReactivateClick={onReactivateClick}
            onStatusChange={onStatusChange}
          />
        </TabsContent>
      )}
    </Tabs>
  );
});

// Add display name for better debugging
InventoryTabs.displayName = "InventoryTabs";

export default InventoryTabs;
