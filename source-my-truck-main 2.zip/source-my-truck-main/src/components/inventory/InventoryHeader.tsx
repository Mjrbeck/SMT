
import { Button } from "@/components/ui/button";
import { Plus, CreditCard, Download, Upload } from "lucide-react";
import { Link } from "react-router-dom";
import { StyledButton } from "@/components/ui/consistent-ui";

interface InventoryHeaderProps {
  remainingCredits: number;
  onOpenBulkUpload: () => void;
}

const InventoryHeader = ({ remainingCredits, onOpenBulkUpload }: InventoryHeaderProps) => {
  return (
    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
      <div className="flex flex-col gap-1">
        <p className="text-muted-foreground">Manage and monitor your vehicle listings</p>
      </div>
      <div className="flex flex-wrap items-center gap-3">
        <div className={`${remainingCredits <= 3 ? 'bg-amber-50' : remainingCredits <= 0 ? 'bg-red-50' : 'bg-white'} px-4 py-2 rounded-md shadow-sm border ${remainingCredits <= 0 ? 'border-red-200' : 'border-indigo-100'} backdrop-blur-sm`}>
          <div className="flex items-center gap-2">
            <CreditCard className={`h-4 w-4 ${remainingCredits <= 0 ? 'text-red-500' : remainingCredits <= 3 ? 'text-amber-500' : 'text-brand-lightBlue'}`} />
            <span className={`font-medium ${remainingCredits <= 0 ? 'text-red-600' : remainingCredits <= 3 ? 'text-amber-600' : 'text-brand-blue'}`}>{remainingCredits}</span>
            <span className="text-sm text-gray-600">{remainingCredits === 1 ? 'credit' : 'credits'} remaining</span>
          </div>
        </div>
        <Link to="/settings?tab=credits">
          <Button variant="outline" className="gap-2 border-indigo-100 hover:bg-indigo-50/70">
            <CreditCard className="h-4 w-4 text-brand-lightBlue" />
            Purchase Credits
          </Button>
        </Link>
        <Link to="/create-listing">
          <StyledButton variant="orange" className="gap-2">
            <Plus className="h-4 w-4" /> Add Vehicle
          </StyledButton>
        </Link>
      </div>
    </div>
  );
};

export default InventoryHeader;
