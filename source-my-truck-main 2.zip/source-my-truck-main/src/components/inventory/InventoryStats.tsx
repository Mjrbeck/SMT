
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BadgeDollarSign, ShoppingCart, Clock, Check, Eye, Tag } from "lucide-react";

interface InventoryStatsProps {
  all: number;
  active: number;
  draft: number;
  expired: number;
  sale_in_progress?: number;
  sold?: number;
  averagePrice?: number;
  totalViews?: number;
}

const InventoryStats = ({ 
  all, 
  active, 
  draft, 
  expired,
  sale_in_progress = 0,
  sold = 0,
  averagePrice = 0,
  totalViews = 0
}: InventoryStatsProps) => {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-4 mb-6">
      <StatCard 
        title="Total Vehicles" 
        value={all} 
        icon={<ShoppingCart className="h-4 w-4 text-brand-blue" />} 
        color="indigo"
      />
      
      <StatCard 
        title="Active" 
        value={active} 
        icon={<Check className="h-4 w-4 text-green-600" />} 
        color="green"
      />
      
      <StatCard 
        title="Draft" 
        value={draft} 
        icon={<Clock className="h-4 w-4 text-amber-600" />} 
        color="amber"
      />
      
      <StatCard 
        title="Sale in Progress" 
        value={sale_in_progress} 
        icon={<Clock className="h-4 w-4 text-blue-600" />} 
        color="blue"
      />
      
      <StatCard 
        title="Sold" 
        value={sold} 
        icon={<Tag className="h-4 w-4 text-purple-600" />} 
        color="purple"
      />
      
      <StatCard 
        title="Expired" 
        value={expired} 
        icon={<Clock className="h-4 w-4 text-red-600" />} 
        color="red"
      />
      
      <StatCard 
        title="Total Views" 
        value={totalViews} 
        icon={<Eye className="h-4 w-4 text-blue-600" />} 
        color="blue"
        className="col-span-1 sm:col-span-1 md:col-span-3"
      />
      
      <StatCard 
        title="Average Price" 
        value={`£${averagePrice.toLocaleString()}`} 
        icon={<BadgeDollarSign className="h-4 w-4 text-brand-orange" />} 
        color="orange"
        className="col-span-1 sm:col-span-2 md:col-span-3"
      />
    </div>
  );
};

interface StatCardProps {
  title: string;
  value: number | string;
  icon: React.ReactNode;
  color: 'green' | 'red' | 'amber' | 'blue' | 'indigo' | 'purple' | 'orange';
  className?: string;
}

const StatCard = ({ title, value, icon, color, className = '' }: StatCardProps) => {
  const colorMap = {
    green: 'from-card to-green-50/50',
    red: 'from-card to-red-50/50',
    amber: 'from-card to-amber-50/50',
    blue: 'from-card to-blue-50/50',
    indigo: 'from-card to-indigo-50/50',
    purple: 'from-card to-purple-50/50',
    orange: 'from-card to-orange-50/50'
  };

  const blurColor = {
    green: 'bg-green-500/10',
    red: 'bg-red-500/10',
    amber: 'bg-amber-500/10',
    blue: 'bg-blue-500/10',
    indigo: 'bg-brand-lightBlue/10',
    purple: 'bg-purple-500/10',
    orange: 'bg-brand-orange/10'
  };

  return (
    <Card className={`overflow-hidden border-0 shadow-sm bg-gradient-to-br ${colorMap[color]} ${className}`}>
      <div className={`absolute top-0 right-0 w-16 h-16 -mt-4 -mr-4 ${blurColor[color]} rounded-full blur-xl`}></div>
      <CardHeader className="pb-2 relative">
        <CardTitle className="text-xs font-medium text-gray-500 flex items-center gap-2">
          {icon} {title}
        </CardTitle>
      </CardHeader>
      <CardContent className="relative pt-0">
        <div className="text-xl font-bold text-gray-800">{value}</div>
      </CardContent>
    </Card>
  );
};

export default InventoryStats;
