
import { Button } from "@/components/ui/button";
import { Eye, Edit, Trash, AlertTriangle, CheckCircle, BarChart, Unlock, Clock, Tag } from "lucide-react";
import { Link } from "react-router-dom";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface VehicleActionsProps {
  vehicleId: string;
  status: string;
  isExpired?: boolean;
  onStatusChange: (id: string, status: string) => Promise<boolean>;
  onDeleteClick: (id: string) => Promise<boolean>;
  onReactivateClick?: (id: string) => void;
}

const VehicleActions = ({ 
  vehicleId, 
  status, 
  isExpired = false,
  onStatusChange, 
  onDeleteClick,
  onReactivateClick
}: VehicleActionsProps) => {
  const handleStatusChange = (newStatus: string) => {
    // Add logging to debug status changes
    console.log(`Changing vehicle ${vehicleId} status from ${status} to ${newStatus}`);
    onStatusChange(vehicleId, newStatus);
  };

  const handleDeleteClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    onDeleteClick(vehicleId);
  };

  return (
    <div className="flex space-x-2 justify-start">
      <Link to={`/vehicle/${vehicleId}`}>
        <Button variant="outline" size="sm">
          <Eye className="mr-2 h-4 w-4" /> View
        </Button>
      </Link>
      
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" size="sm">
            <BarChart className="mr-2 h-4 w-4" /> Actions
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="start">
          <Link to={`/edit-listing/${vehicleId}`}>
            <DropdownMenuItem>
              <Edit className="mr-2 h-4 w-4" /> Edit
            </DropdownMenuItem>
          </Link>
          
          {isExpired ? (
            <DropdownMenuItem 
              onClick={() => onReactivateClick && onReactivateClick(vehicleId)}
              className="text-amber-600 hover:text-amber-700 hover:bg-amber-50"
            >
              <Unlock className="mr-2 h-4 w-4" /> Reactivate
            </DropdownMenuItem>
          ) : (
            <>
              {status === 'draft' && (
                <DropdownMenuItem onClick={() => handleStatusChange('active')}>
                  <CheckCircle className="mr-2 h-4 w-4" /> Publish
                </DropdownMenuItem>
              )}
              
              {status === 'active' && (
                <>
                  <DropdownMenuItem onClick={() => handleStatusChange('draft')}>
                    <AlertTriangle className="mr-2 h-4 w-4" /> Unpublish
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => handleStatusChange('sale_in_progress')}>
                    <Clock className="mr-2 h-4 w-4" /> Mark as Sale in Progress
                  </DropdownMenuItem>
                </>
              )}
              
              {status === 'sale_in_progress' && (
                <>
                  <DropdownMenuItem onClick={() => handleStatusChange('active')}>
                    <CheckCircle className="mr-2 h-4 w-4" /> Mark as Active Again
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => handleStatusChange('sold')}>
                    <Tag className="mr-2 h-4 w-4" /> Mark as Sold
                  </DropdownMenuItem>
                </>
              )}
              
              {status === 'sold' && (
                <DropdownMenuItem onClick={() => handleStatusChange('active')}>
                  <CheckCircle className="mr-2 h-4 w-4" /> Relist Vehicle
                </DropdownMenuItem>
              )}
            </>
          )}
          
          <DropdownMenuItem 
            onClick={handleDeleteClick}
            className="text-red-500 hover:text-red-500 hover:bg-red-50"
          >
            <Trash className="mr-2 h-4 w-4" /> Delete
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
};

export default VehicleActions;
