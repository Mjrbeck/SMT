
import React from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { LoadingSpinner } from "@/components/ui/loading-spinner";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface InventoryDialogsProps {
  isDeleteDialogOpen: boolean;
  setIsDeleteDialogOpen: (isOpen: boolean) => void;
  isReactivateDialogOpen: boolean;
  setIsReactivateDialogOpen: (isOpen: boolean) => void;
  insufficientCredits: boolean;
  setInsufficientCredits: (insufficient: boolean) => void;
  onDeleteConfirm: () => void;
  onReactivateConfirm: () => void;
  isDeleting?: boolean;
  isReactivating?: boolean;
}

const InventoryDialogs = ({
  isDeleteDialogOpen,
  setIsDeleteDialogOpen,
  isReactivateDialogOpen,
  setIsReactivateDialogOpen,
  insufficientCredits,
  setInsufficientCredits,
  onDeleteConfirm,
  onReactivateConfirm,
  isDeleting = false,
  isReactivating = false
}: InventoryDialogsProps) => {
  // Handle delete confirmation with dialog auto-close
  const handleDelete = () => {
    onDeleteConfirm();
    // Dialog will be closed by the parent component
  };

  // Handle reactivate confirmation with dialog auto-close
  const handleReactivate = () => {
    onReactivateConfirm();
    // Dialog will be closed by the parent component
  };

  return (
    <>
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete your
              vehicle listing and remove all associated data from our servers.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isDeleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleDelete}
              className="bg-red-600 hover:bg-red-700 text-white"
              disabled={isDeleting}
            >
              {isDeleting ? (
                <>
                  <LoadingSpinner size={16} className="mr-2" />
                  Deleting...
                </>
              ) : (
                "Delete"
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      
      <AlertDialog open={isReactivateDialogOpen} onOpenChange={setIsReactivateDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Reactivate Vehicle Listing</AlertDialogTitle>
            <AlertDialogDescription>
              This will reactivate your vehicle listing for another 30 days. You will be charged 1 credit.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isReactivating}>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleReactivate}
              disabled={isReactivating}
            >
              {isReactivating ? (
                <>
                  <LoadingSpinner size={16} className="mr-2" />
                  Processing...
                </>
              ) : (
                "Reactivate (1 Credit)"
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      
      <AlertDialog open={insufficientCredits} onOpenChange={setInsufficientCredits}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Insufficient Credits</AlertDialogTitle>
            <AlertDialogDescription>
              You don't have enough credits to reactivate this listing. Purchase more credits to continue.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="flex flex-col sm:flex-row gap-2">
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <Link to="/settings?tab=credits">
              <Button className="w-full">Purchase Credits</Button>
            </Link>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default InventoryDialogs;
