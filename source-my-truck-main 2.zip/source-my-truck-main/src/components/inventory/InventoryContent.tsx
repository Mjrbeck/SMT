
import React, { useState, useEffect, useCallback } from "react";
import { toast } from "@/hooks/use-toast";
import InventoryHeader from "@/components/inventory/InventoryHeader";
import InventoryTabs from "@/components/inventory/InventoryTabs";
import InventoryDialogs from "@/components/inventory/InventoryDialogs";
import { useVehicleManagement } from "@/hooks/useVehicleManagement";
import { useInventory } from "@/contexts/InventoryContext";
import { useAsyncExecution } from "@/hooks/useAsyncExecution";

const InventoryContent = () => {
  const { 
    stats, 
    activeTab, 
    setActiveTab, 
    refetchVehicles, 
    remainingCredits,
    deleteVehicle,
    expireVehicle,
    reactivateVehicle
  } = useInventory();
  
  const [vehicleToDelete, setVehicleToDelete] = useState<string | null>(null);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [isReactivateDialogOpen, setIsReactivateDialogOpen] = useState(false);
  const [vehicleToReactivate, setVehicleToReactivate] = useState<string | null>(null);
  const [isOperationInProgress, setIsOperationInProgress] = useState(false);

  const { 
    isLoading: isActionLoading, 
    executeWithLoading 
  } = useAsyncExecution();

  const {
    insufficientCredits,
    setInsufficientCredits,
    changeVehicleStatus,
    isDeleting,
    isReactivating
  } = useVehicleManagement({
    onSuccess: refetchVehicles
  });

  useEffect(() => {
    const initialFetch = async () => {
      await refetchVehicles();
    };
    initialFetch();
  }, []);

  const openDeleteDialog = useCallback((id: string) => {
    if (isOperationInProgress) return;
    setVehicleToDelete(id);
    setIsDeleteDialogOpen(true);
  }, [isOperationInProgress]);

  const openReactivateDialog = useCallback((id: string) => {
    if (isOperationInProgress) return;
    setVehicleToReactivate(id);
    setIsReactivateDialogOpen(true);
  }, [isOperationInProgress]);

  const handleDeleteVehicle = useCallback(async () => {
    if (!vehicleToDelete || isOperationInProgress) return false;
    
    try {
      setIsOperationInProgress(true);
      setIsDeleteDialogOpen(false);
      
      const success = await executeWithLoading(async () => {
        return await deleteVehicle(vehicleToDelete);
      });
      
      if (success) {
        toast({
          title: "Vehicle deleted",
          description: "The vehicle has been successfully removed from your inventory."
        });
        return true;
      } else {
        toast({
          title: "Error",
          description: "Failed to delete the vehicle. Please try again.",
          variant: "destructive"
        });
        return false;
      }
    } catch (error) {
      console.error("Error in handleDeleteVehicle:", error);
      toast({
        title: "Error",
        description: "Failed to delete the vehicle. Please try again.",
        variant: "destructive"
      });
      return false;
    } finally {
      setVehicleToDelete(null);
      setTimeout(() => {
        setIsOperationInProgress(false);
      }, 500);
    }
  }, [vehicleToDelete, deleteVehicle, executeWithLoading, isOperationInProgress]);

  const handleVehicleDelete = useCallback(async (id: string): Promise<boolean> => {
    if (isOperationInProgress) return false;
    
    try {
      const success = await executeWithLoading(async () => {
        return await deleteVehicle(id);
      });
      
      return success;
    } catch (error) {
      console.error("Error in handleVehicleDelete:", error);
      return false;
    }
  }, [deleteVehicle, executeWithLoading, isOperationInProgress]);

  const handleReactivateVehicle = useCallback(async () => {
    if (!vehicleToReactivate || isOperationInProgress) return false;
    
    try {
      setIsOperationInProgress(true);
      setIsReactivateDialogOpen(false);
      
      const success = await executeWithLoading(async () => {
        return await reactivateVehicle(vehicleToReactivate);
      });
      
      if (success) {
        toast({
          title: "Vehicle reactivated",
          description: "The vehicle has been successfully reactivated and is now visible to potential buyers."
        });
        return true;
      } else {
        toast({
          title: "Error",
          description: "Failed to reactivate the vehicle. Please try again.",
          variant: "destructive"
        });
        return false;
      }
    } catch (error) {
      console.error("Error in handleReactivateVehicle:", error);
      toast({
        title: "Error",
        description: "Failed to reactivate the vehicle. Please try again.",
        variant: "destructive"
      });
      return false;
    } finally {
      setVehicleToReactivate(null);
      setTimeout(() => {
        setIsOperationInProgress(false);
      }, 500);
    }
  }, [vehicleToReactivate, reactivateVehicle, executeWithLoading, isOperationInProgress]);

  const handleStatusChange = useCallback(async (id: string, status: string): Promise<boolean> => {
    if (isOperationInProgress) return false;
    
    try {
      setIsOperationInProgress(true);
      
      const result = await executeWithLoading(async () => {
        if (status === 'expired') {
          const success = await expireVehicle(id);
          if (success) {
            toast({
              title: "Vehicle expired",
              description: "The vehicle has been marked as expired and is no longer visible to potential buyers."
            });
          }
          return success;
        } else if (status === 'draft') {
          const success = await changeVehicleStatus(id, status);
          if (success) {
            toast({
              title: "Vehicle unpublished",
              description: "The vehicle has been unpublished and is no longer visible to potential buyers."
            });
          }
          return success;
        } else if (status === 'active') {
          const success = await changeVehicleStatus(id, status);
          if (success) {
            toast({
              title: "Vehicle published",
              description: "The vehicle has been published and is now visible to potential buyers."
            });
          }
          return success;
        } else {
          const success = await changeVehicleStatus(id, status);
          if (success) {
            toast({
              title: "Status updated",
              description: `The vehicle status has been updated to "${status}".`
            });
          }
          return success;
        }
      });
      
      return result;
    } catch (error) {
      console.error("Error in handleStatusChange:", error);
      toast({
        title: "Error",
        description: "Failed to change vehicle status. Please try again.",
        variant: "destructive"
      });
      return false;
    } finally {
      setTimeout(() => {
        setIsOperationInProgress(false);
      }, 500);
    }
  }, [expireVehicle, changeVehicleStatus, executeWithLoading, isOperationInProgress]);

  const openBulkUploadDialog = useCallback(() => {
    toast({
      title: "Feature Unavailable",
      description: "The bulk upload feature has been temporarily disabled for maintenance.",
      variant: "destructive"
    });
  }, []);

  return (
    <>
      <div className="mb-6">
        <InventoryHeader 
          remainingCredits={remainingCredits || 0} 
          onOpenBulkUpload={openBulkUploadDialog}
        />
        
        <InventoryTabs 
          activeTab={activeTab} 
          setActiveTab={setActiveTab}
          stats={stats}
          onDeleteClick={handleVehicleDelete}
          onReactivateClick={openReactivateDialog}
          onStatusChange={handleStatusChange}
        />
      </div>

      <InventoryDialogs
        isDeleteDialogOpen={isDeleteDialogOpen}
        setIsDeleteDialogOpen={setIsDeleteDialogOpen}
        isReactivateDialogOpen={isReactivateDialogOpen}
        setIsReactivateDialogOpen={setIsReactivateDialogOpen}
        insufficientCredits={insufficientCredits}
        setInsufficientCredits={setInsufficientCredits}
        onDeleteConfirm={handleDeleteVehicle}
        onReactivateConfirm={handleReactivateVehicle}
        isDeleting={isDeleting || isActionLoading || isOperationInProgress}
        isReactivating={isReactivating || isActionLoading || isOperationInProgress}
      />
    </>
  );
};

export default React.memo(InventoryContent);
