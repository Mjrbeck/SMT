import React, { useMemo, useState } from "react";
import { useInventory } from "@/contexts/InventoryContext";
import { Button } from "@/components/ui/button";
import {
  AlertTriangle,
  ArrowUpDown,
  CheckCircle,
  Clock,
  Eye,
  MoreHorizontal,
  Pencil,
  Tag,
  Trash,
  ImageIcon,
  Truck,
  InfoIcon,
  Plus
} from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Checkbox } from "@/components/ui/checkbox";
import { Link } from "react-router-dom";
import { format } from "date-fns";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { StatusBadge } from "./InventoryVehicleCard";
import VehicleActions from "./VehicleActions";
import { getValidImageUrl } from "@/utils/imageUtils";
import { toast } from "sonner";
import { formatExpirationDate } from "@/utils/formatters";

interface Vehicle {
  id: string;
  title: string;
  make: string;
  model: string;
  year: number;
  price: number;
  mileage?: number;
  engineSize?: string;
  fuelType?: string;
  transmission?: string;
  description: string;
  location: string;
  imageUrl: string;
  weight?: number;
  axleConfiguration?: string;
  bodyType?: string;
  features?: string[];
  additionalImages?: string[];
  user_id?: string;
  isPOA?: boolean;
  status?: 'active' | 'draft' | 'expired' | 'sale_in_progress' | 'sold';
  expires_at?: string;
  created_at?: string;
  updated_at?: string;
  registration?: string;
  distance?: number;
  interiorCondition?: string;
  exteriorCondition?: string;
}

interface InventoryVehicleListProps {
  onDeleteClick: (id: string) => Promise<boolean>;
  onReactivateClick?: (id: string) => void;
  onStatusChange: (id: string, status: string) => Promise<boolean>;
}

const InventoryVehicleList = ({
  onDeleteClick,
  onReactivateClick,
  onStatusChange
}: InventoryVehicleListProps) => {
  const { vehicles, activeTab } = useInventory();
  const [selectedRows, setSelectedRows] = useState<string[]>([]);
  const [sortConfig, setSortConfig] = useState<{ key: string; direction: 'ascending' | 'descending' } | null>(null);
  const [isBulkOperationInProgress, setIsBulkOperationInProgress] = useState(false);

  const filteredVehicles = useMemo(() => {
    if (!vehicles) return [];

    switch (activeTab) {
      case "active":
        return vehicles.filter(v => v.status === 'active');
      case "draft":
        return vehicles.filter(v => v.status === 'draft');
      case "expired":
        return vehicles.filter(v => v.status === 'expired' ||
          (v.status === 'active' && v.expires_at && new Date(v.expires_at) < new Date()));
      case "sale_in_progress":
        return vehicles.filter(v => v.status === 'sale_in_progress');
      case "sold":
        return vehicles.filter(v => v.status === 'sold');
      default:
        return vehicles;
    }
  }, [vehicles, activeTab]);

  const handleStatusChange = async (vehicleId: string, newStatus: string): Promise<boolean> => {
    return onStatusChange(vehicleId, newStatus);
  };

  const handleSort = (key: string) => {
    let direction: 'ascending' | 'descending' = 'ascending';
    if (sortConfig && sortConfig.key === key && sortConfig.direction === 'ascending') {
      direction = 'descending';
    }
    setSortConfig({ key, direction });
  };

  const sortedVehicles = useMemo(() => {
    if (!sortConfig || !filteredVehicles) return filteredVehicles;

    return [...filteredVehicles].sort((a, b) => {
      const key = sortConfig.key as keyof Vehicle;

      if (a[key] === null || a[key] === undefined) return -1;
      if (b[key] === null || b[key] === undefined) return 1;

      const aValue = typeof a[key] === 'string' ? a[key].toUpperCase() : a[key];
      const bValue = typeof b[key] === 'string' ? b[key].toUpperCase() : b[key];

      if (aValue < bValue) {
        return sortConfig.direction === 'ascending' ? -1 : 1;
      }
      if (aValue > bValue) {
        return sortConfig.direction === 'ascending' ? 1 : -1;
      }
      return 0;
    });
  }, [filteredVehicles, sortConfig]);

  const isSelected = (id: string) => selectedRows.includes(id);

  const formatMileage = (mileage?: number) => {
    if (mileage === undefined || mileage === null) {
      return "N/A";
    }
    return `${mileage.toLocaleString()} miles`;
  };

  const renderVehicleRow = (vehicle) => {
    const isExpired = vehicle.status === 'expired' || 
      (vehicle.status === 'active' && vehicle.expires_at && new Date(vehicle.expires_at) < new Date());
    
    const daysUntilExpiration = vehicle.expires_at ? 
      Math.ceil((new Date(vehicle.expires_at).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24)) : 0;
    
    const expiringSoon = daysUntilExpiration > 0 && daysUntilExpiration <= 3;
    
    return (
      <TableRow key={vehicle.id} className={`${isSelected(vehicle.id) ? "bg-muted/50" : ""} ${expiringSoon && !isExpired ? "bg-amber-50/50" : ""}`}>
        <TableCell className="py-3 pl-4 pr-0 w-10">
          <Checkbox
            checked={isSelected(vehicle.id)}
            onCheckedChange={(checked) => {
              if (checked) {
                setSelectedRows([...selectedRows, vehicle.id]);
              } else {
                setSelectedRows(selectedRows.filter((rowId) => rowId !== vehicle.id));
              }
            }}
            aria-label={`Select ${vehicle.title}`}
          />
        </TableCell>
        <TableCell className="py-3 max-w-[300px]">
          <div className="flex items-center gap-3">
            <div className="flex-shrink-0 h-14 w-20 rounded-md overflow-hidden bg-gray-100">
              {vehicle.imageUrl ? (
                <img 
                  src={getValidImageUrl(vehicle.imageUrl)} 
                  alt={vehicle.title}
                  className="h-full w-full object-cover"
                />
              ) : (
                <div className="h-full w-full flex items-center justify-center bg-gray-200">
                  <Truck className="h-5 w-5 text-gray-400" />
                </div>
              )}
            </div>
            <div className="flex flex-col min-w-0">
              <span className="font-medium text-base truncate">{vehicle.title}</span>
              <span className="text-xs text-muted-foreground">{formatMileage(vehicle.mileage)}</span>
              {vehicle.registration && (
                <span className="text-xs text-muted-foreground mt-0.5">{vehicle.registration}</span>
              )}
            </div>
          </div>
        </TableCell>
        <TableCell className="py-3 text-center w-[120px]">
          {vehicle.isPOA ? (
            <span className="font-medium text-base">POA</span>
          ) : (
            <span className="font-medium text-base">
              £{vehicle.price?.toLocaleString() || 0}
            </span>
          )}
        </TableCell>
        <TableCell className="py-3 text-center w-[150px]">
          <div className="flex flex-col items-center">
            <StatusBadge status={vehicle.status} isExpired={isExpired} />
            {vehicle.status === 'active' && vehicle.expires_at && !isExpired && (
              <span className={`text-xs mt-1.5 ${expiringSoon ? 'text-amber-600 font-medium' : 'text-muted-foreground'}`}>
                <Clock className={`h-3 w-3 inline-block mr-1 ${expiringSoon ? 'text-amber-600' : ''}`} />
                {formatExpirationDate(vehicle.expires_at)}
                {expiringSoon && (
                  <span className="ml-1">({daysUntilExpiration} day{daysUntilExpiration !== 1 ? 's' : ''} left)</span>
                )}
              </span>
            )}
          </div>
        </TableCell>
        <TableCell className="py-3 text-center w-[120px]">
          {vehicle.created_at && (
            <span className="text-sm text-muted-foreground">
              {format(new Date(vehicle.created_at), "MMM d, yyyy")}
            </span>
          )}
        </TableCell>
        <TableCell className="py-3 text-right pr-4 w-[120px]">
          <VehicleActions
            vehicleId={vehicle.id}
            status={vehicle.status}
            isExpired={isExpired}
            onStatusChange={handleStatusChange}
            onDeleteClick={onDeleteClick}
            onReactivateClick={onReactivateClick}
          />
        </TableCell>
      </TableRow>
    );
  };

  const handleBulkDelete = async () => {
    if (selectedRows.length === 0 || !window.confirm(`Are you sure you want to delete ${selectedRows.length} vehicle${selectedRows.length > 1 ? 's' : ''}?`)) {
      return;
    }
    
    try {
      setIsBulkOperationInProgress(true);
      
      const rowsToDelete = [...selectedRows];
      
      const toastId = toast.loading(`Deleting ${rowsToDelete.length} vehicle${rowsToDelete.length > 1 ? 's' : ''}...`);
      
      let successCount = 0;
      let failedCount = 0;
      
      for (const id of rowsToDelete) {
        try {
          const success = await onDeleteClick(id);
          
          if (success) {
            successCount++;
          } else {
            failedCount++;
            console.error(`Failed to delete vehicle ${id}`);
          }
        } catch (error) {
          console.error(`Error deleting vehicle ${id}:`, error);
          failedCount++;
        }
      }
      
      if (failedCount === 0) {
        toast.success(`Successfully deleted ${successCount} vehicle${successCount > 1 ? 's' : ''}`, {
          id: toastId,
        });
      } else {
        toast.error(`Deleted ${successCount} vehicle${successCount > 1 ? 's' : ''}, but failed to delete ${failedCount}`, {
          id: toastId,
        });
      }
      
      setSelectedRows([]);
    } catch (error) {
      console.error("Error in bulk delete operation:", error);
      toast.error("An error occurred during the bulk delete operation");
    } finally {
      setIsBulkOperationInProgress(false);
    }
  };

  const handleBulkStatusChange = async (newStatus: string) => {
    if (window.confirm(`Are you sure you want to change ${selectedRows.length} vehicle${selectedRows.length > 1 ? 's' : ''} to ${newStatus}?`)) {
      try {
        setIsBulkOperationInProgress(true);
        
        const rowsToUpdate = [...selectedRows];
        
        const toastId = toast.loading(`Updating ${rowsToUpdate.length} vehicle${rowsToUpdate.length > 1 ? 's' : ''}...`);
        
        let successCount = 0;
        let failedCount = 0;
        
        for (const id of rowsToUpdate) {
          try {
            const success = await onStatusChange(id, newStatus);
            if (success) {
              successCount++;
            } else {
              failedCount++;
            }
          } catch (error) {
            console.error(`Failed to update vehicle ${id} status:`, error);
            failedCount++;
          }
        }
        
        if (failedCount === 0) {
          toast.success(`Successfully updated ${successCount} vehicle${successCount > 1 ? 's' : ''} to ${newStatus}`, {
            id: toastId,
          });
        } else {
          toast.error(`Updated ${successCount} vehicle${successCount > 1 ? 's' : ''}, but failed to update ${failedCount}`, {
            id: toastId,
          });
        }
        
        setSelectedRows([]);
      } catch (error) {
        console.error("Error in bulk status update operation:", error);
        toast.error("An error occurred during the bulk status update operation");
      } finally {
        setIsBulkOperationInProgress(false);
      }
    }
  };

  return (
    <div className="rounded-md border shadow-sm overflow-hidden">
      {selectedRows.length > 0 && (
        <div className="bg-muted/50 p-2 flex items-center justify-between">
          <span className="text-sm font-medium ml-2">
            {selectedRows.length} vehicle{selectedRows.length > 1 ? 's' : ''} selected
          </span>
          <div className="flex gap-2">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm" disabled={isBulkOperationInProgress}>
                  {isBulkOperationInProgress ? 'Processing...' : 'Change Status'}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => handleBulkStatusChange('active')} disabled={isBulkOperationInProgress}>
                  <CheckCircle className="mr-2 h-4 w-4 text-green-500" /> Mark as Active
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleBulkStatusChange('draft')} disabled={isBulkOperationInProgress}>
                  <AlertTriangle className="mr-2 h-4 w-4 text-amber-500" /> Mark as Draft
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleBulkStatusChange('sale_in_progress')} disabled={isBulkOperationInProgress}>
                  <Clock className="mr-2 h-4 w-4 text-blue-500" /> Mark as Sale in Progress
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleBulkStatusChange('sold')} disabled={isBulkOperationInProgress}>
                  <Tag className="mr-2 h-4 w-4 text-purple-500" /> Mark as Sold
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <Button 
              variant="outline" 
              size="sm" 
              className="text-red-500 hover:text-red-700 hover:bg-red-50"
              onClick={handleBulkDelete}
              disabled={isBulkOperationInProgress}
            >
              {isBulkOperationInProgress ? (
                <>Processing...</>
              ) : (
                <>
                  <Trash className="mr-2 h-4 w-4" /> Delete
                </>
              )}
            </Button>
          </div>
        </div>
      )}

      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow className="bg-gray-50/80 border-b border-gray-200">
              <TableHead className="w-10 py-3 pl-4 pr-0">
                <Checkbox
                  checked={selectedRows.length === filteredVehicles.length && filteredVehicles.length > 0}
                  onCheckedChange={(checked) => {
                    if (checked) {
                      setSelectedRows(filteredVehicles.map((vehicle) => vehicle.id));
                    } else {
                      setSelectedRows([]);
                    }
                  }}
                  aria-label="Select all"
                />
              </TableHead>
              <TableHead className="py-3 max-w-[300px]">
                <Button variant="ghost" onClick={() => handleSort('title')} className="flex items-center gap-1 font-medium">
                  Vehicle
                  <ArrowUpDown className="ml-2 h-3 w-3" />
                </Button>
              </TableHead>
              <TableHead className="py-3 w-[120px] text-center">
                <Button variant="ghost" onClick={() => handleSort('price')} className="flex items-center justify-center gap-1 font-medium mx-auto">
                  Price
                  <ArrowUpDown className="ml-2 h-3 w-3" />
                </Button>
              </TableHead>
              <TableHead className="py-3 w-[150px] text-center">Status</TableHead>
              <TableHead className="py-3 w-[120px] text-center">
                <Button variant="ghost" onClick={() => handleSort('created_at')} className="flex items-center justify-center gap-1 font-medium mx-auto">
                  Created
                  <ArrowUpDown className="ml-2 h-3 w-3" />
                </Button>
              </TableHead>
              <TableHead className="py-3 w-[120px] text-right pr-4">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredVehicles.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} className="h-32 text-center">
                  <div className="flex flex-col items-center justify-center space-y-3 text-gray-500">
                    <Truck className="h-10 w-10 text-gray-300" />
                    <div>No vehicles found</div>
                    {activeTab === "all" && (
                      <Link to="/create-listing">
                        <Button variant="outline" size="sm" className="mt-2">
                          <Plus className="mr-2 h-4 w-4" /> Add Your First Vehicle
                        </Button>
                      </Link>
                    )}
                  </div>
                </TableCell>
              </TableRow>
            ) : (
              sortedVehicles.map(renderVehicleRow)
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};

export default InventoryVehicleList;
