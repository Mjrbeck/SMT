
import React from "react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertCircle } from "lucide-react";

// Add props interface to match how the component is used in InventoryContent
interface BulkUploadProps {
  isOpen?: boolean;
  onOpenChange?: (open: boolean) => void;
}

const BulkUploadDisabled: React.FC<BulkUploadProps> = () => {
  return (
    <div className="p-4">
      <Alert variant="destructive">
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>Feature Temporarily Disabled</AlertTitle>
        <AlertDescription>
          The bulk upload feature has been temporarily disabled for maintenance. 
          Please add vehicles individually until this feature is restored.
        </AlertDescription>
      </Alert>
    </div>
  );
};

export default BulkUploadDisabled;
