
import React from "react";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Check, FileUp } from "lucide-react";
import { toast } from "@/hooks/use-toast";

interface FileUploaderProps {
  file: File | null;
  setFile: (file: File | null) => void;
}

const FileUploader: React.FC<FileUploaderProps> = ({ file, setFile }) => {
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    
    if (!selectedFile) {
      setFile(null);
      return;
    }
    
    // Validate file type
    if (selectedFile.type !== 'text/csv' && !selectedFile.name.endsWith('.csv')) {
      toast({
        title: "Invalid File",
        description: "Please upload a CSV file",
        variant: "destructive",
      });
      e.target.value = '';
      setFile(null);
      return;
    }
    
    setFile(selectedFile);
  };

  return (
    <div className="grid gap-2">
      <Label htmlFor="csv-file">Upload CSV File</Label>
      <div className="border-2 border-dashed rounded-md p-6 flex flex-col items-center justify-center">
        <FileUp className="h-8 w-8 mb-2 text-muted-foreground" />
        <p className="text-sm text-center text-muted-foreground mb-4">
          Drag and drop your CSV file, or click to browse
        </p>
        <input
          id="csv-file"
          type="file"
          accept=".csv"
          onChange={handleFileChange}
          className="hidden"
        />
        <Button
          type="button"
          variant="outline"
          onClick={() => document.getElementById('csv-file')?.click()}
        >
          Select File
        </Button>
      </div>
      {file && (
        <div className="flex items-center gap-2 mt-2 p-2 bg-secondary rounded">
          <Check className="h-4 w-4 text-green-500" />
          <span className="text-sm">{file.name}</span>
        </div>
      )}
    </div>
  );
};

export default FileUploader;
