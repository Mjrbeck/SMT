
import React from "react";
import { Button } from "@/components/ui/button";
import { Download } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { downloadCsvTemplate } from "@/services/csv";

const TemplateDownload: React.FC = () => {
  const handleDownloadTemplate = () => {
    downloadCsvTemplate();
    toast({
      title: "Template Downloaded",
      description: "Vehicle import template has been downloaded."
    });
  };

  return (
    <div className="flex flex-col gap-2">
      <Button 
        type="button" 
        variant="outline" 
        onClick={handleDownloadTemplate}
        className="w-full flex items-center gap-2"
      >
        <Download className="h-4 w-4" />
        Download CSV Template
      </Button>
      <p className="text-xs text-muted-foreground">
        Download this template as a reference for the required fields.
      </p>
    </div>
  );
};

export default TemplateDownload;
