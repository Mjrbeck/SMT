
import React from "react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertCircle } from "lucide-react";

interface UploadResultProps {
  result: {
    success: boolean;
    message: string;
    createdCount: number;
  } | null;
}

const UploadResult: React.FC<UploadResultProps> = ({ result }) => {
  if (!result) return null;

  return (
    <div className="py-4">
      <Alert variant={result.success ? "default" : "destructive"}>
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>
          {result.success ? "Upload Complete" : "Upload Failed"}
        </AlertTitle>
        <AlertDescription>
          {result.message}
          {result.success && result.createdCount > 0 && (
            <p className="mt-2">Created {result.createdCount} vehicle listings.</p>
          )}
        </AlertDescription>
      </Alert>
    </div>
  );
};

export default UploadResult;
