
import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Upload } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { useInventory } from "@/contexts/InventoryContext";
import { processCsvFile } from "@/services/csv";

import TemplateDownload from "./TemplateDownload";
import FileUploader from "./FileUploader";
import UploadResult from "./UploadResult";

interface BulkUploadDialogProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
}

const BulkUploadDialog: React.FC<BulkUploadDialogProps> = ({ isOpen, onOpenChange }) => {
  const [file, setFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadComplete, setUploadComplete] = useState(false);
  const [uploadResult, setUploadResult] = useState<{ success: boolean; message: string; createdCount: number } | null>(null);
  
  const { refetchVehicles, fetchCredits } = useInventory();

  const handleUpload = async () => {
    if (!file) {
      toast({
        title: "No File Selected",
        description: "Please select a CSV file to upload",
        variant: "destructive",
      });
      return;
    }

    setIsUploading(true);
    setUploadComplete(false);
    
    try {
      const result = await processCsvFile(file);
      setUploadResult(result);
      setUploadComplete(true);
      
      if (result.success) {
        // Refresh vehicle list and credits
        if (refetchVehicles) await refetchVehicles();
        if (fetchCredits) await fetchCredits();
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to process CSV file",
        variant: "destructive",
      });
      console.error("Error processing CSV:", error);
    } finally {
      setIsUploading(false);
    }
  };

  const handleReset = () => {
    setFile(null);
    setUploadComplete(false);
    setUploadResult(null);
    const fileInput = document.getElementById('csv-file') as HTMLInputElement;
    if (fileInput) {
      fileInput.value = '';
    }
  };

  const handleClose = () => {
    handleReset();
    onOpenChange(false);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Bulk Upload Vehicles</DialogTitle>
          <DialogDescription>
            Upload a CSV file to create multiple vehicle listings at once.
            Each vehicle will use 1 credit.
          </DialogDescription>
        </DialogHeader>
        
        {!uploadComplete ? (
          <div className="grid gap-4 py-4">
            <TemplateDownload />
            <FileUploader file={file} setFile={setFile} />
          </div>
        ) : (
          <UploadResult result={uploadResult} />
        )}

        <DialogFooter className="flex flex-col sm:flex-row sm:justify-between gap-2">
          {!uploadComplete ? (
            <>
              <Button
                type="button"
                variant="outline"
                onClick={handleClose}
                className="sm:order-1"
              >
                Cancel
              </Button>
              <Button
                type="button"
                onClick={handleUpload}
                disabled={!file || isUploading}
                className="sm:order-2 gap-2"
              >
                {isUploading ? (
                  <>
                    <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Processing...
                  </>
                ) : (
                  <>
                    <Upload className="h-4 w-4" />
                    Upload Vehicles
                  </>
                )}
              </Button>
            </>
          ) : (
            <>
              <Button type="button" variant="outline" onClick={handleClose} className="sm:order-1">
                Close
              </Button>
              <Button type="button" onClick={handleReset} className="sm:order-2">
                Upload Another File
              </Button>
            </>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default BulkUploadDialog;
