
import { Card, CardContent, CardHeader } from "@/components/ui/card";

const InventoryLoadingSkeleton = () => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {[1, 2, 3].map(i => (
        <Card key={i} className="overflow-hidden">
          <div className="h-48 bg-gray-200 animate-pulse" />
          <CardHeader className="p-4 pb-0">
            <div className="h-6 bg-gray-200 rounded animate-pulse mb-2" />
            <div className="h-4 bg-gray-200 rounded animate-pulse w-1/2" />
          </CardHeader>
          <CardContent className="p-4 pt-2">
            <div className="h-4 bg-gray-200 rounded animate-pulse mb-4" />
            <div className="flex space-x-2">
              <div className="h-8 bg-gray-200 rounded animate-pulse flex-1" />
              <div className="h-8 bg-gray-200 rounded animate-pulse flex-1" />
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default InventoryLoadingSkeleton;
