
import React from "react";
import { Truck } from "lucide-react";
import { cn } from "@/lib/utils";

interface LogoProps {
  className?: string;
  showIcon?: boolean;
  iconOnly?: boolean;
  size?: "sm" | "md" | "lg" | "xl";
  rectangular?: boolean;
}

const Logo = ({ 
  className, 
  showIcon = true, 
  iconOnly = false, 
  size = "md",
  rectangular = false
}: LogoProps) => {
  const sizes = {
    sm: {
      container: "space-x-1",
      icon: "h-5 w-5",
      text: "text-lg"
    },
    md: {
      container: "space-x-2",
      icon: "h-6 w-6",
      text: "text-xl"
    },
    lg: {
      container: "space-x-2",
      icon: "h-8 w-8",
      text: "text-2xl"
    },
    xl: {
      container: "space-x-3",
      icon: "h-10 w-10",
      text: "text-3xl"
    }
  };

  return (
    <div className={cn("flex items-center", sizes[size].container, className)}>
      {showIcon && (
        <div className={rectangular ? "mr-2" : ""}>
          <Truck className={cn(sizes[size].icon, "text-brand-blue")} />
        </div>
      )}
      {!iconOnly && (
        <span className={cn("font-bold", sizes[size].text)}>
          <span className="text-brand-blue">Source my </span>
          <span className="text-brand-orange">Truck</span>
        </span>
      )}
    </div>
  );
};

export default Logo;
