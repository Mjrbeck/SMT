
import { useCallback, useEffect, useState, useRef } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { RequiredLabel } from "./RequiredLabel";
import { Button } from "@/components/ui/button";
import { Wand2 } from "lucide-react";
import { toast } from "sonner";
import { Alert, AlertDescription } from "@/components/ui/alert";

interface ListingDetailsFormProps {
  formValues: {
    isPOA: boolean;
    price: string;
    description: string;
    status: string;
    listingTier?: string;
  };
  allVehicleData?: any; // Optional prop to access all vehicle data for AI description
  handleInputChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => void;
  handleSelectChange: (id: string, value: string) => void;
  handleCheckboxChange: (checked: boolean) => void;
  handleRadioChange?: (id: string, value: string) => void;
}

const ListingDetailsForm = ({ 
  formValues, 
  allVehicleData,
  handleInputChange, 
  handleSelectChange,
  handleCheckboxChange,
  handleRadioChange 
}: ListingDetailsFormProps) => {
  const [isGeneratingDescription, setIsGeneratingDescription] = useState(false);
  const previousFormValuesRef = useRef(formValues);

  useEffect(() => {
    previousFormValuesRef.current = { ...formValues };
  }, [formValues]);
  
  const onCheckboxChange = useCallback((checked: boolean | "indeterminate") => {
    if (typeof checked === 'boolean') {
      console.log("POA checkbox changed to:", checked);
      handleCheckboxChange(checked);
    }
  }, [handleCheckboxChange]);

  const generateDescription = useCallback(() => {
    setIsGeneratingDescription(true);
    
    if (!allVehicleData || !allVehicleData.make || !allVehicleData.model || !allVehicleData.year) {
      toast.error("Not enough vehicle information", {
        description: "Please fill in at least the make, model, and year fields",
        duration: 5000,
      });
      setIsGeneratingDescription(false);
      return;
    }

    try {
      const { 
        make, model, year, color, fuelType, transmission, 
        engineSize, bodyType, mileage, features,
        exteriorCondition, interiorCondition
      } = allVehicleData;

      let description = `${year} ${make} ${model}`;
      
      if (color) {
        description += ` in ${color}`;
      }
      
      if (bodyType) {
        description += `. This ${bodyType.toLowerCase()}`;
      } else {
        description += `. This vehicle`;
      }
      
      if (mileage) {
        description += ` has ${mileage.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")} miles`;
      }
      
      let engineDetails = [];
      if (engineSize) engineDetails.push(`${engineSize} engine`);
      if (fuelType) engineDetails.push(`${fuelType.toLowerCase()} fuel type`);
      if (transmission) engineDetails.push(`${transmission.toLowerCase()} transmission`);
      
      if (engineDetails.length > 0) {
        description += ` and features a ${engineDetails.join(", ")}.`;
      } else {
        description += `.`;
      }
      
      if (exteriorCondition || interiorCondition) {
        description += ` The vehicle is in`;
        if (exteriorCondition) description += ` ${exteriorCondition.toLowerCase()} exterior condition`;
        if (exteriorCondition && interiorCondition) description += ` with`;
        if (interiorCondition) description += ` ${interiorCondition.toLowerCase()} interior condition`;
        description += `.`;
      }
      
      if (features && features.length > 0) {
        if (features.length === 1) {
          description += ` It comes with ${features[0]}.`;
        } else if (features.length === 2) {
          description += ` It comes with ${features[0]} and ${features[1]}.`;
        } else if (features.length > 2) {
          const lastFeature = features[features.length - 1];
          const otherFeatures = features.slice(0, features.length - 1);
          description += ` It comes equipped with ${otherFeatures.join(", ")}, and ${lastFeature}.`;
        }
      }
      
      description += ` Contact us today to schedule a viewing or test drive.`;
      
      setTimeout(() => {
        const event = {
          target: {
            id: "description",
            value: description
          }
        } as React.ChangeEvent<HTMLTextAreaElement>;
        
        handleInputChange(event);
        setIsGeneratingDescription(false);
        
        toast.success("Description generated", {
          description: "You can edit it to add any additional details",
          duration: 3000,
        });
      }, 1000);
      
    } catch (error) {
      console.error("Error generating description:", error);
      toast.error("Failed to generate description", {
        description: "Please try again or fill in the description manually",
      });
      setIsGeneratingDescription(false);
    }
  }, [allVehicleData, handleInputChange]);
  
  const onPriceChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    const numericValue = value.replace(/[^0-9.]/g, '');
    
    const parts = numericValue.split('.');
    const sanitizedValue = parts.length > 2 
      ? `${parts[0]}.${parts.slice(1).join('')}`
      : numericValue;
    
    const sanitizedEvent = {
      ...e,
      target: {
        ...e.target,
        value: sanitizedValue,
        id: e.target.id,
        name: e.target.name
      }
    };
    
    handleInputChange(sanitizedEvent);
  }, [handleInputChange]);
  
  const onDescriptionChange = useCallback((e: React.ChangeEvent<HTMLTextAreaElement>) => {
    handleInputChange(e);
  }, [handleInputChange]);
  
  useEffect(() => {
    if (!formValues.status) {
      handleSelectChange("status", "active");
    }
  }, [formValues.status, handleSelectChange]);

  useEffect(() => {
    if (formValues.description === undefined) {
      handleInputChange({
        target: {
          id: "description",
          value: ""
        }
      } as React.ChangeEvent<HTMLTextAreaElement>);
    }
  }, [formValues.description, handleInputChange]);

  useEffect(() => {
    console.log("Current POA status in form:", formValues.isPOA, "type:", typeof formValues.isPOA);
    console.log("Current listing tier:", formValues.listingTier, "price:", formValues.price);
  }, [formValues.isPOA, formValues.listingTier, formValues.price]);
  
  return (
    <div className="space-y-4">
      <h3 className="font-medium">Listing Details</h3>
      
      <div className="flex items-center space-x-2 mb-4">
        <Checkbox 
          id="isPOA" 
          checked={formValues.isPOA}
          onCheckedChange={onCheckboxChange}
        />
        <Label htmlFor="isPOA" className="cursor-pointer">Price on Application (POA)</Label>
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="price" className={formValues.isPOA ? "text-muted-foreground" : ""}>
          {formValues.isPOA ? "Price (POA)" : "Price (£)"}
          {!formValues.isPOA && <span className="text-red-500 ml-1">*</span>}
        </Label>
        <Input 
          id="price" 
          name="price"
          type="text" 
          inputMode="decimal"
          pattern="[0-9]*\.?[0-9]*"
          placeholder={formValues.isPOA ? "POA" : "e.g. 45000"} 
          value={formValues.isPOA ? "" : formValues.price}
          onChange={onPriceChange}
          disabled={formValues.isPOA}
          required={!formValues.isPOA}
          className={formValues.isPOA ? "bg-gray-100" : ""}
        />
        {!formValues.isPOA && formValues.price === "0" && (
          <p className="text-yellow-600 text-sm mt-1">
            Price must be greater than zero unless POA is selected.
          </p>
        )}
      </div>
      
      <div className="space-y-2">
        <div className="flex justify-between items-center">
          <Label htmlFor="description">Description</Label>
          <Button 
            type="button" 
            size="sm" 
            variant="outline"
            onClick={generateDescription}
            disabled={isGeneratingDescription}
            className="flex items-center gap-1"
          >
            <Wand2 className="h-4 w-4" /> 
            {isGeneratingDescription ? "Generating..." : "Generate with AI"}
          </Button>
        </div>
        <Textarea 
          id="description" 
          name="description"
          rows={5}
          placeholder="Describe the vehicle, its condition, history and any special features (optional)"
          value={formValues.description || ""}
          onChange={onDescriptionChange}
          className="focus:border-primary"
        />
        {!allVehicleData?.make && allVehicleData?.model && (
          <Alert className="mt-2 bg-blue-50 text-blue-800 border-blue-100">
            <AlertDescription>
              Complete the basic vehicle information first to enable AI-generated descriptions.
            </AlertDescription>
          </Alert>
        )}
      </div>
      
      <div className="space-y-2">
        <RequiredLabel htmlFor="status">Listing Status</RequiredLabel>
        <Select 
          value={formValues.status || "active"}
          onValueChange={(value) => handleSelectChange("status", value)}
          required
        >
          <SelectTrigger id="status">
            <SelectValue placeholder="Select status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="active">Active</SelectItem>
            <SelectItem value="inactive">Inactive</SelectItem>
          </SelectContent>
        </Select>
      </div>
    </div>
  );
};

export default ListingDetailsForm;
