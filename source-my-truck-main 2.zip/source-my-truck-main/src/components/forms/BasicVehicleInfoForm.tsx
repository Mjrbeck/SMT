
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RequiredLabel } from "./RequiredLabel";

interface BasicVehicleInfoFormProps {
  formValues: {
    make: string;
    model: string;
    year: string | number;
    color: string;
  };
  handleInputChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => void;
}

const BasicVehicleInfoForm = ({
  formValues,
  handleInputChange
}: BasicVehicleInfoFormProps) => {
  return (
    <div className="space-y-4">
      <h3 className="font-medium">Basic Information</h3>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <RequiredLabel htmlFor="make">Make</RequiredLabel>
          <Input 
            id="make" 
            name="make"
            value={formValues.make || ""} 
            onChange={handleInputChange} 
            required 
            className="focus:border-primary focus:ring-primary"
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="model">Model (Optional)</Label>
          <Input 
            id="model" 
            name="model"
            value={formValues.model || ""} 
            onChange={handleInputChange}
            className="focus:border-primary focus:ring-primary"
            placeholder="Optional"
          />
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="space-y-2 my-[9px]">
          <RequiredLabel htmlFor="year">Year</RequiredLabel>
          <Input 
            id="year" 
            name="year"
            value={formValues.year?.toString() || ""} 
            onChange={handleInputChange} 
            required 
            className="focus:border-primary focus:ring-primary"
          />
        </div>
        
        <div className="space-y-2 my-0">
          <Label htmlFor="color">Color (Optional)</Label>
          <Input 
            id="color" 
            name="color"
            value={formValues.color || ""} 
            onChange={handleInputChange} 
            className="focus:border-primary focus:ring-primary"
            placeholder="Optional"
          />
        </div>
      </div>
    </div>
  );
};

export default BasicVehicleInfoForm;
