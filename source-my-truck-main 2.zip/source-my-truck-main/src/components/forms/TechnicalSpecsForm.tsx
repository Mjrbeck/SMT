import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

interface TechnicalSpecsFormProps {
  formValues: {
    fuelType: string;
    transmission: string;
    engineSize: string;
    bodyType: string;
    axleConfiguration: string;
    weight: string; // Keep this as string
    interiorCondition: string;
    exteriorCondition: string;
    cabType?: string;
    driverPosition?: string;
    enginePower?: string;
    emissionsClass?: string;
    color?: string;
    numberOfSeats?: string | number;
    grossVehicleWeight?: string | number;
    volume?: string;
    internalLength?: string | number;
    internalWidth?: string | number;
    internalHeight?: string | number;
    externalLength?: string | number;
    externalWidth?: string | number;
    externalHeight?: string | number;
    isNew?: boolean;
  };
  handleInputChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => void;
  handleSelectChange: (id: string, value: string) => void;
  handleRadioChange: (id: string, value: string) => void;
}

const TechnicalSpecsForm = ({
  formValues,
  handleInputChange,
  handleSelectChange,
  handleRadioChange
}: TechnicalSpecsFormProps) => {
  return (
    <div className="space-y-4">
      <h3 className="font-medium">Technical Specifications</h3>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="fuelType">Fuel Type (optional)</Label>
          <Select
            value={formValues.fuelType || ""}
            onValueChange={(value) => handleSelectChange("fuelType", value)}
          >
            <SelectTrigger id="fuelType">
              <SelectValue placeholder="Select fuel type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Diesel">Diesel</SelectItem>
              <SelectItem value="Petrol">Petrol</SelectItem>
              <SelectItem value="Electric">Electric</SelectItem>
              <SelectItem value="Hybrid">Hybrid</SelectItem>
              <SelectItem value="LPG">LPG</SelectItem>
              <SelectItem value="Hydrogen">Hydrogen</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="transmission">Transmission (optional)</Label>
          <Select
            value={formValues.transmission || ""}
            onValueChange={(value) => handleSelectChange("transmission", value)}
          >
            <SelectTrigger id="transmission">
              <SelectValue placeholder="Select transmission" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Manual">Manual</SelectItem>
              <SelectItem value="Automatic">Automatic</SelectItem>
              <SelectItem value="Semi-Automatic">Semi-Automatic</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="bodyType">Body Type</Label>
          <Select
            value={formValues.bodyType || ""}
            onValueChange={(value) => handleSelectChange("bodyType", value)}
          >
            <SelectTrigger id="bodyType">
              <SelectValue placeholder="Select body type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Box Van">Box Van</SelectItem>
              <SelectItem value="Curtainsider">Curtainsider</SelectItem>
              <SelectItem value="Dropside">Dropside</SelectItem>
              <SelectItem value="Flatbed">Flatbed</SelectItem>
              <SelectItem value="Tipper">Tipper</SelectItem>
              <SelectItem value="Tractor Unit">Tractor Unit</SelectItem>
              <SelectItem value="Luton">Luton</SelectItem>
              <SelectItem value="Skip Loader">Skip Loader</SelectItem>
              <SelectItem value="Hook Loader">Hook Loader</SelectItem>
              <SelectItem value="Refrigerated">Refrigerated</SelectItem>
              <SelectItem value="Tanker">Tanker</SelectItem>
              <SelectItem value="Crane">Crane</SelectItem>
              <SelectItem value="Recovery">Recovery</SelectItem>
              <SelectItem value="Crew Cab">Crew Cab</SelectItem>
              <SelectItem value="Municipal">Municipal</SelectItem>
              <SelectItem value="Other">Other</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="engineSize">Engine Size (optional)</Label>
          <Input 
            id="engineSize" 
            type="text" 
            placeholder="e.g. 2.0L" 
            value={formValues.engineSize || ""}
            onChange={handleInputChange}
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="enginePower">Engine Power</Label>
          <Input 
            id="enginePower" 
            type="text" 
            placeholder="e.g. 150 bhp" 
            value={formValues.enginePower || ""}
            onChange={handleInputChange}
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="emissionsClass">Emissions Class</Label>
          <Select
            value={formValues.emissionsClass || ""}
            onValueChange={(value) => handleSelectChange("emissionsClass", value)}
          >
            <SelectTrigger id="emissionsClass">
              <SelectValue placeholder="Select emissions class" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Euro 1">Euro 1</SelectItem>
              <SelectItem value="Euro 2">Euro 2</SelectItem>
              <SelectItem value="Euro 3">Euro 3</SelectItem>
              <SelectItem value="Euro 4">Euro 4</SelectItem>
              <SelectItem value="Euro 5">Euro 5</SelectItem>
              <SelectItem value="Euro 6">Euro 6</SelectItem>
              <SelectItem value="Euro 6d">Euro 6d</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="axleConfiguration">Axle Configuration</Label>
          <Select
            value={formValues.axleConfiguration || ""}
            onValueChange={(value) => handleSelectChange("axleConfiguration", value)}
          >
            <SelectTrigger id="axleConfiguration">
              <SelectValue placeholder="Select axle configuration" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="4x2">4x2</SelectItem>
              <SelectItem value="4x4">4x4</SelectItem>
              <SelectItem value="6x2">6x2</SelectItem>
              <SelectItem value="6x4">6x4</SelectItem>
              <SelectItem value="8x2">8x2</SelectItem>
              <SelectItem value="8x4">8x4</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="cabType">Cab Type</Label>
          <Select
            value={formValues.cabType || ""}
            onValueChange={(value) => handleSelectChange("cabType", value)}
          >
            <SelectTrigger id="cabType">
              <SelectValue placeholder="Select cab type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Day Cab">Day Cab</SelectItem>
              <SelectItem value="Sleeper Cab">Sleeper Cab</SelectItem>
              <SelectItem value="High Roof">High Roof</SelectItem>
              <SelectItem value="Low Roof">Low Roof</SelectItem>
              <SelectItem value="Crew Cab">Crew Cab</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="driverPosition">Driver Position</Label>
          <Select
            value={formValues.driverPosition || ""}
            onValueChange={(value) => handleSelectChange("driverPosition", value)}
          >
            <SelectTrigger id="driverPosition">
              <SelectValue placeholder="Select driver position" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Left">Left</SelectItem>
              <SelectItem value="Right">Right</SelectItem>
              <SelectItem value="Center">Center</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="weight">Weight (kg)</Label>
          <Input 
            id="weight" 
            type="text" 
            placeholder="Vehicle weight in kg" 
            value={formValues.weight || ""}
            onChange={handleInputChange}
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="grossVehicleWeight">Gross Vehicle Weight (kg)</Label>
          <Input 
            id="grossVehicleWeight" 
            type="text" 
            placeholder="GVW in kg" 
            value={formValues.grossVehicleWeight?.toString() || ""}
            onChange={handleInputChange}
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="volume">Volume (m³)</Label>
          <Input 
            id="volume" 
            type="text" 
            placeholder="Volume in cubic meters" 
            value={formValues.volume || ""}
            onChange={handleInputChange}
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="numberOfSeats">Number of Seats</Label>
          <Input 
            id="numberOfSeats" 
            type="text" 
            placeholder="Number of seats" 
            value={formValues.numberOfSeats?.toString() || ""}
            onChange={handleInputChange}
          />
        </div>
      </div>
      
      <div className="border-t pt-4">
        <h4 className="text-sm font-medium mb-3">Dimensions</h4>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="space-y-2">
            <Label htmlFor="internalLength">Internal Length (mm)</Label>
            <Input 
              id="internalLength" 
              type="text" 
              placeholder="Internal length in mm" 
              value={formValues.internalLength?.toString() || ""}
              onChange={handleInputChange}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="internalWidth">Internal Width (mm)</Label>
            <Input 
              id="internalWidth" 
              type="text" 
              placeholder="Internal width in mm" 
              value={formValues.internalWidth?.toString() || ""}
              onChange={handleInputChange}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="internalHeight">Internal Height (mm)</Label>
            <Input 
              id="internalHeight" 
              type="text" 
              placeholder="Internal height in mm" 
              value={formValues.internalHeight?.toString() || ""}
              onChange={handleInputChange}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="externalLength">External Length (mm)</Label>
            <Input 
              id="externalLength" 
              type="text" 
              placeholder="External length in mm" 
              value={formValues.externalLength?.toString() || ""}
              onChange={handleInputChange}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="externalWidth">External Width (mm)</Label>
            <Input 
              id="externalWidth" 
              type="text" 
              placeholder="External width in mm" 
              value={formValues.externalWidth?.toString() || ""}
              onChange={handleInputChange}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="externalHeight">External Height (mm)</Label>
            <Input 
              id="externalHeight" 
              type="text" 
              placeholder="External height in mm" 
              value={formValues.externalHeight?.toString() || ""}
              onChange={handleInputChange}
            />
          </div>
        </div>
      </div>
      
      <div className="border-t pt-4">
        <h4 className="text-sm font-medium mb-3">Vehicle Condition</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="isNew">Vehicle Age</Label>
            <RadioGroup 
              value={formValues.isNew ? "new" : "used"}
              onValueChange={(value) => handleRadioChange("isNew", value)}
              className="flex flex-col space-y-1"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="new" id="new" />
                <Label htmlFor="new" className="cursor-pointer">New</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="used" id="used" />
                <Label htmlFor="used" className="cursor-pointer">Used</Label>
              </div>
            </RadioGroup>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="exteriorCondition">Exterior Condition</Label>
            <Select
              value={formValues.exteriorCondition || ""}
              onValueChange={(value) => handleSelectChange("exteriorCondition", value)}
            >
              <SelectTrigger id="exteriorCondition">
                <SelectValue placeholder="Select condition" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="excellent">Excellent</SelectItem>
                <SelectItem value="good">Good</SelectItem>
                <SelectItem value="average">Average</SelectItem>
                <SelectItem value="fair">Fair</SelectItem>
                <SelectItem value="poor">Poor</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="interiorCondition">Interior Condition</Label>
            <Select
              value={formValues.interiorCondition || ""}
              onValueChange={(value) => handleSelectChange("interiorCondition", value)}
            >
              <SelectTrigger id="interiorCondition">
                <SelectValue placeholder="Select condition" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="excellent">Excellent</SelectItem>
                <SelectItem value="good">Good</SelectItem>
                <SelectItem value="average">Average</SelectItem>
                <SelectItem value="fair">Fair</SelectItem>
                <SelectItem value="poor">Poor</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TechnicalSpecsForm;
