
import { Label } from "@/components/ui/label";

interface RequiredLabelProps {
  htmlFor: string; 
  children: React.ReactNode;
}

export const RequiredLabel = ({ htmlFor, children }: RequiredLabelProps) => (
  <Label htmlFor={htmlFor} className="flex items-center">
    {children} <span className="text-red-500 ml-1">*</span>
  </Label>
);
