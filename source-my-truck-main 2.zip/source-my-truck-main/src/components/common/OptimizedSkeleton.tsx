
import React from "react";
import { Skeleton } from "@/components/ui/skeleton";

interface OptimizedSkeletonProps {
  variant?: "card" | "list" | "text" | "profile";
  count?: number;
  className?: string;
}

export const OptimizedSkeleton = ({ 
  variant = "card", 
  count = 1,
  className = ""
}: OptimizedSkeletonProps) => {
  
  const renderSkeleton = () => {
    switch (variant) {
      case "card":
        return (
          <div className={`bg-white rounded-lg shadow-sm p-4 ${className}`}>
            <Skeleton className="h-8 w-48 mb-4" />
            <Skeleton className="h-16 w-full mb-4" />
            <Skeleton className="h-12 w-32" />
          </div>
        );
      case "list":
        return (
          <div className={`space-y-2 ${className}`}>
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-3/4" />
            <Skeleton className="h-4 w-1/2" />
          </div>
        );
      case "text":
        return <Skeleton className={`h-4 w-full ${className}`} />;
      case "profile":
        return (
          <div className={`space-y-4 ${className}`}>
            <div className="flex items-center space-x-4">
              <Skeleton className="h-12 w-12 rounded-full" />
              <div className="space-y-2">
                <Skeleton className="h-4 w-32" />
                <Skeleton className="h-4 w-24" />
              </div>
            </div>
            <Skeleton className="h-24 w-full rounded-md" />
          </div>
        );
      default:
        return <Skeleton className={`h-8 w-full ${className}`} />;
    }
  };

  return (
    <div className="animate-in fade-in duration-300">
      {Array.from({ length: count }).map((_, index) => (
        <div key={index} className="mb-3">
          {renderSkeleton()}
        </div>
      ))}
    </div>
  );
};
