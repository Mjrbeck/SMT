
import React, { memo, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MapPin, CalendarRange, Gauge, Eye, Truck } from "lucide-react";
import { formatPrice, formatPriceOrPOA } from "@/utils/formatters";
import { getValidImageUrl } from "@/utils/imageUtils";
import { Button } from "@/components/ui/button";
import { TrustBadges } from "@/components/ui/trust-badges";
import { getSellerTrustData, type SellerTrustData } from "@/services/trustBadgeService";
import { WatchButton } from "@/components/watchlist/WatchButton";

export interface VehicleData {
  id: string;
  title: string;
  make: string;
  model?: string;
  year: number;
  price: number;
  mileage?: number;
  engineSize?: string;
  fuelType?: string;
  transmission?: string;
  description: string;
  location: string;
  imageUrl: string;
  weight?: number;
  axleConfiguration?: string;
  bodyType?: string;
  features?: string[];
  additionalImages?: string[];
  user_id?: string;
  isPOA?: boolean;
  status?: string;
  expires_at?: string;
  created_at?: string;
  updated_at?: string;
  registration?: string;
  distance?: number;
  interiorCondition?: string;
  exteriorCondition?: string;
  cabType?: string;
  driverPosition?: string;
  enginePower?: string;
  emissionsClass?: string;
  color?: string;
  numberOfSeats?: number;
  grossVehicleWeight?: number;
  volume?: string;
  internalLength?: number;
  internalWidth?: number;
  internalHeight?: number;
  externalLength?: number;
  externalWidth?: number;
  externalHeight?: number;
  isNew?: boolean;
  listingTier?: string;
  videoUrl?: string;
  youtubeUrl?: string; // Make sure this property is defined in the interface
  vehicle_images?: Array<{
    id: string;
    image_url?: string;
    url?: string;
    is_main: boolean;
    order?: number;
  }>;
}

interface VehicleCardProps {
  vehicle: VehicleData;
  showDistance?: boolean;
  compact?: boolean;
}

const VehicleImage = memo(({
  imageUrl,
  title,
  distance,
  showDistance,
  vehicleId
}: {
  imageUrl: string;
  title: string;
  distance?: number;
  showDistance?: boolean;
  vehicleId: string;
}) => {
  return <div className="relative">
      {imageUrl ? <div className="overflow-hidden rounded-t-lg">
          <img src={getValidImageUrl(imageUrl)} alt={title} className="w-full h-48 object-cover transition-transform duration-200 group-hover:scale-105" loading="lazy" />
        </div> : <div className="w-full h-48 bg-gray-100 flex items-center justify-center rounded-t-lg">
          <Truck size={64} className="text-gray-300" />
        </div>}
      
      {/* Watch Button */}
      <div className="absolute top-2 right-2">
        <WatchButton 
          vehicleId={vehicleId}
          vehicleTitle={title}
          variant="outline"
          size="icon"
          className="bg-white/90 hover:bg-white border-white/50 hover:border-white shadow-sm"
          showText={false}
        />
      </div>
      
      {showDistance && distance !== undefined && <Badge className="absolute bottom-2 left-2 bg-brand-blue text-white font-medium text-xs flex items-center gap-1">
          <MapPin className="h-3 w-3" />
          {distance.toFixed(1)} mi
        </Badge>}
    </div>;
});
VehicleImage.displayName = 'VehicleImage';

const VehicleCard: React.FC<VehicleCardProps> = memo(({
  vehicle,
  showDistance = false,
  compact = false
}) => {
  const [trustData, setTrustData] = useState<SellerTrustData>({
    isTrusted: false,
    depotVerified: false,
    hasMultipleListings: false
  });

  const isPOA = vehicle.isPOA || vehicle.price === 0;
  const formattedMileage = vehicle.mileage !== undefined && vehicle.mileage !== null ? `${vehicle.mileage.toLocaleString()} miles` : "Mileage N/A";
  const displayTitle = vehicle.title || `${vehicle.year} ${vehicle.make} ${vehicle.model || ''}`.trim();

  useEffect(() => {
    if (vehicle.user_id) {
      getSellerTrustData(vehicle.user_id).then(setTrustData);
    }
  }, [vehicle.user_id]);

  return <Card className="overflow-hidden group transition-all duration-200 hover:shadow-md">
      <Link to={`/vehicle/${vehicle.id}`} className="block overflow-hidden">
        <VehicleImage 
          imageUrl={vehicle.imageUrl} 
          title={displayTitle} 
          distance={vehicle.distance} 
          showDistance={showDistance}
          vehicleId={vehicle.id}
        />
      </Link>
      
      <CardContent className={`p-4 ${compact ? 'space-y-1' : 'space-y-2'}`}>
        <h3 className={`font-semibold truncate hover:text-brand-blue transition-colors duration-200 ${compact ? 'text-base' : 'text-lg'}`}>
          <Link to={`/vehicle/${vehicle.id}`}>{displayTitle}</Link>
        </h3>
        
        <TrustBadges 
          isTrusted={trustData.isTrusted}
          depotVerified={trustData.depotVerified}
          hasMultipleListings={trustData.hasMultipleListings}
          size="sm"
          className="mb-2"
        />
        
        <div className="flex justify-between items-center text-sm text-muted-foreground">
          <div className="flex items-center">
            <CalendarRange className="h-4 w-4 mr-1" />
            <span>{vehicle.year}</span>
          </div>
          <div className="flex items-center">
            <Gauge className="h-4 w-4 mr-1" />
            <span>{formattedMileage}</span>
          </div>
        </div>
      </CardContent>
      
      <CardFooter className="p-4 border-t">
        <div className="flex justify-between items-center w-full">
          <span className="font-semibold text-brand-blue">
            {isPOA ? "POA" : formatPrice(vehicle.price)}
          </span>
          <Link to={`/vehicle/${vehicle.id}`} className="
            inline-flex items-center gap-1 text-sm font-medium text-white 
            px-3 py-1.5 rounded-md transition-colors duration-200
            bg-brand-blue hover:bg-brand-blue/90
          ">
            <Eye className="h-4 w-4" />
            View Details
          </Link>
        </div>
      </CardFooter>
    </Card>;
});
VehicleCard.displayName = 'VehicleCard';
export default VehicleCard;
