
import { ReactNode, useEffect, useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { useUserRole } from "@/hooks/useUserRole";
import { LayoutDashboard, Truck, User } from "lucide-react";
import DashboardNavBar from "./dashboard/DashboardNavBar";
import DashboardMobileMenu from "./dashboard/DashboardMobileMenu";
import DashboardContent from "./dashboard/DashboardContent";

interface DashboardLayoutProps {
  children: ReactNode;
  requireAuth?: boolean;
  title?: string;
  subtitle?: string;
}

const DashboardLayout = ({ 
  children, 
  requireAuth = true,
  title,
  subtitle
}: DashboardLayoutProps) => {
  const { isAuthenticated, isLoading, signOut } = useAuth();
  const { isSeller } = useUserRole();
  const navigate = useNavigate();
  const location = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    if (!isLoading && requireAuth && !isAuthenticated) {
      navigate("/login");
    }
  }, [isAuthenticated, isLoading, navigate, requireAuth]);

  // Close mobile menu when route changes
  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [location.pathname]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-pulse flex flex-col items-center">
          <div className="rounded-full bg-gray-200 h-16 w-16 mb-4"></div>
          <div className="h-4 bg-gray-200 rounded w-24 mb-2.5"></div>
          <div className="h-2 bg-gray-200 rounded w-32"></div>
        </div>
      </div>
    );
  }

  if (requireAuth && !isAuthenticated) {
    return null; // Will redirect in the useEffect
  }

  const navigation = [
    { name: 'Dashboard', href: '/dashboard', icon: LayoutDashboard },
    { name: 'Inventory', href: '/inventory', icon: Truck },
    { name: 'Profile', href: '/profile', icon: User },
  ].filter(item => {
    // Filter out seller-only routes for buyers
    if (!isSeller && (
      item.href === "/inventory" || 
      item.href === "/profile"
    )) {
      return false;
    }
    return true;
  });

  const handleSignOut = async () => {
    await signOut();
    navigate("/");
  };

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <DashboardNavBar 
        onMobileMenuToggle={toggleMobileMenu}
        isMobileMenuOpen={isMobileMenuOpen}
      />
      
      <DashboardMobileMenu 
        navigation={navigation}
        onSignOut={handleSignOut}
        isOpen={isMobileMenuOpen}
        isSeller={isSeller}
      />

      <DashboardContent title={title} subtitle={subtitle}>
        {children}
      </DashboardContent>
    </div>
  );
};

export default DashboardLayout;
