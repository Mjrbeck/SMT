import React, { useEffect } from 'react';
import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';

interface ProtectedRouteProps {
  requiredRole?: 'buyer' | 'seller' | 'administrator';
}

const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ requiredRole }) => {
  const { user, userRole, isLoading } = useAuth();
  const location = useLocation();
  const { toast } = useToast();
  const toastShownRef = React.useRef(false);

  useEffect(() => {
    // Show a toast only once when redirecting due to authentication
    if (!isLoading && !user && !toastShownRef.current) {
      toastShownRef.current = true;
      toast({
        title: "Authentication required",
        description: "Please sign in to access this page",
      });
    }

    // Reset the toast flag when component unmounts
    return () => {
      toastShownRef.current = false;
    };
  }, [isLoading, user, toast]);

  // Show loading state while auth is loading
  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-blue"></div>
      </div>
    );
  }

  // If user is not authenticated, redirect to login with the return URL
  if (!user) {
    return <Navigate to={`/login?redirect=${encodeURIComponent(location.pathname)}`} replace />;
  }

  // Check role requirements
  if (requiredRole && userRole !== requiredRole && userRole !== 'administrator') {
    // For seller routes, redirect buyers to home
    if (requiredRole === 'seller' && userRole === 'buyer') {
      return <Navigate to="/" replace />;
    }
    
    // For buyer routes, redirect sellers to dashboard
    if (requiredRole === 'buyer' && userRole === 'seller') {
      return <Navigate to="/dashboard" replace />;
    }
  }

  // Render child routes
  return <Outlet />;
};

export default ProtectedRoute;