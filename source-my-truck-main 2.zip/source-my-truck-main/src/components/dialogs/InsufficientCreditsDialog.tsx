
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Coins } from "lucide-react";
import { useNavigate } from "react-router-dom";

interface InsufficientCreditsDialogProps {
  isOpen: boolean;
  onClose: () => void;
  requiredCredits: number;
  currentCredits: number;
  tierName: string;
}

const InsufficientCreditsDialog = ({
  isOpen,
  onClose,
  requiredCredits,
  currentCredits,
  tierName
}: InsufficientCreditsDialogProps) => {
  const navigate = useNavigate();

  const handlePurchaseCredits = () => {
    navigate("/profile?tab=credits");
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <div className="mx-auto bg-amber-100 p-3 rounded-full w-16 h-16 flex items-center justify-center mb-4">
            <Coins className="h-8 w-8 text-amber-600" />
          </div>
          <DialogTitle className="text-center text-xl">Insufficient Credits</DialogTitle>
          <DialogDescription className="text-center">
            You need {requiredCredits} credits to list a vehicle with {tierName} tier.
          </DialogDescription>
        </DialogHeader>
        
        <div className="grid grid-cols-2 gap-4 py-4">
          <div className="bg-gray-50 p-4 rounded-lg text-center">
            <p className="text-sm text-gray-500">You have</p>
            <p className="text-2xl font-bold">{currentCredits}</p>
            <p className="text-xs text-gray-500">credits</p>
          </div>
          <div className="bg-gray-50 p-4 rounded-lg text-center">
            <p className="text-sm text-gray-500">You need</p>
            <p className="text-2xl font-bold">{requiredCredits}</p>
            <p className="text-xs text-gray-500">credits</p>
          </div>
        </div>
        
        <DialogFooter className="flex-col sm:flex-row sm:justify-center space-y-2 sm:space-y-0 sm:space-x-2">
          <Button onClick={handlePurchaseCredits} className="w-full sm:w-auto">
            Purchase Credits
          </Button>
          <Button variant="outline" onClick={onClose} className="w-full sm:w-auto">
            Cancel
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default InsufficientCreditsDialog;
