
import React, { useMemo } from "react";
import { VehicleData } from "@/components/VehicleCard";
import VehicleCard from "@/components/VehicleCard";
import { StarIcon, ChevronLeft, ChevronRight, Crown, Award, TrendingUp } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { 
  Carousel, 
  CarouselContent, 
  CarouselItem, 
  CarouselPrevious, 
  CarouselNext 
} from "@/components/ui/carousel";
import Autoplay from "embla-carousel-autoplay";
import { useRef } from "react";

interface FeaturedVehiclesSectionProps {
  vehicles: VehicleData[];
  title: string;
  icon: React.ReactNode;
  className?: string;
  limit?: number;
  viewAllLink?: string;
  badgeColor: string;
}

const FeaturedVehiclesSection: React.FC<FeaturedVehiclesSectionProps> = ({
  vehicles,
  title,
  icon,
  className = "",
  limit = 6,
  viewAllLink,
  badgeColor
}) => {
  const limitedVehicles = useMemo(() => {
    return vehicles.slice(0, limit);
  }, [vehicles, limit]);
  
  const autoplayPlugin = useRef(
    Autoplay({ delay: 3000, stopOnInteraction: true })
  );
  
  if (limitedVehicles.length === 0) return null;

  return (
    <div className={cn(
      "my-6 rounded-lg overflow-hidden p-6 shadow-sm",
      "bg-gradient-to-r from-slate-50 via-white to-slate-50",
      "dark:from-slate-900/20 dark:via-gray-900/40 dark:to-slate-900/10",
      "border border-slate-200/70",
      className
    )}>
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6 gap-4">
        <div className="flex items-center">
          <div className={cn(
            "p-2 rounded-lg mr-3 shadow-sm",
            badgeColor
          )}>
            {icon}
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-800 dark:text-slate-200">
              {title}
            </h2>
            <p className="text-slate-600 dark:text-slate-400 text-sm">
              Browse our selection of premium commercial vehicles
            </p>
          </div>
        </div>
        
        {viewAllLink && (
          <Link to={viewAllLink}>
            <Button 
              variant="outline" 
              className="border-slate-300 text-slate-700 hover:bg-slate-50 
                dark:border-slate-600 dark:text-slate-300 dark:hover:bg-slate-900/30 
                font-medium transition-all"
            >
              View All Premium Listings
              <StarIcon className="ml-2 h-4 w-4" />
            </Button>
          </Link>
        )}
      </div>
      
      <Carousel 
        className="w-full"
        plugins={[autoplayPlugin.current]}
        opts={{
          align: "start",
          loop: true
        }}
      >
        <CarouselContent className="-ml-4">
          {limitedVehicles.map((vehicle) => (
            <CarouselItem 
              key={vehicle.id} 
              className="pl-4 basis-full sm:basis-1/2 md:basis-1/3 lg:basis-1/4"
            >
              <div className="transform transition-all duration-300 hover:-translate-y-1 hover:shadow-md h-full">
                <VehicleCard vehicle={vehicle} compact={true} />
              </div>
            </CarouselItem>
          ))}
        </CarouselContent>
        <div className="flex justify-end gap-2 mt-4">
          <CarouselPrevious className="static h-8 w-8 rounded-full translate-y-0 bg-slate-100 border-slate-200 hover:bg-slate-200 text-slate-700" />
          <CarouselNext className="static h-8 w-8 rounded-full translate-y-0 bg-slate-100 border-slate-200 hover:bg-slate-200 text-slate-700" />
        </div>
      </Carousel>
    </div>
  );
};

export default FeaturedVehiclesSection;
