
import { useState, useEffect } from "react";
import VehicleContentLayout from "./VehicleContentLayout";
import { VehicleData } from "@/components/VehicleCard";
import { prepareVehicleImages } from "@/utils/vehicleUtils";

interface VehicleContentProps {
  vehicle: VehicleData;
  sellerDetails: {
    name: string;
    initials: string;
    phone: string;
    location: string;
    isVerified: boolean;
    logoUrl?: string;
    id?: string;
  };
  onImageUpdate?: () => void;
}

const VehicleContent = ({ vehicle, sellerDetails, onImageUpdate }: VehicleContentProps) => {
  const [vehicleImages, setVehicleImages] = useState<string[]>([]);
  
  useEffect(() => {
    if (vehicle) {
      // Process vehicle images
      const images = prepareVehicleImages(vehicle);
      setVehicleImages(images);
    }
  }, [vehicle]);
  
  if (!vehicle) {
    return <div>Vehicle information not available</div>;
  }
  
  return (
    <VehicleContentLayout 
      vehicle={vehicle}
      vehicleImages={vehicleImages}
      sellerDetails={sellerDetails}
      onImageUpdate={onImageUpdate}
    />
  );
};

export default VehicleContent;
