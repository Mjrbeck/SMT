
import React from 'react';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";

interface VehicleListingsHeaderProps {
  vehicleCount: number;
  sortBy: string;
  setSortBy: (value: string) => void;
}

const VehicleListingsHeader: React.FC<VehicleListingsHeaderProps> = ({
  vehicleCount,
  sortBy,
  setSortBy
}) => {
  return (
    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-4 gap-4">
      <h2 className="text-xl font-semibold">
        {vehicleCount} {vehicleCount === 1 ? 'vehicle' : 'vehicles'} found
      </h2>
      
      <div className="flex items-center gap-2">
        <span className="text-sm text-gray-500">Sort by:</span>
        <Select value={sortBy} onValueChange={setSortBy}>
          <SelectTrigger className="w-[150px]">
            <SelectValue placeholder="Sort by" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="newest">Newest First</SelectItem>
            <SelectItem value="oldest">Oldest First</SelectItem>
            <SelectItem value="price-asc">Price: Low to High</SelectItem>
            <SelectItem value="price-desc">Price: High to Low</SelectItem>
            <SelectItem value="mileage-asc">Mileage: Low to High</SelectItem>
          </SelectContent>
        </Select>
      </div>
    </div>
  );
};

export default VehicleListingsHeader;
