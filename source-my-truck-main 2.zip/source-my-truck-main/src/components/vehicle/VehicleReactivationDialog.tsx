
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";

interface VehicleReactivationDialogProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  onReactivate: () => void;
}

const VehicleReactivationDialog = ({
  isOpen,
  onOpenChange,
  onReactivate
}: VehicleReactivationDialogProps) => {
  return (
    <AlertDialog open={isOpen} onOpenChange={onOpenChange}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Reactivate Vehicle Listing</AlertDialogTitle>
          <AlertDialogDescription>
            This will reactivate your vehicle listing for another 30 days. You will be charged 1 credit.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>Cancel</AlertDialogCancel>
          <AlertDialogAction onClick={onReactivate}>
            Reactivate
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
};

export default VehicleReactivationDialog;
