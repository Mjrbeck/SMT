
import { useState } from "react";
import { Trash, Power, Share2, Edit, Clock, Tag, Link, Facebook, Twitter, Mail, MessageSquare } from "lucide-react";
import { Button } from "@/components/ui/button";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { useVehicleManagement } from "@/hooks/useVehicleManagement";
import { toast } from "sonner";
import { VehicleData } from "@/components/VehicleCard";
import { Link as RouterLink, useNavigate } from "react-router-dom";
import { getVehicleImageData } from "@/utils/vehicleUtils";
import { prepareSocialSharingImage } from "@/utils/imageUtils";
import { WatchButton } from "@/components/watchlist/WatchButton";

interface VehicleActionsProps {
  vehicle: VehicleData;
  isOwner: boolean;
  isExpired: boolean;
  onNavigate: () => void;
}

const VehicleActions = ({ vehicle, isOwner, isExpired, onNavigate }: VehicleActionsProps) => {
  const navigate = useNavigate();
  const [isDeleting, setIsDeleting] = useState(false);
  const { deleteVehicle, changeVehicleStatus } = useVehicleManagement({
    redirectPath: "/inventory",
  });

  // Get the primary image URL for sharing using the utility function
  const getShareImageUrl = () => {
    const { mainImage } = getVehicleImageData(vehicle);
    
    // Ensure we never use lovable images by checking the URL
    if (!mainImage || mainImage.includes('lovable-uploads')) {
      const baseUrl = typeof window !== 'undefined' ? window.location.origin : '';
      return `${baseUrl}/source-my-truck-logo.png`;
    }
    
    // Make sure we return an absolute URL properly formatted for sharing
    const shareUrl = prepareSocialSharingImage(mainImage);
    
    // Log the final sharing URL for troubleshooting
    if (process.env.NODE_ENV === 'development') {
      console.log("Sharing vehicle image URL:", shareUrl);
    }
    return shareUrl;
  };

  // Function to handle sharing the vehicle listing
  const handleShare = async (platform: 'copy' | 'facebook' | 'twitter' | 'whatsapp' | 'email') => {
    // Build the absolute URL for the vehicle
    const vehicleUrl = `${window.location.origin}/vehicle/${vehicle.id}`;
    const title = `Check out this ${vehicle.year} ${vehicle.make} ${vehicle.model || ''}`;
    const message = `${title} at ${vehicleUrl}`;
    
    // Get the image URL for sharing - this should be a fully qualified URL
    const shareImageUrl = getShareImageUrl();
    
    // Log the share action with the image URL being used
    if (process.env.NODE_ENV === 'development') {
      console.log(`Sharing vehicle ${vehicle.id} via ${platform}`, { 
        vehicleUrl, 
        shareImageUrl,
        title
      });
    }
    
    switch (platform) {
      case 'copy':
        try {
          await navigator.clipboard.writeText(vehicleUrl);
          toast.success("Link copied to clipboard");
        } catch (error) {
          console.error("Failed to copy URL:", error);
          toast.error("Failed to copy URL to clipboard");
        }
        break;
      case 'facebook':
        // Use u parameter for the page URL - Facebook will get image from og:tags
        const fbUrl = new URL('https://www.facebook.com/sharer/sharer.php');
        fbUrl.searchParams.append('u', vehicleUrl);
        window.open(fbUrl.toString(), '_blank', 'width=600,height=400');
        break;
      case 'twitter':
        const twitterUrl = new URL('https://twitter.com/intent/tweet');
        twitterUrl.searchParams.append('text', title);
        twitterUrl.searchParams.append('url', vehicleUrl);
        window.open(twitterUrl.toString(), '_blank');
        break;
      case 'whatsapp':
        window.open(`https://wa.me/?text=${encodeURIComponent(message)}`, '_blank');
        break;
      case 'email':
        window.open(`mailto:?subject=${encodeURIComponent(title)}&body=${encodeURIComponent(message)}`, '_blank');
        break;
    }
  };

  const handleStatusChange = (status: string) => {
    console.log(`Changing vehicle status to: ${status}`);
    changeVehicleStatus(vehicle.id, status);
  };

  const handleDeleteVehicle = async () => {
    if (isDeleting) return; // Prevent multiple clicks
    
    setIsDeleting(true);
    try {
      // First, call the onNavigate callback to inform parent components
      if (onNavigate) {
        onNavigate();
      }
      
      await deleteVehicle(vehicle.id);
      toast.success("Vehicle deleted successfully");
      
      // Then navigate to inventory page after a brief delay to allow state updates
      setTimeout(() => {
        navigate("/inventory");
      }, 200);
    } catch (error) {
      console.error("Error deleting vehicle:", error);
      toast.error("Failed to delete vehicle");
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <div className="flex justify-end mb-3 gap-2 flex-wrap">
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" size="sm">
            <Share2 className="mr-2 h-4 w-4" />
            Share
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent>
          <DropdownMenuItem onClick={() => handleShare('copy')}>
            <Link className="mr-2 h-4 w-4" /> Copy Link
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => handleShare('facebook')}>
            <Facebook className="mr-2 h-4 w-4" /> Share on Facebook
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => handleShare('twitter')}>
            <Twitter className="mr-2 h-4 w-4" /> Share on Twitter
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => handleShare('whatsapp')}>
            <MessageSquare className="mr-2 h-4 w-4" /> Share on WhatsApp
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => handleShare('email')}>
            <Mail className="mr-2 h-4 w-4" /> Share via Email
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
      
      {/* Watch Button - available to all users */}
      <WatchButton 
        vehicleId={vehicle.id}
        vehicleTitle={vehicle.title}
        variant="outline"
        size="sm"
      />
      
      {isOwner && (
        <>
          <RouterLink to={`/edit-listing/${vehicle.id}`}>
            <Button variant="outline" size="sm">
              <Edit className="mr-2 h-4 w-4" /> Edit Listing
            </Button>
          </RouterLink>
          
          {/* Status change dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button 
                variant="outline" 
                size="sm"
                disabled={isExpired}
              >
                <Power className="mr-2 h-4 w-4" />
                Change Status
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
              {vehicle.status !== "active" && (
                <DropdownMenuItem onClick={() => handleStatusChange("active")}>
                  <Power className="mr-2 h-4 w-4" /> Activate Listing
                </DropdownMenuItem>
              )}
              
              {vehicle.status !== "draft" && (
                <DropdownMenuItem onClick={() => handleStatusChange("draft")}>
                  <Power className="mr-2 h-4 w-4" /> Deactivate Listing
                </DropdownMenuItem>
              )}
              
              {vehicle.status !== "sale_in_progress" && (
                <DropdownMenuItem onClick={() => handleStatusChange("sale_in_progress")}>
                  <Clock className="mr-2 h-4 w-4" /> Mark as Sale in Progress
                </DropdownMenuItem>
              )}
              
              {vehicle.status !== "sold" && (
                <DropdownMenuItem onClick={() => handleStatusChange("sold")}>
                  <Tag className="mr-2 h-4 w-4" /> Mark as Sold
                </DropdownMenuItem>
              )}
            </DropdownMenuContent>
          </DropdownMenu>
          
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="destructive" size="sm" disabled={isDeleting}>
                <Trash className="mr-2 h-4 w-4" />
                {isDeleting ? "Deleting..." : "Delete Vehicle"}
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                <AlertDialogDescription>
                  This action cannot be undone. This will permanently delete the vehicle
                  listing and all associated data.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={handleDeleteVehicle}>
                  Delete
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </>
      )}
    </div>
  );
};

export default VehicleActions;
