
import React, { useState, useEffect } from "react";
import { VehicleData } from "@/components/VehicleCard";
import { Package, Ruler, Info } from "lucide-react";

interface VehicleVisualizationProps {
  vehicle: VehicleData;
}

const VehicleVisualization: React.FC<VehicleVisualizationProps> = ({ vehicle }) => {
  const [isMounted, setIsMounted] = useState(false);
  
  useEffect(() => {
    setIsMounted(true);
  }, []);
  
  if (!isMounted) {
    return <div className="h-96 flex items-center justify-center bg-gray-50 rounded-lg">Loading visualization...</div>;
  }
  
  // Default values if not provided
  const length = vehicle.externalLength || 0; // Default length in meters
  const width = vehicle.externalWidth || 0; // Default width in meters
  const height = vehicle.externalHeight || 0; // Default height in meters
  const axles = parseAxleConfig(vehicle.axleConfiguration);
  const gvw = vehicle.grossVehicleWeight || 0; // Gross Vehicle Weight
  
  // Check if we have enough data to show the visualization
  const hasAxleData = axles.total > 0 || vehicle.axleConfiguration;
  const hasDimensionData = length > 0 || width > 0 || height > 0 || gvw > 0;
  
  return (
    <div className="flex flex-col space-y-6">
      {/* Removed the duplicate heading that was here */}
      
      {/* Vehicle dimensions overview - updated to show "Not specified" when missing */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <DimensionCard 
          title="Length" 
          value={vehicle.externalLength} 
          unit="m" 
          icon={<Ruler className="h-5 w-5" />} 
        />
        <DimensionCard 
          title="Width" 
          value={vehicle.externalWidth} 
          unit="m" 
          icon={<Ruler className="h-5 w-5 rotate-90" />} 
        />
        <DimensionCard 
          title="Height" 
          value={vehicle.externalHeight} 
          unit="m" 
          icon={<Package className="h-5 w-5" />} 
        />
      </div>
      
      <div className="bg-gray-50 p-6 rounded-lg border border-gray-200">
        <div className="text-center mb-4">
          {hasAxleData ? (
            <h4 className="text-base font-medium">{axles.total * 2} wheels / {axles.total} axles</h4>
          ) : (
            <h4 className="text-base font-medium text-gray-500">Axle configuration not specified</h4>
          )}
        </div>
        
        {hasDimensionData || hasAxleData ? (
          <div className="h-64 relative">
            <AxleConfigurationView 
              axles={axles}
              length={length}
              width={width}
              gvw={gvw}
            />
          </div>
        ) : (
          <div className="h-64 flex items-center justify-center text-gray-500">
            <p>Insufficient data to display vehicle dimensions</p>
          </div>
        )}
        
        <div className="text-sm text-gray-500 text-center mt-4">
          <p>Axle configuration diagram showing vehicle layout and wheel arrangement</p>
        </div>
      </div>
      
      <div className="bg-white p-4 rounded-lg border border-gray-200 shadow-sm">
        <h4 className="text-sm font-medium text-gray-600 mb-2">Vehicle Configuration</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <div className="flex items-center space-x-2">
              <div className="bg-gray-800 w-4 h-4 rounded-full"></div>
              <span className="text-sm">Standard Axle</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="bg-red-500 w-4 h-4 rounded-full"></div>
              <span className="text-sm">Driven Axle</span>
            </div>
          </div>
          <div>
            <p className="text-sm text-gray-600">
              <span className="font-medium">Configuration:</span> {vehicle.axleConfiguration || "Not specified"}
            </p>
            <p className="text-sm text-gray-600">
              <span className="font-medium">Total axles:</span> {hasAxleData ? axles.total : "Not specified"}
            </p>
            <p className="text-sm text-gray-600">
              <span className="font-medium">Driven axles:</span> {hasAxleData ? axles.driven : "Not specified"}
            </p>
            <p className="text-sm text-gray-600">
              <span className="font-medium">Total wheels:</span> {hasAxleData ? axles.total * 2 : "Not specified"}
            </p>
            {gvw > 0 ? (
              <p className="text-sm text-gray-600">
                <span className="font-medium">Max G.W.:</span> {gvw.toLocaleString()} kg
              </p>
            ) : (
              <p className="text-sm text-gray-600">
                <span className="font-medium">Max G.W.:</span> Not specified
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

const DimensionCard = ({ title, value, unit, icon }: { title: string, value?: number, unit: string, icon: React.ReactNode }) => (
  <div className="flex items-center p-4 bg-white border border-gray-200 rounded-lg">
    <div className="mr-3 text-gray-700">
      {icon}
    </div>
    <div>
      <div className="text-sm text-gray-600">{title}</div>
      <div className="font-medium">
        {value ? `${value} ${unit}` : "Not specified"}
      </div>
    </div>
  </div>
);

const calculateTotalWheels = (totalAxles: number): number => {
  return totalAxles * 2;
};

const parseAxleConfig = (config?: string): { total: number, driven: number } => {
  if (!config) return { total: 0, driven: 0 };
  
  const parts = config.toLowerCase().split('x');
  if (parts.length !== 2) return { total: 0, driven: 0 };
  
  const totalWheels = parseInt(parts[0], 10);
  const drivenWheels = parseInt(parts[1], 10);
  
  // Calculate the number of axles based on wheels
  const totalAxles = Math.ceil(totalWheels / 2);
  const drivenAxles = Math.ceil(drivenWheels / 2);
  
  return {
    total: isNaN(totalAxles) ? 0 : totalAxles,
    driven: isNaN(drivenAxles) ? 0 : drivenAxles
  };
};

const AxleConfigurationView = ({ 
  axles, 
  length,
  width,
  gvw 
}: { 
  axles: { total: number, driven: number },
  length: number,
  width: number,
  gvw: number
}) => {
  // Only show the visualization if we have some data
  const hasData = axles.total > 0 || length > 0 || width > 0 || gvw > 0;
  
  if (!hasData) {
    return (
      <div className="h-full w-full flex items-center justify-center text-gray-500">
        <p>No axle configuration data available</p>
      </div>
    );
  }
  
  return (
    <div className="h-full w-full relative">
      {/* Top view of vehicle */}
      <div className="w-full h-20 border-2 border-gray-700 rounded-lg mb-8">
        <div className="flex h-full">
          <div className="w-1/4 border-r-2 border-gray-700 flex items-center justify-center">
            <span className="text-xs font-bold uppercase">CAB</span>
          </div>
          <div className="w-3/4 flex items-center justify-center">
            <span className="text-xs font-bold uppercase">SEMI-TRAILER</span>
          </div>
        </div>
        
        {/* Wheels on top view */}
        <VehicleTopWheels axles={axles} />
      </div>
      
      {/* Axle view */}
      <div className="w-full h-32 relative">
        <AxleDiagram total={axles.total > 0 ? axles.total : 4} driven={axles.driven} />
      </div>
      
      {/* Length indicator */}
      <div className="w-full mt-4 flex justify-center items-center">
        <div className="relative w-full h-6">
          <div className="absolute left-0 right-0 top-0 h-[1px] bg-gray-400"></div>
          <div className="absolute left-0 h-2 w-[1px] bg-gray-500 -top-1"></div>
          <div className="absolute right-0 h-2 w-[1px] bg-gray-500 -top-1"></div>
          <div className="absolute left-1/2 -translate-x-1/2 -top-5 text-sm">
            {length > 0 ? `Length: ${length.toFixed(1)}m` : "Length: Not specified"}
          </div>
        </div>
      </div>
    </div>
  );
};

const VehicleTopWheels = ({ axles }: { axles: { total: number, driven: number } }) => {
  // If no axle data, show default 4 axle layout but with a faded appearance
  const hasAxleData = axles.total > 0;
  
  // Default to 4 axles if no data
  const totalAxles = hasAxleData ? axles.total : 4;
  
  // Generate wheel positions based on the number of axles
  const wheelPositions = [];
  
  // Use default 4 axle layout if no data
  if (!hasAxleData) {
    wheelPositions.push(
      // Front axle wheels (black)
      { left: "15%", top: "-2px", driven: false },
      { left: "15%", bottom: "-2px", driven: false },
      // Second axle wheels (black)
      { left: "30%", top: "-2px", driven: false },
      { left: "30%", bottom: "-2px", driven: false },
      // Third axle wheels (red - driven)
      { left: "65%", top: "-2px", driven: true },
      { left: "65%", bottom: "-2px", driven: true },
      // Fourth axle wheels (red - driven)
      { left: "80%", top: "-2px", driven: true },
      { left: "80%", bottom: "-2px", driven: true }
    );
  } else {
    // Calculate positions for dynamic number of axles
    for (let i = 0; i < totalAxles; i++) {
      // Distribute axles evenly across the length
      // First 40% for cab, rest 60% for trailer
      let position;
      const isDriven = i >= (totalAxles - axles.driven);
      
      if (i < 2) {
        // Cab axles (first 2 or fewer)
        position = 15 + (i * 15) + "%";
      } else {
        // Trailer axles
        const trailerAxleCount = totalAxles - 2;
        const trailerAxleIndex = i - 2;
        position = 60 + (trailerAxleIndex * (20 / Math.max(1, trailerAxleCount))) + "%";
      }
      
      wheelPositions.push(
        { left: position, top: "-2px", driven: isDriven },
        { left: position, bottom: "-2px", driven: isDriven }
      );
    }
  }
  
  return (
    <>
      {wheelPositions.map((pos, index) => (
        <div 
          key={`wheel-${index}`}
          className={`absolute w-2 h-2 rounded-full ${pos.driven ? 'bg-red-500' : 'bg-gray-800'} ${!hasAxleData ? 'opacity-50' : ''}`}
          style={{
            left: pos.left,
            top: pos.top,
            bottom: pos.bottom
          }}
        />
      ))}
    </>
  );
};

const AxleDiagram = ({ total, driven }: { total: number, driven: number }) => {
  // Use default 4 axles if total is not specified or is 0
  const displayTotal = total || 4;
  const hasAxleData = total > 0;
  
  // Calculate positions for the axles based on the total number
  const axlePositions = [];
  
  // For normal distribution of 4 default axles
  if (displayTotal === 4) {
    axlePositions.push(20, 40, 65, 85);
  } else {
    // Distribute axles evenly
    for (let i = 0; i < displayTotal; i++) {
      const position = 15 + ((i / (displayTotal - 1)) * 70);
      axlePositions.push(position);
    }
  }
  
  return (
    <div className="w-full h-full relative">
      {/* Main chassis line */}
      <div className="absolute left-[10%] right-[10%] top-1/2 h-[2px] bg-gray-800"></div>
      
      {axlePositions.map((position, index) => {
        // Determine if this axle is driven (for default 4 axles, last two are driven)
        // For custom axle count, the last N axles are driven where N is the driven count
        const isDriven = hasAxleData ? 
          (index >= displayTotal - driven) : 
          (index >= 2); // Default behavior for 4 axles
        
        const isSteeringAxle = index === 0; // First axle is steering
        
        return (
          <div 
            key={`axle-${index}`}
            className={`absolute w-[1px] h-full flex flex-col items-center justify-center ${!hasAxleData ? 'opacity-50' : ''}`}
            style={{ left: `${position}%` }}
          >
            <div className={`h-full w-[1px] ${isDriven ? 'bg-red-500' : 'bg-gray-800'}`}></div>
            
            {/* Top wheel */}
            <div 
              className={`absolute top-0 w-3 h-3 rounded-full border-2 ${isDriven ? 'border-red-500' : 'border-gray-800'} bg-white`}
            ></div>
            
            {/* Bottom wheel */}
            <div 
              className={`absolute bottom-0 w-3 h-3 rounded-full border-2 ${isDriven ? 'border-red-500' : 'border-gray-800'} bg-white`}
            ></div>
            
            {/* Steering axle indicators */}
            {isSteeringAxle && (
              <>
                <div className="absolute top-0 w-5 h-[1px] bg-gray-800 mt-1.5"></div>
                <div className="absolute bottom-0 w-5 h-[1px] bg-gray-800 mb-1.5"></div>
              </>
            )}
            
            {/* Double wheels for driven axles */}
            {isDriven && (
              <>
                <div className="absolute top-0 -right-2.5 w-3 h-3 rounded-full border-2 border-red-500 bg-white"></div>
                <div className="absolute bottom-0 -right-2.5 w-3 h-3 rounded-full border-2 border-red-500 bg-white"></div>
              </>
            )}
          </div>
        );
      })}
    </div>
  );
};

export default VehicleVisualization;
