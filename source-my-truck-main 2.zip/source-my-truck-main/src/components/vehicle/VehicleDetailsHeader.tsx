
import { format } from "date-fns";
import { Badge } from "@/components/ui/badge";
import { Verified, Clock, MapPin } from "lucide-react";
interface VehicleDetailsHeaderProps {
  title: string;
  location: string;
  logoUrl?: string;
  registration?: string;
  createdAt?: string | Date;
}
const VehicleDetailsHeader = ({
  title,
  location,
  logoUrl,
  registration,
  createdAt
}: VehicleDetailsHeaderProps) => {
  // Check if location is coordinate format (latitude,longitude)
  const isCoordinateFormat = location?.includes(',') && !isNaN(parseFloat(location.split(',')[0])) && !isNaN(parseFloat(location.split(',')[1]));

  // Don't display location at all if it's in coordinate format
  const displayLocation = isCoordinateFormat ? "" : location;
  return <div className="bg-white rounded-lg p-4 sm:p-6 shadow-sm border border-gray-100 mb-4 sm:mb-6 transform transition-all duration-300 hover:shadow-md">
      <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-4">
        <div className="space-y-2">
          <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-gray-800 leading-tight">
            {title}
          </h1>
          
          <div className="flex flex-wrap items-center gap-2 text-gray-600">
            {displayLocation && displayLocation}
            
            {registration && <Badge variant="outline" className="ml-0 sm:ml-2 bg-gray-50 text-gray-700 border-gray-200 py-1 px-2 text-xs sm:text-sm">
                Reg: {registration}
              </Badge>}
            
            {createdAt && <div className="flex items-center gap-1 ml-0 sm:ml-2 mt-1 sm:mt-0 w-full sm:w-auto">
                <Clock className="h-4 w-4 text-gray-500" />
                <span className="text-xs sm:text-sm text-gray-500">
                  Listed: {typeof createdAt === 'string' ? format(new Date(createdAt), 'dd MMM yyyy') : format(createdAt, 'dd MMM yyyy')}
                </span>
              </div>}
          </div>
        </div>
        
        {logoUrl && <div className="flex items-center">
            <div className="relative flex-shrink-0 w-12 h-12 sm:w-16 sm:h-16 rounded-full overflow-hidden border-2 border-gray-100">
              <img src={logoUrl} alt="Seller logo" className="w-full h-full object-contain bg-white p-1" onError={e => {
            e.currentTarget.style.display = 'none';
          }} />
            </div>
            <div className="ml-2 hidden md:block">
              <div className="flex items-center">
                <Verified className="h-4 w-4 text-brand-blue mr-1" />
                <span className="text-sm font-medium">Verified Seller</span>
              </div>
            </div>
          </div>}
      </div>
    </div>;
};
export default VehicleDetailsHeader;
