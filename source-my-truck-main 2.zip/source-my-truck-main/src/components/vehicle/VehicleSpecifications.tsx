
import { Fragment } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { VehicleData } from "@/components/VehicleCard";
import { cn } from "@/lib/utils";

interface VehicleSpecificationsProps {
  vehicle: VehicleData;
}

const VehicleSpecifications = ({ vehicle }: VehicleSpecificationsProps) => {
  // Better formatting for display values
  const formatValue = (value: any) => {
    // Check if the value is null, undefined, empty string, or "null" string (from DB)
    if (value === null || value === undefined || value === "" || value === "null" || (value === 0 && typeof value === 'number')) {
      return "Not specified";
    }
    return value;
  };

  // Safely format number values with toLocaleString
  const formatNumber = (value: number | undefined | null): string => {
    if (value === null || value === undefined || value === 0) {
      return "Not specified";
    }
    return value.toLocaleString();
  };

  // Add special formatting for mileage to ensure it's displayed with "miles"
  const formatMileage = (value: number | undefined | null): string => {
    if (value === null || value === undefined || value === 0) {
      return "Not specified";
    }
    return `${value.toLocaleString()} miles`;
  };

  // Group specifications for display
  const engineSpecs = [
    { label: "Engine Size", value: formatValue(vehicle.engineSize) },
    { label: "Engine Power", value: formatValue(vehicle.enginePower) },
    { label: "Fuel Type", value: formatValue(vehicle.fuelType) },
    { label: "Emissions Class", value: formatValue(vehicle.emissionsClass) },
    { label: "Transmission", value: formatValue(vehicle.transmission) }
  ];

  const basicSpecs = [
    { label: "Year", value: formatValue(vehicle.year) },
    { label: "Make", value: formatValue(vehicle.make) },
    { label: "Model", value: formatValue(vehicle.model) },
    { label: "Mileage", value: formatMileage(vehicle.mileage) },
    { label: "Registration", value: formatValue(vehicle.registration) },
    { label: "Color", value: formatValue(vehicle.color) },
    { label: "Condition", value: vehicle.isNew ? "New" : "Used" }
  ];

  const bodySpecs = [
    { label: "Body Type", value: formatValue(vehicle.bodyType) },
    { label: "Cab Type", value: formatValue(vehicle.cabType) },
    { label: "Axle Configuration", value: formatValue(vehicle.axleConfiguration) },
    { label: "Number of Seats", value: formatValue(vehicle.numberOfSeats) },
    { label: "Driver Position", value: formatValue(vehicle.driverPosition) }
  ];

  const dimensionsSpecs = [
    { label: "Gross Vehicle Weight", value: vehicle.grossVehicleWeight ? `${formatNumber(vehicle.grossVehicleWeight)} kg` : "Not specified" },
    { label: "Volume / Capacity", value: formatValue(vehicle.volume) },
    { label: "Internal Dimensions (L×W×H)", value: vehicle.internalLength || vehicle.internalWidth || vehicle.internalHeight ? 
      `${formatValue(vehicle.internalLength)} × ${formatValue(vehicle.internalWidth)} × ${formatValue(vehicle.internalHeight)} mm` : 
      "Not specified" },
    { label: "External Dimensions (L×W×H)", value: vehicle.externalLength || vehicle.externalWidth || vehicle.externalHeight ? 
      `${formatValue(vehicle.externalLength)} × ${formatValue(vehicle.externalWidth)} × ${formatValue(vehicle.externalHeight)} mm` : 
      "Not specified" }
  ];

  const conditionSpecs = [
    { label: "Interior Condition", value: formatValue(vehicle.interiorCondition) },
    { label: "Exterior Condition", value: formatValue(vehicle.exteriorCondition) }
  ];

  // Check if any field in a group has a value to determine if we should show the group
  const hasEngineData = engineSpecs.some(spec => spec.value !== "Not specified");
  const hasBodyData = bodySpecs.some(spec => spec.value !== "Not specified");
  const hasDimensionsData = dimensionsSpecs.some(spec => spec.value !== "Not specified");
  const hasConditionData = conditionSpecs.some(spec => spec.value !== "Not specified");

  const renderSpecGroup = (specs: { label: string; value: string }[], title: string) => (
    <div className="space-y-3">
      <h3 className="font-medium text-sm text-gray-700 uppercase">{title}</h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {specs.map((spec, index) => (
          <div 
            key={index} 
            className={cn(
              "bg-gradient-to-r p-3 rounded-md shadow-sm border border-gray-100",
              title === "Basic Information" && "from-blue-50 to-blue-50/50",
              title === "Engine & Performance" && "from-orange-50 to-orange-50/50",
              title === "Body & Configuration" && "from-green-50 to-green-50/50",
              title === "Dimensions & Capacity" && "from-purple-50 to-purple-50/50",
              title === "Condition" && "from-red-50 to-red-50/50"
            )}
          >
            <p className="text-xs text-gray-500 mb-1">{spec.label}</p>
            <p className="font-semibold text-gray-800">{spec.value}</p>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <Card className="border shadow-sm overflow-hidden">
      <CardContent className="space-y-6 p-6">
        {/* Always show basic info */}
        {renderSpecGroup(basicSpecs, "Basic Information")}
        
        {/* Only show sections with data */}
        {hasEngineData && (
          <>
            <Separator className="my-4" />
            {renderSpecGroup(engineSpecs, "Engine & Performance")}
          </>
        )}
        
        {hasBodyData && (
          <>
            <Separator className="my-4" />
            {renderSpecGroup(bodySpecs, "Body & Configuration")}
          </>
        )}
        
        {hasDimensionsData && (
          <>
            <Separator className="my-4" />
            {renderSpecGroup(dimensionsSpecs, "Dimensions & Capacity")}
          </>
        )}
        
        {hasConditionData && (
          <>
            <Separator className="my-4" />
            {renderSpecGroup(conditionSpecs, "Condition")}
          </>
        )}
      </CardContent>
    </Card>
  );
};

export default VehicleSpecifications;
