
import { Link } from "react-router-dom";
import { 
  Breadcrumb,
  BreadcrumbList,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbSeparator,
  BreadcrumbPage
} from "@/components/ui/breadcrumb";
import { Home, Truck } from "lucide-react";

interface VehicleBreadcrumbsProps {
  make?: string;
  model?: string;
  title: string;
}

const VehicleBreadcrumbs = ({ make, model, title }: VehicleBreadcrumbsProps) => {
  return (
    <Breadcrumb className="mb-6">
      <BreadcrumbList>
        <BreadcrumbItem>
          <BreadcrumbLink asChild>
            <Link to="/" className="flex items-center text-gray-500 hover:text-brand-blue">
              <Home className="h-4 w-4 mr-1" />
              <span className="hidden sm:inline">Home</span>
            </Link>
          </BreadcrumbLink>
        </BreadcrumbItem>
        
        <BreadcrumbSeparator />
        
        <BreadcrumbItem>
          <BreadcrumbLink asChild>
            <Link to="/listings" className="flex items-center text-gray-500 hover:text-brand-blue">
              <Truck className="h-4 w-4 mr-1" />
              <span>Vehicles</span>
            </Link>
          </BreadcrumbLink>
        </BreadcrumbItem>
        
        {make && (
          <>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbLink asChild>
                <Link 
                  to={`/listings?make=${encodeURIComponent(make)}`} 
                  className="text-gray-500 hover:text-brand-blue"
                >
                  {make}
                </Link>
              </BreadcrumbLink>
            </BreadcrumbItem>
          </>
        )}
        
        {model && (
          <>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbLink asChild>
                <Link 
                  to={`/listings?make=${encodeURIComponent(make || '')}&model=${encodeURIComponent(model)}`}
                  className="text-gray-500 hover:text-brand-blue"
                >
                  {model}
                </Link>
              </BreadcrumbLink>
            </BreadcrumbItem>
          </>
        )}
        
        <BreadcrumbSeparator />
        
        <BreadcrumbItem>
          <BreadcrumbPage className="text-gray-900 font-medium truncate max-w-[200px] sm:max-w-xs">
            {title}
          </BreadcrumbPage>
        </BreadcrumbItem>
      </BreadcrumbList>
    </Breadcrumb>
  );
};

export default VehicleBreadcrumbs;
