
import { Badge } from "@/components/ui/badge";
import { formatPrice, formatPriceOrPOA } from "@/utils/formatters";

interface VehiclePriceCardProps {
  price: number;
  location?: string; // Make location optional
  id: string;
  bodyType?: string;
  isPOA?: boolean;
  registration?: string;
  mileage?: number; // Keep in the interface for backward compatibility
}

const VehiclePriceCard = ({ 
  price, 
  id, 
  bodyType, 
  isPOA = false
}: VehiclePriceCardProps) => {
  // Determine if this is actually a POA listing
  // Either explicitly marked as POA or price is 0/undefined
  const shouldShowPOA = isPOA || price === 0 || price === undefined;

  return (
    <div className="bg-white p-6 rounded-lg shadow-sm">
      <div className="flex justify-between items-center mb-4">
        <h3 className="font-semibold text-lg">Price</h3>
        {bodyType && (
          <Badge variant="outline">{bodyType}</Badge>
        )}
      </div>
      
      <div className="text-3xl font-bold text-brand-blue mb-4">
        {shouldShowPOA ? "POA" : formatPrice(price)}
      </div>
      
      <div className="text-sm text-gray-500">
        {!shouldShowPOA && <p>Price excludes VAT</p>}
      </div>
    </div>
  );
};

export default VehiclePriceCard;
