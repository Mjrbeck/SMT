
import { useState } from "react";
import { VehicleData } from "@/components/VehicleCard";
import FilterSidebar from "@/components/vehicle/FilterSidebar";
import ListingsSorter from "@/components/vehicle/ListingsSorter";
import { Separator } from "@/components/ui/separator";
import VehicleResultsGrid from "./VehicleResultsGrid";
import {
  Pagination,
  PaginationContent,
  PaginationEllipsis,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination";

interface VehicleListingsContainerProps {
  yearRange: [number, number];
  setYearRange: (range: [number, number]) => void;
  selectedMakes: string[];
  handleMakeChange: (make: string) => void;
  selectedBodyTypes: string[];
  handleBodyTypeChange: (bodyType: string) => void;
  availableMakes: string[];
  availableBodyTypes: string[];
  filteredVehicles: VehicleData[];
  sortBy: string;
  setSortBy: (sortBy: string) => void;
  isLoading: boolean;
  showDistance: boolean;
  trustedSellersOnly: boolean;
  setTrustedSellersOnly: (trusted: boolean) => void;
  depotVerifiedOnly: boolean;
  setDepotVerifiedOnly: (verified: boolean) => void;
}

const ITEMS_PER_PAGE = 12;

const VehicleListingsContainer = ({
  yearRange,
  setYearRange,
  selectedMakes,
  handleMakeChange,
  selectedBodyTypes,
  handleBodyTypeChange,
  availableMakes,
  availableBodyTypes,
  filteredVehicles,
  sortBy,
  setSortBy,
  isLoading,
  showDistance,
  trustedSellersOnly,
  setTrustedSellersOnly,
  depotVerifiedOnly,
  setDepotVerifiedOnly
}: VehicleListingsContainerProps) => {
  const [showFilters, setShowFilters] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  
  // Calculate pagination
  const totalPages = Math.ceil(filteredVehicles.length / ITEMS_PER_PAGE);
  const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
  const endIndex = startIndex + ITEMS_PER_PAGE;
  const currentVehicles = filteredVehicles.slice(startIndex, endIndex);
  
  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    // Scroll to top when changing pages
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };
  
  const renderPagination = () => {
    if (totalPages <= 1) return null;
    
    const pages = [];
    const maxPagesToShow = 5;
    let startPage = Math.max(1, currentPage - 2);
    let endPage = Math.min(totalPages, startPage + maxPagesToShow - 1);
    
    if (endPage - startPage + 1 < maxPagesToShow) {
      startPage = Math.max(1, endPage - maxPagesToShow + 1);
    }
    
    for (let i = startPage; i <= endPage; i++) {
      pages.push(i);
    }
    
    return (
      <Pagination className="my-8">
        <PaginationContent>
          {currentPage > 1 && (
            <PaginationItem>
              <PaginationPrevious 
                onClick={() => handlePageChange(currentPage - 1)} 
                href="#" 
              />
            </PaginationItem>
          )}
          
          {startPage > 1 && (
            <>
              <PaginationItem>
                <PaginationLink 
                  onClick={() => handlePageChange(1)} 
                  href="#"
                >
                  1
                </PaginationLink>
              </PaginationItem>
              {startPage > 2 && (
                <PaginationItem>
                  <PaginationEllipsis />
                </PaginationItem>
              )}
            </>
          )}
          
          {pages.map(page => (
            <PaginationItem key={page}>
              <PaginationLink 
                isActive={page === currentPage}
                onClick={() => handlePageChange(page)}
                href="#"
              >
                {page}
              </PaginationLink>
            </PaginationItem>
          ))}
          
          {endPage < totalPages && (
            <>
              {endPage < totalPages - 1 && (
                <PaginationItem>
                  <PaginationEllipsis />
                </PaginationItem>
              )}
              <PaginationItem>
                <PaginationLink 
                  onClick={() => handlePageChange(totalPages)} 
                  href="#"
                >
                  {totalPages}
                </PaginationLink>
              </PaginationItem>
            </>
          )}
          
          {currentPage < totalPages && (
            <PaginationItem>
              <PaginationNext 
                onClick={() => handlePageChange(currentPage + 1)} 
                href="#" 
              />
            </PaginationItem>
          )}
        </PaginationContent>
      </Pagination>
    );
  };
  
  return (
    <div className="flex flex-col lg:flex-row gap-4">
      <FilterSidebar
        yearRange={yearRange}
        setYearRange={setYearRange}
        selectedMakes={selectedMakes}
        handleMakeChange={handleMakeChange}
        selectedBodyTypes={selectedBodyTypes}
        handleBodyTypeChange={handleBodyTypeChange}
        availableMakes={availableMakes}
        availableBodyTypes={availableBodyTypes}
        showFilters={showFilters}
        setShowFilters={setShowFilters}
        trustedSellersOnly={trustedSellersOnly}
        setTrustedSellersOnly={setTrustedSellersOnly}
        depotVerifiedOnly={depotVerifiedOnly}
        setDepotVerifiedOnly={setDepotVerifiedOnly}
      />
      
      <div className="flex-1 min-w-0">
        <div className="mb-6 flex flex-col gap-2">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold">
              {filteredVehicles.length} {filteredVehicles.length === 1 ? 'result' : 'results'} found
            </h2>
            <ListingsSorter sortBy={sortBy} setSortBy={setSortBy} />
          </div>
          <Separator />
        </div>
        
        {/* All Vehicles Grid */}
        <div className="mt-6">
          <h2 className="text-xl font-semibold mb-4">All Vehicles</h2>
          <VehicleResultsGrid 
            vehicles={currentVehicles}
            showDistance={showDistance}
            columns={3}
          />
          
          {/* Pagination Controls */}
          {renderPagination()}
        </div>
        
        {filteredVehicles.length === 0 && (
          <div className="text-center py-12 bg-gray-50 rounded-lg">
            <p className="text-lg text-gray-500">No vehicles match your criteria</p>
            <p className="text-sm text-gray-400 mt-2">Try adjusting your filters</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default VehicleListingsContainer;
