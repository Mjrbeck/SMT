
import { cn } from "@/lib/utils";

interface ImageThumbnailsProps {
  images: string[];
  selectedIndex: number;
  onSelect: (index: number) => void;
  getImageUrl: (url: string, index: number) => string;
}

const ImageThumbnails = ({
  images,
  selectedIndex,
  onSelect,
  getImageUrl
}: ImageThumbnailsProps) => {
  // Handle case with no images
  if (!images || images.length <= 1) {
    return null;
  }
  
  return (
    <div className="grid grid-cols-4 sm:grid-cols-5 md:grid-cols-6 gap-2">
      {images.map((image, index) => (
        <button
          key={`thumb-${index}`}
          onClick={() => onSelect(index)}
          className={cn(
            "aspect-video rounded-md overflow-hidden border-2 transition-all",
            selectedIndex === index 
              ? "border-brand-blue ring-2 ring-brand-blue ring-offset-1" 
              : "border-transparent hover:border-gray-300"
          )}
          aria-label={`View image ${index + 1}`}
        >
          <img
            src={getImageUrl(image, index + 1)}
            alt={`Thumbnail ${index + 1}`}
            className="w-full h-full object-cover"
            loading="lazy"
          />
        </button>
      ))}
    </div>
  );
};

export default ImageThumbnails;
