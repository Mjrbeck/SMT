
import { VehicleData } from "@/components/VehicleCard";
import VehiclePriceCard from "./VehiclePriceCard";
import ContactSellerCard from "./ContactSellerCard";
import { memo } from "react";

interface VehicleDetailsSidebarProps {
  vehicle: VehicleData;
  sellerDetails: {
    name: string;
    initials: string;
    phone: string;
    location: string;
    isVerified: boolean;
    logoUrl?: string;
    id?: string;
  };
}

const VehicleDetailsSidebar = memo(({ 
  vehicle,
  sellerDetails 
}: VehicleDetailsSidebarProps) => {
  // Check if the price is 0 or if isPOA is true
  const isPOA = vehicle.isPOA || vehicle.price === 0;

  // Create display title with make and model
  const vehicleTitle = vehicle.title || `${vehicle.year} ${vehicle.make} ${vehicle.model || ''}`.trim();

  return (
    <div className="lg:col-span-1 space-y-6">
      <VehiclePriceCard 
        price={vehicle.price} 
        id={vehicle.id} 
        bodyType={vehicle.bodyType}
        isPOA={isPOA}
        mileage={vehicle.mileage}
      />
      <ContactSellerCard 
        sellerName={sellerDetails.name}
        sellerInitials={sellerDetails.initials}
        sellerPhone={sellerDetails.phone}
        isVerified={sellerDetails.isVerified}
        logoUrl={sellerDetails.logoUrl}
        location={sellerDetails.location}
        vehicleTitle={vehicleTitle}
        sellerId={sellerDetails.id}
        vehicleId={vehicle.id}
      />
    </div>
  );
});

VehicleDetailsSidebar.displayName = "VehicleDetailsSidebar";

export default VehicleDetailsSidebar;
