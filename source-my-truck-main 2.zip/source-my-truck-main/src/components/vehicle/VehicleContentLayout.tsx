
import { memo, useEffect, useState } from "react";
import VehicleImageGallery from "./VehicleImageGallery";
import VehicleTabs from "./VehicleTabs";
import VehicleDetailsSidebar from "./VehicleDetailsSidebar";
import { VehicleData } from "@/components/VehicleCard";
import { AlignLeft, Youtube } from "lucide-react";
import { useIsMobile } from "@/hooks/use-mobile";
import YouTubeEmbed from "./YouTubeEmbed";

interface VehicleContentLayoutProps {
  vehicle: VehicleData;
  vehicleImages: any[];
  sellerDetails: {
    name: string;
    initials: string;
    phone: string;
    location: string;
    isVerified: boolean;
    logoUrl?: string;
    id?: string;
  };
  onImageUpdate?: () => void;
}

const VehicleContentLayout = memo(({ 
  vehicle, 
  vehicleImages, 
  sellerDetails,
  onImageUpdate 
}: VehicleContentLayoutProps) => {
  const isMobile = useIsMobile();
  const [hasYoutubeUrl, setHasYoutubeUrl] = useState(false);
  
  useEffect(() => {
    // Check if the YouTube URL exists and is valid
    const isValid = 
      typeof vehicle.youtubeUrl === 'string' && 
      vehicle.youtubeUrl.trim() !== '' && 
      vehicle.youtubeUrl !== 'undefined' &&
      vehicle.youtubeUrl !== 'null';
    
    setHasYoutubeUrl(isValid);
  }, [vehicle.id, vehicle.youtubeUrl]);
  
  return (
    <div className="mt-4 sm:mt-6">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 lg:gap-8">
        <div className="lg:col-span-2">
          <VehicleImageGallery 
            images={vehicleImages} 
            title={vehicle.title} 
            vehicleId={vehicle.id}
            onImageUpdate={onImageUpdate}
          />
          
          {/* YouTube Video Section (if available) */}
          {hasYoutubeUrl && (
            <div className="mt-4 sm:mt-8 p-4 sm:p-8 bg-white rounded-lg shadow-sm border border-gray-100 overflow-hidden">
              <h3 className="text-lg sm:text-xl font-semibold text-gray-800 mb-4 sm:mb-6 pb-2 sm:pb-4 border-b border-gray-200 flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center">
                  <Youtube className="h-4 w-4 text-brand-blue" />
                </div>
                Video Tour
              </h3>
              <YouTubeEmbed videoUrl={vehicle.youtubeUrl as string} title={`${vehicle.title} video tour`} />
            </div>
          )}
          
          {/* Vehicle Description Section */}
          <div className="mt-4 sm:mt-8 p-4 sm:p-8 bg-white rounded-lg shadow-sm border border-gray-100 overflow-hidden">
            <h3 className="text-lg sm:text-xl font-semibold text-gray-800 mb-4 sm:mb-6 pb-2 sm:pb-4 border-b border-gray-200 flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center">
                <AlignLeft className="h-4 w-4 text-brand-blue" />
              </div>
              Vehicle Description
            </h3>
            {vehicle.description ? (
              <p className="text-gray-700 whitespace-pre-line leading-relaxed break-words">
                {vehicle.description}
              </p>
            ) : (
              <div className="text-center p-4 sm:p-10 bg-gray-50 rounded-lg border border-gray-100">
                <p className="text-gray-500 font-medium mb-2">No description provided for this vehicle</p>
                <p className="text-gray-400 text-sm">Contact the seller for more information about this vehicle's features.</p>
              </div>
            )}
          </div>
          
          <VehicleTabs vehicle={vehicle} />
        </div>
        
        <div>
          <VehicleDetailsSidebar 
            vehicle={vehicle}
            sellerDetails={sellerDetails}
          />
        </div>
      </div>
    </div>
  );
});

VehicleContentLayout.displayName = "VehicleContentLayout";

export default VehicleContentLayout;
