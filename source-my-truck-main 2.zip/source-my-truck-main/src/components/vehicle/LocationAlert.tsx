
import React from 'react';
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertCircle } from "lucide-react";

interface LocationAlertProps {
  locationError: string | null;
  location: string | null;
  searchCoordinates: { lat: number, lng: number } | null;
  radius: number;
  filteredVehicleCount: number;
}

const LocationAlert: React.FC<LocationAlertProps> = ({
  locationError,
  location,
  searchCoordinates,
  radius,
  filteredVehicleCount
}) => {
  if (locationError) {
    return (
      <Alert variant="destructive" className="mb-4">
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>Location Search Error</AlertTitle>
        <AlertDescription>{locationError}</AlertDescription>
      </Alert>
    );
  }
  
  if (location && searchCoordinates) {
    return (
      <Alert className="mb-4">
        <AlertTitle>Location Search Active</AlertTitle>
        <AlertDescription>
          Showing vehicles within {radius} miles of {location}.
          {filteredVehicleCount === 0 && " No vehicles found in this area."}
        </AlertDescription>
      </Alert>
    );
  }
  
  return null;
};

export default LocationAlert;
