
import { AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { formatExpirationDate } from "@/utils/formatters";

interface VehicleExpirationBannerProps {
  isExpired: boolean;
  isOwner: boolean;
  onReactivate: () => void;
  expirationDate?: string;
}

const VehicleExpirationBanner = ({ 
  isExpired, 
  isOwner, 
  onReactivate,
  expirationDate
}: VehicleExpirationBannerProps) => {
  if (!isExpired || !isOwner) return null;
  
  return (
    <div className="mb-4 p-4 bg-amber-50 border border-amber-200 rounded-lg">
      <div className="flex items-start gap-3">
        <AlertCircle className="h-5 w-5 text-amber-500 mt-0.5 flex-shrink-0" />
        <div>
          <h3 className="font-semibold text-amber-800">Listing Expired</h3>
          <p className="text-sm text-amber-700 mb-2">
            {expirationDate ? 
              `This vehicle listing expired on ${new Date(expirationDate).toLocaleDateString()}.` : 
              'This vehicle listing has expired.'} Reactivate it for another 30 days using 1 credit.
          </p>
          <Button
            variant="outline"
            size="sm"
            className="border-amber-300 bg-amber-100 hover:bg-amber-200 text-amber-800"
            onClick={onReactivate}
          >
            Reactivate Listing
          </Button>
        </div>
      </div>
    </div>
  );
};

export default VehicleExpirationBanner;
