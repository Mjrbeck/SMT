
import React from "react";

export function VehicleImagesSkeleton() {
  return (
    <div className="space-y-4">
      <div className="aspect-video bg-gray-100 rounded-lg overflow-hidden animate-pulse" />
      <div className="grid grid-cols-4 gap-4">
        {[0, 1, 2, 3].map((_, index) => (
          <div key={index} className="aspect-video bg-gray-100 rounded-lg overflow-hidden animate-pulse" />
        ))}
      </div>
    </div>
  );
}
