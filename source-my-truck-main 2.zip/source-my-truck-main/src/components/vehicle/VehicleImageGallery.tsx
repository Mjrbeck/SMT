
import React, { useState, useCallback, memo, useEffect } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { MainImageDisplay } from "./MainImageDisplay";
import ImageEnlargedDialog from "./ImageEnlargedDialog";
import ImageThumbnails from "./ImageThumbnails";
import { cn } from "@/lib/utils";
import { useIsMobile } from "@/hooks/use-mobile";
import { useAuth } from "@/contexts/AuthContext";

// Define the image type for better type safety
export interface ImageType {
  id?: string;
  url: string;
  isMain?: boolean;
  user_id?: string;
}

interface VehicleImageGalleryProps {
  images: string[] | ImageType[];
  title: string;
  vehicleId?: string;
  onImageUpdate?: () => void;
  className?: string;
}

const VehicleImageGallery = memo(({ 
  images, 
  title, 
  vehicleId,
  onImageUpdate,
  className 
}: VehicleImageGalleryProps) => {
  const { user } = useAuth();
  const isMobile = useIsMobile();
  
  // Convert string[] to ImageType[] if needed
  const [processedImages, setProcessedImages] = useState<ImageType[]>([]);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [enlargedDialogOpen, setEnlargedDialogOpen] = useState(false);
  const [mainImageError, setMainImageError] = useState(false);

  // Process the incoming images into a consistent format
  useEffect(() => {
    if (!images || images.length === 0) {
      setProcessedImages([{ url: "/placeholder.svg" }]);
      return;
    }
    
    // Convert all images to ImageType format
    const imagesArray: ImageType[] = images.map((img, index) => {
      if (typeof img === 'string') {
        return { 
          id: `img-${index}`, 
          url: img,
          isMain: index === 0
        };
      } else {
        return {
          id: img.id || `img-${index}`,
          url: img.url,
          isMain: img.isMain || index === 0,
          user_id: img.user_id
        };
      }
    });
    
    setProcessedImages(imagesArray);
  }, [images]);
  
  // Determine if the current user is the owner of this vehicle listing
  const isOwner = user && vehicleId && processedImages.length > 0 
    ? user.id === processedImages[0]?.user_id
    : false;
  
  // Format the image URL based on context
  const getImageUrl = useCallback((url: string, index: number) => {
    return url;
  }, []);
  
  const handleThumbnailClick = (index: number) => {
    setCurrentImageIndex(index);
  };
  
  const handleMainImageClick = () => {
    if (processedImages.length > 0) {
      setEnlargedDialogOpen(true);
    }
  };
  
  const handlePrevImage = () => {
    setCurrentImageIndex((prevIndex) => 
      prevIndex === 0 ? processedImages.length - 1 : prevIndex - 1
    );
  };
  
  const handleNextImage = () => {
    setCurrentImageIndex((prevIndex) => 
      prevIndex === processedImages.length - 1 ? 0 : prevIndex + 1
    );
  };
  
  const handleImageError = () => {
    setMainImageError(true);
  };
  
  // Determine if there are multiple images
  const hasMultipleImages = processedImages.length > 1;
  
  // Determine if we should show reduced motion
  const reducedMotion = false;
  
  // If no images, show a placeholder
  if (processedImages.length === 0) {
    return (
      <div className={cn("space-y-2", className)}>
        <MainImageDisplay 
          mainImage="/placeholder.svg"
          title={title}
          getImageUrl={getImageUrl}
          onError={() => {}}
        />
      </div>
    );
  }
  
  return (
    <div className={cn("space-y-2", className)}>
      {/* Main Image */}
      <div 
        className={cn(
          "relative cursor-pointer rounded-lg overflow-hidden",
          hasMultipleImages ? "group" : ""
        )}
        onClick={handleMainImageClick} 
        aria-label={`View enlarged image of ${title}`}
      >
        <MainImageDisplay 
          mainImage={processedImages[currentImageIndex]?.url || "/placeholder.svg"}
          title={title}
          getImageUrl={getImageUrl}
          onError={handleImageError}
        />
        
        {/* Prev/Next buttons for desktop */}
        {hasMultipleImages && !isMobile && (
          <>
            <Button
              variant="ghost"
              size="icon"
              onClick={(e) => {
                e.stopPropagation();
                handlePrevImage();
              }}
              className="absolute left-2 top-1/2 transform -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity bg-black/30 hover:bg-black/50 text-white"
              aria-label="Previous image"
            >
              <ChevronLeft />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={(e) => {
                e.stopPropagation();
                handleNextImage();
              }}
              className="absolute right-2 top-1/2 transform -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity bg-black/30 hover:bg-black/50 text-white"
              aria-label="Next image"
            >
              <ChevronRight />
            </Button>
          </>
        )}
      </div>
      
      {/* Thumbnails */}
      {hasMultipleImages && (
        <ImageThumbnails 
          images={processedImages.map(img => img.url)} 
          selectedIndex={currentImageIndex}
          onSelect={handleThumbnailClick}
          getImageUrl={getImageUrl}
        />
      )}
      
      {/* Enlarged Image Dialog */}
      <ImageEnlargedDialog
        isOpen={enlargedDialogOpen}
        onClose={() => setEnlargedDialogOpen(false)}
        currentImage={processedImages[currentImageIndex]?.url || ""}
        title={title}
        onNext={handleNextImage}
        onPrev={handlePrevImage}
        hasMultipleImages={hasMultipleImages}
        reducedMotion={reducedMotion}
      />
    </div>
  );
});

VehicleImageGallery.displayName = "VehicleImageGallery";

export default VehicleImageGallery;
