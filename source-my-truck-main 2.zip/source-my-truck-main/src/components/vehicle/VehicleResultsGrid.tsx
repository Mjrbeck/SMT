
import { memo } from "react";
import { VehicleData } from "@/components/VehicleCard";
import VehicleCard from "@/components/VehicleCard";

interface VehicleResultsGridProps {
  vehicles: VehicleData[];
  isLoading?: boolean;
  showDistance?: boolean;
  compact?: boolean;
  columns?: number;
}

const VehicleResultsGrid = ({
  vehicles,
  isLoading = false,
  showDistance = false,
  compact = false,
  columns = 3
}: VehicleResultsGridProps) => {
  if (vehicles.length === 0) {
    return null;
  }

  // Determine grid columns based on the columns prop
  const gridColumnsClass = 
    columns === 2 ? "grid-cols-1 sm:grid-cols-2" :
    columns === 4 ? "grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4" :
    "grid-cols-1 sm:grid-cols-2 lg:grid-cols-3"; // Default (3 columns)

  return (
    <div className={`grid ${gridColumnsClass} gap-4`}>
      {vehicles.map((vehicle) => (
        <VehicleCard
          key={vehicle.id}
          vehicle={vehicle}
          showDistance={showDistance}
          compact={compact}
        />
      ))}
    </div>
  );
};

export default memo(VehicleResultsGrid);
