
import React from 'react';
import { AlertTriangle } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Link } from 'react-router-dom';

interface VehicleDetailsErrorProps {
  message?: string;
}

const VehicleDetailsError: React.FC<VehicleDetailsErrorProps> = ({ 
  message = "We couldn't find the vehicle you're looking for"
}) => {
  return (
    <div className="container mx-auto px-4 py-16">
      <div className="flex flex-col items-center justify-center text-center">
        <AlertTriangle className="h-16 w-16 text-yellow-500 mb-4" />
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Vehicle Not Found</h1>
        <p className="text-gray-600 max-w-md mb-8">
          {message}
        </p>
        <div className="flex flex-col sm:flex-row gap-4">
          <Button asChild variant="default">
            <Link to="/listings">Browse All Vehicles</Link>
          </Button>
          <Button asChild variant="outline">
            <Link to="/">Return to Home</Link>
          </Button>
        </div>
      </div>
    </div>
  );
};

export default VehicleDetailsError;
