
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { AlertDialog, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";

interface InsufficientCreditsDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenChange?: (open: boolean) => void;  // Added this property
  requiredCredits: number;
  currentCredits: number;
  tierName: string;
}

const InsufficientCreditsDialog = ({
  isOpen,
  onClose,
  onOpenChange,
  requiredCredits,
  currentCredits,
  tierName
}: InsufficientCreditsDialogProps) => {
  return (
    <AlertDialog 
      open={isOpen} 
      onOpenChange={(open) => {
        // Use the provided onOpenChange if it exists, otherwise fall back to onClose
        if (onOpenChange) {
          onOpenChange(open);
        } else if (!open) {
          onClose();
        }
      }}
    >
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Insufficient Credits</AlertDialogTitle>
          <AlertDialogDescription>
            You need {requiredCredits} credits to create a {tierName} listing, but you only have {currentCredits} credits.
            Please purchase more credits to continue.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter className="flex flex-col sm:flex-row gap-2">
          <AlertDialogCancel onClick={onClose}>Close</AlertDialogCancel>
          <Button asChild>
            <Link to="/settings?tab=credits">Purchase Credits</Link>
          </Button>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
};

export default InsufficientCreditsDialog;
