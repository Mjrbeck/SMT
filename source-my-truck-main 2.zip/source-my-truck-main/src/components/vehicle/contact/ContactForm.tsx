
import { useState, useEffect } from "react";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { RequiredLabel } from "@/components/forms/RequiredLabel";
import { ContactFormData } from "@/services/messages/types";

interface ContactFormProps {
  sellerName: string;
  vehicleTitle: string;
  isAuthenticated: boolean;
  isSending: boolean;
  onSubmit: (formData: {
    subject: string;
    emailContent: string;
    name: string;
    email: string;
    phone: string;
  }) => void;
  onCancel: () => void;
}

const ContactForm = ({
  sellerName,
  vehicleTitle,
  isAuthenticated,
  isSending,
  onSubmit,
  onCancel
}: ContactFormProps) => {
  const [formData, setFormData] = useState<ContactFormData>({
    name: "",
    email: "",
    phone: "",
    subject: `Inquiry about ${vehicleTitle}`,
    message: ""
  });
  
  const [formErrors, setFormErrors] = useState({
    name: false,
    email: false,
    message: false
  });

  useEffect(() => {
    setFormData(prev => ({
      ...prev,
      subject: `Inquiry about ${vehicleTitle}`,
      message: `Hi ${sellerName},\n\nI'm interested in ${vehicleTitle} that you have listed on Source my Truck.\n\nPlease provide more information about this vehicle.\n\nThank you.`
    }));
  }, [sellerName, vehicleTitle]);

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    
    // Clear error when user types
    if (name in formErrors) {
      setFormErrors(prev => ({
        ...prev,
        [name]: false
      }));
    }
  };

  const validateForm = () => {
    const requiredFields = ['message'];
    
    // Add name and email validation for non-authenticated users
    if (!isAuthenticated) {
      requiredFields.push('name', 'email');
    }
    
    const errors = {
      name: !isAuthenticated && !formData.name.trim(),
      email: !isAuthenticated && !formData.email.trim(),
      message: !formData.message.trim()
    };
    
    setFormErrors(errors);
    
    return !Object.values(errors).some(hasError => hasError);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    
    onSubmit({
      subject: formData.subject,
      emailContent: formData.message,
      name: formData.name,
      email: formData.email,
      phone: formData.phone
    });
  };

  return (
    <form onSubmit={handleFormSubmit} className="space-y-4 mt-4">
      {/* Always show contact fields, but mark as required only for non-authenticated users */}
      <div className="space-y-2">
        {isAuthenticated ? (
          <Label htmlFor="name" className="text-sm font-medium">Your Name</Label>
        ) : (
          <RequiredLabel htmlFor="name">Your Name</RequiredLabel>
        )}
        <Input 
          id="name" 
          name="name"
          value={formData.name} 
          onChange={handleChange}
          placeholder="Enter your name"
          className={formErrors.name ? "border-red-500" : ""}
          required={!isAuthenticated}
        />
        {formErrors.name && (
          <p className="text-red-500 text-sm">Name is required</p>
        )}
      </div>

      <div className="space-y-2">
        {isAuthenticated ? (
          <Label htmlFor="email" className="text-sm font-medium">Your Email</Label>
        ) : (
          <RequiredLabel htmlFor="email">Your Email</RequiredLabel>
        )}
        <Input 
          id="email" 
          name="email"
          type="email"
          value={formData.email} 
          onChange={handleChange}
          placeholder="Enter your email"
          className={formErrors.email ? "border-red-500" : ""}
          required={!isAuthenticated}
        />
        {formErrors.email && (
          <p className="text-red-500 text-sm">Email is required</p>
        )}
      </div>

      <div className="space-y-2">
        <Label htmlFor="phone" className="text-sm font-medium">Your Phone Number</Label>
        <Input 
          id="phone" 
          name="phone"
          value={formData.phone} 
          onChange={handleChange}
          placeholder="Enter your phone number"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="subject" className="text-sm font-medium">Subject</Label>
        <Input 
          id="subject" 
          name="subject"
          value={formData.subject} 
          onChange={handleChange}
          placeholder="Enter subject"
          required
        />
      </div>
      
      <div className="space-y-2">
        <RequiredLabel htmlFor="message">Message</RequiredLabel>
        <Textarea 
          id="message" 
          name="message"
          value={formData.message} 
          onChange={handleChange}
          placeholder="Enter your message to the seller"
          rows={6}
          className={formErrors.message ? "border-red-500" : ""}
          required
        />
        {formErrors.message && (
          <p className="text-red-500 text-sm">Message is required</p>
        )}
      </div>
      
      <div className="flex justify-end gap-2 pt-2">
        <Button 
          type="button" 
          variant="outline" 
          onClick={onCancel}
        >
          Cancel
        </Button>
        <Button 
          type="submit" 
          className="bg-brand-blue hover:bg-brand-blue/90"
          disabled={isSending}
        >
          {isSending ? "Sending..." : "Send Message"}
        </Button>
      </div>
    </form>
  );
};

export default ContactForm;
