
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import ContactForm from "./ContactForm";
import AnonymousContactForm from "./AnonymousContactForm";
import { useAuth } from "@/contexts/AuthContext";
import { useState } from "react";
import { sendMessage } from "@/services/messages";
import { toast } from "sonner";

interface MessageDialogProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  sellerName: string;
  vehicleTitle: string;
  vehicleId: string;
  recipientId: string;
  registration?: string;
}

const MessageDialog = ({
  isOpen,
  onOpenChange,
  sellerName,
  vehicleTitle,
  vehicleId,
  recipientId,
  registration = "Unknown"
}: MessageDialogProps) => {
  const { user } = useAuth();
  const [isSending, setIsSending] = useState(false);

  const handleSubmit = async (formData: {
    subject: string;
    emailContent: string;
    name: string;
    email: string;
    phone: string;
  }) => {
    if (!user) return; // Only authenticated users can send internal messages
    
    setIsSending(true);
    try {
      const { success, error } = await sendMessage({
        recipient_id: recipientId,
        subject: formData.subject,
        content: formData.emailContent,
        vehicle_id: vehicleId
      });

      if (success) {
        toast.success("Message sent successfully!");
        onOpenChange(false);
      } else {
        toast.error(error || "Failed to send message");
      }
    } catch (error) {
      console.error("Error sending message:", error);
      toast.error("An unexpected error occurred");
    } finally {
      setIsSending(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Contact {sellerName}</DialogTitle>
        </DialogHeader>

        {user ? (
          <ContactForm
            sellerName={sellerName}
            vehicleTitle={vehicleTitle}
            isAuthenticated={!!user}
            isSending={isSending}
            onSubmit={handleSubmit}
            onCancel={() => onOpenChange(false)}
          />
        ) : (
          <AnonymousContactForm
            vehicleId={vehicleId}
            sellerId={recipientId}
            vehicleTitle={vehicleTitle}
            registration={registration}
            onClose={() => onOpenChange(false)}
          />
        )}
      </DialogContent>
    </Dialog>
  );
};

export default MessageDialog;
