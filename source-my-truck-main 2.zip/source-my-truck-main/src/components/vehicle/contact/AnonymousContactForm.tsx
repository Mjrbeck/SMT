
import { useState } from "react";
import { FormField } from "@/components/ui/form-field";
import { Button } from "@/components/ui/button";
import { sendMessage } from "@/services/messages";
import { toast } from "sonner";
import { Mail, Phone, User } from "lucide-react";

interface AnonymousContactFormProps {
  vehicleId: string;
  sellerId: string;
  vehicleTitle: string;
  registration: string;
  onClose?: () => void;
}

const AnonymousContactForm = ({ 
  vehicleId, 
  sellerId,
  vehicleTitle,
  registration,
  onClose 
}: AnonymousContactFormProps) => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: ""
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const { success, error } = await sendMessage({
        recipient_id: sellerId,
        subject: `Vehicle Enquiry: ${registration}`,
        content: `Enquiry for vehicle: ${vehicleTitle}\nRegistration: ${registration}`,
        vehicle_id: vehicleId,
        sender_name: formData.name,
        sender_email: formData.email,
        sender_phone: formData.phone
      });

      if (success) {
        toast.success("Your message has been sent successfully!");
        onClose?.();
      } else {
        toast.error(error || "Failed to send message");
      }
    } catch (error) {
      toast.error("Failed to send message");
      console.error("Error sending message:", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="relative">
        <FormField
          id="name"
          label="Your Name"
          required
          placeholder="Enter your full name"
          value={formData.name}
          onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
        />
        <div className="absolute left-3 bottom-3 text-muted-foreground">
          <User className="h-4 w-4" />
        </div>
        <div className="pl-8"></div>
      </div>

      <div className="relative">
        <FormField
          id="email"
          type="email"
          label="Email Address"
          required
          placeholder="Enter your email address"
          value={formData.email}
          onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
        />
        <div className="absolute left-3 bottom-3 text-muted-foreground">
          <Mail className="h-4 w-4" />
        </div>
        <div className="pl-8"></div>
      </div>

      <div className="relative">
        <FormField
          id="phone"
          type="tel"
          label="Phone Number"
          required
          placeholder="Enter your phone number"
          value={formData.phone}
          onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
        />
        <div className="absolute left-3 bottom-3 text-muted-foreground">
          <Phone className="h-4 w-4" />
        </div>
        <div className="pl-8"></div>
      </div>

      <Button 
        type="submit" 
        className="w-full" 
        disabled={isSubmitting}
      >
        {isSubmitting ? "Sending..." : "Send Message"}
      </Button>
    </form>
  );
};

export default AnonymousContactForm;
