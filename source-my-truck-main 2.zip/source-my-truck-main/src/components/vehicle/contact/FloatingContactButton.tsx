
import { useState, useEffect } from 'react';
import { Phone, MessageSquare, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import MessageDialog from './MessageDialog';
import { cn } from '@/lib/utils';

interface FloatingContactButtonProps {
  onClick: () => void;
}

const FloatingContactButton = ({ onClick }: FloatingContactButtonProps) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    // Show the button after scrolling down a bit
    const handleScroll = () => {
      const scrollPosition = window.scrollY;
      // Show button after scrolling down 300px
      setIsVisible(scrollPosition > 300);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  if (!isVisible) return null;

  return (
    <div 
      className={cn(
        "fixed bottom-6 right-6 z-40 flex flex-col items-end space-y-2",
        "transition-all duration-300 ease-in-out",
        !isExpanded && "items-end"
      )}
    >
      <Button
        onClick={onClick}
        className={cn(
          "rounded-full shadow-lg flex items-center justify-center h-16 w-16 transform hover:scale-105 transition-transform",
          "bg-gradient-to-r from-brand-blue to-brand-lightBlue hover:from-brand-lightBlue hover:to-brand-blue"
        )}
      >
        <div className="flex flex-col items-center">
          <Phone className="h-6 w-6" />
          <span className="text-[10px] mt-0.5">Contact</span>
        </div>
      </Button>
    </div>
  );
};

export default FloatingContactButton;
