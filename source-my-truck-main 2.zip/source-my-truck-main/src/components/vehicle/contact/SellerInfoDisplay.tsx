
import { Verified } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

interface SellerInfoDisplayProps {
  sellerName: string;
  sellerInitials: string;
  isVerified: boolean;
  logoUrl?: string;
  location?: string;
}

const SellerInfoDisplay = ({
  sellerName,
  sellerInitials,
  isVerified,
  logoUrl,
  location
}: SellerInfoDisplayProps) => {
  // Check if location is coordinate format (latitude,longitude)
  const isCoordinateFormat = location?.includes(',') && 
    !isNaN(parseFloat(location.split(',')[0])) && 
    !isNaN(parseFloat(location.split(',')[1]));
  
  // Don't display location at all if it's in coordinate format
  const displayLocation = isCoordinateFormat ? "" : location;

  return (
    <div className="flex items-center space-x-4">
      <Avatar className="h-14 w-14 border-2 border-gray-100">
        {logoUrl ? (
          <AvatarImage src={logoUrl} alt={sellerName} />
        ) : null}
        <AvatarFallback className="bg-indigo-100 text-indigo-800 text-lg font-semibold">
          {sellerInitials}
        </AvatarFallback>
      </Avatar>
      
      <div>
        <div className="flex items-center">
          <h3 className="font-semibold text-gray-800">{sellerName}</h3>
          {isVerified && (
            <Verified className="h-4 w-4 text-blue-600 ml-2" />
          )}
        </div>
        
        {displayLocation && (
          <p className="text-sm text-gray-500 mt-1">{displayLocation}</p>
        )}
      </div>
    </div>
  );
};

export default SellerInfoDisplay;
