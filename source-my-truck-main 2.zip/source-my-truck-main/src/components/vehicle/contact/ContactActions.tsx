
import { Button } from "@/components/ui/button";
import { Phone, Mail, Store, MessageSquare } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { Link } from "react-router-dom";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useQuery } from "@tanstack/react-query";
import { getSellerDepotById } from "@/services/sellers/sellerDepotService";

interface ContactActionsProps {
  sellerPhone: string;
  onEmailClick: () => void;
  sellerId?: string;
}

const ContactActions = ({
  sellerPhone,
  onEmailClick,
  sellerId
}: ContactActionsProps) => {
  const { isAuthenticated } = useAuth();
  const [themeColor, setThemeColor] = useState<string>("#0284c7");

  const { data: depotData } = useQuery({
    queryKey: ["sellerDepotContact", sellerId],
    queryFn: () => sellerId ? getSellerDepotById(sellerId) : null,
    enabled: !!sellerId,
    staleTime: 300000, // 5 minutes
  });
  
  // Set theme color when depot data is loaded
  useEffect(() => {
    if (depotData?.theme_color) {
      setThemeColor(depotData.theme_color);
    }
  }, [depotData]);

  // Determine if seller shop button should be shown
  const showSellerShop = depotData?.is_public && depotData?.custom_url_slug;

  return (
    <div className="space-y-4">
      <Button 
        variant="outline" 
        className="w-full flex items-center justify-center gap-2 text-gray-700 border-gray-300 hover:bg-gray-50 py-5"
      >
        <Phone className="text-indigo-600" size={18} />
        <span className="font-medium">{sellerPhone}</span>
      </Button>
      
      {isAuthenticated ? (
        <Button 
          onClick={onEmailClick} 
          className="w-full bg-indigo-600 hover:bg-indigo-700 flex items-center justify-center gap-2 shadow-sm py-5"
        >
          <MessageSquare size={18} />
          <span>Send Message</span>
        </Button>
      ) : (
        <Link to="/register" className="w-full">
          <Button 
            className="w-full bg-indigo-600 hover:bg-indigo-700 flex items-center justify-center gap-2 shadow-sm py-5"
          >
            <Mail size={18} />
            <span>Sign Up to Contact</span>
          </Button>
        </Link>
      )}
      
      {/* Only show seller depot button when seller has a valid URL slug */}
      {sellerId && showSellerShop && (
        <Link to={`/seller/${depotData?.custom_url_slug}`} className="w-full">
          <Button 
            variant="outline" 
            className="w-full flex items-center justify-center gap-2 shadow-sm transition-all hover:shadow-md border-indigo-200 text-indigo-700 hover:bg-indigo-50 py-5"
            style={{
              borderColor: `${themeColor}33`, // Add transparency
              color: themeColor
            }}
          >
            <Store size={18} />
            <span>Visit Seller Shop</span>
          </Button>
        </Link>
      )}
    </div>
  );
};

export default ContactActions;
