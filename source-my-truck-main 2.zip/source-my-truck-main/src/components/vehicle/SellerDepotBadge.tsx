
import { Link } from "react-router-dom";
import { Store } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { getSellerDepotById } from "@/services/sellers/sellerDepotService";

interface SellerDepotBadgeProps {
  sellerId: string;
}

const SellerDepotBadge = ({ sellerId }: SellerDepotBadgeProps) => {
  const { data: depot, isLoading, isError } = useQuery({
    queryKey: ["sellerDepot", sellerId],
    queryFn: () => getSellerDepotById(sellerId),
    enabled: !!sellerId,
    staleTime: 300000, // 5 minutes
    retry: 1, // Only retry once to avoid excessive API calls on error
  });
  
  if (isLoading || isError || !depot || !depot.is_public) {
    return null;
  }
  
  const slug = depot.custom_url_slug;
  if (!slug) {
    return null;
  }
  
  const themeColor = depot.theme_color || "#0284c7";
  
  return (
    <Link to={`/seller/${slug}`} className="w-full block">
      <Badge 
        variant="outline" 
        className="flex items-center gap-1 hover:bg-slate-100 transition-colors w-full justify-center py-2"
        style={{ 
          borderColor: themeColor,
          color: themeColor,
        }}
      >
        <Store className="h-3.5 w-3.5" />
        <span>Visit Seller Shop</span>
      </Badge>
    </Link>
  );
};

export default SellerDepotBadge;
