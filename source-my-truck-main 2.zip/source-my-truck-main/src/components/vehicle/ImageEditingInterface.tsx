
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ImageType } from "./VehicleImageGallery";

interface ImageEditingInterfaceProps {
  images: ImageType[];
  onSetMainImage: (image: ImageType) => void;
  onFinishEditing: () => void;
  isUpdatingMain: boolean;
  hasLoadingState: boolean;
}

const ImageEditingInterface = ({
  images,
  onSetMainImage,
  onFinishEditing,
  isUpdatingMain,
  hasLoadingState,
}: ImageEditingInterfaceProps) => {
  return (
    <div className="space-y-4">
      <Tabs defaultValue="reorder">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="reorder">Reorder Images</TabsTrigger>
          <TabsTrigger value="main">Set Main Image</TabsTrigger>
        </TabsList>
        
        <TabsContent value="reorder" className="pt-4">
          <div className="grid grid-cols-4 gap-2">
            {images.map((image, index) => (
              <div
                key={image.id}
                className={`aspect-video rounded-md overflow-hidden cursor-move border-2 ${
                  image.isMain ? "border-brand-blue" : "border-transparent"
                }`}
                data-image-id={image.id}
              >
                <img
                  src={image.url}
                  alt={`Image ${index + 1}`}
                  className="w-full h-full object-cover"
                />
              </div>
            ))}
          </div>
          <Button
            variant="outline"
            className="mt-4"
            onClick={onFinishEditing}
            disabled={hasLoadingState}
          >
            {hasLoadingState ? "Saving..." : "Done"}
          </Button>
        </TabsContent>
        
        <TabsContent value="main" className="pt-4">
          <div className="grid grid-cols-4 gap-2">
            {images.map((image, index) => (
              <div
                key={image.id}
                className={`aspect-video rounded-md overflow-hidden cursor-pointer border-2 ${
                  image.isMain ? "border-brand-blue" : "border-transparent"
                }`}
                onClick={() => !isUpdatingMain && onSetMainImage(image)}
              >
                <img
                  src={image.url}
                  alt={`Image ${index + 1}`}
                  className="w-full h-full object-cover"
                />
              </div>
            ))}
          </div>
          <Button
            variant="outline"
            className="mt-4"
            onClick={onFinishEditing}
            disabled={isUpdatingMain}
          >
            {isUpdatingMain ? "Updating..." : "Done"}
          </Button>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ImageEditingInterface;
