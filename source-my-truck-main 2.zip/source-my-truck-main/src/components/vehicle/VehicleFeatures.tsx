
import { Check, AlertTriangle } from "lucide-react";

interface VehicleFeaturesProps {
  features: string[];
}

const VehicleFeatures = ({ features }: VehicleFeaturesProps) => {
  // Normalize features array to handle nulls, empty arrays, and undefined
  const normalizedFeatures = Array.isArray(features) ? features.filter(Boolean) : [];
  
  return (
    <>
      {normalizedFeatures.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {normalizedFeatures.map((feature, index) => (
            <div 
              key={index} 
              className="flex items-center space-x-3 p-4 bg-white rounded-lg border border-gray-200 shadow-sm hover:shadow-md transition-shadow duration-200 transform hover:-translate-y-1 transition-transform"
            >
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-green-100 flex items-center justify-center">
                <Check className="h-4 w-4 text-green-600" />
              </div>
              <span className="text-gray-800 font-medium">{feature}</span>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center p-10 bg-gray-50 rounded-lg border border-gray-100">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gray-100 mb-4">
            <AlertTriangle className="h-8 w-8 text-gray-400" />
          </div>
          <p className="text-gray-500 font-medium mb-2">No features listed for this vehicle</p>
          <p className="text-gray-400 text-sm">Contact the seller for more information about this vehicle's features.</p>
        </div>
      )}
    </>
  );
};

export default VehicleFeatures;
