
import { useState, useCallback } from "react";
import { X, Plus, Check } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

interface FeaturesInputProps {
  features: string[];
  onChange: (features: string[]) => void;
}

const FeaturesInput = ({ features, onChange }: FeaturesInputProps) => {
  const [newFeature, setNewFeature] = useState("");
  
  const addFeature = useCallback(() => {
    if (newFeature.trim() && !features.includes(newFeature.trim())) {
      const updatedFeatures = [...features, newFeature.trim()];
      onChange(updatedFeatures);
      setNewFeature("");
    }
  }, [newFeature, features, onChange]);
  
  const removeFeature = useCallback((index: number) => {
    const updatedFeatures = [...features];
    updatedFeatures.splice(index, 1);
    onChange(updatedFeatures);
  }, [features, onChange]);
  
  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      addFeature();
    }
  }, [addFeature]);
  
  return (
    <div className="space-y-3">
      <div className="flex space-x-2">
        <div className="flex-1">
          <Input
            value={newFeature}
            onChange={(e) => setNewFeature(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="e.g. Air Conditioning, GPS, Cruise Control"
          />
        </div>
        <Button 
          type="button" 
          onClick={addFeature}
          variant="secondary"
          size="icon"
          className="h-10 w-10"
        >
          <Plus className="h-4 w-4" />
        </Button>
      </div>
      
      {features.length > 0 && (
        <div className="flex flex-wrap gap-2 mt-3">
          {features.map((feature, index) => (
            <Badge 
              key={index}
              variant="secondary"
              className="flex items-center gap-1 py-1 px-2"
            >
              <Check className="h-3 w-3 text-green-500" />
              <span>{feature}</span>
              <button
                type="button"
                onClick={() => removeFeature(index)}
                className="ml-1 rounded-full hover:bg-gray-200 p-0.5 focus:outline-none"
                aria-label={`Remove ${feature}`}
              >
                <X className="h-3 w-3" />
              </button>
            </Badge>
          ))}
        </div>
      )}
      
      <p className="text-xs text-muted-foreground mt-2">
        Add unique features of this vehicle. Press Enter or click the plus button to add.
      </p>
    </div>
  );
};

export default FeaturesInput;
