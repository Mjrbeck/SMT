
import React from "react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { X, ChevronLeft, ChevronRight } from "lucide-react";

interface ImageEnlargedDialogProps {
  isOpen: boolean;
  onClose: () => void;
  currentImage: string;
  title: string;
  onNext?: () => void;
  onPrev?: () => void;
  hasMultipleImages?: boolean;
  reducedMotion?: boolean;
}

const ImageEnlargedDialog = ({
  isOpen,
  onClose,
  currentImage,
  title,
  onNext,
  onPrev,
  hasMultipleImages = false,
  reducedMotion = false
}: ImageEnlargedDialogProps) => {
  // Create a class for animation conditionally based on reducedMotion
  const contentClassName = `max-w-6xl w-[95vw] h-[90vh] p-0 bg-brand-blue/95 border-none overflow-hidden ${
    reducedMotion ? "data-[state=open]:animate-none data-[state=closed]:animate-none" : ""
  }`;

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent
        className={contentClassName}
        onEscapeKeyDown={onClose}
      >
        <div className="relative h-full w-full flex items-center justify-center">
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            className="absolute top-4 right-4 z-50 bg-white/20 hover:bg-white/50 text-white rounded-full"
            aria-label="Close image viewer"
          >
            <X />
          </Button>
          
          {hasMultipleImages && onPrev && (
            <Button
              variant="ghost"
              size="icon"
              onClick={onPrev}
              className="absolute left-4 z-50 bg-white/20 hover:bg-white/50 text-white rounded-full h-12 w-12"
              aria-label="Previous image"
            >
              <ChevronLeft className="h-8 w-8" />
            </Button>
          )}
          
          {hasMultipleImages && onNext && (
            <Button
              variant="ghost"
              size="icon"
              onClick={onNext}
              className="absolute right-4 z-50 bg-white/20 hover:bg-white/50 text-white rounded-full h-12 w-12"
              aria-label="Next image"
            >
              <ChevronRight className="h-8 w-8" />
            </Button>
          )}
          
          <div className="h-full w-full flex items-center justify-center p-6 md:p-8">
            <img
              src={currentImage}
              alt={title}
              className="max-h-[calc(100%-3rem)] max-w-[calc(100%-3rem)] object-contain"
              loading="eager"
              fetchPriority="high"
              aria-label={`Enlarged view of ${title}`}
            />
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default ImageEnlargedDialog;
