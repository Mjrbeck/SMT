
import { VehicleData } from "@/components/VehicleCard";
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import VehicleSpecifications from "./VehicleSpecifications";
import VehicleFeatures from "./VehicleFeatures";
import VehicleVisualization from "./VehicleVisualization";
import { FileText, Settings, Package } from "lucide-react";
import { useIsMobile } from "@/hooks/use-mobile";

interface VehicleTabsProps {
  vehicle: VehicleData;
}

const VehicleTabs = ({ vehicle }: VehicleTabsProps) => {
  const isMobile = useIsMobile();
  
  // Ensure features is always an array even if it's null or undefined
  const features = Array.isArray(vehicle.features) ? vehicle.features : [];
  
  // Check if the vehicle has dimensions or axle configuration data to show visualization
  const hasVisualizationData = vehicle.axleConfiguration || 
    vehicle.externalLength || 
    vehicle.externalWidth || 
    vehicle.externalHeight || 
    vehicle.grossVehicleWeight;
  
  return (
    <div className="mt-8">
      <Tabs defaultValue="details" className="w-full">
        <TabsList className={`grid w-full ${hasVisualizationData ? 'grid-cols-3' : 'grid-cols-2'} mb-6 gap-1 p-1 bg-gray-50 rounded-lg border border-gray-200`}>
          <TabsTrigger 
            value="details" 
            className={`flex items-center ${isMobile ? 'gap-1 text-xs' : 'gap-2'} py-2 rounded-md transition-all`}
          >
            <div className={`${isMobile ? 'w-6 h-6' : 'w-8 h-8'} rounded-full bg-gray-100 flex items-center justify-center`}>
              <Settings className={`${isMobile ? 'h-3 w-3' : 'h-4 w-4'} text-brand-blue`} />
            </div>
            <span className={`font-medium ${isMobile ? 'text-xs' : 'text-base'}`}>
              {isMobile ? 'Details' : 'Technical Details'}
            </span>
          </TabsTrigger>
          
          {hasVisualizationData && (
            <TabsTrigger 
              value="visualization" 
              className={`flex items-center ${isMobile ? 'gap-1 text-xs' : 'gap-2'} py-2 rounded-md transition-all`}
            >
              <div className={`${isMobile ? 'w-6 h-6' : 'w-8 h-8'} rounded-full bg-gray-100 flex items-center justify-center`}>
                <Package className={`${isMobile ? 'h-3 w-3' : 'h-4 w-4'} text-brand-blue`} />
              </div>
              <span className={`font-medium ${isMobile ? 'text-xs' : 'text-base'}`}>
                {isMobile ? 'Dimensions' : 'Vehicle Dimensions'}
              </span>
            </TabsTrigger>
          )}
          
          <TabsTrigger 
            value="features" 
            className={`flex items-center ${isMobile ? 'gap-1 text-xs' : 'gap-2'} py-2 rounded-md transition-all`}
          >
            <div className={`${isMobile ? 'w-6 h-6' : 'w-8 h-8'} rounded-full bg-gray-100 flex items-center justify-center`}>
              <FileText className={`${isMobile ? 'h-3 w-3' : 'h-4 w-4'} text-brand-blue`} />
            </div>
            <span className={`font-medium ${isMobile ? 'text-xs truncate max-w-full' : 'text-base'}`}>
              {isMobile ? 'Features' : 'Features & Equipment'}
            </span>
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="details" className="p-4 sm:p-8 bg-white rounded-lg shadow-sm border border-gray-100">
          <h3 className="text-lg sm:text-xl font-semibold text-gray-800 mb-4 sm:mb-6 pb-2 sm:pb-4 border-b border-gray-200">
            Technical Specifications
          </h3>
          <VehicleSpecifications vehicle={vehicle} />
        </TabsContent>
        
        {hasVisualizationData && (
          <TabsContent value="visualization" className="p-4 sm:p-8 bg-white rounded-lg shadow-sm border border-gray-100">
            <h3 className="text-lg sm:text-xl font-semibold text-gray-800 mb-4 sm:mb-6 pb-2 sm:pb-4 border-b border-gray-200">
              Vehicle Dimensions
            </h3>
            <VehicleVisualization vehicle={vehicle} />
          </TabsContent>
        )}
        
        <TabsContent value="features" className="p-4 sm:p-8 bg-white rounded-lg shadow-sm border border-gray-100">
          <h3 className="text-lg sm:text-xl font-semibold text-gray-800 mb-4 sm:mb-6 pb-2 sm:pb-4 border-b border-gray-200">
            Vehicle Features
          </h3>
          <VehicleFeatures features={features} />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default VehicleTabs;
