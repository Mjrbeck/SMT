
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { capitalizeFirstLetter } from "@/utils/formatters";
import { useState, useEffect } from "react";

interface FilterSidebarProps {
  yearRange: [number, number];
  setYearRange: (range: [number, number]) => void;
  selectedMakes: string[];
  handleMakeChange: (make: string) => void;
  selectedBodyTypes: string[];
  handleBodyTypeChange: (bodyType: string) => void;
  availableMakes: string[];
  availableBodyTypes: string[];
  trustedSellersOnly: boolean;
  setTrustedSellersOnly: (trusted: boolean) => void;
  depotVerifiedOnly: boolean;
  setDepotVerifiedOnly: (verified: boolean) => void;
}

const VehicleFiltersSidebar = ({
  yearRange,
  setYearRange,
  selectedMakes,
  handleMakeChange,
  selectedBodyTypes,
  handleBodyTypeChange,
  availableMakes,
  availableBodyTypes,
  trustedSellersOnly,
  setTrustedSellersOnly,
  depotVerifiedOnly,
  setDepotVerifiedOnly
}: FilterSidebarProps) => {
  const currentYear = new Date().getFullYear();
  const minYear = 2000;
  
  // Generate an array of years for the dropdowns
  const years = Array.from(
    { length: (currentYear - minYear) + 1 }, 
    (_, i) => (minYear + i).toString()
  ).reverse(); // Most recent years first
  
  // Local state for year inputs
  const [fromYear, setFromYear] = useState(yearRange[0].toString());
  const [toYear, setToYear] = useState(yearRange[1].toString());
  
  // Update parent state when local state changes
  useEffect(() => {
    const from = parseInt(fromYear);
    const to = parseInt(toYear);
    if (from <= to) {
      setYearRange([from, to]);
    }
  }, [fromYear, toYear, setYearRange]);
  
  // Handle from year change
  const handleFromYearChange = (value: string) => {
    setFromYear(value);
  };
  
  // Handle to year change
  const handleToYearChange = (value: string) => {
    setToYear(value);
  };

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-semibold px-1 mb-1">Filters</h2>
      
      {/* Year Range Filter */}
      <Card className="shadow-sm border-gray-200">
        <CardHeader className="pb-2 pt-3">
          <CardTitle className="text-base font-medium">Year</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-1">
                <Label htmlFor="from-year" className="text-xs text-gray-600">From</Label>
                <Select
                  value={fromYear}
                  onValueChange={handleFromYearChange}
                >
                  <SelectTrigger id="from-year" className="h-8 text-sm">
                    <SelectValue placeholder="From" />
                  </SelectTrigger>
                  <SelectContent className="max-h-[300px]">
                    {years.map(year => (
                      <SelectItem key={`from-${year}`} value={year}>
                        {year}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1">
                <Label htmlFor="to-year" className="text-xs text-gray-600">To</Label>
                <Select
                  value={toYear}
                  onValueChange={handleToYearChange}
                >
                  <SelectTrigger id="to-year" className="h-8 text-sm">
                    <SelectValue placeholder="To" />
                  </SelectTrigger>
                  <SelectContent className="max-h-[300px]">
                    {years.map(year => (
                      <SelectItem key={`to-${year}`} value={year}>
                        {year}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
      
      {/* Make Filter */}
      <Card className="shadow-sm border-gray-200">
        <CardHeader className="pb-2 pt-3">
          <CardTitle className="text-base font-medium">Make</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-1 max-h-48 overflow-auto pr-1">
            {availableMakes.length > 0 ? (
              availableMakes.map((make) => (
                <div key={make} className="flex items-center space-x-2 py-1 px-1 hover:bg-gray-50 rounded-md">
                  <Checkbox 
                    id={`make-${make}`} 
                    checked={selectedMakes.includes(make)}
                    onCheckedChange={() => handleMakeChange(make)}
                    className="h-3.5 w-3.5"
                  />
                  <Label 
                    htmlFor={`make-${make}`}
                    className="text-xs capitalize cursor-pointer font-normal"
                  >
                    {capitalizeFirstLetter(make)}
                  </Label>
                </div>
              ))
            ) : (
              <p className="text-xs text-gray-500 py-1">No makes available</p>
            )}
          </div>
        </CardContent>
      </Card>
      
      {/* Body Type Filter */}
      <Card className="shadow-sm border-gray-200">
        <CardHeader className="pb-2 pt-3">
          <CardTitle className="text-base font-medium">Body Type</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-1 max-h-48 overflow-auto pr-1">
            {availableBodyTypes.length > 0 ? (
              availableBodyTypes.map((bodyType) => (
                <div key={bodyType} className="flex items-center space-x-2 py-1 px-1 hover:bg-gray-50 rounded-md">
                  <Checkbox 
                    id={`bodyType-${bodyType}`} 
                    checked={selectedBodyTypes.includes(bodyType)}
                    onCheckedChange={() => handleBodyTypeChange(bodyType)}
                    className="h-3.5 w-3.5"
                  />
                  <Label 
                    htmlFor={`bodyType-${bodyType}`}
                    className="text-xs capitalize cursor-pointer font-normal"
                  >
                    {bodyType ? capitalizeFirstLetter(bodyType) : "Unknown"}
                  </Label>
                </div>
              ))
            ) : (
              <p className="text-xs text-gray-500 py-1">No body types available</p>
            )}
          </div>
        </CardContent>
      </Card>
      
      {/* Seller Verification Filters */}
      <Card className="shadow-sm border-gray-200">
        <CardHeader className="pb-2 pt-3">
          <CardTitle className="text-base font-medium">Seller Verification</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center space-x-2 py-1 px-1 hover:bg-gray-50 rounded-md">
              <Checkbox 
                id="trusted-sellers" 
                checked={trustedSellersOnly}
                onCheckedChange={setTrustedSellersOnly}
                className="h-3.5 w-3.5"
              />
              <Label 
                htmlFor="trusted-sellers"
                className="text-xs cursor-pointer font-normal"
              >
                Trusted Sellers Only
              </Label>
            </div>
            <div className="flex items-center space-x-2 py-1 px-1 hover:bg-gray-50 rounded-md">
              <Checkbox 
                id="depot-verified" 
                checked={depotVerifiedOnly}
                onCheckedChange={setDepotVerifiedOnly}
                className="h-3.5 w-3.5"
              />
              <Label 
                htmlFor="depot-verified"
                className="text-xs cursor-pointer font-normal"
              >
                Depot Verified Only
              </Label>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default VehicleFiltersSidebar;
