
import { useSortable } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { GripVertical } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Trash } from "lucide-react";

interface DraggableImageProps {
  image: string;
  index: number;
  isMain: boolean;
  title: string;
  onError: () => void;
  onDelete?: () => void;
  getImageUrl: (url: string, index: number) => string;
  isDeleting?: boolean;
  isReadOnly?: boolean;
}

export function DraggableImage({
  image,
  index,
  isMain,
  title,
  onError,
  onDelete,
  getImageUrl,
  isDeleting,
  isReadOnly
}: DraggableImageProps) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging
  } = useSortable({ id: image });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      className={`aspect-video bg-gray-100 rounded-lg overflow-hidden relative group
        ${isMain ? 'ring-2 ring-brand-blue ring-offset-2' : ''}`}
    >
      <img
        src={getImageUrl(image, index)}
        alt={`${title} - View ${index + 1}`}
        className="w-full h-full object-cover"
        onError={onError}
        loading={isMain ? "eager" : "lazy"}
        fetchPriority={isMain ? "high" : "auto"}
        decoding={isMain ? "sync" : "async"}
      />
      
      {!isReadOnly && (
        <>
          <div
            {...attributes}
            {...listeners}
            className="absolute top-1 left-1 cursor-grab opacity-0 group-hover:opacity-100 transition-opacity"
            aria-label="Drag to reorder"
          >
            <GripVertical className="h-5 w-5 text-white drop-shadow-md" />
          </div>
          
          {onDelete && (
            <Button
              variant="destructive"
              size="icon"
              className="absolute top-1 right-1 h-7 w-7 opacity-0 group-hover:opacity-80 hover:opacity-100 transition-opacity"
              onClick={onDelete}
              disabled={isDeleting}
              aria-label="Delete image"
            >
              <Trash className="h-3 w-3" />
            </Button>
          )}
        </>
      )}
    </div>
  );
}
