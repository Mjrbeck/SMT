
import { Card, CardContent } from "@/components/ui/card";
import { useState, memo } from "react";
import ContactActions from "./contact/ContactActions";
import SellerInfoDisplay from "./contact/SellerInfoDisplay";
import MessageDialog from "./contact/MessageDialog";

interface ContactSellerCardProps {
  sellerName: string;
  sellerInitials: string;
  sellerPhone: string;
  isVerified: boolean;
  logoUrl?: string;
  location?: string;
  vehicleTitle: string;
  sellerId?: string;
  vehicleId: string;
  registration?: string;
}

const ContactSellerCard = memo(({
  sellerName,
  sellerInitials,
  sellerPhone,
  isVerified,
  logoUrl,
  location,
  vehicleTitle,
  sellerId,
  vehicleId,
  registration
}: ContactSellerCardProps) => {
  const [isMessageDialogOpen, setIsMessageDialogOpen] = useState(false);

  return (
    <Card className="border-2 border-gray-100 shadow-md overflow-hidden transform transition-all duration-300 hover:shadow-lg">
      <div className="bg-gradient-to-r from-indigo-700 via-indigo-600 to-purple-700 p-4 text-white">
        <h2 className="text-lg font-semibold text-center">Contact Seller</h2>
      </div>
      
      <CardContent className="p-5 pb-6">
        <SellerInfoDisplay
          sellerName={sellerName}
          sellerInitials={sellerInitials}
          isVerified={isVerified}
          logoUrl={logoUrl}
          location={location}
        />
        
        <div className="mt-6 pt-6 border-t border-gray-200">
          <ContactActions
            sellerPhone={sellerPhone}
            onEmailClick={() => setIsMessageDialogOpen(true)}
            sellerId={sellerId}
          />
        </div>
      </CardContent>
      
      <MessageDialog
        isOpen={isMessageDialogOpen}
        onOpenChange={setIsMessageDialogOpen}
        sellerName={sellerName}
        vehicleTitle={vehicleTitle}
        vehicleId={vehicleId}
        recipientId={sellerId || ""}
        registration={registration}
      />
    </Card>
  );
});

ContactSellerCard.displayName = "ContactSellerCard";

export default ContactSellerCard;
