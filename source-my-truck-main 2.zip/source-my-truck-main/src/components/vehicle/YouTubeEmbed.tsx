
import React, { useEffect, useState } from 'react';

interface YouTubeEmbedProps {
  videoUrl: string;
  title?: string;
}

const YouTubeEmbed = ({ videoUrl, title = 'YouTube Video' }: YouTubeEmbedProps) => {
  const [videoId, setVideoId] = useState<string | null>(null);
  
  useEffect(() => {
    // Extract YouTube video ID from various URL formats
    const getYouTubeVideoId = (url: string): string | null => {
      if (!url || typeof url !== 'string' || url === 'undefined' || url === 'null') {
        return null;
      }
      
      // Handle various YouTube URL formats
      const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
      const match = url.match(regExp);
      
      return (match && match[2].length === 11) ? match[2] : null;
    };
    
    setVideoId(getYouTubeVideoId(videoUrl));
  }, [videoUrl]);
  
  if (!videoId) {
    return (
      <div className="bg-gray-100 p-4 rounded-lg text-center">
        <p className="text-gray-500">Invalid YouTube URL</p>
      </div>
    );
  }
  
  // Build YouTube URL with parameters for better accessibility and performance
  const embedUrl = `https://www.youtube.com/embed/${videoId}?rel=0&modestbranding=1`;
  
  return (
    <div className="relative w-full pb-[56.25%] overflow-hidden rounded-lg shadow-md">
      <iframe
        className="absolute top-0 left-0 w-full h-full border-0"
        src={embedUrl}
        title={title}
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
        allowFullScreen
        loading="lazy"
        referrerPolicy="strict-origin-when-cross-origin"
        aria-label={`YouTube video: ${title}`}
      ></iframe>
    </div>
  );
};

export default YouTubeEmbed;
