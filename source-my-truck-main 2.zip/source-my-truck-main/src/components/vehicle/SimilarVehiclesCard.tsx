
import { useState } from "react";
import { Link } from "react-router-dom";
import { VehicleData } from "@/components/VehicleCard";
import { getPlaceholderImage } from "@/utils/imageUtils";

interface SimilarVehiclesCardProps {
  vehicle: {
    id: string;
    make: string;
  };
  vehicles?: VehicleData[];
}

const SimilarVehiclesCard = ({ vehicle, vehicles = [] }: SimilarVehiclesCardProps) => {
  const [imageErrors, setImageErrors] = useState<Record<string, boolean>>({});
  
  const formatPrice = (price: number) => {
    return price.toLocaleString('en-GB', {
      style: 'currency',
      currency: 'GBP',
      maximumFractionDigits: 0,
    });
  };

  const handleImageError = (vehicleId: string) => {
    console.log("Image error in similar vehicle:", vehicleId);
    setImageErrors(prev => ({
      ...prev,
      [vehicleId]: true
    }));
  };

  // Get appropriate image URL (original or placeholder)
  const getImageUrl = (vehicle: VehicleData) => {
    // Only use placeholder if the original image fails to load
    if (imageErrors[vehicle.id]) {
      return getPlaceholderImage(0);
    }
    return vehicle.imageUrl;
  };

  // Display price or POA
  const getDisplayPrice = (vehicle: VehicleData) => {
    const isPOA = vehicle.isPOA || vehicle.price === 0;
    return isPOA ? "POA" : formatPrice(vehicle.price);
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-sm">
      <h3 className="font-semibold text-lg mb-4">Similar Vehicles</h3>
      
      <div className="space-y-4">
        {vehicles.length > 0 ? (
          vehicles.map(vehicle => (
            <Link 
              key={vehicle.id} 
              to={`/vehicles/${vehicle.id}`}
              className="flex items-start space-x-3 group"
            >
              <div className="w-20 h-16 bg-gray-100 rounded overflow-hidden">
                <img 
                  src={getImageUrl(vehicle)} 
                  alt={vehicle.title} 
                  className="w-full h-full object-cover group-hover:scale-105 transition"
                  onError={() => handleImageError(vehicle.id)}
                />
              </div>
              <div>
                <p className="font-medium text-sm line-clamp-2 group-hover:text-brand-blue transition-colors">
                  {vehicle.title}
                </p>
                <p className="text-brand-blue font-semibold text-sm">
                  {getDisplayPrice(vehicle)}
                </p>
              </div>
            </Link>
          ))
        ) : (
          <p className="text-gray-500 text-sm">No similar vehicles found</p>
        )}
      </div>
    </div>
  );
};

export default SimilarVehiclesCard;
