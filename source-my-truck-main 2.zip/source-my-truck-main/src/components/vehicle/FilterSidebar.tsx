
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { 
  Sheet, 
  SheetContent, 
  SheetTrigger,
  SheetHeader,
  SheetTitle,
  SheetFooter
} from "@/components/ui/sheet";
import { 
  SlidersHorizontal, 
  FilterX,
  Check
} from "lucide-react";
import VehicleFiltersSidebar from "./VehicleFiltersSidebar";
import { useIsMobile } from "@/hooks/use-mobile";
import { 
  Drawer, 
  DrawerTrigger, 
  DrawerContent, 
  DrawerHeader, 
  DrawerTitle, 
  DrawerFooter 
} from "@/components/ui/drawer";

interface FilterSidebarProps {
  yearRange: [number, number];
  setYearRange: (range: [number, number]) => void;
  selectedMakes: string[];
  handleMakeChange: (make: string) => void;
  selectedBodyTypes: string[];
  handleBodyTypeChange: (bodyType: string) => void;
  availableMakes: string[];
  availableBodyTypes: string[];
  showFilters: boolean;
  setShowFilters: (show: boolean) => void;
  trustedSellersOnly: boolean;
  setTrustedSellersOnly: (trusted: boolean) => void;
  depotVerifiedOnly: boolean;
  setDepotVerifiedOnly: (verified: boolean) => void;
}

const FilterSidebar = ({
  yearRange,
  setYearRange,
  selectedMakes,
  handleMakeChange,
  selectedBodyTypes,
  handleBodyTypeChange,
  availableMakes,
  availableBodyTypes,
  showFilters,
  setShowFilters,
  trustedSellersOnly,
  setTrustedSellersOnly,
  depotVerifiedOnly,
  setDepotVerifiedOnly
}: FilterSidebarProps) => {
  const isMobile = useIsMobile();
  const filtersActive = selectedMakes.length > 0 || selectedBodyTypes.length > 0 || 
    yearRange[0] !== 2000 || yearRange[1] !== 2025 || trustedSellersOnly || depotVerifiedOnly;
  
  const activeFiltersCount = selectedMakes.length + selectedBodyTypes.length + 
    (yearRange[0] !== 2000 || yearRange[1] !== 2025 ? 1 : 0) +
    (trustedSellersOnly ? 1 : 0) + (depotVerifiedOnly ? 1 : 0);
  
  const handleClearFilters = () => {
    setYearRange([2000, 2025]);
    selectedMakes.forEach(make => handleMakeChange(make));
    selectedBodyTypes.forEach(bodyType => handleBodyTypeChange(bodyType));
    setTrustedSellersOnly(false);
    setDepotVerifiedOnly(false);
  };
  
  // Desktop sidebar
  const desktopFilters = (
    <div className="hidden lg:block w-[220px] flex-shrink-0">
      <VehicleFiltersSidebar
        yearRange={yearRange}
        setYearRange={setYearRange}
        selectedMakes={selectedMakes}
        handleMakeChange={handleMakeChange}
        selectedBodyTypes={selectedBodyTypes}
        handleBodyTypeChange={handleBodyTypeChange}
        availableMakes={availableMakes}
        availableBodyTypes={availableBodyTypes}
        trustedSellersOnly={trustedSellersOnly}
        setTrustedSellersOnly={setTrustedSellersOnly}
        depotVerifiedOnly={depotVerifiedOnly}
        setDepotVerifiedOnly={setDepotVerifiedOnly}
      />
    </div>
  );
  
  // Mobile filters using Drawer for bottom sheet on smaller screens
  const mobileFilters = (
    <div className="lg:hidden w-full mb-4">
      {isMobile ? (
        <Drawer open={showFilters} onOpenChange={setShowFilters}>
          <DrawerTrigger asChild>
            <Button 
              variant={filtersActive ? "default" : "outline"} 
              className="w-full"
              size="sm"
            >
              <SlidersHorizontal className="h-4 w-4 mr-2" />
              Filters {filtersActive && (
                <span className="ml-1 text-xs bg-white text-black rounded-full w-5 h-5 inline-flex items-center justify-center">
                  {activeFiltersCount}
                </span>
              )}
            </Button>
          </DrawerTrigger>
          <DrawerContent>
            <DrawerHeader className="flex justify-between items-center border-b pb-2">
              <DrawerTitle>Filters</DrawerTitle>
              {filtersActive && (
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="h-8 text-xs flex items-center"
                  onClick={handleClearFilters}
                >
                  <FilterX className="h-3 w-3 mr-1" />
                  Clear All
                </Button>
              )}
            </DrawerHeader>
            <div className="px-4 py-4 max-h-[60vh] overflow-y-auto">
              <VehicleFiltersSidebar
                yearRange={yearRange}
                setYearRange={setYearRange}
                selectedMakes={selectedMakes}
                handleMakeChange={handleMakeChange}
                selectedBodyTypes={selectedBodyTypes}
                handleBodyTypeChange={handleBodyTypeChange}
                availableMakes={availableMakes}
                availableBodyTypes={availableBodyTypes}
                trustedSellersOnly={trustedSellersOnly}
                setTrustedSellersOnly={setTrustedSellersOnly}
                depotVerifiedOnly={depotVerifiedOnly}
                setDepotVerifiedOnly={setDepotVerifiedOnly}
              />
            </div>
            <DrawerFooter className="border-t">
              <Button onClick={() => setShowFilters(false)} className="w-full">
                <Check className="h-4 w-4 mr-2" /> Apply Filters
              </Button>
            </DrawerFooter>
          </DrawerContent>
        </Drawer>
      ) : (
        <Sheet open={showFilters} onOpenChange={setShowFilters}>
          <SheetTrigger asChild>
            <Button 
              variant={filtersActive ? "default" : "outline"} 
              className="w-full"
              size="sm"
            >
              <SlidersHorizontal className="h-4 w-4 mr-2" />
              Filters {filtersActive && (
                <span className="ml-1 text-xs bg-white text-black rounded-full w-5 h-5 inline-flex items-center justify-center">
                  {activeFiltersCount}
                </span>
              )}
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-[85%] sm:w-[350px] overflow-y-auto">
            <SheetHeader className="flex justify-between items-center border-b pb-2">
              <SheetTitle>Filters</SheetTitle>
              {filtersActive && (
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="h-8 text-xs"
                  onClick={handleClearFilters}
                >
                  <FilterX className="h-3 w-3 mr-1" />
                  Clear All
                </Button>
              )}
            </SheetHeader>
            <div className="py-4">
              <VehicleFiltersSidebar
                yearRange={yearRange}
                setYearRange={setYearRange}
                selectedMakes={selectedMakes}
                handleMakeChange={handleMakeChange}
                selectedBodyTypes={selectedBodyTypes}
                handleBodyTypeChange={handleBodyTypeChange}
                availableMakes={availableMakes}
                availableBodyTypes={availableBodyTypes}
                trustedSellersOnly={trustedSellersOnly}
                setTrustedSellersOnly={setTrustedSellersOnly}
                depotVerifiedOnly={depotVerifiedOnly}
                setDepotVerifiedOnly={setDepotVerifiedOnly}
              />
            </div>
            <SheetFooter className="border-t pt-2">
              <Button onClick={() => setShowFilters(false)} className="w-full">
                <Check className="h-4 w-4 mr-2" /> Apply Filters
              </Button>
            </SheetFooter>
          </SheetContent>
        </Sheet>
      )}
    </div>
  );

  return (
    <>
      {mobileFilters}
      {desktopFilters}
    </>
  );
};

export default FilterSidebar;
