
import React, { useState } from "react";
import { Truck } from "lucide-react";

interface MainImageDisplayProps {
  mainImage: string;
  title: string;
  getImageUrl: (url: string, index: number) => string;
  onError: () => void;
}

export function MainImageDisplay({ 
  mainImage, 
  title, 
  getImageUrl, 
  onError 
}: MainImageDisplayProps) {
  const [imageError, setImageError] = useState(false);
  
  const handleImageError = () => {
    console.error("Failed to load image:", mainImage);
    setImageError(true);
    onError();
  };
  
  return (
    <div className="aspect-video bg-gray-100 rounded-lg overflow-hidden">
      {mainImage && !imageError ? (
        <img 
          src={getImageUrl(mainImage, 0)} 
          alt={title} 
          className="w-full h-full object-cover"
          onError={handleImageError}
          loading="eager"
          fetchPriority="high"
          decoding="sync"
        />
      ) : (
        <div className="w-full h-full flex items-center justify-center">
          <Truck size={80} className="text-gray-300" aria-label="No image available" />
        </div>
      )}
    </div>
  );
}
