
import React from 'react';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";

interface ListingsSorterProps {
  sortBy: string;
  setSortBy: (value: string) => void;
}

const ListingsSorter: React.FC<ListingsSorterProps> = ({
  sortBy,
  setSortBy
}) => {
  return (
    <div className="flex items-center gap-2">
      <span className="text-sm text-gray-500 hidden sm:inline">Sort by:</span>
      <Select value={sortBy} onValueChange={setSortBy}>
        <SelectTrigger className="w-[150px]">
          <SelectValue placeholder="Sort by" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="newest">Newest First</SelectItem>
          <SelectItem value="oldest">Oldest First</SelectItem>
          <SelectItem value="price-asc">Price: Low to High</SelectItem>
          <SelectItem value="price-desc">Price: High to Low</SelectItem>
          <SelectItem value="mileage-asc">Mileage: Low to High</SelectItem>
        </SelectContent>
      </Select>
    </div>
  );
};

export default ListingsSorter;
