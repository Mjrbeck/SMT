
import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckCircle, XCircle, AlertTriangle, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";

interface HealthCheckResult {
  name: string;
  status: 'pass' | 'fail' | 'warning';
  message: string;
  details?: string;
}

const HealthCheck = () => {
  const [results, setResults] = useState<HealthCheckResult[]>([]);
  const [isRunning, setIsRunning] = useState(false);
  const { user } = useAuth();

  const runHealthCheck = async () => {
    setIsRunning(true);
    setResults([]);
    
    const checks: HealthCheckResult[] = [];

    // 1. Supabase Connection Test
    try {
      const { data, error } = await supabase.from('profiles').select('count').limit(1);
      checks.push({
        name: 'Supabase Database Connection',
        status: error ? 'fail' : 'pass',
        message: error ? 'Database connection failed' : 'Database connection successful',
        details: error?.message
      });
    } catch (error) {
      checks.push({
        name: 'Supabase Database Connection',
        status: 'fail',
        message: 'Database connection failed',
        details: error instanceof Error ? error.message : 'Unknown error'
      });
    }

    // 2. Authentication Status
    try {
      const { data: { session } } = await supabase.auth.getSession();
      checks.push({
        name: 'Authentication System',
        status: 'pass',
        message: session ? 'User authenticated' : 'Not authenticated (expected for health check)',
        details: session ? `User ID: ${session.user.id}` : 'No active session'
      });
    } catch (error) {
      checks.push({
        name: 'Authentication System',
        status: 'fail',
        message: 'Auth system error',
        details: error instanceof Error ? error.message : 'Unknown error'
      });
    }

    // 3. Core Tables Check - using proper TypeScript types
    const tables = ['profiles', 'vehicles', 'messages', 'transactions'] as const;
    for (const table of tables) {
      try {
        const { data, error } = await supabase.from(table).select('count').limit(1);
        checks.push({
          name: `Table: ${table}`,
          status: error ? 'fail' : 'pass',
          message: error ? `${table} table inaccessible` : `${table} table accessible`,
          details: error?.message
        });
      } catch (error) {
        checks.push({
          name: `Table: ${table}`,
          status: 'fail',
          message: `${table} table error`,
          details: error instanceof Error ? error.message : 'Unknown error'
        });
      }
    }

    // 4. Credits System Check
    if (user) {
      try {
        const { data, error } = await supabase
          .from('profiles')
          .select('credits')
          .eq('id', user.id)
          .single();
        
        checks.push({
          name: 'Credits System',
          status: error ? 'fail' : 'pass',
          message: error ? 'Credits system error' : `Credits available: ${data?.credits || 0}`,
          details: error?.message
        });
      } catch (error) {
        checks.push({
          name: 'Credits System',
          status: 'fail',
          message: 'Credits system error',
          details: error instanceof Error ? error.message : 'Unknown error'
        });
      }
    } else {
      checks.push({
        name: 'Credits System',
        status: 'warning',
        message: 'Cannot check credits - user not authenticated',
        details: 'Login required to test credits system'
      });
    }

    // 5. Environment Configuration
    const requiredConfig = {
      'Supabase URL': 'https://xfpokywrvoshtwtevyaz.supabase.co',
      'Supabase Key': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InhmcG9reXdydm9zaHR3dGV2eWF6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDE2OTQwNzcsImV4cCI6MjA1NzI3MDA3N30.MuDD7d7LLMwKpUQ2zjPPg6JLueQ6uDPeQPNbg_g7P-A'
    };

    Object.entries(requiredConfig).forEach(([name, value]) => {
      checks.push({
        name: `Config: ${name}`,
        status: value ? 'pass' : 'fail',
        message: value ? 'Configuration present' : 'Configuration missing',
        details: value ? 'Value configured correctly' : 'Missing required configuration'
      });
    });

    // 6. Component Rendering Test
    try {
      const testElement = document.createElement('div');
      checks.push({
        name: 'React Rendering',
        status: 'pass',
        message: 'React components rendering successfully',
        details: 'DOM manipulation working correctly'
      });
    } catch (error) {
      checks.push({
        name: 'React Rendering',
        status: 'fail',
        message: 'React rendering issue',
        details: error instanceof Error ? error.message : 'Unknown error'
      });
    }

    // 7. Database Functions Check (Fixed Functions)
    const databaseFunctions = [
      'decrement_credits',
      'has_enough_credits', 
      'is_admin'
    ];
    
    for (const functionName of databaseFunctions) {
      try {
        let functionResult;
        
        if (functionName === 'decrement_credits' && user) {
          // Test decrement_credits function (will test with 0 to avoid actually changing credits)
          const { data, error } = await supabase.rpc(functionName, { amount: 0 });
          functionResult = { data, error };
        } else if (functionName === 'has_enough_credits' && user) {
          // Test has_enough_credits function
          const { data, error } = await supabase.rpc(functionName, { user_id: user.id });
          functionResult = { data, error };
        } else if (functionName === 'is_admin' && user) {
          // Test is_admin function
          const { data, error } = await supabase.rpc(functionName, { user_id: user.id });
          functionResult = { data, error };
        } else {
          checks.push({
            name: `Database Function: ${functionName}`,
            status: 'warning',
            message: 'Cannot test function - user not authenticated',
            details: 'Login required to test this function'
          });
          continue;
        }
        
        checks.push({
          name: `Database Function: ${functionName}`,
          status: functionResult.error ? 'fail' : 'pass',
          message: functionResult.error ? `Function ${functionName} failed` : `Function ${functionName} working correctly`,
          details: functionResult.error?.message || `Result: ${JSON.stringify(functionResult.data)}`
        });
      } catch (error) {
        checks.push({
          name: `Database Function: ${functionName}`,
          status: 'fail',
          message: `Function ${functionName} error`,
          details: error instanceof Error ? error.message : 'Unknown error'
        });
      }
    }

    // 8. Security Validation - RLS Policies Check
    try {
      // Test that we can access vehicles with RLS
      const { data: vehiclesData, error: vehiclesError } = await supabase
        .from('vehicles')
        .select('id')
        .limit(1);
      
      checks.push({
        name: 'RLS Security Check',
        status: vehiclesError ? 'fail' : 'pass',
        message: vehiclesError ? 'RLS policies blocking access' : 'RLS policies working correctly',
        details: vehiclesError?.message || 'Public access to vehicles functioning'
      });
    } catch (error) {
      checks.push({
        name: 'RLS Security Check',
        status: 'fail',
        message: 'Security check failed',
        details: error instanceof Error ? error.message : 'Unknown security error'
      });
    }

    // 9. Frontend Components Check
    try {
      // Test that React components are rendering correctly
      const testDiv = document.createElement('div');
      testDiv.innerHTML = '<div>Test Component</div>';
      
      checks.push({
        name: 'Frontend Rendering',
        status: 'pass',
        message: 'React components rendering successfully',
        details: 'DOM manipulation and component rendering working correctly'
      });
    } catch (error) {
      checks.push({
        name: 'Frontend Rendering',
        status: 'fail', 
        message: 'Frontend rendering issue',
        details: error instanceof Error ? error.message : 'Unknown frontend error'
      });
    }

    // 10. Network Connectivity
    try {
      const response = await fetch('https://api.github.com/zen', { method: 'HEAD' });
      checks.push({
        name: 'External Network',
        status: response.ok ? 'pass' : 'warning',
        message: response.ok ? 'External network accessible' : 'External network issues',
        details: `Status: ${response.status}`
      });
    } catch (error) {
      checks.push({
        name: 'External Network',
        status: 'warning',
        message: 'Network connectivity issues',
        details: 'External API calls may fail'
      });
    }

    setResults(checks);
    setIsRunning(false);

    // Show summary toast
    const passed = checks.filter(c => c.status === 'pass').length;
    const failed = checks.filter(c => c.status === 'fail').length;
    const warnings = checks.filter(c => c.status === 'warning').length;

    if (failed > 0) {
      toast.error(`Health Check Complete: ${failed} failures, ${warnings} warnings, ${passed} passed`);
    } else if (warnings > 0) {
      toast.warning(`Health Check Complete: ${warnings} warnings, ${passed} passed`);
    } else {
      toast.success(`Health Check Complete: All ${passed} checks passed!`);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pass': return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'fail': return <XCircle className="h-5 w-5 text-red-500" />;
      case 'warning': return <AlertTriangle className="h-5 w-5 text-yellow-500" />;
      default: return null;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pass': return 'border-green-200 bg-green-50';
      case 'fail': return 'border-red-200 bg-red-50';
      case 'warning': return 'border-yellow-200 bg-yellow-50';
      default: return 'border-gray-200 bg-gray-50';
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            Platform Health Check
            {isRunning && <Loader2 className="h-5 w-5 animate-spin" />}
          </CardTitle>
          <CardDescription>
            Comprehensive system check for Source my Truck platform
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <Button 
              onClick={runHealthCheck} 
              disabled={isRunning}
              className="w-full"
            >
              {isRunning ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Running Health Check...
                </>
              ) : (
                'Run Health Check'
              )}
            </Button>

            {results.length > 0 && (
              <div className="space-y-3">
                <h3 className="text-lg font-semibold">Results:</h3>
                {results.map((result, index) => (
                  <div 
                    key={index} 
                    className={`p-4 rounded-lg border ${getStatusColor(result.status)}`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        {getStatusIcon(result.status)}
                        <span className="font-medium">{result.name}</span>
                      </div>
                      <span className={`text-sm px-2 py-1 rounded ${
                        result.status === 'pass' ? 'bg-green-100 text-green-800' :
                        result.status === 'fail' ? 'bg-red-100 text-red-800' :
                        'bg-yellow-100 text-yellow-800'
                      }`}>
                        {result.status.toUpperCase()}
                      </span>
                    </div>
                    <p className="text-sm text-gray-600 mt-1">{result.message}</p>
                    {result.details && (
                      <p className="text-xs text-gray-500 mt-1">{result.details}</p>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default HealthCheck;
