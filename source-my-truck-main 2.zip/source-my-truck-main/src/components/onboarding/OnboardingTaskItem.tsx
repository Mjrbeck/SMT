
import React from "react";
import { 
  Check, 
  User,
  Store,
  Truck,
  ChevronRight
} from "lucide-react";
import { cn } from "@/lib/utils";
import { OnboardingTask } from "@/contexts/OnboardingContext";

interface OnboardingTaskItemProps {
  task: OnboardingTask;
  isActive: boolean;
  onClick: () => void;
  stepNumber: number;
}

const OnboardingTaskItem = ({ 
  task, 
  isActive, 
  onClick,
  stepNumber
}: OnboardingTaskItemProps) => {
  const getIcon = () => {
    switch (task.icon) {
      case "user":
        return <User className="h-5 w-5" />;
      case "store":
        return <Store className="h-5 w-5" />;
      case "truck":
        return <Truck className="h-5 w-5" />;
      default:
        return <User className="h-5 w-5" />;
    }
  };
  
  return (
    <div 
      className={cn(
        "flex cursor-pointer items-center justify-between p-4 px-6 transition-colors",
        isActive ? "bg-blue-50" : "hover:bg-gray-50",
        task.completed && "bg-green-50 hover:bg-green-50"
      )}
      onClick={onClick}
    >
      <div className="flex items-center gap-4">
        <div className={cn(
          "flex h-8 w-8 items-center justify-center rounded-full border text-sm font-medium",
          task.completed ? "border-green-500 bg-green-100 text-green-600" : 
          isActive ? "border-blue-500 bg-blue-100 text-blue-600" : "border-gray-300 bg-gray-100 text-gray-600"
        )}>
          {task.completed ? (
            <Check className="h-4 w-4" />
          ) : (
            stepNumber
          )}
        </div>
        
        <div>
          <h4 className={cn(
            "font-medium",
            task.completed ? "text-green-600" : 
            isActive ? "text-blue-600" : "text-gray-700"
          )}>
            {task.title}
          </h4>
          <p className="text-sm text-gray-500">{task.description}</p>
        </div>
      </div>
      
      <div className="flex items-center">
        {task.completed ? (
          <span className="rounded-full bg-green-100 px-3 py-1 text-xs font-medium text-green-600">
            Completed
          </span>
        ) : isActive ? (
          <ChevronRight className="h-5 w-5 text-blue-500" />
        ) : (
          <span className="text-sm text-gray-400">Pending</span>
        )}
      </div>
    </div>
  );
};

export default OnboardingTaskItem;
