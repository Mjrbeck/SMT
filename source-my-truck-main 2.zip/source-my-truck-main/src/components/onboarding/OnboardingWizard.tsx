
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { CheckCircle, ChevronRight, Rocket, X } from "lucide-react";
import { useOnboarding, OnboardingStep } from "@/contexts/OnboardingContext";
import OnboardingTaskItem from "./OnboardingTaskItem";
import { cn } from "@/lib/utils";

const OnboardingWizard = () => {
  const { 
    tasks, 
    currentStep, 
    isOnboardingComplete,
    isOnboardingVisible,
    markTaskComplete, 
    setCurrentStep,
    dismissOnboarding,
    refreshTaskStatus 
  } = useOnboarding();
  const navigate = useNavigate();
  const [progress, setProgress] = useState(0);
  
  // Refresh task status whenever component is mounted
  useEffect(() => {
    refreshTaskStatus();
  }, []);
  
  useEffect(() => {
    // Calculate progress
    const completedTasks = tasks.filter(task => task.completed).length;
    const progressValue = (completedTasks / tasks.length) * 100;
    
    // Add animation with a slight delay
    const timer = setTimeout(() => {
      setProgress(progressValue);
    }, 300);
    
    return () => clearTimeout(timer);
  }, [tasks]);
  
  const handleTaskClick = (taskId: OnboardingStep) => {
    setCurrentStep(taskId);
  };
  
  const handleActionClick = () => {
    if (!currentStep) return;
    
    // Navigate to the appropriate page based on the current step
    switch (currentStep) {
      case "profile":
        navigate("/profile?tab=account");
        break;
      case "shop":
        navigate("/profile?tab=seller-depot");
        break;
      case "listing":
        navigate("/create-listing");
        break;
      case "branding":
        // Scroll to brand assets section on dashboard
        const brandAssetsElement = document.getElementById('brand-assets-section');
        if (brandAssetsElement) {
          brandAssetsElement.scrollIntoView({ behavior: 'smooth' });
        }
        // Mark as viewed
        localStorage.setItem('brandAssetsViewed', 'true');
        markTaskComplete('branding');
        break;
    }
  };
  
  if (!isOnboardingVisible) return null;
  
  return (
    <Card className={cn(
      "mb-8 overflow-hidden border-indigo-100 shadow-md transition-all duration-500",
      isOnboardingComplete ? "bg-green-50" : "bg-gradient-to-r from-blue-50 to-indigo-50"
    )}>
      <CardContent className="p-0">
        {/* Header */}
        <div className="relative bg-gradient-to-r from-indigo-600 to-blue-500 px-6 py-4 text-white">
          <Button 
            variant="ghost" 
            size="icon"
            className="absolute right-2 top-2 h-8 w-8 text-white hover:bg-white/20 hover:text-white"
            onClick={dismissOnboarding}
          >
            <X className="h-4 w-4" />
          </Button>

          <div className="flex items-center gap-3">
            <div className="rounded-full bg-white/20 p-2">
              <Rocket className="h-6 w-6 text-white" />
            </div>
            <div>
              <h3 className="text-xl font-bold">
                {isOnboardingComplete ? "All set!" : "Welcome to your dashboard!"}
              </h3>
              <p className="text-sm text-white/80">
                {isOnboardingComplete 
                  ? "You've completed all the onboarding steps" 
                  : "Let's get your account set up with these simple steps"}
              </p>
            </div>
          </div>
          
          {/* Progress bar */}
          <div className="mt-4 space-y-1">
            <div className="flex justify-between text-xs">
              <span>Setup progress</span>
              <span>{Math.round(progress)}%</span>
            </div>
            <Progress value={progress} className="h-2 bg-white/30" indicatorClassName="bg-white" />
          </div>
        </div>
        
        {/* Tasks list */}
        <div className="divide-y divide-gray-100">
          {tasks.map((task, index) => (
            <OnboardingTaskItem
              key={task.id}
              task={task}
              isActive={currentStep === task.id}
              onClick={() => handleTaskClick(task.id)}
              stepNumber={index + 1}
            />
          ))}
        </div>
        
        {/* Actions footer */}
        {!isOnboardingComplete && currentStep && (
          <div className="bg-gray-50 px-6 py-4">
            <div className="flex items-center justify-between">
              <p className="text-sm text-gray-600">
                Complete these steps to get the most out of the platform
              </p>
              <Button 
                onClick={handleActionClick}
                className="bg-indigo-600 text-white hover:bg-indigo-700"
              >
                {tasks.find(t => t.id === currentStep)?.title}
                <ChevronRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>
        )}
        
        {/* Completion message */}
        {isOnboardingComplete && (
          <div className="bg-green-100 px-6 py-4">
            <div className="flex items-center gap-3 text-green-700">
              <CheckCircle className="h-6 w-6" />
              <div>
                <p className="font-medium">You're all set!</p>
                <p className="text-sm">Your account is fully configured and ready to go</p>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default OnboardingWizard;
