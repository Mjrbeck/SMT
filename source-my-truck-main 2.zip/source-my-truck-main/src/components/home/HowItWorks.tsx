
import { useState } from "react";
import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CreditCard, ListChecks, PoundSterling, Truck, ArrowRight, ThumbsUp, BadgePlus } from "lucide-react";
import { cn } from "@/lib/utils";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/contexts/AuthContext";

const HowItWorks = () => {
  const { isAuthenticated } = useAuth();
  const [activeTab, setActiveTab] = useState("credits");

  const fadeInUp = {
    initial: { opacity: 0, y: 20 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.5 }
  };

  const tabItems = [
    {
      id: "credits",
      title: "Credits System",
      icon: <CreditCard className="h-5 w-5" />,
      description: "Our simple credit system makes listing vehicles straightforward and cost-effective.",
      content: (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="bg-white hover:shadow-md transition-shadow duration-300">
            <CardContent className="p-6 flex flex-col items-center text-center">
              <div className="w-16 h-16 rounded-full bg-brand-blue/10 flex items-center justify-center mb-4">
                <PoundSterling className="h-8 w-8 text-brand-blue" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Affordable Pricing</h3>
              <p className="text-gray-600">Just £10.00 per credit, with each credit allowing you to list one vehicle for 30 days.</p>
            </CardContent>
          </Card>
          
          <Card className="bg-white hover:shadow-md transition-shadow duration-300">
            <CardContent className="p-6 flex flex-col items-center text-center">
              <div className="w-16 h-16 rounded-full bg-brand-blue/10 flex items-center justify-center mb-4">
                <ThumbsUp className="h-8 w-8 text-brand-blue" />
              </div>
              <h3 className="text-lg font-semibold mb-2">No Hidden Fees</h3>
              <p className="text-gray-600">Pay only for what you use with no commission or additional charges when you make a sale.</p>
            </CardContent>
          </Card>
          
          <Card className="bg-white hover:shadow-md transition-shadow duration-300">
            <CardContent className="p-6 flex flex-col items-center text-center">
              <div className="w-16 h-16 rounded-full bg-brand-blue/10 flex items-center justify-center mb-4">
                <ArrowRight className="h-8 w-8 text-brand-blue" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Easy Renewals</h3>
              <p className="text-gray-600">Renew your listing with just one click when your 30-day period expires.</p>
            </CardContent>
          </Card>
        </div>
      )
    },
    {
      id: "selling",
      title: "Selling Process",
      icon: <Truck className="h-5 w-5" />,
      description: "List and sell your commercial vehicles with our streamlined three-step process.",
      content: (
        <div className="flex flex-col md:flex-row gap-6">
          {[
            {
              step: "1",
              title: "Create Your Listing",
              description: "Upload photos, add details, and set your price in our easy-to-use form.",
              icon: <ListChecks className="h-8 w-8 text-brand-blue" />
            },
            {
              step: "2",
              title: "Connect With Buyers",
              description: "Receive inquiries directly through our messaging system from interested buyers.",
              icon: <BadgePlus className="h-8 w-8 text-brand-blue" />
            },
            {
              step: "3",
              title: "Complete Your Sale",
              description: "Finalize details and complete the transaction on your terms.",
              icon: <ThumbsUp className="h-8 w-8 text-brand-blue" />
            }
          ].map((item, index) => (
            <div key={index} className="relative flex-1 bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow duration-300">
              <div className="absolute -top-4 -left-4 w-10 h-10 rounded-full bg-brand-orange text-white flex items-center justify-center font-bold text-lg">
                {item.step}
              </div>
              <div className="flex flex-col items-center text-center mt-4">
                <div className="w-16 h-16 rounded-full bg-brand-blue/10 flex items-center justify-center mb-4">
                  {item.icon}
                </div>
                <h3 className="text-lg font-semibold mb-2">{item.title}</h3>
                <p className="text-gray-600">{item.description}</p>
              </div>
            </div>
          ))}
        </div>
      )
    }
  ];

  return (
    <section className="py-16 bg-gradient-to-b from-brand-blue/5 to-brand-lightBlue/5">
      <div className="container mx-auto px-4">
        <motion.div 
          className="text-center mb-12"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-3xl font-bold mb-4 text-brand-blue">How Source my Truck Works</h2>
          <p className="text-gray-700 max-w-2xl mx-auto">
            Our platform makes buying and selling commercial vehicles simple, transparent, and cost-effective.
          </p>
        </motion.div>
        
        <Tabs
          defaultValue="credits"
          value={activeTab}
          onValueChange={setActiveTab}
          className="w-full"
        >
          <div className="flex justify-center mb-8">
            <TabsList className="bg-brand-blue/10">
              {tabItems.map(tab => (
                <TabsTrigger
                  key={tab.id}
                  value={tab.id}
                  className={cn(
                    "flex items-center gap-2 py-3 px-5 data-[state=active]:bg-white",
                    "data-[state=active]:text-brand-blue data-[state=active]:shadow-sm",
                    "text-gray-700 transition-all duration-200"
                  )}
                >
                  {tab.icon}
                  <span>{tab.title}</span>
                </TabsTrigger>
              ))}
            </TabsList>
          </div>
          
          {tabItems.map(tab => (
            <TabsContent key={tab.id} value={tab.id} className="focus-visible:outline-none focus-visible:ring-0">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.3 }}
                className="space-y-8"
              >
                <p className="text-lg text-center mb-8 max-w-3xl mx-auto text-gray-700">
                  {tab.description}
                </p>
                
                {tab.content}
              </motion.div>
            </TabsContent>
          ))}
        </Tabs>
        
        <motion.div 
          className="mt-12 text-center"
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <Link to={isAuthenticated ? "/create-listing" : "/register"}>
            <Button 
              className="bg-brand-orange hover:bg-brand-orange/90 text-white px-8 py-6 text-lg shadow-lg"
            >
              {isAuthenticated ? "Create a Listing Now" : "Get Started Today"}
            </Button>
          </Link>
        </motion.div>
      </div>
    </section>
  );
};

export default HowItWorks;
