import { useEffect } from 'react';
import { useParams } from 'react-router-dom';

/**
 * Component that immediately redirects to the edge function prerender route
 * This ensures crawlers get the server-rendered HTML with proper meta tags
 */
const VehiclePrerender = () => {
  const { id } = useParams<{ id: string }>();

  useEffect(() => {
    if (id) {
      // Redirect to the edge function URL for server-side rendering
      const prerenderUrl = `https://xfpokywrvoshtwtevyaz.supabase.co/functions/v1/vehicle-meta-prerender/${id}`;
      window.location.replace(prerenderUrl);
    }
  }, [id]);

  return (
    <div className="flex h-screen items-center justify-center">
      <div className="text-center">
        <div className="mb-4">
          <div className="w-16 h-16 border-4 border-t-brand-blue border-r-transparent border-b-brand-orange border-l-transparent rounded-full animate-spin mx-auto"></div>
        </div>
        <p className="text-lg font-medium">Loading vehicle details...</p>
        <p className="text-sm text-gray-500 mt-2">Preparing optimized content for sharing.</p>
      </div>
    </div>
  );
};

export default VehiclePrerender;