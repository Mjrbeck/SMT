
import React, { useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Download, Copy, Check } from "lucide-react";
import Logo from "./Logo";

const LogoExporter = () => {
  const svgRef = useRef<SVGSVGElement>(null);
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    if (svgRef.current) {
      const svgData = new XMLSerializer().serializeToString(svgRef.current);
      navigator.clipboard.writeText(svgData);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleDownloadSVG = () => {
    if (svgRef.current) {
      const svgData = new XMLSerializer().serializeToString(svgRef.current);
      const svgBlob = new Blob([svgData], { type: "image/svg+xml;charset=utf-8" });
      const svgUrl = URL.createObjectURL(svgBlob);
      const downloadLink = document.createElement("a");
      downloadLink.href = svgUrl;
      downloadLink.download = "source-my-truck-logo.svg";
      document.body.appendChild(downloadLink);
      downloadLink.click();
      document.body.removeChild(downloadLink);
    }
  };

  const handleDownloadPNG = () => {
    if (svgRef.current) {
      const svgData = new XMLSerializer().serializeToString(svgRef.current);
      const canvas = document.createElement("canvas");
      canvas.width = 300;
      canvas.height = 100;
      const ctx = canvas.getContext("2d");
      
      if (ctx) {
        const img = new Image();
        const svgBlob = new Blob([svgData], { type: "image/svg+xml;charset=utf-8" });
        const url = URL.createObjectURL(svgBlob);
        
        img.onload = () => {
          ctx.drawImage(img, 0, 0, 300, 100);
          URL.revokeObjectURL(url);
          
          const pngUrl = canvas.toDataURL("image/png");
          const downloadLink = document.createElement("a");
          downloadLink.href = pngUrl;
          downloadLink.download = "source-my-truck-logo.png";
          document.body.appendChild(downloadLink);
          downloadLink.click();
          document.body.removeChild(downloadLink);
        };
        
        img.src = url;
      }
    }
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>Source my Truck Logo</CardTitle>
        <CardDescription>Export the logo in SVG or PNG format</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <Tabs defaultValue="svg" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="svg">SVG Format</TabsTrigger>
            <TabsTrigger value="png">PNG Format</TabsTrigger>
          </TabsList>
          
          <TabsContent value="svg" className="pt-4">
            <div className="bg-gray-50 p-8 rounded-md flex justify-center">
              <svg
                ref={svgRef}
                width="300"
                height="100"
                viewBox="0 0 300 100"
                xmlns="http://www.w3.org/2000/svg"
              >
                <g transform="translate(100, 50)">
                  <path 
                    d="M-70,0 L-70,-20 L-30,-20 L-30,-30 L-10,-30 L-10,-20 L0,-20 L10,-30 L25,-30 L37.5,-17.5 L37.5,5 L25,5 L25,-5 L15,-5 L15,5 L-70,5 Z" 
                    fill="#3b82f6" 
                    strokeWidth="2"
                  />
                  <circle cx="-50" cy="10" r="7.5" fill="#3b82f6" />
                  <circle cx="0" cy="10" r="7.5" fill="#3b82f6" />
                </g>
                <text x="150" y="60" fontFamily="Arial" fontSize="24" fontWeight="bold" textAnchor="middle">
                  <tspan fill="#3b82f6">Source my </tspan>
                  <tspan fill="#f97316">Truck</tspan>
                </text>
              </svg>
            </div>
            <div className="flex justify-center mt-4 space-x-4">
              <Button onClick={handleCopy}>
                {copied ? <Check className="h-4 w-4 mr-2" /> : <Copy className="h-4 w-4 mr-2" />}
                {copied ? "Copied!" : "Copy SVG"}
              </Button>
              <Button onClick={handleDownloadSVG}>
                <Download className="h-4 w-4 mr-2" />
                Download SVG
              </Button>
            </div>
          </TabsContent>
          
          <TabsContent value="png" className="pt-4">
            <div className="bg-gray-50 p-8 rounded-md flex justify-center">
              <div className="border border-gray-200 p-4 rounded">
                <Logo size="xl" />
              </div>
            </div>
            <div className="flex justify-center mt-4">
              <Button onClick={handleDownloadPNG}>
                <Download className="h-4 w-4 mr-2" />
                Download PNG
              </Button>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
      <CardFooter className="flex justify-between text-sm text-gray-500">
        <p>Note: These are simplified versions based on the app's styling</p>
      </CardFooter>
    </Card>
  );
};

export default LogoExporter;
