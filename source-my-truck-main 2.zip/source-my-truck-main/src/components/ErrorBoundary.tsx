import { Component, ErrorInfo, ReactNode, useEffect } from "react";
import { AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";

// Helper function to suppress specific React warnings in development
const suppressReactWarnings = () => {
  if (process.env.NODE_ENV === 'development') {
    // Store the original console.error
    const originalConsoleError = console.error;
    
    // Override console.error to filter out specific warnings
    console.error = (...args: any[]) => {
      // Filter out the UNSAFE_componentWillMount warning for SideEffect
      if (
        typeof args[0] === 'string' && 
        args[0].includes('Warning: Using UNSAFE_componentWillMount in strict mode') &&
        args[0].includes('SideEffect')
      ) {
        return;
      }
      
      // Pass through all other console errors
      originalConsoleError.apply(console, args);
    };
    
    // Return a cleanup function to restore the original console.error
    return () => {
      console.error = originalConsoleError;
    };
  }
  
  // No-op for production
  return () => {};
};

// Component to suppress warnings that can be used at the app level
export const WarningSupressor: React.FC = () => {
  useEffect(() => {
    return suppressReactWarnings();
  }, []);
  
  return null;
};

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
  onError?: (error: Error, errorInfo: ErrorInfo) => void;
  onReset?: () => void;
}

interface State {
  hasError: boolean;
  error: Error | null;
  errorInfo: ErrorInfo | null;
}

class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null,
    errorInfo: null
  };

  public static getDerivedStateFromError(error: Error): Partial<State> {
    // Update state so the next render will show the fallback UI
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    // Only log actual errors, not auth session missing errors
    if (!error.message.includes('Auth session missing')) {
      console.error("Uncaught error:", error, errorInfo);
    }
    this.setState({ errorInfo });
    
    // Call optional onError callback
    if (this.props.onError) {
      this.props.onError(error, errorInfo);
    }
  }
  
  private handleReset = () => {
    this.setState({ hasError: false, error: null, errorInfo: null });
    
    // Call optional onReset callback
    if (this.props.onReset) {
      this.props.onReset();
    }
  }

  public componentDidMount() {
    // Apply warning suppression in development mode
    if (process.env.NODE_ENV === 'development') {
      suppressReactWarnings();
    }
  }

  public render() {
    if (this.state.hasError) {
      if (this.props.fallback) {
        return this.props.fallback;
      }
      
      return (
        <div className="flex flex-col items-center justify-center min-h-[400px] p-6 text-center bg-card text-card-foreground">
          <AlertTriangle className="h-16 w-16 text-destructive mb-4" />
          <h2 className="text-2xl font-bold mb-2 text-foreground">Something went wrong</h2>
          <p className="text-muted-foreground mb-6 max-w-md">
            We're sorry, but an unexpected error occurred. Technical details have been logged for investigation.
          </p>
          <div className="flex flex-col sm:flex-row gap-3">
            <Button
              onClick={() => window.location.reload()}
              variant="outline"
            >
              Reload Page
            </Button>
            <Button
              onClick={this.handleReset}
            >
              Try Again
            </Button>
          </div>
          
          {this.state.error && process.env.NODE_ENV === 'development' && (
            <div className="mt-6 p-4 bg-destructive/10 border border-destructive/20 rounded-md text-left max-w-full overflow-auto">
              <p className="font-mono text-sm text-destructive whitespace-pre-wrap">
                {this.state.error.toString()}
                {this.state.errorInfo && (
                  <>
                    <br />
                    <br />
                    {this.state.errorInfo.componentStack}
                  </>
                )}
              </p>
            </div>
          )}
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;
