
import React from 'react';
import SearchBox from './SearchBox';
import { ErrorBoundary } from 'react-error-boundary';
import { motion } from 'framer-motion';

const SearchBoxFallback = () => (
  <div className="w-full bg-white p-6 rounded-lg shadow-md mb-4">
    <p className="text-center text-red-500">
      There was an error loading the search box. Please try refreshing the page.
    </p>
  </div>
);

const SearchBoxWrapper = () => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="relative z-10"
    >
      <div className="rounded-xl overflow-hidden shadow-xl">
        <ErrorBoundary FallbackComponent={SearchBoxFallback}>
          <SearchBox />
        </ErrorBoundary>
      </div>
    </motion.div>
  );
};

export default SearchBoxWrapper;
