import { useState, useMemo, useEffect } from "react";
import React from "react";
import { useQuery } from "@tanstack/react-query";
import { useSearchParams } from "react-router-dom";
import { getFeaturedVehicles } from "@/services/vehicleService";
import VehicleResultsGrid from "@/components/vehicle/VehicleResultsGrid";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { Truck, ArrowRight, Star } from "lucide-react";
import { VehicleData } from "@/components/VehicleCard";
import { getBodyTypeValue } from "@/utils/vehicleUtils";
import { OptimizedSkeleton } from "@/components/common/OptimizedSkeleton";

const filterVehicles = (vehicles: VehicleData[], keyword: string, make: string, priceMax: number, bodyType: string) => {
  if (!vehicles.length) return [];
  
  if (!(keyword || make || priceMax > 0 || bodyType)) {
    return vehicles;
  }
  
  return vehicles.filter((vehicle: VehicleData) => {
    if (keyword) {
      const searchTerm = keyword.toLowerCase();
      const matchesSearch = vehicle.title.toLowerCase().includes(searchTerm) || 
                           vehicle.make.toLowerCase().includes(searchTerm) || 
                           vehicle.model.toLowerCase().includes(searchTerm) || 
                           (vehicle.description || "").toLowerCase().includes(searchTerm);
      if (!matchesSearch) return false;
    }

    if (make && !vehicle.make.toLowerCase().includes(make.toLowerCase())) {
      return false;
    }

    if (priceMax > 0 && vehicle.price > priceMax) {
      return false;
    }

    if (bodyType && vehicle.bodyType) {
      const vehicleBodyTypeValue = getBodyTypeValue(vehicle.bodyType);
      if (vehicleBodyTypeValue !== bodyType) {
        return false;
      }
    }
    return true;
  });
};

const FeaturedVehicles = () => {
  const [searchParams] = useSearchParams();
  const [cachedVehicles, setCachedVehicles] = useState<VehicleData[]>([]);

  const filters = useMemo(() => ({
    keyword: searchParams.get("keyword") || "",
    make: searchParams.get("make") || "",
    priceMax: searchParams.get("priceMax") ? parseInt(searchParams.get("priceMax") || "0") : 0,
    bodyType: searchParams.get("bodyType") || "",
  }), [searchParams]);

  const {
    data: vehicles = [],
    isLoading,
    error,
    isSuccess
  } = useQuery({
    queryKey: ['featuredVehicles'],
    queryFn: () => getFeaturedVehicles(12, true),
    staleTime: 5 * 60 * 1000,
    placeholderData: cachedVehicles,
  });

  useEffect(() => {
    if (isSuccess && vehicles.length > 0) {
      setCachedVehicles(vehicles);
      
      try {
        localStorage.setItem('featuredVehicles', JSON.stringify(vehicles));
        localStorage.setItem('featuredVehiclesTimestamp', Date.now().toString());
      } catch (e) {
      }
    }
  }, [isSuccess, vehicles]);

  useEffect(() => {
    try {
      const cached = localStorage.getItem('featuredVehicles');
      const timestamp = localStorage.getItem('featuredVehiclesTimestamp');
      
      if (cached && timestamp) {
        const cacheAge = Date.now() - parseInt(timestamp);
        if (cacheAge < 30 * 60 * 1000) {
          setCachedVehicles(JSON.parse(cached));
        }
      }
    } catch (e) {
    }
  }, []);

  const filteredVehicles = useMemo(() => 
    filterVehicles(vehicles, filters.keyword, filters.make, filters.priceMax, filters.bodyType),
    [vehicles, filters]
  );

  if (isLoading && !cachedVehicles.length) {
    return (
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <h2 className="text-2xl font-bold text-gray-900">Latest Vehicles</h2>
        </div>
        <OptimizedSkeleton variant="card" count={3} className="md:grid md:grid-cols-3 gap-4" />
      </div>
    );
  }
  
  if (error) {
    return <div className="bg-gray-50 p-8 rounded-lg text-center">
        <h3 className="text-xl font-semibold mb-2">Unable to load vehicles</h3>
        <p className="text-gray-600 mb-4">
          There was an error loading the featured vehicles. Please try again later.
        </p>
        <Button variant="outline" onClick={() => window.location.reload()}>
          Retry
        </Button>
      </div>;
  }
  
  return <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">Latest Vehicles</h2>
        <Link to="/listings">
          <Button variant="outline" className="flex items-center gap-2">
            <Truck size={16} />
            <span>View all vehicles</span>
          </Button>
        </Link>
      </div>
      
      {filteredVehicles.length > 0 ? (
        <VehicleResultsGrid vehicles={filteredVehicles} compact={true} columns={4} /> 
      ) : (
        <div className="bg-gray-50 p-8 rounded-lg text-center">
          <h3 className="text-xl font-semibold mb-2">No matching vehicles found</h3>
          <p className="text-gray-600">
            Try adjusting your search criteria or browse all vehicles.
          </p>
        </div>
      )}

      <div className="flex justify-center mt-8">
        <Link to="/listings">
          <Button size="lg" className="flex items-center gap-2 bg-brand-blue">
            Browse all Vehicles
            <ArrowRight size={16} />
          </Button>
        </Link>
      </div>
    </div>;
};

export default React.memo(FeaturedVehicles);
