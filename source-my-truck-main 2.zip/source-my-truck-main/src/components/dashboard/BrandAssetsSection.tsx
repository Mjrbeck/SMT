import React, { useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Download, Copy, Check, ExternalLink, Share2 } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { useOnboarding } from "@/contexts/OnboardingContext";
import { ProfileData } from "@/components/profile/types";

interface BrandAssetsSectionProps {
  profile: ProfileData | null;
}

const BrandAssetsSection: React.FC<BrandAssetsSectionProps> = ({ profile }) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const { markTaskComplete } = useOnboarding();
  const svgRef = useRef<SVGSVGElement>(null);
  const [copied, setCopied] = useState<string>("");

  // Generate user-specific URLs
  const userProfileUrl = `https://sourcemytruck.com/sellers/${user?.id}`;
  const userListingsUrl = `https://sourcemytruck.com/vehicles?seller=${user?.id}`;
  const companyName = profile?.company_name || "Your Company";

  const markBrandingTaskComplete = () => {
    localStorage.setItem('brandAssetsViewed', 'true');
    markTaskComplete('branding');
  };

  const handleCopy = (text: string, type: string) => {
    navigator.clipboard.writeText(text);
    setCopied(type);
    setTimeout(() => setCopied(""), 2000);
    toast({
      title: "Copied to clipboard!",
      description: "The code has been copied to your clipboard.",
    });
    markBrandingTaskComplete();
  };

  const handleDownloadSVG = (linkUrl: string, filename: string) => {
    if (svgRef.current) {
      const svgData = new XMLSerializer().serializeToString(svgRef.current);
      const svgBlob = new Blob([svgData], { type: "image/svg+xml;charset=utf-8" });
      const svgUrl = URL.createObjectURL(svgBlob);
      const downloadLink = document.createElement("a");
      downloadLink.href = svgUrl;
      downloadLink.download = filename;
      document.body.appendChild(downloadLink);
      downloadLink.click();
      document.body.removeChild(downloadLink);
      markBrandingTaskComplete();
    }
  };

  const generateEmbedCode = (linkUrl: string, alt: string) => {
    return `<a href="${linkUrl}" target="_blank" rel="noopener noreferrer">
  <img src="/lovable-uploads/37a3fc96-0977-42b4-b4dc-dfbefcea1e7b.png" 
       alt="${alt}" 
       width="200" 
       height="67" />
</a>`;
  };

  const generatePartnerBadgeCode = () => {
    return `<div style="display: inline-flex; align-items: center; padding: 8px 16px; background: #f8f9fa; border: 1px solid #e9ecef; border-radius: 6px; text-decoration: none; color: #495057; font-family: Arial, sans-serif;">
  <img src="/lovable-uploads/064ee632-b1be-4033-8273-6fe9166737c1.png" alt="Source my Truck" width="24" height="24" style="margin-right: 8px;" />
  <span style="font-size: 14px; font-weight: 500;">Find us on SourcemyTruck.com</span>
</div>`;
  };

  return (
    <Card id="brand-assets-section" className="border-0 shadow-lg bg-gradient-to-br from-white to-blue-50/30 overflow-hidden">
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center gap-2 text-lg">
          <div className="p-2 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg">
            <Share2 className="h-5 w-5 text-white" />
          </div>
          Brand Assets & Backlinks
        </CardTitle>
        <CardDescription className="text-muted-foreground">
          Download logos and embed codes to promote your presence on SourceMyTruck
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <Tabs defaultValue="logos" className="w-full" onValueChange={() => markBrandingTaskComplete()}>
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="logos">Logos</TabsTrigger>
            <TabsTrigger value="badges">Partner Badges</TabsTrigger>
            <TabsTrigger value="embed">Embed Codes</TabsTrigger>
          </TabsList>
          
          <TabsContent value="logos" className="pt-4">
            <div className="space-y-4">
              <div className="bg-gradient-to-r from-gray-50 to-gray-100 p-6 rounded-lg border border-gray-200">
                <img 
                  src="/lovable-uploads/37a3fc96-0977-42b4-b4dc-dfbefcea1e7b.png"
                  alt="Source my Truck Logo"
                  className="mx-auto max-w-full h-auto"
                  style={{ maxHeight: '120px' }}
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Button 
                  onClick={() => handleDownloadSVG(userProfileUrl, `sourcemytruck-${companyName.toLowerCase().replace(/\s+/g, '-')}-logo.svg`)}
                  className="flex items-center gap-2"
                  variant="outline"
                >
                  <Download className="h-4 w-4" />
                  Download Profile Logo
                </Button>
                <Button 
                  onClick={() => handleDownloadSVG(userListingsUrl, `sourcemytruck-${companyName.toLowerCase().replace(/\s+/g, '-')}-listings.svg`)}
                  className="flex items-center gap-2"
                  variant="outline"
                >
                  <Download className="h-4 w-4" />
                  Download Listings Logo
                </Button>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="badges" className="pt-4">
            <div className="space-y-4">
              <div className="bg-white p-6 rounded-lg border border-gray-200 text-center">
                <div 
                  className="inline-flex items-center p-3 bg-gray-50 border border-gray-200 rounded-lg text-gray-700 font-medium"
                  style={{ fontFamily: 'Arial, sans-serif' }}
                >
                  <img 
                    src="/lovable-uploads/064ee632-b1be-4033-8273-6fe9166737c1.png"
                    alt="Source my Truck"
                    width="24"
                    height="24"
                    className="mr-3"
                  />
                  Find us on SourcemyTruck.com
                </div>
              </div>
              
              <div className="space-y-2">
                <p className="text-sm font-medium text-gray-700">HTML Code:</p>
                <div className="bg-gray-900 text-gray-100 p-3 rounded-md text-xs font-mono overflow-x-auto">
                  <pre>{generatePartnerBadgeCode()}</pre>
                </div>
                <Button
                  onClick={() => handleCopy(generatePartnerBadgeCode(), "badge")}
                  size="sm"
                  variant="outline"
                  className="w-full"
                >
                  {copied === "badge" ? <Check className="h-4 w-4 mr-2" /> : <Copy className="h-4 w-4 mr-2" />}
                  {copied === "badge" ? "Copied!" : "Copy Badge Code"}
                </Button>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="embed" className="pt-4">
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-3">
                  <h4 className="font-medium text-gray-900 flex items-center gap-2">
                    <ExternalLink className="h-4 w-4" />
                    Profile Link
                  </h4>
                  <div className="bg-gray-900 text-gray-100 p-3 rounded-md text-xs font-mono overflow-x-auto">
                    <pre>{generateEmbedCode(userProfileUrl, `${companyName} on SourceMyTruck`)}</pre>
                  </div>
                  <Button
                    onClick={() => handleCopy(generateEmbedCode(userProfileUrl, `${companyName} on SourceMyTruck`), "profile")}
                    size="sm"
                    variant="outline"
                    className="w-full"
                  >
                    {copied === "profile" ? <Check className="h-4 w-4 mr-2" /> : <Copy className="h-4 w-4 mr-2" />}
                    {copied === "profile" ? "Copied!" : "Copy Profile Code"}
                  </Button>
                </div>
                
                <div className="space-y-3">
                  <h4 className="font-medium text-gray-900 flex items-center gap-2">
                    <ExternalLink className="h-4 w-4" />
                    Listings Link
                  </h4>
                  <div className="bg-gray-900 text-gray-100 p-3 rounded-md text-xs font-mono overflow-x-auto">
                    <pre>{generateEmbedCode(userListingsUrl, `${companyName} Vehicles on SourceMyTruck`)}</pre>
                  </div>
                  <Button
                    onClick={() => handleCopy(generateEmbedCode(userListingsUrl, `${companyName} Vehicles on SourceMyTruck`), "listings")}
                    size="sm"
                    variant="outline"
                    className="w-full"
                  >
                    {copied === "listings" ? <Check className="h-4 w-4 mr-2" /> : <Copy className="h-4 w-4 mr-2" />}
                    {copied === "listings" ? "Copied!" : "Copy Listings Code"}
                  </Button>
                </div>
              </div>
              
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <h5 className="font-medium text-blue-900 mb-2">How to use these codes:</h5>
                <ul className="text-sm text-blue-800 space-y-1">
                  <li>• Copy the HTML code and paste it into your website</li>
                  <li>• Add it to your email signature</li>
                  <li>• Include it in your social media profiles</li>
                  <li>• Use it on business cards or marketing materials</li>
                </ul>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};

export default BrandAssetsSection;