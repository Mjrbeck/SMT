
import { ReactNode, useState } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { useUserRole } from "@/hooks/useUserRole";
import { Button } from "@/components/ui/button";
import { 
  Truck, 
  Menu, 
  X, 
  Plus,
  ChevronDown,
  CreditCard,
  User,
  LogOut,
  LayoutDashboard,
  MessageSquare,
  Building,
  Settings
} from "lucide-react";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";
import DashboardMobileMenu from "./DashboardMobileMenu";

interface DashboardNavBarProps {
  onMobileMenuToggle: () => void;
  isMobileMenuOpen: boolean;
}

const DashboardNavBar = ({ 
  onMobileMenuToggle, 
  isMobileMenuOpen 
}: DashboardNavBarProps) => {
  const { user, signOut } = useAuth();
  const { isSeller } = useUserRole();
  const navigate = useNavigate();
  const location = useLocation();
  
  const handleSignOut = async () => {
    await signOut();
    navigate("/");
  };

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <div className="relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 -mt-8 -mr-8 bg-brand-lightBlue/5 rounded-full blur-2xl"></div>
        <div className="container mx-auto px-4 flex justify-between items-center h-16 relative z-10">
          <div className="flex items-center">
            <Link to="/" className="flex items-center space-x-2">
              <Truck className="h-7 w-7 text-brand-blue" />
              <span className="text-lg md:text-xl font-bold text-brand-blue">Source my <span className="text-brand-orange">Truck</span></span>
            </Link>

            <nav className="hidden md:flex items-center space-x-6 ml-8">
              <Link
                to="/dashboard"
                className={cn(
                  "text-sm font-medium transition-colors hover:text-brand-blue flex items-center",
                  location.pathname === "/dashboard"
                    ? "text-brand-blue"
                    : "text-gray-600"
                )}
              >
                Dashboard
              </Link>
              {isSeller && (
                <Link
                  to="/inventory"
                  className={cn(
                    "text-sm font-medium transition-colors hover:text-brand-blue flex items-center",
                    location.pathname === "/inventory"
                      ? "text-brand-blue"
                      : "text-gray-600"
                  )}
                >
                  Inventory
                </Link>
              )}
              <Link
                to="/messages"
                className={cn(
                  "text-sm font-medium transition-colors hover:text-brand-blue flex items-center",
                  location.pathname === "/messages" || location.pathname.startsWith("/messages/")
                    ? "text-brand-blue"
                    : "text-gray-600"
                )}
              >
                Messages
              </Link>
              {isSeller && (
                <Link
                  to="/profile"
                  className={cn(
                    "text-sm font-medium transition-colors hover:text-brand-blue flex items-center",
                    location.pathname === "/profile"
                      ? "text-brand-blue"
                      : "text-gray-600"
                  )}
                >
                  Company Profile
                </Link>
              )}
            </nav>
          </div>

          <div className="flex items-center space-x-3">
            {isSeller && (
              <Link to="/create-listing" className="hidden md:flex">
                <Button size="sm" className="bg-gradient-to-r from-brand-blue to-brand-lightBlue hover:from-brand-lightBlue hover:to-brand-blue transition-all duration-300">
                  <Plus className="h-4 w-4 mr-1" /> New Listing
                </Button>
              </Link>
            )}

            {isSeller && (
              <Link to="/settings?tab=credits" className="hidden md:flex">
                <Button variant="outline" size="sm" className="border-indigo-100 hover:bg-indigo-50/70">
                  <CreditCard className="h-4 w-4 mr-1 text-brand-lightBlue" /> Credits
                </Button>
              </Link>
            )}

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="hidden md:flex border-indigo-100 hover:bg-indigo-50/70"
                >
                  {user?.email?.split('@')[0]}
                  <ChevronDown className="ml-2 h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56 border-0 shadow-md bg-white/95 backdrop-blur-sm z-50">
                <DropdownMenuItem onClick={() => navigate("/dashboard")} className={cn(
                  location.pathname === "/dashboard" ? "text-brand-lightBlue" : ""
                )}>
                  <LayoutDashboard className="mr-2 h-4 w-4 text-brand-lightBlue" />
                  Dashboard
                </DropdownMenuItem>
                {isSeller && (
                  <DropdownMenuItem onClick={() => navigate("/profile")} className={cn(
                    location.pathname === "/profile" ? "text-brand-lightBlue" : ""
                  )}>
                    <Building className="mr-2 h-4 w-4 text-brand-lightBlue" />
                    Profile
                  </DropdownMenuItem>
                )}
                <DropdownMenuItem onClick={() => navigate("/settings")} className={cn(
                  location.pathname === "/settings" ? "text-brand-lightBlue" : ""
                )}>
                  <Settings className="mr-2 h-4 w-4 text-brand-lightBlue" />
                  Settings
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => navigate("/messages")} className={cn(
                  location.pathname === "/messages" || location.pathname.startsWith("/messages/") ? "text-brand-lightBlue" : ""
                )}>
                  <MessageSquare className="mr-2 h-4 w-4 text-brand-lightBlue" />
                  Messages
                </DropdownMenuItem>
                {isSeller && (
                  <DropdownMenuItem onClick={() => navigate("/inventory")} className={cn(
                    location.pathname === "/inventory" ? "text-brand-lightBlue" : ""
                  )}>
                    <Truck className="mr-2 h-4 w-4 text-brand-lightBlue" />
                    My Inventory
                  </DropdownMenuItem>
                )}
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleSignOut} className="text-red-500">
                  <LogOut className="mr-2 h-4 w-4" />
                  Log out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <Button
              variant="ghost"
              size="sm"
              className="md:hidden p-2"
              onClick={onMobileMenuToggle}
              aria-label={isMobileMenuOpen ? "Close menu" : "Open menu"}
            >
              {isMobileMenuOpen ? (
                <X className="h-6 w-6" />
              ) : (
                <Menu className="h-6 w-6" />
              )}
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default DashboardNavBar;
