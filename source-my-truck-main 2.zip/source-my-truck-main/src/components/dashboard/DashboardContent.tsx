
import { ReactNode } from "react";
import { PageHeader } from "../ui/consistent-ui";

interface DashboardContentProps {
  children: ReactNode;
  title?: string;
  subtitle?: string;
}

const DashboardContent = ({ children, title = "Dashboard", subtitle }: DashboardContentProps) => {
  return (
    <main className="px-4 py-8 mx-auto max-w-7xl relative">
      <div className="relative overflow-hidden mb-6">
        <div className="absolute top-0 left-0 w-40 h-40 -mt-20 -ml-20 bg-brand-lightBlue/5 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 right-0 w-40 h-40 -mb-10 -mr-10 bg-brand-orange/5 rounded-full blur-3xl"></div>
        <PageHeader
          title={title}
          subtitle={subtitle}
          variant="dark"
          className="relative z-10"
        />
      </div>
      <div className="mt-6 relative z-10">
        {children}
      </div>
    </main>
  );
};

export default DashboardContent;
