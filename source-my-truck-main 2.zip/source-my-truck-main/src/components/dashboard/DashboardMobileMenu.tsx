
import { Link, useLocation } from "react-router-dom";
import { CreditCard, LogOut, Plus, Truck, List, Phone } from "lucide-react";
import { cn } from "@/lib/utils";

interface DashboardMobileMenuProps {
  navigation: Array<{ name: string; href: string; icon: React.ComponentType<{ className?: string }> }>;
  onSignOut: () => void;
  isOpen: boolean;
  isSeller: boolean;
}

const DashboardMobileMenu = ({ navigation, onSignOut, isOpen, isSeller }: DashboardMobileMenuProps) => {
  const location = useLocation();
  
  if (!isOpen) return null;

  // Filter navigation items based on user role
  const filteredNavigation = navigation.filter(item => {
    // Filter out seller-only routes for buyers
    if (!isSeller && (
      item.href === "/inventory" || 
      item.href === "/profile"
    )) {
      return false;
    }
    return true;
  });

  // Enhance navigation with additional icons for specific routes
  const enhancedNavigation = filteredNavigation.map(item => {
    // Add custom icons for specific routes
    if (item.href === "/vehicles" || item.name.toLowerCase().includes("trucks")) {
      return { ...item, icon: Truck };
    }
    if (item.href === "/contact" || item.name.toLowerCase().includes("contact")) {
      return { ...item, icon: Phone };
    }
    return item;
  });

  return (
    <div className="md:hidden fixed inset-x-0 top-16 z-40 bg-white/95 backdrop-blur-sm shadow-lg">
      <div className="container mx-auto px-4 py-3 space-y-2 max-h-[calc(100vh-64px)] overflow-y-auto">
        {enhancedNavigation.map((item) => (
          <Link
            key={item.name}
            to={item.href}
            className={cn(
              "flex items-center py-3 px-4 rounded-md text-base font-medium",
              location.pathname === item.href || 
              (item.href === "/messages" && location.pathname.startsWith("/messages/"))
                ? "bg-indigo-50 text-brand-lightBlue"
                : "text-gray-600 hover:bg-gray-50 hover:text-brand-blue"
            )}
          >
            <item.icon className="h-5 w-5 mr-3 flex-shrink-0 text-brand-lightBlue" />
            <span>{item.name}</span>
          </Link>
        ))}
        {isSeller && (
          <Link
            to="/create-listing"
            className="flex items-center py-3 px-4 rounded-md text-base font-medium text-white bg-gradient-to-r from-brand-blue to-brand-lightBlue"
          >
            <Plus className="h-5 w-5 mr-3 flex-shrink-0" />
            <span>New Listing</span>
          </Link>
        )}
        {isSeller && (
          <Link
            to="/settings?tab=credits"
            className="flex items-center py-3 px-4 rounded-md text-base font-medium border border-indigo-100"
          >
            <CreditCard className="h-5 w-5 mr-3 flex-shrink-0 text-brand-lightBlue" />
            <span>Credits</span>
          </Link>
        )}
        <button
          onClick={onSignOut}
          className="flex w-full items-center py-3 px-4 rounded-md text-base font-medium text-red-600 hover:bg-red-50"
        >
          <LogOut className="h-5 w-5 mr-3 flex-shrink-0" />
          <span>Log out</span>
        </button>
      </div>
    </div>
  );
};

export default DashboardMobileMenu;
