
import React, { useEffect, useRef, useState } from 'react';
import HCaptcha from '@hcaptcha/react-hcaptcha';
import { supabase } from '@/integrations/supabase/client';

interface HCaptchaFieldProps {
  onChange: (token: string | null) => void;
  error?: string;
}

const HCaptchaField: React.FC<HCaptchaFieldProps> = ({ onChange, error }) => {
  const [siteKey, setSiteKey] = useState<string>("");
  const captchaRef = useRef<HCaptcha>(null);
  const [scriptLoaded, setScriptLoaded] = useState(false);
  const [domainError, setDomainError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  
  // Fetch site key from Supabase secrets on component mount
  useEffect(() => {
    const fetchSiteKey = async () => {
      try {
        console.log("Fetching hCaptcha site key from Supabase secrets...");
        const { data, error } = await supabase.functions.invoke('get-hcaptcha-site-key');
        
        console.log("hCaptcha site key response:", { data, error });
        
        if (data?.siteKey && !error) {
          setSiteKey(data.siteKey);
          console.log("hCaptcha site key loaded successfully from Supabase secrets");
        } else {
          console.error("Failed to load hCaptcha site key:", error);
          setDomainError("Failed to load hCaptcha configuration. Please refresh the page.");
        }
      } catch (error) {
        console.error("Error fetching hCaptcha site key:", error);
        setDomainError("Failed to load hCaptcha configuration. Please refresh the page.");
      } finally {
        setIsLoading(false);
      }
    };

    fetchSiteKey();
  }, []);
  
  // Log domain and key info
  useEffect(() => {
    if (siteKey) {
      const currentDomain = window.location.hostname;
      console.log("Current domain for hCaptcha:", currentDomain);
      console.log("Using hCaptcha site key:", siteKey.substring(0, 8) + "...");
    }
  }, [siteKey]);

  const handleVerificationSuccess = (token: string) => {
    console.log(`hCaptcha response received, length: ${token.length}`);
    setDomainError(null);
    onChange(token);
  };

  // Show loading state while fetching site key
  if (isLoading) {
    return (
      <div className="space-y-2" data-testid="hcaptcha-container">
        <div className="text-sm text-gray-600 p-2 bg-gray-50 border border-gray-200 rounded">
          Loading hCaptcha...
        </div>
      </div>
    );
  }

  // Show error if we couldn't load the site key
  if (!siteKey) {
    return (
      <div className="space-y-2" data-testid="hcaptcha-container">
        <div className="text-sm text-red-600 p-2 bg-red-50 border border-red-200 rounded">
          Failed to load hCaptcha configuration. Please refresh the page and try again.
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-2" data-testid="hcaptcha-container">
      {domainError && (
        <div className="text-sm text-red-600 mb-2 p-2 bg-red-50 border border-red-200 rounded">
          {domainError}
        </div>
      )}
      
      <HCaptcha
        ref={captchaRef}
        sitekey={siteKey}
        onVerify={handleVerificationSuccess}
        onError={(err) => {
          console.error("hCaptcha error:", err);
          setDomainError("Error loading hCaptcha. Please refresh the page and try again.");
          onChange(null);
        }}
        onLoad={() => {
          console.log("hCaptcha widget loaded");
          setScriptLoaded(true);
          setDomainError(null);
        }}
      />
      
      {error && !domainError && (
        <p className="text-sm text-red-500">{error}</p>
      )}
    </div>
  );
};

export default HCaptchaField;
