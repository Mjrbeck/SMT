
import React, { useEffect, useState } from "react";
import { Truck, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";

interface TruckAnimationProps {
  size?: number;
  className?: string;
  onComplete?: () => void;
  animated?: boolean;
}

const TruckAnimation = ({ 
  size = 64, 
  className, 
  onComplete, 
  animated = false 
}: TruckAnimationProps) => {
  const [isAnimationComplete, setIsAnimationComplete] = useState(false);

  useEffect(() => {
    if (isAnimationComplete && onComplete) {
      const timer = setTimeout(() => {
        onComplete();
      }, 500);
      
      return () => clearTimeout(timer);
    }
  }, [isAnimationComplete, onComplete]);

  if (!animated) {
    return (
      <div className="relative overflow-hidden w-full h-24 my-4">
        <div className={cn("absolute opacity-10", className)}>
          <Truck 
            size={size * 3} 
            className="text-brand-blue" 
          />
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-white/90 backdrop-blur-sm">
      <div className="flex flex-col items-center text-center max-w-md px-4">
        <motion.div
          initial={{ x: -300, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ duration: 1 }}
          onAnimationComplete={() => {
            setTimeout(() => setIsAnimationComplete(true), 1500);
          }}
        >
          <div className="relative">
            <Truck size={size * 1.5} className="text-brand-blue" />
            <motion.div 
              className="absolute -top-2 -right-2"
              initial={{ scale: 0 }}
              animate={{ scale: [0, 1.2, 1] }}
              transition={{ delay: 0.8, duration: 0.5 }}
            >
              <Sparkles size={24} className="text-amber-500" />
            </motion.div>
          </div>
        </motion.div>
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1, duration: 0.5 }}
          className="mt-6"
        >
          <h2 className="text-2xl font-bold text-brand-blue mb-2">Success!</h2>
          <p className="text-gray-600">
            Your vehicle listing has been created and is now live!
          </p>
        </motion.div>
      </div>
    </div>
  );
};

export default TruckAnimation;
