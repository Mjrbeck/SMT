import { useState, useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { Search, MapPin, Truck, PoundSterling } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel 
} from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";

const formSchema = z.object({
  keyword: z.string().optional(),
  make: z.string().optional(),
  priceMax: z.string().optional(),
  bodyType: z.string().optional(),
  location: z.string().optional(),
  radius: z.string().optional(),
});

type FormValues = z.infer<typeof formSchema>;

const SearchBox = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [expanded, setExpanded] = useState(false);
  
  // Get initial values from URL params
  const initialValues = {
    keyword: searchParams.get("keyword") || "",
    make: searchParams.get("make") || "",
    priceMax: searchParams.get("priceMax") || "",
    bodyType: searchParams.get("bodyType") || "",
    location: searchParams.get("location") || "",
    radius: searchParams.get("radius") || "50",
  };

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: initialValues,
  });

  // Update form values when URL params change
  useEffect(() => {
    form.reset({
      keyword: searchParams.get("keyword") || "",
      make: searchParams.get("make") || "",
      priceMax: searchParams.get("priceMax") || "",
      bodyType: searchParams.get("bodyType") || "",
      location: searchParams.get("location") || "",
      radius: searchParams.get("radius") || "50",
    });
  }, [searchParams, form]);

  const onSubmit = (data: FormValues) => {
    // Build query params
    const params = new URLSearchParams();
    
    if (data.keyword) params.set("keyword", data.keyword);
    if (data.make) params.set("make", data.make);
    if (data.priceMax) params.set("priceMax", data.priceMax);
    if (data.bodyType) params.set("bodyType", data.bodyType);
    if (data.location) params.set("location", data.location);
    if (data.radius) params.set("radius", data.radius);
    
    // Navigate to listings page with search params
    navigate(`/listings?${params.toString()}`);
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100">
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          {/* Top Row - Always visible */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Keyword Search */}
            <FormField
              control={form.control}
              name="keyword"
              render={({ field }) => (
                <FormItem>
                  <div className="flex items-center h-5 mb-1">
                    <Search className="h-4 w-4 mr-2 text-gray-500" />
                    <FormLabel className="text-gray-600 font-medium">Search</FormLabel>
                  </div>
                  <FormControl>
                    <Input 
                      placeholder="Make, model, or keyword" 
                      {...field} 
                      className="h-10"
                    />
                  </FormControl>
                </FormItem>
              )}
            />
            
            {/* Make Dropdown */}
            <FormField
              control={form.control}
              name="make"
              render={({ field }) => (
                <FormItem>
                  <div className="flex items-center h-5 mb-1">
                    <Truck className="h-4 w-4 mr-2 text-gray-500" />
                    <FormLabel className="text-gray-600 font-medium">Make</FormLabel>
                  </div>
                  <Select 
                    onValueChange={field.onChange} 
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger className="h-10">
                        <SelectValue placeholder="Any make" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="any_make">Any make</SelectItem>
                      <SelectItem value="daf">DAF</SelectItem>
                      <SelectItem value="man">MAN</SelectItem>
                      <SelectItem value="mercedes">Mercedes</SelectItem>
                      <SelectItem value="scania">Scania</SelectItem>
                      <SelectItem value="volvo">Volvo</SelectItem>
                      <SelectItem value="iveco">Iveco</SelectItem>
                      <SelectItem value="renault">Renault</SelectItem>
                    </SelectContent>
                  </Select>
                </FormItem>
              )}
            />
            
            {/* Max Price */}
            <FormField
              control={form.control}
              name="priceMax"
              render={({ field }) => (
                <FormItem>
                  <div className="flex items-center h-5 mb-1">
                    <PoundSterling className="h-4 w-4 mr-2 text-gray-500" />
                    <FormLabel className="text-gray-600 font-medium">Max Price</FormLabel>
                  </div>
                  <Select 
                    onValueChange={field.onChange} 
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger className="h-10">
                        <SelectValue placeholder="No limit" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="no_limit">No limit</SelectItem>
                      <SelectItem value="10000">£10,000</SelectItem>
                      <SelectItem value="20000">£20,000</SelectItem>
                      <SelectItem value="30000">£30,000</SelectItem>
                      <SelectItem value="40000">£40,000</SelectItem>
                      <SelectItem value="50000">£50,000</SelectItem>
                      <SelectItem value="75000">£75,000</SelectItem>
                      <SelectItem value="100000">£100,000</SelectItem>
                    </SelectContent>
                  </Select>
                </FormItem>
              )}
            />
          </div>
          
          {/* Expanded Fields */}
          {expanded && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
              {/* Body Type */}
              <FormField
                control={form.control}
                name="bodyType"
                render={({ field }) => (
                  <FormItem>
                    <div className="flex items-center h-5 mb-1">
                      <div className="w-4 mr-2"></div> {/* Empty space for alignment */}
                      <FormLabel className="text-gray-600 font-medium">Body Type</FormLabel>
                    </div>
                    <Select 
                      onValueChange={field.onChange} 
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger className="h-10">
                          <SelectValue placeholder="Any type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="any_type">Any type</SelectItem>
                        <SelectItem value="box-van">Box Van</SelectItem>
                        <SelectItem value="curtainsider">Curtainsider</SelectItem>
                        <SelectItem value="dropside">Dropside</SelectItem>
                        <SelectItem value="flatbed">Flatbed</SelectItem>
                        <SelectItem value="tipper">Tipper</SelectItem>
                        <SelectItem value="tractor-unit">Tractor Unit</SelectItem>
                        <SelectItem value="luton">Luton</SelectItem>
                        <SelectItem value="skip-loader">Skip Loader</SelectItem>
                        <SelectItem value="hook-loader">Hook Loader</SelectItem>
                        <SelectItem value="refrigerated">Refrigerated</SelectItem>
                        <SelectItem value="tanker">Tanker</SelectItem>
                        <SelectItem value="crane">Crane</SelectItem>
                        <SelectItem value="recovery">Recovery</SelectItem>
                        <SelectItem value="crew-cab">Crew Cab</SelectItem>
                        <SelectItem value="municipal">Municipal</SelectItem>
                      </SelectContent>
                    </Select>
                  </FormItem>
                )}
              />
              
              {/* Location */}
              <FormField
                control={form.control}
                name="location"
                render={({ field }) => (
                  <FormItem>
                    <div className="flex items-center h-5 mb-1">
                      <MapPin className="h-4 w-4 mr-2 text-gray-500" />
                      <FormLabel className="text-gray-600 font-medium">Location</FormLabel>
                    </div>
                    <FormControl>
                      <Input 
                        placeholder="Postcode" 
                        {...field} 
                        className="h-10"
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
              
              {/* Radius */}
              <FormField
                control={form.control}
                name="radius"
                render={({ field }) => (
                  <FormItem>
                    <div className="flex items-center h-5 mb-1">
                      <div className="w-4 mr-2"></div> {/* Empty space for alignment */}
                      <FormLabel className="text-gray-600 font-medium">Distance</FormLabel>
                    </div>
                    <Select 
                      onValueChange={field.onChange} 
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger className="h-10">
                          <SelectValue placeholder="50 miles" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="10">10 miles</SelectItem>
                        <SelectItem value="25">25 miles</SelectItem>
                        <SelectItem value="50">50 miles</SelectItem>
                        <SelectItem value="100">100 miles</SelectItem>
                        <SelectItem value="200">200 miles</SelectItem>
                        <SelectItem value="nationwide">Nationwide</SelectItem>
                      </SelectContent>
                    </Select>
                  </FormItem>
                )}
              />
            </div>
          )}
          
          <div className="flex justify-between items-center pt-2">
            <Button 
              type="button" 
              variant="ghost" 
              onClick={() => setExpanded(!expanded)}
              className="text-brand-blue hover:text-brand-blue/90"
            >
              {expanded ? "Less options" : "More options"}
            </Button>
            
            <Button type="submit" className="bg-brand-blue hover:bg-brand-blue/90">
              Search
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
};

export default SearchBox;
