
// Export all consistent UI components from here
export { StyledButton } from "@/components/ui/styled-button";
export { default as StyledCard } from "@/components/ui/styled-card";
export { default as PageHeader } from "@/components/layouts/PageHeader";
