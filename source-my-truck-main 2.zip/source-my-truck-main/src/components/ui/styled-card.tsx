import React from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { LucideIcon } from "lucide-react";
interface StyledCardProps {
  title?: string;
  description?: string;
  children: React.ReactNode;
  footer?: React.ReactNode;
  className?: string;
  contentClassName?: string;
  icon?: React.ReactNode;
}

/**
 * A styled card component matching the appearance of cards in the Create Listing page
 */
const StyledCard = ({
  title,
  description,
  children,
  footer,
  className,
  contentClassName,
  icon
}: StyledCardProps) => {
  return <div className="relative">
      {icon}
      
      <Card className={cn("border-2 border-muted shadow-md", icon && "pt-2", className)}>
        {(title || description) && <CardHeader>
            {title && <CardTitle className="text-xl font-semibold">{title}</CardTitle>}
            {description && <CardDescription>{description}</CardDescription>}
          </CardHeader>}
        
        <CardContent className={cn(contentClassName)}>
          {children}
        </CardContent>
        
        {footer && <CardFooter>
            {footer}
          </CardFooter>}
      </Card>
    </div>;
};
export default StyledCard;