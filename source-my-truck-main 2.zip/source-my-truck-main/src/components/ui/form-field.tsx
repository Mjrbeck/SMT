
import React from "react";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import { Info } from "lucide-react";

interface FormFieldProps extends React.InputHTMLAttributes<HTMLInputElement> {
  id: string;
  label: string;
  error?: string;
  loading?: boolean;
  className?: string;
  labelClassName?: string;
  inputClassName?: string;
  errorClassName?: string;
  tooltip?: string;
  required?: boolean;
}

const FormField = React.forwardRef<HTMLInputElement, FormFieldProps>(
  ({ 
    id, 
    label, 
    error, 
    loading, 
    className, 
    labelClassName, 
    inputClassName, 
    errorClassName,
    tooltip,
    required,
    ...props 
  }, ref) => {
    return (
      <div className={cn("space-y-2", className)}>
        <div className="flex items-center gap-1">
          <Label 
            htmlFor={id} 
            className={cn(error && "text-red-500", labelClassName)}
          >
            {label} {required && <span className="text-red-500">*</span>}
          </Label>
          
          {tooltip && (
            <div className="group relative">
              <Info className="h-4 w-4 text-muted-foreground cursor-help" />
              <div className="absolute left-1/2 -translate-x-1/2 bottom-full mb-2 hidden group-hover:block w-48 p-2 text-xs text-gray-700 bg-white border border-gray-200 rounded-md shadow-sm">
                {tooltip}
              </div>
            </div>
          )}
        </div>
        
        <Input
          id={id}
          ref={ref}
          disabled={loading || props.disabled}
          className={cn(
            "transition-all duration-300 focus:ring-2 focus:ring-brand-blue",
            error && "border-red-500",
            inputClassName
          )}
          aria-invalid={!!error}
          aria-describedby={error ? `${id}-error` : undefined}
          {...props}
        />
        
        {error && (
          <p 
            id={`${id}-error`} 
            className={cn("text-sm text-red-500", errorClassName)}
          >
            {error}
          </p>
        )}
      </div>
    );
  }
);

FormField.displayName = "FormField";

export { FormField };
