
import React from "react";
import { Button, ButtonProps } from "@/components/ui/button";
import { cn } from "@/lib/utils";

// Create a new type for our custom variants
type StyledButtonVariant = "primary" | "secondary" | "outline" | "orange" | "blue";

// Create props interface that excludes the variant from ButtonProps
type ButtonPropsWithoutVariant = Omit<ButtonProps, "variant">;

// Then extend it with our custom variant
interface StyledButtonProps extends ButtonPropsWithoutVariant {
  variant?: StyledButtonVariant;
}

/**
 * Styled button component with consistent styling options
 * including the orange accent from the Create Listing page
 */
const StyledButton = React.forwardRef<HTMLButtonElement, StyledButtonProps>(
  ({ className, variant = "primary", ...props }, ref) => {
    const getVariantClasses = () => {
      switch (variant) {
        case "orange":
          return "bg-brand-orange hover:bg-brand-orange/90 text-white";
        case "blue":
          return "bg-brand-blue hover:bg-brand-blue/90 text-white";
        case "primary":
          return "bg-primary text-primary-foreground hover:bg-primary/90";
        case "secondary":
          return "bg-secondary text-secondary-foreground hover:bg-secondary/80";
        case "outline":
          return "border border-input bg-background hover:bg-accent hover:text-accent-foreground";
        default:
          return "";
      }
    };

    // Map our custom variant to the underlying Button component's variant
    const buttonVariant = variant === "primary" 
      ? "default" 
      : (variant === "outline" || variant === "secondary" 
          ? variant 
          : undefined);

    return (
      <Button
        ref={ref}
        className={cn(
          "shadow-sm transition-all duration-300 hover:shadow-md",
          getVariantClasses(),
          className
        )}
        variant={buttonVariant}
        {...props}
      />
    );
  }
);

StyledButton.displayName = "StyledButton";

export { StyledButton };
