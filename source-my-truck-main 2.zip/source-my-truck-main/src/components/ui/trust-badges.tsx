import React from "react";
import { Badge } from "@/components/ui/badge";
import { Shield, Award, Star } from "lucide-react";

interface TrustBadgesProps {
  isTrusted?: boolean;
  depotVerified?: boolean;
  hasMultipleListings?: boolean;
  size?: "sm" | "md";
  className?: string;
}

export const TrustBadges: React.FC<TrustBadgesProps> = ({
  isTrusted = false,
  depotVerified = false,
  hasMultipleListings = false,
  size = "sm",
  className = ""
}) => {
  const badges = [];

  if (isTrusted) {
    badges.push(
      <Badge 
        key="trusted" 
        className={`bg-blue-50 text-blue-700 border-blue-300 hover:bg-blue-100 ${size === 'sm' ? 'text-xs px-2 py-1' : 'text-sm px-3 py-1'} font-medium`}
      >
        <Shield className={`${size === 'sm' ? 'h-3 w-3' : 'h-4 w-4'} mr-1 text-blue-600`} />
        Trusted Seller
      </Badge>
    );
  }

  if (depotVerified) {
    badges.push(
      <Badge 
        key="depot" 
        className={`bg-amber-50 text-amber-700 border-amber-300 hover:bg-amber-100 ${size === 'sm' ? 'text-xs px-2 py-1' : 'text-sm px-3 py-1'} font-medium`}
      >
        <Award className={`${size === 'sm' ? 'h-3 w-3' : 'h-4 w-4'} mr-1 text-amber-600`} />
        Depot Verified
      </Badge>
    );
  }

  if (hasMultipleListings) {
    badges.push(
      <Badge 
        key="multiple" 
        className={`bg-orange-100 text-orange-800 border-orange-200 hover:bg-orange-200 ${size === 'sm' ? 'text-xs px-2 py-1' : 'text-sm px-3 py-1'}`}
      >
        <Star className={`${size === 'sm' ? 'h-3 w-3' : 'h-4 w-4'} mr-1`} />
        Multiple Listings
      </Badge>
    );
  }

  if (badges.length === 0) return null;

  return (
    <div className={`flex flex-wrap gap-1 ${className}`}>
      {badges}
    </div>
  );
};