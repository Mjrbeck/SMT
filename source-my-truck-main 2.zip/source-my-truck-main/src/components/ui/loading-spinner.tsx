
import { Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";

interface LoadingSpinnerProps {
  size?: number;
  className?: string;
  text?: string;
}

/**
 * Reusable loading spinner component with optional text
 */
export const LoadingSpinner = ({ 
  size = 24, 
  className, 
  text 
}: LoadingSpinnerProps) => {
  return (
    <div className="flex flex-col items-center justify-center">
      <Loader2 
        className={cn(
          "animate-spin text-primary", 
          text && "mb-2",
          className
        )} 
        size={size}
      />
      {text && <p className="text-gray-600 text-sm">{text}</p>}
    </div>
  );
};

export default LoadingSpinner;
