
import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.tsx'
import './index.css'
import { BrowserRouter } from 'react-router-dom'
import NotFoundHandler from './components/seo/NotFoundHandler.tsx'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import ErrorBoundary from './components/ErrorBoundary.tsx'

// Create a client with proper configuration and error handling
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 5 * 60 * 1000, // 5 minutes
      retry: 1,
      refetchOnWindowFocus: false,
    },
  },
})

// Handle page visibility changes
const handleVisibilityChange = (e: Event) => {
  if (e) e.preventDefault();
  
  if (process.env.NODE_ENV === 'development') {
    console.log('Document visibility changed:', document.visibilityState);
  }
};

document.addEventListener('visibilitychange', handleVisibilityChange, { passive: false });

// Determine if we should use the prerender version
const shouldUsePrerender = false; // Simplified - bot detection now handled in BotRedirector component

if (shouldUsePrerender) {
  console.log('Using prerender version for crawler or fragment detection');
}

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <ErrorBoundary>
      <QueryClientProvider client={queryClient}>
        <BrowserRouter>
          <NotFoundHandler>
            <App />
          </NotFoundHandler>
        </BrowserRouter>
      </QueryClientProvider>
    </ErrorBoundary>
  </React.StrictMode>,
)
