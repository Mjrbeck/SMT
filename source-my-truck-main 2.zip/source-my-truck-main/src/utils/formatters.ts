
/**
 * Format a number as a price in GBP
 */
export const formatPrice = (price: number | null | undefined): string => {
  // Handle null, undefined, or zero price
  if (price === null || price === undefined || price === 0) {
    return "POA";
  }
  
  // Make sure price is a valid number
  if (isNaN(price)) {
    return "POA";
  }
  
  return new Intl.NumberFormat('en-GB', {
    style: 'currency',
    currency: 'GBP',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(price);
};

/**
 * Format a date as a readable string
 */
export const formatDate = (date: string | Date): string => {
  return new Date(date).toLocaleDateString('en-GB', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });
};

/**
 * Format an expiration date with relative time indication
 */
export const formatExpirationDate = (date: string | Date): string => {
  const expirationDate = new Date(date);
  const now = new Date();
  const daysLeft = Math.ceil((expirationDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
  
  const formattedDate = formatDate(date);
  
  if (daysLeft < 0) {
    return `Expired on ${formattedDate}`;
  } else if (daysLeft === 0) {
    return `Expires today (${formattedDate})`;
  } else if (daysLeft === 1) {
    return `Expires tomorrow (${formattedDate})`;
  } else {
    return `Expires in ${daysLeft} days (${formattedDate})`;
  }
};

/**
 * Capitalize the first letter of a string
 */
export const capitalizeFirstLetter = (string: string): string => {
  return string.charAt(0).toUpperCase() + string.slice(1);
};

/**
 * Format a price value or show "POA" (Price on Application)
 */
export const formatPriceOrPOA = (price: number | null | undefined, isPOA: boolean): string => {
  if (isPOA || price === 0 || price === null || price === undefined) {
    return "POA";
  }
  return formatPrice(price);
};
