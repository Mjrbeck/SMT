
import { VehicleData } from "@/components/VehicleCard";
import { VehicleWithImages } from "@/services/types";
import { processImageUrls, getPlaceholderImage } from "./imageUtils";

export const VEHICLE_BODY_TYPES = [
  "Ambulance Body",
  "Box/Van Body (Rigid or Luton)",
  "Car Transporter",
  "Crane Lorry (Hiab)",
  "Curtain Side Truck",
  "Dump Truck",
  "Dropside Truck",
  "Fire Truck",
  "Flatbed Truck",
  "Hook Loader (RoRo)",
  "Livestock Truck",
  "Logging Truck",
  "Mixer Truck (Concrete Mixer)",
  "Recovery Truck",
  "Refrigerated Truck (Reefer)",
  "Refuse Collection Vehicle (RCV)",
  "Road Sweeper",
  "Skip Loader",
  "Tanker Truck",
  "Tipper Truck",
  "Utility Service Truck"
] as const;

export const getBodyTypeValue = (type: string): string => {
  return type.toLowerCase().replace(/\s+/g, '-');
};

export const convertToVehicleData = (vehicleWithImages: VehicleWithImages): VehicleData => {
  // Process images with fallbacks
  const { mainImage, additionalImages } = processImageUrls(
    vehicleWithImages.vehicle_images.map(img => ({
      image_url: img.image_url || img.url || '',
      is_main: img.is_main
    }))
  );
  
  // Only use placeholders if the main image is completely invalid
  const validatedMainImage = mainImage && mainImage.trim() !== ""
    ? mainImage
    : getPlaceholderImage(0);
  
  // Only filter out completely invalid images
  const validatedAdditionalImages = additionalImages
    .filter(img => img && img.trim() !== "");
  
  // Convert all numeric strings to numbers where appropriate
  const year = typeof vehicleWithImages.year === 'string' 
    ? parseInt(vehicleWithImages.year, 10) 
    : vehicleWithImages.year;
    
  const mileage = typeof vehicleWithImages.mileage === 'string' || typeof vehicleWithImages.mileage === 'number'
    ? parseInt(String(vehicleWithImages.mileage), 10) 
    : 0; // Default to 0 if undefined
  
  // Convert fields that might be string or number to number
  const convertToNumber = (value: string | number | undefined): number | undefined => {
    if (value === undefined) return undefined;
    if (typeof value === 'number') return value;
    const parsed = parseFloat(value);
    return isNaN(parsed) ? undefined : parsed;
  };

  const vehiclePrice = typeof vehicleWithImages.price === 'string' 
    ? parseFloat(vehicleWithImages.price) 
    : (vehicleWithImages.price || 0);
  
  return {
    id: vehicleWithImages.id,
    title: vehicleWithImages.title,
    description: vehicleWithImages.description || "",
    price: vehiclePrice,
    location: vehicleWithImages.location || "",
    year: year || 0,
    make: vehicleWithImages.make,
    model: vehicleWithImages.model,
    mileage: mileage,
    engineSize: vehicleWithImages.engine_size,
    fuelType: vehicleWithImages.fuel_type,
    transmission: vehicleWithImages.transmission,
    weight: convertToNumber(vehicleWithImages.weight),
    imageUrl: validatedMainImage,
    features: vehicleWithImages.features || [],
    bodyType: vehicleWithImages.body_type || undefined,
    axleConfiguration: vehicleWithImages.axle_configuration || undefined,
    additionalImages: validatedAdditionalImages,
    user_id: vehicleWithImages.user_id,
    isPOA: vehicleWithImages.is_poa || false,
    status: vehicleWithImages.status as 'active' | 'draft' || 'active',
    expires_at: vehicleWithImages.expires_at,
    created_at: vehicleWithImages.created_at,
    updated_at: vehicleWithImages.updated_at,
    registration: vehicleWithImages.registration,
    
    // Map all fields from the database to our UI model with proper type handling
    interiorCondition: vehicleWithImages.interior_condition || undefined,
    exteriorCondition: vehicleWithImages.exterior_condition || undefined,
    cabType: vehicleWithImages.cab_type || undefined,
    driverPosition: vehicleWithImages.driver_position || undefined,
    enginePower: vehicleWithImages.engine_power || undefined,
    emissionsClass: vehicleWithImages.emissions_class || undefined,
    color: vehicleWithImages.color || undefined,
    numberOfSeats: convertToNumber(vehicleWithImages.number_of_seats),
    grossVehicleWeight: convertToNumber(vehicleWithImages.gross_vehicle_weight),
    volume: vehicleWithImages.volume || undefined,
    internalLength: convertToNumber(vehicleWithImages.internal_length),
    internalWidth: convertToNumber(vehicleWithImages.internal_width),
    internalHeight: convertToNumber(vehicleWithImages.internal_height),
    externalLength: convertToNumber(vehicleWithImages.external_length),
    externalWidth: convertToNumber(vehicleWithImages.external_width),
    externalHeight: convertToNumber(vehicleWithImages.external_height),
    isNew: vehicleWithImages.is_new || false,
    youtubeUrl: vehicleWithImages.youtube_url || undefined,
    videoUrl: vehicleWithImages.video_url || undefined
  };
};

/**
 * Prepares vehicle images from a VehicleData object, handling all image sources
 */
export const prepareVehicleImages = (vehicle: any): string[] => {
  const images: string[] = [];
  
  // First check for vehicle_images with is_main flag
  if (Array.isArray(vehicle.vehicle_images) && vehicle.vehicle_images.length > 0) {
    // Add main image first if it exists
    const mainImage = vehicle.vehicle_images.find((img: any) => img.is_main === true);
    if (mainImage && (mainImage.image_url || mainImage.url)) {
      const imageUrl = mainImage.image_url || mainImage.url;
      if (imageUrl && !images.includes(imageUrl)) {
        images.push(imageUrl);
      }
    }
    
    // Add remaining images
    vehicle.vehicle_images.forEach((img: any) => {
      // Skip main image as it's already added
      if (img.is_main === true) return;
      
      const imageUrl = img.image_url || img.url;
      if (imageUrl && !images.includes(imageUrl)) {
        images.push(imageUrl);
      }
    });
  }
  
  // If no images from vehicle_images, fallback to other sources
  if (images.length === 0) {
    // Add main image if it exists
    if (vehicle.imageUrl && vehicle.imageUrl.trim() !== '') {
      images.push(vehicle.imageUrl);
    }
    
    // Add additional images if they exist
    if (Array.isArray(vehicle.additionalImages)) {
      vehicle.additionalImages.forEach((img: string) => {
        // Avoid duplicates and empty strings
        if (img && img.trim() !== '' && !images.includes(img)) {
          images.push(img);
        }
      });
    }
  }
  
  // If no images found, add a placeholder
  if (images.length === 0) {
    images.push("/placeholder.svg");
  }
  
  return images;
};

/**
 * Get safe vehicle image data with fallbacks
 */
export const getVehicleImageData = (vehicle: any) => {
  // Handle main image with priority for is_main flag
  let mainImage = null;
  
  // High priority: Look for vehicle_images with is_main flag
  if (Array.isArray(vehicle.vehicle_images) && vehicle.vehicle_images.length > 0) {
    // First, try to find the main image
    const mainImageObj = vehicle.vehicle_images.find((img: any) => img.is_main === true);
    
    if (mainImageObj && (mainImageObj.image_url || mainImageObj.url)) {
      mainImage = mainImageObj.image_url || mainImageObj.url;
    } else {
      // If no main image found, use the first available image
      for (const img of vehicle.vehicle_images) {
        if (img && (img.image_url || img.url)) {
          mainImage = img.image_url || img.url;
          break;
        }
      }
    }
  }
  
  // Medium priority: Check imageUrl property
  if (!mainImage && vehicle.imageUrl) {
    mainImage = vehicle.imageUrl;
  } 
  
  // Lower priority: Check additionalImages array
  if (!mainImage && Array.isArray(vehicle.additionalImages) && vehicle.additionalImages.length > 0) {
    for (const img of vehicle.additionalImages) {
      if (img && typeof img === 'string' && img.trim() !== '') {
        mainImage = img;
        break;
      }
    }
  }
  
  // Get all images without duplicates
  const allImages = prepareVehicleImages(vehicle);
  
  return {
    mainImage,
    allImages,
    totalImages: allImages.length
  };
};
