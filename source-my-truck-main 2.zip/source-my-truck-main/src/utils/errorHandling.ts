
type ErrorWithMessage = {
  message: string;
};

/**
 * Type guard to check if an error has a message property
 */
function isErrorWithMessage(error: unknown): error is ErrorWithMessage {
  return (
    typeof error === 'object' &&
    error !== null &&
    'message' in error &&
    typeof (error as Record<string, unknown>).message === 'string'
  );
}

/**
 * Convert unknown error to an error with a readable message
 */
export function toErrorWithMessage(maybeError: unknown): ErrorWithMessage {
  if (isErrorWithMessage(maybeError)) return maybeError;
  
  try {
    return new Error(JSON.stringify(maybeError));
  } catch {
    // Fallback in case there's an error stringifying the maybeError
    // Like with circular references for example
    return new Error(String(maybeError));
  }
}

/**
 * Extract error message from unknown error
 */
export function getErrorMessage(error: unknown): string {
  return toErrorWithMessage(error).message;
}

/**
 * Check if error is a Supabase error and categorize it
 */
export function categorizeSupabaseError(error: unknown): {
  type: 'auth' | 'database' | 'storage' | 'edge-function' | 'unknown';
  code?: string;
  message: string;
  originalError: unknown;
} {
  const errorWithMessage = toErrorWithMessage(error);
  const message = errorWithMessage.message;
  
  // Handle authentication errors
  if (message.includes('auth/') || 
      message.includes('email') || 
      message.includes('password') ||
      message.includes('JWT') ||
      message.includes('token')) {
    return {
      type: 'auth',
      message: getAuthErrorMessage(message),
      originalError: error
    };
  }
  
  // Handle database errors
  if (message.includes('duplicate key') || 
      message.includes('violates foreign key') || 
      message.includes('PGRST') ||
      message.includes('constraint')) {
    return {
      type: 'database',
      message: getDatabaseErrorMessage(message),
      originalError: error
    };
  }
  
  // Handle storage errors
  if (message.includes('storage/') || message.includes('bucket')) {
    return {
      type: 'storage',
      message: getStorageErrorMessage(message),
      originalError: error
    };
  }
  
  // Handle edge function errors
  if (message.includes('function/') || message.includes('edge function')) {
    return {
      type: 'edge-function',
      message: getEdgeFunctionErrorMessage(message),
      originalError: error
    };
  }
  
  // Default unknown error
  return {
    type: 'unknown',
    message: 'An unexpected error occurred. Please try again.',
    originalError: error
  };
}

/**
 * Get user-friendly message for auth errors
 */
function getAuthErrorMessage(message: string): string {
  if (message.includes('invalid login')) {
    return 'Invalid email or password. Please check your credentials and try again.';
  }
  
  if (message.includes('email not confirmed')) {
    return 'Please verify your email address before signing in.';
  }
  
  if (message.includes('already registered')) {
    return 'This email is already registered. Please use a different email or try to sign in.';
  }
  
  if (message.includes('invalid token')) {
    return 'Your session has expired. Please sign in again.';
  }
  
  return 'Authentication error. Please try again.';
}

/**
 * Get user-friendly message for database errors
 */
function getDatabaseErrorMessage(message: string): string {
  if (message.includes('duplicate key')) {
    return 'This record already exists. Please try with different information.';
  }
  
  if (message.includes('violates foreign key')) {
    return 'Unable to complete this operation because referenced data is missing.';
  }
  
  if (message.includes('constraint')) {
    return 'Your request could not be processed due to data validation constraints.';
  }
  
  return 'Database error. Please try again.';
}

/**
 * Get user-friendly message for storage errors
 */
function getStorageErrorMessage(message: string): string {
  if (message.includes('file size')) {
    return 'The file is too large. Please upload a smaller file.';
  }
  
  if (message.includes('file type')) {
    return 'This file type is not supported. Please upload a different file.';
  }
  
  return 'File storage error. Please try again.';
}

/**
 * Get user-friendly message for edge function errors
 */
function getEdgeFunctionErrorMessage(message: string): string {
  if (message.includes('timeout')) {
    return 'The operation timed out. Please try again.';
  }
  
  return 'Error processing your request. Please try again.';
}
