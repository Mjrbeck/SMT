
import { supabase } from "@/integrations/supabase/client";

/**
 * Uploads an image to Supabase storage
 * @param file The file to upload
 * @param bucket The storage bucket to upload to
 * @param path The path within the bucket
 * @returns The URL of the uploaded image
 */
export const uploadImage = async (
  file: File,
  bucket: string = "vehicles",
  path: string = "images"
): Promise<string | null> => {
  try {
    // Generate a unique filename
    const fileExt = file.name.split(".").pop();
    const fileName = `${Math.random().toString(36).substring(2, 15)}_${Date.now()}.${fileExt}`;
    const filePath = `${path}/${fileName}`;

    // Upload the file
    const { data, error } = await supabase.storage
      .from(bucket)
      .upload(filePath, file, {
        cacheControl: "3600",
        upsert: false,
      });

    if (error) {
      console.error("Error uploading image:", error);
      return null;
    }

    // Get the public URL
    const { data: urlData } = supabase.storage
      .from(bucket)
      .getPublicUrl(data.path);

    return urlData.publicUrl;
  } catch (error) {
    console.error("Unexpected error uploading image:", error);
    return null;
  }
};

/**
 * Deletes an image from Supabase storage
 * @param url The URL of the image to delete
 * @returns Whether the deletion was successful
 */
export const deleteImage = async (url: string): Promise<boolean> => {
  try {
    // Extract the path from the URL
    const urlObj = new URL(url);
    const pathParts = urlObj.pathname.split("/");
    const bucket = pathParts[1]; // After the first slash
    const path = pathParts.slice(2).join("/"); // Everything after the bucket

    const { error } = await supabase.storage.from(bucket).remove([path]);

    if (error) {
      console.error("Error deleting image:", error);
      return false;
    }

    return true;
  } catch (error) {
    console.error("Unexpected error deleting image:", error);
    return false;
  }
};

/**
 * Prepare an image URL for social sharing by ensuring it is correctly formatted
 * and accessible. This handles both Supabase storage URLs and public assets.
 */
export const prepareSocialSharingImage = (imageUrl: string): string => {
  if (!imageUrl) {
    console.warn('Empty image URL provided to prepareSocialSharingImage');
    return `${typeof window !== 'undefined' ? window.location.origin : 'https://source-my-truck.vercel.app'}/source-my-truck-logo.png`;
  }
  
  // Handle data URLs
  if (imageUrl.startsWith('data:')) {
    return imageUrl;
  }
  
  // Check if it's already an absolute URL
  if (imageUrl.startsWith('http://') || imageUrl.startsWith('https://')) {
    // For Supabase URLs, ensure they are publicly accessible
    if (imageUrl.includes('supabase.co')) {
      return imageUrl;
    }
    return imageUrl;
  }
  
  // It's a relative URL, convert to absolute
  const baseUrl = typeof window !== 'undefined' ? window.location.origin : 'https://source-my-truck.vercel.app'; // Always use absolute HTTPS URL for social sharing
  
  // Ensure we're not using any lovable-uploads references
  if (imageUrl.includes('lovable-uploads')) {
    console.warn(`Using Source my Truck logo instead of ${imageUrl}`);
    return `${baseUrl}/source-my-truck-logo.png`;
  }
  
  // Otherwise assume it's a regular path
  return `${baseUrl}${imageUrl.startsWith('/') ? '' : '/'}${imageUrl}`;
};

/**
 * Get the best image to use for social sharing based on availability
 */
export const getSocialSharingImage = (mainImage?: string): string => {
  // If we have a main image and it's valid, ALWAYS use it (unless it's a lovable-uploads)
  if (mainImage && mainImage.trim() !== '' && !mainImage.includes('lovable-uploads')) {
    const processedImage = prepareSocialSharingImage(mainImage);
    return processedImage;
  }
  
  // Only fall back to logo if no valid image exists
  return `${typeof window !== 'undefined' ? window.location.origin : 'https://source-my-truck.vercel.app'}/source-my-truck-logo.png`;
};

/**
 * Preload an image to ensure it's cached
 * @param src The image URL to preload
 * @returns A promise that resolves when the image is loaded or rejects on error
 */
export const preloadImage = (src: string): Promise<Event> => {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = (event) => resolve(event);
    img.onerror = (error) => reject(error);
    img.src = src;
  });
};

/**
 * Get a placeholder image based on an index
 * @param index Index to determine which placeholder to use
 * @returns URL of a placeholder image
 */
export const getPlaceholderImage = (index: number): string => {
  const placeholders = [
    '/placeholder.svg',
    '/placeholder-alt.svg',
    '/vehicle-placeholder.png'
  ];
  
  const safeIndex = Math.abs(index) % placeholders.length;
  return placeholders[safeIndex];
};

/**
 * Process an array of image objects to extract main and additional images
 * @param images Array of image objects with urls and main flag
 * @returns Object containing mainImage and additionalImages
 */
export const processImageUrls = (images: Array<{image_url: string; is_main: boolean}>): {
  mainImage: string;
  additionalImages: string[];
} => {
  if (!images || !Array.isArray(images) || images.length === 0) {
    return {
      mainImage: '',
      additionalImages: []
    };
  }

  // Find the main image
  const mainImageObj = images.find(img => img.is_main === true);
  let mainImage = '';
  const additionalImages: string[] = [];

  if (mainImageObj && mainImageObj.image_url) {
    mainImage = mainImageObj.image_url;
  }

  // Collect all non-main images
  images.forEach(img => {
    // Simplified condition to handle is_main correctly
    if (img.image_url && !img.is_main) {
      additionalImages.push(img.image_url);
    }
  });

  // If no main image was found but we have images, use the first one
  if (!mainImage && additionalImages.length > 0) {
    mainImage = additionalImages.shift() || '';
  }

  return {
    mainImage,
    additionalImages
  };
};

/**
 * Validate an image URL and return it if valid, otherwise return a fallback
 * @param url The image URL to validate
 * @returns A valid image URL or fallback
 */
export const getValidImageUrl = (url: string): string => {
  if (!url || url.trim() === '') {
    return getPlaceholderImage(0);
  }
  
  // Handle relative URLs
  if (url.startsWith('/') && typeof window !== 'undefined') {
    return `${window.location.origin}${url}`;
  }
  
  // Return the URL if it seems valid
  return url;
};

/**
 * Get a fallback text based on the provided text or a default one
 * @param text The text to use if available
 * @returns The original text or a fallback
 */
export const getTextFallback = (text: string | undefined): string => {
  return text || 'No information available';
};
