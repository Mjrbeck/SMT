
/**
 * Utilities for location-based operations
 */

/**
 * Convert latitude/longitude from degrees to radians
 */
const toRadians = (degrees: number): number => {
  return degrees * (Math.PI / 180);
};

/**
 * Calculate distance between two coordinates using the Haversine formula
 * @param lat1 First latitude
 * @param lon1 First longitude
 * @param lat2 Second latitude
 * @param lon2 Second longitude
 * @returns Distance in miles
 */
export const calculateDistance = (
  lat1: number, 
  lon1: number, 
  lat2: number, 
  lon2: number
): number => {
  // Earth's radius in miles
  const earthRadius = 3958.8;
  
  const dLat = toRadians(lat2 - lat1);
  const dLon = toRadians(lon2 - lon1);
  
  const a = 
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRadians(lat1)) * Math.cos(toRadians(lat2)) * 
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distance = earthRadius * c;
  
  return distance;
};

/**
 * UK Postcode validation
 */
export const isValidUKPostcode = (postcode: string): boolean => {
  const postcodeRegex = /^[A-Z]{1,2}[0-9][A-Z0-9]? ?[0-9][A-Z]{2}$/i;
  return postcodeRegex.test(postcode);
};

/**
 * Parse coordinates from string format
 * @param coordinateString String in format "lat,lng"
 * @returns Object with lat and lng properties
 */
export const parseCoordinates = (coordinateString: string): { lat: number; lng: number } | null => {
  if (!coordinateString) return null;
  
  const parts = coordinateString.split(',');
  if (parts.length !== 2) return null;
  
  const lat = parseFloat(parts[0]);
  const lng = parseFloat(parts[1]);
  
  if (isNaN(lat) || isNaN(lng)) return null;
  
  return { lat, lng };
};

/**
 * Format location string to hide coordinates
 * @param location Location string that might be coordinates
 * @returns User-friendly location string
 */
export const formatLocation = (location: string | undefined): string => {
  if (!location) return "Location not available";
  
  // Check if location is in coordinate format
  const isCoordinate = location.includes(',') && 
    !isNaN(parseFloat(location.split(',')[0])) && 
    !isNaN(parseFloat(location.split(',')[1]));
  
  if (isCoordinate) {
    return ""; // Return empty string instead of "Location available on request"
  }
  
  return location;
};
