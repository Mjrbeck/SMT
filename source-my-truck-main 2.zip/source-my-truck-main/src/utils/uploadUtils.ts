
import { supabase } from "@/integrations/supabase/client";
import { v4 as uuidv4 } from "uuid";
import { toast } from "sonner";

interface UploadResult {
  url: string;
  fileName: string;
}

export const validateFile = (
  file: File, 
  maxSizeMB: number = 5,
  isLogo: boolean = false
): boolean => {
  // For logo uploads, limit to 500KB
  const actualMaxSize = isLogo ? 0.5 : maxSizeMB;
  
  // Check file type
  const fileExt = file.name.split('.').pop()?.toLowerCase();
  const allowedTypes = ['jpg', 'jpeg', 'png', 'webp'];
  
  if (!fileExt || !allowedTypes.includes(fileExt)) {
    toast.error("Invalid file type", {
      description: "Please upload an image file (JPG, PNG, or WebP).",
    });
    return false;
  }

  // Check file size
  if (file.size > actualMaxSize * 1024 * 1024) {
    toast.error("File too large", {
      description: `Please upload an image smaller than ${actualMaxSize}MB.`,
    });
    return false;
  }

  return true;
};

export const uploadToStorage = async (
  file: File,
  userId: string,
  bucket: string
): Promise<UploadResult> => {
  // Generate a unique filename
  const fileExt = file.name.split('.').pop();
  const fileName = `${userId}_${uuidv4()}.${fileExt}`;
  
  // Upload file to Supabase Storage
  const { data, error } = await supabase.storage
    .from(bucket)
    .upload(fileName, file);
    
  if (error) throw error;
  
  // Get the public URL
  const { data: publicUrlData } = supabase.storage
    .from(bucket)
    .getPublicUrl(fileName);
  
  return {
    url: publicUrlData.publicUrl,
    fileName
  };
};

export const deleteFromStorage = async (
  bucket: string,
  url: string
): Promise<void> => {
  // Extract filename from URL
  const filePathParts = url.split('/');
  const fileName = filePathParts[filePathParts.length - 1];
  
  const { error } = await supabase.storage
    .from(bucket)
    .remove([fileName]);
  
  if (error) throw error;
};
