const WATCHLIST_KEY = 'sourcemytruck_watchlist';
const WATCHLIST_EXPIRY_KEY = 'sourcemytruck_watchlist_expiry';
const WATCHLIST_EXPIRY_DAYS = 30;

export interface WatchlistItem {
  vehicleId: string;
  addedAt: number;
}

export const watchlistStorage = {
  // Get all watched vehicle IDs
  getWatchedVehicles(): string[] {
    try {
      if (this.isExpired()) {
        this.clearWatchlist();
        return [];
      }
      
      const stored = localStorage.getItem(WATCHLIST_KEY);
      if (!stored) return [];
      
      const watchlist: WatchlistItem[] = JSON.parse(stored);
      return watchlist.map(item => item.vehicleId);
    } catch (error) {
      console.error('Error reading watchlist from localStorage:', error);
      return [];
    }
  },

  // Get full watchlist with metadata
  getWatchlistItems(): WatchlistItem[] {
    try {
      if (this.isExpired()) {
        this.clearWatchlist();
        return [];
      }
      
      const stored = localStorage.getItem(WATCHLIST_KEY);
      if (!stored) return [];
      
      return JSON.parse(stored);
    } catch (error) {
      console.error('Error reading watchlist items from localStorage:', error);
      return [];
    }
  },

  // Add a vehicle to watchlist
  addToWatchlist(vehicleId: string): boolean {
    try {
      const watchlist = this.getWatchlistItems();
      
      // Check if already exists
      if (watchlist.some(item => item.vehicleId === vehicleId)) {
        return false;
      }
      
      // Add new item
      const newItem: WatchlistItem = {
        vehicleId,
        addedAt: Date.now()
      };
      
      watchlist.push(newItem);
      
      // Save to localStorage
      localStorage.setItem(WATCHLIST_KEY, JSON.stringify(watchlist));
      this.setExpiry();
      
      return true;
    } catch (error) {
      console.error('Error adding to watchlist:', error);
      return false;
    }
  },

  // Remove a vehicle from watchlist
  removeFromWatchlist(vehicleId: string): boolean {
    try {
      const watchlist = this.getWatchlistItems();
      const filtered = watchlist.filter(item => item.vehicleId !== vehicleId);
      
      if (filtered.length === watchlist.length) {
        return false; // Item wasn't in the list
      }
      
      localStorage.setItem(WATCHLIST_KEY, JSON.stringify(filtered));
      return true;
    } catch (error) {
      console.error('Error removing from watchlist:', error);
      return false;
    }
  },

  // Check if a vehicle is watched
  isWatched(vehicleId: string): boolean {
    return this.getWatchedVehicles().includes(vehicleId);
  },

  // Get watchlist count
  getCount(): number {
    return this.getWatchedVehicles().length;
  },

  // Clear entire watchlist
  clearWatchlist(): void {
    localStorage.removeItem(WATCHLIST_KEY);
    localStorage.removeItem(WATCHLIST_EXPIRY_KEY);
  },

  // Set expiry timestamp
  setExpiry(): void {
    const expiryTime = Date.now() + (WATCHLIST_EXPIRY_DAYS * 24 * 60 * 60 * 1000);
    localStorage.setItem(WATCHLIST_EXPIRY_KEY, expiryTime.toString());
  },

  // Check if watchlist has expired
  isExpired(): boolean {
    const expiryTime = localStorage.getItem(WATCHLIST_EXPIRY_KEY);
    if (!expiryTime) return false;
    
    return Date.now() > parseInt(expiryTime);
  },

  // Export watchlist for account sync
  exportWatchlist(): string[] {
    return this.getWatchedVehicles();
  }
};