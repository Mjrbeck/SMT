/**
 * Clears all user-specific data from localStorage when auth fails or user signs out
 */
export const clearUserData = () => {
  const keysToRemove = [
    'messages_',
    'cachedTransactions', 
    'transactionCacheTime',
    'stripeSessionId',
    'sessionTimestamp', 
    'pendingTransactionId',
    'pendingTransactionAmount',
    'featuredVehicles',
    'featuredVehiclesTimestamp',
    'onboardingDismissed',
    'lastSuccessfulSession',
    'paymentSuccessTime',
    'pendingSubscriptionId',
    'pendingSubscriptionCreated',
    'pendingSubscriptionTier'
  ];
  
  // Remove keys that start with user-specific prefixes or exact matches
  for (let i = localStorage.length - 1; i >= 0; i--) {
    const key = localStorage.key(i);
    if (key && keysToRemove.some(prefix => key.startsWith(prefix) || key === prefix)) {
      localStorage.removeItem(key);
      console.log(`Cleared localStorage key: ${key}`);
    }
  }
};

/**
 * Clear all localStorage data (nuclear option for debugging)
 */
export const clearAllUserData = () => {
  localStorage.clear();
  console.log('Cleared all localStorage data');
};