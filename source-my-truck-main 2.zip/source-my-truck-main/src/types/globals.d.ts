
interface Window {
  gtag?: (command: string, action: string, params?: any) => void;
  hcaptcha?: any;
}
