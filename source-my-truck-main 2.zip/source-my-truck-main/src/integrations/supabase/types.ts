export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instanciate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "12.2.3 (519615d)"
  }
  public: {
    Tables: {
      blog_articles: {
        Row: {
          author: string
          category: string
          content: string
          created_at: string
          date: string
          excerpt: string
          id: string
          image_url: string
          published: boolean
          read_time: string
          tags: string[] | null
          title: string
          updated_at: string
        }
        Insert: {
          author: string
          category: string
          content: string
          created_at?: string
          date: string
          excerpt: string
          id?: string
          image_url: string
          published?: boolean
          read_time: string
          tags?: string[] | null
          title: string
          updated_at?: string
        }
        Update: {
          author?: string
          category?: string
          content?: string
          created_at?: string
          date?: string
          excerpt?: string
          id?: string
          image_url?: string
          published?: boolean
          read_time?: string
          tags?: string[] | null
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      chat_messages: {
        Row: {
          created_at: string
          id: string
          is_read: boolean
          message: string
          sender_type: string
          session_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          is_read?: boolean
          message: string
          sender_type: string
          session_id: string
        }
        Update: {
          created_at?: string
          id?: string
          is_read?: boolean
          message?: string
          sender_type?: string
          session_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "chat_messages_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "chat_sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      chat_sessions: {
        Row: {
          ai_mode: boolean
          created_at: string
          id: string
          seller_id: string
          status: string
          updated_at: string
          visitor_email: string | null
          visitor_id: string
          visitor_name: string | null
        }
        Insert: {
          ai_mode?: boolean
          created_at?: string
          id?: string
          seller_id: string
          status?: string
          updated_at?: string
          visitor_email?: string | null
          visitor_id: string
          visitor_name?: string | null
        }
        Update: {
          ai_mode?: boolean
          created_at?: string
          id?: string
          seller_id?: string
          status?: string
          updated_at?: string
          visitor_email?: string | null
          visitor_id?: string
          visitor_name?: string | null
        }
        Relationships: []
      }
      credits_transactions: {
        Row: {
          amount: number
          cost_pence: number
          created_at: string
          id: string
          payment_intent_id: string | null
          status: string
          user_id: string
        }
        Insert: {
          amount: number
          cost_pence: number
          created_at?: string
          id?: string
          payment_intent_id?: string | null
          status?: string
          user_id: string
        }
        Update: {
          amount?: number
          cost_pence?: number
          created_at?: string
          id?: string
          payment_intent_id?: string | null
          status?: string
          user_id?: string
        }
        Relationships: []
      }
      messages: {
        Row: {
          anonymous_sender_email: string | null
          anonymous_sender_name: string | null
          anonymous_sender_phone: string | null
          content: string
          created_at: string | null
          id: string
          is_important: boolean | null
          is_read: boolean | null
          order: number | null
          recipient_id: string
          sender_id: string | null
          subject: string
          updated_at: string | null
          vehicle_id: string | null
        }
        Insert: {
          anonymous_sender_email?: string | null
          anonymous_sender_name?: string | null
          anonymous_sender_phone?: string | null
          content: string
          created_at?: string | null
          id?: string
          is_important?: boolean | null
          is_read?: boolean | null
          order?: number | null
          recipient_id: string
          sender_id?: string | null
          subject: string
          updated_at?: string | null
          vehicle_id?: string | null
        }
        Update: {
          anonymous_sender_email?: string | null
          anonymous_sender_name?: string | null
          anonymous_sender_phone?: string | null
          content?: string
          created_at?: string | null
          id?: string
          is_important?: boolean | null
          is_read?: boolean | null
          order?: number | null
          recipient_id?: string
          sender_id?: string | null
          subject?: string
          updated_at?: string | null
          vehicle_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "messages_vehicle_id_fkey"
            columns: ["vehicle_id"]
            isOneToOne: false
            referencedRelation: "vehicles"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          company_address: string | null
          company_description: string | null
          company_name: string
          company_phone: string | null
          created_at: string
          credits: number
          depot_verified: boolean | null
          id: string
          is_trusted: boolean | null
          logo_url: string | null
          role: Database["public"]["Enums"]["user_role"]
          updated_at: string
        }
        Insert: {
          company_address?: string | null
          company_description?: string | null
          company_name: string
          company_phone?: string | null
          created_at?: string
          credits?: number
          depot_verified?: boolean | null
          id: string
          is_trusted?: boolean | null
          logo_url?: string | null
          role?: Database["public"]["Enums"]["user_role"]
          updated_at?: string
        }
        Update: {
          company_address?: string | null
          company_description?: string | null
          company_name?: string
          company_phone?: string | null
          created_at?: string
          credits?: number
          depot_verified?: boolean | null
          id?: string
          is_trusted?: boolean | null
          logo_url?: string | null
          role?: Database["public"]["Enums"]["user_role"]
          updated_at?: string
        }
        Relationships: []
      }
      seller_depots: {
        Row: {
          ai_assistant_enabled: boolean | null
          ai_assistant_prompt: string | null
          background_color: string | null
          button_color: string | null
          chat_enabled: boolean | null
          created_at: string | null
          custom_url_slug: string | null
          description: string | null
          header_image_url: string | null
          id: string
          is_public: boolean | null
          shop_name: string | null
          tagline: string | null
          text_color: string | null
          theme_color: string | null
          updated_at: string | null
          website_url: string | null
        }
        Insert: {
          ai_assistant_enabled?: boolean | null
          ai_assistant_prompt?: string | null
          background_color?: string | null
          button_color?: string | null
          chat_enabled?: boolean | null
          created_at?: string | null
          custom_url_slug?: string | null
          description?: string | null
          header_image_url?: string | null
          id: string
          is_public?: boolean | null
          shop_name?: string | null
          tagline?: string | null
          text_color?: string | null
          theme_color?: string | null
          updated_at?: string | null
          website_url?: string | null
        }
        Update: {
          ai_assistant_enabled?: boolean | null
          ai_assistant_prompt?: string | null
          background_color?: string | null
          button_color?: string | null
          chat_enabled?: boolean | null
          created_at?: string | null
          custom_url_slug?: string | null
          description?: string | null
          header_image_url?: string | null
          id?: string
          is_public?: boolean | null
          shop_name?: string | null
          tagline?: string | null
          text_color?: string | null
          theme_color?: string | null
          updated_at?: string | null
          website_url?: string | null
        }
        Relationships: []
      }
      transactions: {
        Row: {
          amount: number
          cost_pence: number
          created_at: string | null
          id: string
          payment_intent_id: string | null
          status: string
          updated_at: string | null
          user_id: string
        }
        Insert: {
          amount: number
          cost_pence: number
          created_at?: string | null
          id?: string
          payment_intent_id?: string | null
          status: string
          updated_at?: string | null
          user_id: string
        }
        Update: {
          amount?: number
          cost_pence?: number
          created_at?: string | null
          id?: string
          payment_intent_id?: string | null
          status?: string
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      trust_applications: {
        Row: {
          business_email: string
          company_name: string | null
          company_registration_number: string | null
          created_at: string
          document_url: string | null
          full_name: string
          id: string
          phone_number: string | null
          reason: string
          status: string
          updated_at: string
          user_id: string
          website_or_social_links: string | null
          years_in_business: number
        }
        Insert: {
          business_email: string
          company_name?: string | null
          company_registration_number?: string | null
          created_at?: string
          document_url?: string | null
          full_name: string
          id?: string
          phone_number?: string | null
          reason: string
          status?: string
          updated_at?: string
          user_id: string
          website_or_social_links?: string | null
          years_in_business: number
        }
        Update: {
          business_email?: string
          company_name?: string | null
          company_registration_number?: string | null
          created_at?: string
          document_url?: string | null
          full_name?: string
          id?: string
          phone_number?: string | null
          reason?: string
          status?: string
          updated_at?: string
          user_id?: string
          website_or_social_links?: string | null
          years_in_business?: number
        }
        Relationships: []
      }
      vehicle_images: {
        Row: {
          created_at: string
          id: string
          image_url: string
          is_main: boolean | null
          order: number | null
          vehicle_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          image_url: string
          is_main?: boolean | null
          order?: number | null
          vehicle_id: string
        }
        Update: {
          created_at?: string
          id?: string
          image_url?: string
          is_main?: boolean | null
          order?: number | null
          vehicle_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "vehicle_images_vehicle_id_fkey"
            columns: ["vehicle_id"]
            isOneToOne: false
            referencedRelation: "vehicles"
            referencedColumns: ["id"]
          },
        ]
      }
      vehicle_views: {
        Row: {
          id: string
          ip_address: string | null
          vehicle_id: string
          viewed_at: string
          viewer_id: string | null
        }
        Insert: {
          id?: string
          ip_address?: string | null
          vehicle_id: string
          viewed_at?: string
          viewer_id?: string | null
        }
        Update: {
          id?: string
          ip_address?: string | null
          vehicle_id?: string
          viewed_at?: string
          viewer_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "vehicle_views_vehicle_id_fkey"
            columns: ["vehicle_id"]
            isOneToOne: false
            referencedRelation: "vehicles"
            referencedColumns: ["id"]
          },
        ]
      }
      vehicles: {
        Row: {
          axle_configuration: string | null
          body_type: string | null
          cab_type: string | null
          color: string | null
          created_at: string
          description: string | null
          driver_position: string | null
          emissions_class: string | null
          engine_power: string | null
          engine_size: string | null
          expires_at: string | null
          exterior_condition: string | null
          external_height: number | null
          external_length: number | null
          external_width: number | null
          features: string[] | null
          fuel_type: string | null
          gross_vehicle_weight: number | null
          id: string
          interior_condition: string | null
          internal_height: number | null
          internal_length: number | null
          internal_width: number | null
          is_new: boolean | null
          is_poa: boolean
          listing_tier: string
          location: string | null
          make: string
          mileage: number | null
          model: string | null
          number_of_seats: number | null
          price: number
          registration: string
          status: string | null
          title: string
          transmission: string | null
          updated_at: string
          user_id: string
          video_url: string | null
          volume: string | null
          weight: number | null
          year: number
          youtube_url: string | null
        }
        Insert: {
          axle_configuration?: string | null
          body_type?: string | null
          cab_type?: string | null
          color?: string | null
          created_at?: string
          description?: string | null
          driver_position?: string | null
          emissions_class?: string | null
          engine_power?: string | null
          engine_size?: string | null
          expires_at?: string | null
          exterior_condition?: string | null
          external_height?: number | null
          external_length?: number | null
          external_width?: number | null
          features?: string[] | null
          fuel_type?: string | null
          gross_vehicle_weight?: number | null
          id?: string
          interior_condition?: string | null
          internal_height?: number | null
          internal_length?: number | null
          internal_width?: number | null
          is_new?: boolean | null
          is_poa?: boolean
          listing_tier?: string
          location?: string | null
          make: string
          mileage?: number | null
          model?: string | null
          number_of_seats?: number | null
          price: number
          registration: string
          status?: string | null
          title: string
          transmission?: string | null
          updated_at?: string
          user_id: string
          video_url?: string | null
          volume?: string | null
          weight?: number | null
          year: number
          youtube_url?: string | null
        }
        Update: {
          axle_configuration?: string | null
          body_type?: string | null
          cab_type?: string | null
          color?: string | null
          created_at?: string
          description?: string | null
          driver_position?: string | null
          emissions_class?: string | null
          engine_power?: string | null
          engine_size?: string | null
          expires_at?: string | null
          exterior_condition?: string | null
          external_height?: number | null
          external_length?: number | null
          external_width?: number | null
          features?: string[] | null
          fuel_type?: string | null
          gross_vehicle_weight?: number | null
          id?: string
          interior_condition?: string | null
          internal_height?: number | null
          internal_length?: number | null
          internal_width?: number | null
          is_new?: boolean | null
          is_poa?: boolean
          listing_tier?: string
          location?: string | null
          make?: string
          mileage?: number | null
          model?: string | null
          number_of_seats?: number | null
          price?: number
          registration?: string
          status?: string | null
          title?: string
          transmission?: string | null
          updated_at?: string
          user_id?: string
          video_url?: string | null
          volume?: string | null
          weight?: number | null
          year?: number
          youtube_url?: string | null
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      add_credits: {
        Args: { user_id: string; credit_amount: number }
        Returns: undefined
      }
      cleanup_orphaned_vehicle_images: {
        Args: Record<PropertyKey, never>
        Returns: undefined
      }
      decrement_credits: {
        Args: { amount: number }
        Returns: number
      }
      get_user_role: {
        Args: { user_id: string }
        Returns: Database["public"]["Enums"]["user_role"]
      }
      handle_successful_payment: {
        Args: {
          payment_intent_id: string
          user_id: string
          credit_amount: number
        }
        Returns: undefined
      }
      has_enough_credits: {
        Args: { user_id: string }
        Returns: boolean
      }
      is_admin: {
        Args: { user_id: string }
        Returns: boolean
      }
    }
    Enums: {
      user_role: "buyer" | "seller" | "administrator"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      user_role: ["buyer", "seller", "administrator"],
    },
  },
} as const
