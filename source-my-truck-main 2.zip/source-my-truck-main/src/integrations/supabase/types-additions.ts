
// This file contains type extensions that might be missing in the auto-generated types.ts file
// Include it where necessary

import { Database } from "./types";

// Extend the vehicles type to include expires_at
export type ExtendedVehicleTypes = Database["public"]["Tables"]["vehicles"]["Row"] & {
  expires_at?: string;
};
