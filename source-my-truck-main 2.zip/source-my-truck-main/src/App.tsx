import { WatchlistProvider } from '@/contexts/WatchlistContext';
import React, { useEffect, Suspense } from 'react';
import { Routes, Route, useLocation, Navigate } from 'react-router-dom';
import { AuthProvider } from '@/contexts/AuthContext';
import { InventoryProvider } from '@/contexts/InventoryContext';
import { LayoutProvider } from '@/contexts/LayoutContext';
import { OnboardingProvider } from '@/contexts/OnboardingContext';
import { Toaster } from 'sonner';
import Index from './pages/Index';
import RegisterPage from './pages/auth/RegisterPage';
import LoginPage from './pages/auth/LoginPage';
import VehicleListings from './pages/VehicleListings';
import VehicleDetails from './pages/VehicleDetails';
import Dashboard from './pages/Dashboard';
import Inventory from './pages/Inventory';
import Profile from './pages/Profile';
import Settings from './pages/Settings';

import Messages from './pages/Messages';
import MessageDetail from './pages/MessageDetail';
import CreateListing from './pages/CreateListing';
import EditListing from './pages/EditListing';
import SellerDashboard from './pages/SellerDashboard';
import Pricing from './pages/Pricing';
import SellerGuide from './pages/SellerGuide';
import Terms from './pages/Terms';
import PrivacyPolicy from './pages/PrivacyPolicy';
import Blog from './pages/Blog';
import BlogDetail from './pages/BlogDetail';
import NotFound from './pages/NotFound';
import SeoTools from './pages/SeoTools';
import ProtectedRoute from '@/components/auth/ProtectedRoute';
import SellerDepot from "@/pages/SellerDepot";
import ResetPasswordPage from './pages/auth/ResetPasswordPage';
import HealthCheckPage from './pages/HealthCheck';
import Watchlist from './pages/Watchlist';
import { supabase } from '@/integrations/supabase/client';
import About from './pages/About';
import Contact from './pages/Contact';

import VehiclePrerender from './components/VehiclePrerender';

import SitemapVehicles from './components/seo/SitemapVehicles';


const AuthRedirect = () => {
  const location = useLocation();
  
  useEffect(() => {
    console.log("AuthRedirect component mounted");
    console.log("Current location:", location);
    
    const handleAuthCallback = async () => {
      try {
        const fullUrl = window.location.href;
        const url = new URL(fullUrl);
        
        const allParams = new URLSearchParams();
        
        if (url.hash) {
          const hashParams = new URLSearchParams(url.hash.substring(1));
          for (const [key, value] of hashParams.entries()) {
            allParams.append(key, value);
          }
        }
        
        if (url.search) {
          const searchParams = new URLSearchParams(url.search);
          for (const [key, value] of searchParams.entries()) {
            if (!allParams.has(key)) {
              allParams.append(key, value);
            }
          }
        }
        
        const paramString = allParams.toString();
        console.log("AuthRedirect: Full param string:", paramString);
        console.log("AuthRedirect: All params:", Object.fromEntries(allParams.entries()));
        
        // Check if this is a password recovery flow
        const isPasswordRecovery = paramString.includes('type=recovery');
        console.log("AuthRedirect: Is password recovery?", isPasswordRecovery);
        
        if (!isPasswordRecovery) {
          // Only sign out for non-recovery flows
          await supabase.auth.signOut();
          console.log("User signed out during auth callback");
        } else {
          console.log("Password recovery detected, preserving session");
        }
        
        if (paramString.includes("error") || paramString.includes("error_code")) {
          console.log("AuthRedirect: Detected error in callback, redirecting with error params");
          window.location.href = `/reset-password#${paramString}`;
        } else if (isPasswordRecovery) {
          const redirectUrl = `/reset-password#${paramString}`;
          console.log("AuthRedirect: Redirecting to reset password:", redirectUrl);
          console.log("AuthRedirect: Full URL being redirected to:", window.location.origin + redirectUrl);
          window.location.href = redirectUrl;
        } else {
          // For other auth flows, redirect appropriately
          window.location.href = "/dashboard";
        }
      } catch (error) {
        console.error("Error handling auth callback:", error);
        window.location.href = "/login?error=callback_failed";
      }
    };
    
    handleAuthCallback();
  }, [location]);

  return (
    <div className="flex h-screen items-center justify-center">
      <div className="text-center">
        <div className="mb-4">
          <div className="w-16 h-16 border-4 border-t-brand-blue border-r-transparent border-b-brand-orange border-l-transparent rounded-full animate-spin mx-auto"></div>
        </div>
        <p className="text-lg font-medium">Processing your request...</p>
        <p className="text-sm text-gray-500 mt-2">You'll be redirected shortly.</p>
      </div>
    </div>
  );
};

function App() {
  const location = useLocation();
  
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [location]);

  const checkForResetTokens = () => {
    try {
      const url = new URL(window.location.href);
      
      if ((url.hash.includes('access_token') || url.search.includes('access_token')) && 
          url.pathname !== '/reset-password' && 
          url.pathname !== '/auth/callback') {
        console.log("App: Detected reset token outside of reset-password page");
        
        const signOutAndRedirect = async () => {
          try {
            await supabase.auth.signOut();
            console.log("App: Signed out for reset password flow");
            
            const params = new URLSearchParams();
            
            if (url.hash) {
              const hashParams = new URLSearchParams(url.hash.substring(1));
              for (const [key, value] of hashParams.entries()) {
                params.append(key, value);
              }
            }
            
            if (url.search) {
              const searchParams = new URLSearchParams(url.search);
              for (const [key, value] of searchParams.entries()) {
                if (!params.has(key)) {
                  params.append(key, value);
                }
              }
            }
            
            const resetUrl = `/reset-password#${params.toString()}`;
            console.log("App: Redirecting to:", resetUrl);
            window.location.href = resetUrl;
          } catch (error) {
            console.error("Error signing out for reset:", error);
          }
        };
        
        signOutAndRedirect();
        return true;
      }
    } catch (err) {
      console.error("Error checking for reset tokens:", err);
    }
    
    return false;
  };

  const redirectToLoginWithForgotPassword = () => {
    return <Navigate to="/login?forgotPassword=true" replace />;
  };

  return (
    <div className="App">
      <AuthProvider>
        <LayoutProvider>
          <InventoryProvider>
            <OnboardingProvider>
              <WatchlistProvider>
                <Suspense fallback={<p>Loading...</p>}>
                  <Routes>
                    <Route path="/" element={<Index />} />
                    <Route path="/register" element={<RegisterPage />} />
                    <Route path="/login" element={<LoginPage />} />
                    <Route path="/reset-password" element={<ResetPasswordPage />} />
                    <Route path="/reset-password/recovery" element={<ResetPasswordPage />} />
                    <Route path="/health-check" element={<HealthCheckPage />} />
                    <Route path="/forgot-password" element={redirectToLoginWithForgotPassword()} />
                    <Route path="/listings" element={<VehicleListings />} />
                    <Route path="/watchlist" element={<Watchlist />} />
                    <Route path="/vehicle/:id" element={<VehicleDetails />} />
                    <Route path="/seller/:slug" element={<SellerDepot />} />
                    <Route path="/blog" element={<Blog />} />
                    <Route path="/blog/:id" element={<BlogDetail />} />
                    <Route path="/about" element={<About />} />
                    <Route path="/contact" element={<Contact />} />
                    <Route path="/sitemap.xml" element={<SitemapVehicles />} />
                    <Route path="/sitemap-vehicles.xml" element={<SitemapVehicles />} />
                    <Route path="/sitemap-static.xml" element={<SitemapVehicles />} />
                    <Route path="/sitemap-sellers.xml" element={<SitemapVehicles />} />
                    <Route path="/sitemap-blog.xml" element={<SitemapVehicles />} />
                    
                    <Route path="/vehicles/:id" element={<Navigate to={`/vehicle/${location.pathname.split('/').pop()}`} replace />} />
                    <Route path="/vehicles" element={<Navigate to="/listings" replace />} />
                    <Route path="/browse/*" element={<Navigate to={`/listings/${location.pathname.replace('/browse/', '')}`} replace />} />
                    <Route path="/browse-trucks" element={<Navigate to="/listings" replace />} />
                    <Route path="/all-trucks" element={<Navigate to="/listings" replace />} />
                    <Route path="/dealer/:id" element={<Navigate to={`/seller/${location.pathname.split('/').pop()}`} replace />} />
                    <Route path="/truck/:id" element={<Navigate to={`/vehicle/${location.pathname.split('/').pop()}`} replace />} />
                    
                    {/* Prerender route for crawlers - redirects to edge function */}
                    <Route path="/vehicle-meta-prerender/:id" element={<VehiclePrerender />} />
                    
                    <Route path="/privacy-policy" element={<Navigate to="/privacy" replace />} />
                    
                    <Route path="/auth/callback" element={<AuthRedirect />} />
                    
                    <Route element={<ProtectedRoute />}>
                    <Route path="/messages" element={<Messages />} />
                      <Route path="/messages/:id" element={<MessageDetail />} />
                      <Route path="/settings" element={<Settings />} />
                    </Route>
                    
                    <Route element={<ProtectedRoute requiredRole="seller" />}>
                      <Route path="/dashboard" element={<Dashboard />} />
                      <Route path="/inventory" element={<Inventory />} />
                      <Route path="/profile" element={<Profile />} />
                      <Route path="/create-listing" element={<CreateListing />} />
                      <Route path="/edit-listing/:id" element={<EditListing />} />
                      <Route path="/seller-dashboard" element={<SellerDashboard />} />
                      <Route path="/seo-tools" element={<SeoTools />} />
                    </Route>
                    
                    <Route path="/pricing" element={<Pricing />} />
                    <Route path="/seller-guide" element={<SellerGuide />} />
                    <Route path="/terms" element={<Terms />} />
                    <Route path="/privacy" element={<PrivacyPolicy />} />
                    
                    {/* Handle favicon.ico to prevent 404 logging */}
                    <Route path="/favicon.ico" element={<Navigate to="/lovable-uploads/a4996b55-dc58-40bd-b548-af7de97e900a.png" replace />} />
                    
                    <Route path="*" element={<NotFound />} />
                  </Routes>
                </Suspense>
              </WatchlistProvider>
            </OnboardingProvider>
          </InventoryProvider>
        </LayoutProvider>
        <Toaster />
      </AuthProvider>
    </div>
  );
}

export default App;
