
import React from "react";
import DashboardLayout from "@/components/DashboardLayout";
import InventoryContent from "@/components/inventory/InventoryContent";

const Inventory = () => {
  return (
    <DashboardLayout title="Inventory">
      <InventoryContent />
    </DashboardLayout>
  );
};

export default React.memo(Inventory);
