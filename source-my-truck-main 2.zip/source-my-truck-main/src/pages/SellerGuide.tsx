
import { useEffect } from "react";
import { Link } from "react-router-dom";
import { CheckCircle2, MousePointer, Camera, FileText, BarChart3, BadgeCheck } from "lucide-react";
import PageLayout from "@/components/layouts/PageLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

const SellerGuide = () => {
  // Set page title
  useEffect(() => {
    document.title = "Seller Guide | Source my Truck";
  }, []);

  return (
    <PageLayout>
      <div className="bg-gradient-to-b from-brand-blue/10 to-white">
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-4xl mx-auto mb-16 text-center">
            <h1 className="text-4xl font-bold mb-6">How to Create Effective Truck Listings</h1>
            <p className="text-xl text-gray-600">
              Follow our expert tips to maximize your chances of selling your commercial vehicle quickly and at the best price.
            </p>
          </div>

          {/* Key Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
            <Card className="border-l-4 border-l-green-500">
              <CardContent className="pt-6">
                <div className="text-3xl font-bold text-green-600 mb-2">87%</div>
                <p className="text-gray-600">of successful listings include high-quality photos from multiple angles</p>
              </CardContent>
            </Card>
            <Card className="border-l-4 border-l-blue-500">
              <CardContent className="pt-6">
                <div className="text-3xl font-bold text-blue-600 mb-2">73%</div>
                <p className="text-gray-600">of buyers consider detailed specifications as the most important factor</p>
              </CardContent>
            </Card>
            <Card className="border-l-4 border-l-orange-500">
              <CardContent className="pt-6">
                <div className="text-3xl font-bold text-orange-600 mb-2">3.5x</div>
                <p className="text-gray-600">more inquiries for listings with complete maintenance history information</p>
              </CardContent>
            </Card>
          </div>

          {/* Steps Grid */}
          <div className="mb-16">
            <h2 className="text-3xl font-bold mb-8 text-center">The 6-Step Process to Creating a Perfect Listing</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              <Card className="bg-white hover:shadow-lg transition-shadow">
                <CardContent className="pt-6">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="bg-blue-100 p-3 rounded-full">
                      <MousePointer className="h-6 w-6 text-brand-blue" />
                    </div>
                    <h3 className="text-xl font-semibold">1. Sign Up & Login</h3>
                  </div>
                  <p className="text-gray-600">
                    Create your account to access the seller dashboard with all listing tools and analytics.
                  </p>
                </CardContent>
              </Card>
              
              <Card className="bg-white hover:shadow-lg transition-shadow">
                <CardContent className="pt-6">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="bg-blue-100 p-3 rounded-full">
                      <FileText className="h-6 w-6 text-brand-blue" />
                    </div>
                    <h3 className="text-xl font-semibold">2. Enter Details</h3>
                  </div>
                  <p className="text-gray-600">
                    Fill in all vehicle specifications, including make, model, year, and technical data.
                  </p>
                </CardContent>
              </Card>
              
              <Card className="bg-white hover:shadow-lg transition-shadow">
                <CardContent className="pt-6">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="bg-blue-100 p-3 rounded-full">
                      <Camera className="h-6 w-6 text-brand-blue" />
                    </div>
                    <h3 className="text-xl font-semibold">3. Upload Photos</h3>
                  </div>
                  <p className="text-gray-600">
                    Add high-quality images showing all angles of your vehicle, inside and out.
                  </p>
                </CardContent>
              </Card>
              
              <Card className="bg-white hover:shadow-lg transition-shadow">
                <CardContent className="pt-6">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="bg-blue-100 p-3 rounded-full">
                      <BarChart3 className="h-6 w-6 text-brand-blue" />
                    </div>
                    <h3 className="text-xl font-semibold">4. Set Price</h3>
                  </div>
                  <p className="text-gray-600">
                    Research market rates and set a competitive price to attract serious buyers.
                  </p>
                </CardContent>
              </Card>
              
              <Card className="bg-white hover:shadow-lg transition-shadow">
                <CardContent className="pt-6">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="bg-blue-100 p-3 rounded-full">
                      <CheckCircle2 className="h-6 w-6 text-brand-blue" />
                    </div>
                    <h3 className="text-xl font-semibold">5. Review & Submit</h3>
                  </div>
                  <p className="text-gray-600">
                    Double-check all information for accuracy before publishing your listing.
                  </p>
                </CardContent>
              </Card>
              
              <Card className="bg-white hover:shadow-lg transition-shadow">
                <CardContent className="pt-6">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="bg-blue-100 p-3 rounded-full">
                      <BadgeCheck className="h-6 w-6 text-brand-blue" />
                    </div>
                    <h3 className="text-xl font-semibold">6. Manage Inquiries</h3>
                  </div>
                  <p className="text-gray-600">
                    Respond quickly to buyer messages to increase your chances of selling.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Tips Accordion */}
          <div className="max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl font-bold mb-8 text-center">Expert Tips for Standout Listings</h2>
            
            <Accordion type="single" collapsible className="bg-white rounded-lg shadow-md">
              <AccordionItem value="item-1">
                <AccordionTrigger className="px-6 py-4 hover:no-underline">
                  <span className="text-lg font-semibold">Taking Professional-Quality Photos</span>
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-4">
                  <ul className="list-disc pl-5 space-y-2 text-gray-700">
                    <li>Clean the vehicle thoroughly before photographing</li>
                    <li>Shoot in good natural light, ideally during the "golden hour"</li>
                    <li>Take photos from multiple angles (front, rear, sides, interior)</li>
                    <li>Highlight special features and any custom modifications</li>
                    <li>Include close-ups of the dashboard, engine, and any damage for transparency</li>
                    <li>Use landscape orientation for better display on the platform</li>
                  </ul>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-2">
                <AccordionTrigger className="px-6 py-4 hover:no-underline">
                  <span className="text-lg font-semibold">Writing Compelling Descriptions</span>
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-4">
                  <ul className="list-disc pl-5 space-y-2 text-gray-700">
                    <li>Start with a strong headline mentioning key selling points</li>
                    <li>Be specific about vehicle specifications and features</li>
                    <li>Include maintenance history and recent repairs/upgrades</li>
                    <li>Mention any warranties that are still valid</li>
                    <li>Be honest about the condition and any issues</li>
                    <li>Use industry-specific terminology correctly</li>
                    <li>Explain why your vehicle stands out from similar models</li>
                  </ul>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-3">
                <AccordionTrigger className="px-6 py-4 hover:no-underline">
                  <span className="text-lg font-semibold">Setting the Right Price</span>
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-4">
                  <ul className="list-disc pl-5 space-y-2 text-gray-700">
                    <li>Research similar vehicles on the market for competitive pricing</li>
                    <li>Consider the age, mileage, and condition of your vehicle</li>
                    <li>Factor in any special features or recent major repairs</li>
                    <li>Set a slightly higher price if you're willing to negotiate</li>
                    <li>Use the "Price on Application" option for high-value or unique vehicles</li>
                    <li>Regularly review and adjust your price if needed</li>
                  </ul>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-4">
                <AccordionTrigger className="px-6 py-4 hover:no-underline">
                  <span className="text-lg font-semibold">Responding to Buyer Inquiries</span>
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-4">
                  <ul className="list-disc pl-5 space-y-2 text-gray-700">
                    <li>Respond to messages promptly, ideally within 24 hours</li>
                    <li>Be prepared to answer technical questions about the vehicle</li>
                    <li>Have service records and documentation readily available</li>
                    <li>Be flexible with viewing arrangements when possible</li>
                    <li>Stay professional even with lowball offers</li>
                    <li>Follow up with serious buyers who haven't made a decision</li>
                  </ul>
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </div>

          {/* CTA Section */}
          <div className="bg-brand-blue rounded-xl p-8 text-white text-center">
            <h2 className="text-2xl font-bold mb-4">Ready to Create Your Listing?</h2>
            <p className="mb-6 max-w-2xl mx-auto">
              Put these tips into practice and start creating your winning vehicle listing today.
              Our platform makes it easy to reach thousands of potential buyers.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/create-listing">
                <Button size="lg" variant="secondary">Create a Listing</Button>
              </Link>
              <Link to="/register">
                <Button size="lg" variant="outline" className="bg-transparent border-white text-white hover:bg-white hover:text-brand-blue">
                  Sign Up Now
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </PageLayout>
  );
};

export default SellerGuide;
