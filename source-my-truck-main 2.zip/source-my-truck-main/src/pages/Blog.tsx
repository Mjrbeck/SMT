
import React, { useState } from "react";
import PageLayout from "@/components/layouts/PageLayout";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { ArrowRight, Clock, ImageOff } from "lucide-react";
import { useBlogArticles, useBlogArticlesByCategory } from "@/hooks/useBlogArticles";
import { Skeleton } from "@/components/ui/skeleton";
import { getValidImageUrl, getTextFallback } from "@/utils/imageUtils";
import { BlogArticle } from "@/services/blog/types";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useIsMobile } from "@/hooks/use-mobile";

const CATEGORY_FALLBACK_IMAGES: Record<string, string> = {
  "technology": "https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=800&h=600",
  "industry": "https://images.unsplash.com/photo-1601584115197-04ecc0da31d7?auto=format&fit=crop&w=800&h=600",
  "trucking": "https://images.unsplash.com/photo-1601584115197-04ecc0da31d7?auto=format&fit=crop&w=800&h=600",
  "logistics": "https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d?auto=format&fit=crop&w=800&h=600",
  "innovation": "https://images.unsplash.com/photo-1488590528505-98d2a5aee158?auto=format&fit=crop&w=800&h=600",
  "sustainability": "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&w=800&h=600",
  "maintenance": "https://images.unsplash.com/photo-1487058792275-0ad4aaf24ca7?auto=format&fit=crop&w=800&h=600",
  "safety": "https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=800&h=600",
  "regulations": "https://images.unsplash.com/photo-1461749280684-dccba630e2f6?auto=format&fit=crop&w=800&h=600",
  "news": "https://images.unsplash.com/photo-1649972904349-6e44c42644a7?auto=format&fit=crop&w=800&h=600"
};

const DEFAULT_FALLBACK = "https://images.unsplash.com/photo-1584824486509-112e4181ff6b?auto=format&fit=crop&w=800&h=600&q=80";

const getRelevantImage = (post: BlogArticle): string => {
  if (getValidImageUrl(post.image)) {
    return post.image;
  }
  
  const lowerCategory = post.category.toLowerCase();
  if (CATEGORY_FALLBACK_IMAGES[lowerCategory]) {
    return CATEGORY_FALLBACK_IMAGES[lowerCategory];
  }
  
  const title = post.title.toLowerCase();
  
  if (title.includes('tech') || title.includes('digital') || title.includes('software') || title.includes('computer')) {
    return CATEGORY_FALLBACK_IMAGES.technology;
  }
  
  if (title.includes('trucking') || title.includes('vehicle') || title.includes('transport') || title.includes('truck')) {
    return CATEGORY_FALLBACK_IMAGES.trucking;
  }
  
  if (title.includes('green') || title.includes('sustain') || title.includes('environment') || title.includes('eco')) {
    return CATEGORY_FALLBACK_IMAGES.sustainability;
  }
  
  if (title.includes('regulations') || title.includes('compliance') || title.includes('law') || title.includes('policy')) {
    return CATEGORY_FALLBACK_IMAGES.regulations;
  }
  
  if (title.includes('maintenance') || title.includes('repair') || title.includes('service')) {
    return CATEGORY_FALLBACK_IMAGES.maintenance;
  }
  
  return DEFAULT_FALLBACK;
};

const BlogPost = ({ post }: { post: BlogArticle }) => {
  const [imageError, setImageError] = useState(false);
  const isMobile = useIsMobile();
  
  const handleImageError = () => {
    setImageError(true);
  };

  const relevantImage = getRelevantImage(post);

  return (
    <Card className="overflow-hidden hover:shadow-md transition-shadow duration-300 h-full flex flex-col">
      <div className="h-48 overflow-hidden bg-gray-100 relative">
        {imageError ? (
          <div className="w-full h-full flex items-center justify-center bg-gray-200">
            <ImageOff className="h-12 w-12 text-gray-400" />
          </div>
        ) : (
          <img 
            src={relevantImage} 
            alt={post.title} 
            className="w-full h-full object-cover transform hover:scale-105 transition-transform duration-500"
            onError={handleImageError}
          />
        )}
      </div>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between mb-2">
          <Badge variant="outline" className="bg-brand-blue/10 text-brand-blue border-brand-blue/30 text-xs">
            {post.category}
          </Badge>
          <div className="flex items-center text-gray-500 text-xs">
            <Clock className="h-3 w-3 mr-1" />
            {post.readTime}
          </div>
        </div>
        <CardTitle className={`${isMobile ? 'text-lg' : 'text-xl'} leading-tight hover:text-brand-blue transition-colors line-clamp-2`}>
          <Link to={`/blog/${post.id}`}>{post.title}</Link>
        </CardTitle>
      </CardHeader>
      <CardContent className="pb-4 flex-grow">
        <CardDescription className="text-gray-600 line-clamp-3 text-sm">
          {post.excerpt}
        </CardDescription>
      </CardContent>
      <CardFooter className="pt-0 flex items-center justify-end text-sm border-t border-gray-100 mt-auto">
        <div className="text-gray-400 text-xs">
          {post.date}
        </div>
      </CardFooter>
    </Card>
  );
};

const BlogPostSkeleton = () => (
  <Card className="overflow-hidden h-full flex flex-col">
    <div className="h-48 overflow-hidden">
      <Skeleton className="w-full h-full" />
    </div>
    <CardHeader className="pb-2">
      <div className="flex items-center justify-between mb-2">
        <Skeleton className="h-6 w-24" />
        <Skeleton className="h-4 w-16" />
      </div>
      <Skeleton className="h-6 w-full mb-2" />
    </CardHeader>
    <CardContent className="pb-4 flex-grow">
      <Skeleton className="h-4 w-full mb-2" />
      <Skeleton className="h-4 w-full mb-2" />
      <Skeleton className="h-4 w-3/4" />
    </CardContent>
    <CardFooter className="pt-0 flex items-center justify-between text-sm border-t border-gray-100 mt-auto">
      <Skeleton className="h-4 w-24" />
      <Skeleton className="h-4 w-20" />
    </CardFooter>
  </Card>
);

const Blog = () => {
  const [activeTab, setActiveTab] = useState("all");
  const isMobile = useIsMobile();
  
  const { data: allArticles, isLoading: isLoadingAll, error: errorAll, refetch: refetchAll } = useBlogArticles();
  
  const { data: categoryArticles, isLoading: isLoadingCategory, refetch: refetchCategory } = useBlogArticlesByCategory(activeTab);
  
  const isLoading = activeTab === "all" ? isLoadingAll : isLoadingCategory;
  const articles = activeTab === "all" ? allArticles : categoryArticles;
  
  const categories = allArticles 
    ? ["all", ...new Set(allArticles.map(article => article.category.toLowerCase()))]
    : ["all"];
  
  const formatCategoryName = (category: string) => {
    if (category === "all") return "All";
    return category.split(" ").map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(" ");
  };
  
  if (errorAll) {
    return (
      <PageLayout 
        title="Industry Information" 
        subtitle="Stay informed with the latest news, trends, and insights about the commercial vehicle industry"
      >
        <div className="text-center py-12">
          <h3 className="text-xl font-medium text-gray-600 mb-2">Unable to load blog articles</h3>
          <p className="text-gray-500">There was an error loading the content. Please try again later.</p>
        </div>
      </PageLayout>
    );
  }

  return (
    <PageLayout 
      title="Industry Information" 
      subtitle="Stay informed with the latest news, trends, and insights about the commercial vehicle industry"
    >
      <div className="mb-8 max-w-full overflow-hidden">
        <Tabs defaultValue="all" className="w-full" onValueChange={setActiveTab}>
          <div className="relative border-b mb-6 overflow-hidden">
            <ScrollArea className="max-w-full pb-2">
              <div className="min-w-max">
                <TabsList className="bg-transparent inline-flex h-auto w-auto">
                  {categories.map(category => (
                    <TabsTrigger 
                      key={category} 
                      value={category}
                      className="data-[state=active]:bg-brand-blue data-[state=active]:text-white whitespace-nowrap text-xs sm:text-sm px-2 sm:px-3"
                    >
                      {formatCategoryName(category)}
                    </TabsTrigger>
                  ))}
                </TabsList>
              </div>
            </ScrollArea>
          </div>
          
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
              {[1, 2, 3, 4, 5, 6].map((n) => (
                <BlogPostSkeleton key={n} />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
              {articles && articles.map(post => (
                <BlogPost key={post.id} post={post} />
              ))}
              
              {articles && articles.length === 0 && (
                <div className="text-center py-12 col-span-full">
                  <h3 className="text-xl font-medium text-gray-600 mb-2">No articles in this category yet</h3>
                  <p className="text-gray-500">Check back soon for new content or browse other categories</p>
                </div>
              )}
            </div>
          )}
        </Tabs>
      </div>
      
      <div className="bg-gradient-to-r from-brand-blue to-brand-lightBlue text-white rounded-lg p-4 sm:p-8 my-8 sm:my-12">
        <div className="flex flex-col md:flex-row items-center justify-between">
          <div className="mb-6 md:mb-0 md:mr-8">
            <h2 className="text-xl sm:text-2xl font-bold mb-2">Stay Updated with Industry News</h2>
            <p className="text-blue-100">
              Subscribe to our newsletter to receive the latest updates, insights and expert articles.
            </p>
          </div>
          <Button 
            className="bg-white text-brand-blue hover:bg-blue-50"
            size={isMobile ? "default" : "lg"}
            onClick={() => window.open("https://sourcemytruck.eo.page/rjhrw", "_blank")}
          >
            Subscribe Now <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </div>
    </PageLayout>
  );
};

export default Blog;
