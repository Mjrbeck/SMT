
import React, { useEffect } from "react";
import { useParams, Navigate, useNavigate } from "react-router-dom";
import CreateListingPage from "./CreateListing/index";
import { toast } from "sonner";
import { InventoryProvider } from "@/contexts/InventoryContext";

const EditListing = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  
  useEffect(() => {
    if (!id) {
      toast.error("Missing vehicle ID", {
        description: "Unable to find the vehicle to edit",
      });
      navigate("/inventory");
    }
  }, [id, navigate]);
  
  if (!id) {
    return <Navigate to="/inventory" replace />;
  }
  
  return (
    <InventoryProvider>
      <CreateListingPage editVehicleId={id} />
    </InventoryProvider>
  );
};

export default EditListing;
