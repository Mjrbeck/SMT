
import { useState, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import DashboardLayout from "@/components/DashboardLayout";
import ProfileTabs from "@/components/profile/ProfileTabs";
import { ProfileProvider } from "@/contexts/ProfileContext";
import { useProfileProvider } from "@/hooks/useProfileProvider";

const Profile = () => {
  const [searchParams] = useSearchParams();
  const tabParam = searchParams.get("tab");
  const [activeTab, setActiveTab] = useState(tabParam || "account");
  const profileData = useProfileProvider(); // Get profile data with useAuth inside this component
  
  useEffect(() => {
    if (tabParam) {
      setActiveTab(tabParam);
    }
  }, [tabParam]);
  
  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
  };

  return (
    <DashboardLayout title="Company Profile">
      <div className="mx-auto">
        <ProfileProvider profileData={profileData}>
          <ProfileTabs 
            activeTab={activeTab} 
            handleTabChange={handleTabChange} 
          />
        </ProfileProvider>
      </div>
    </DashboardLayout>
  );
};

export default Profile;
