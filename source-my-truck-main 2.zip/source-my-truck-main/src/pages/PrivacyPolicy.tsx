
import { useEffect } from "react";
import PageLayout from "@/components/layouts/PageLayout";
import { formatDate } from "@/utils/formatters";

const PrivacyPolicy = () => {
  // Set page title
  useEffect(() => {
    document.title = "Privacy Policy | Source my Truck";
  }, []);

  // Get the current date for the effective date
  const effectiveDate = formatDate(new Date());

  return (
    <PageLayout>
      <div className="container mx-auto px-4 py-10 max-w-4xl">
        <h1 className="text-3xl font-bold mb-6">Privacy Policy</h1>

        <section className="mb-8">
          <h2 className="text-xl font-semibold mb-4">1. Introduction</h2>
          <p className="mb-4">
            Welcome to Source My Truck ("we", "us", "our"). This Privacy Policy explains how we collect, use, store, and protect your personal information when you use our website sourcemytruck.com ("the Platform"). We are committed to protecting your privacy and ensuring compliance with UK GDPR and Data Protection Act 2018.
          </p>
        </section>

        <section className="mb-8">
          <h2 className="text-xl font-semibold mb-4">2. Information We Collect</h2>
          <p className="mb-2">When you use our Platform, we may collect the following types of personal data:</p>

          <h3 className="text-lg font-medium mt-4 mb-2">a. Information You Provide to Us</h3>
          <ul className="list-disc pl-6 mb-4 space-y-2">
            <li><span className="font-medium">Account Details:</span> Name, email address, phone number, company details, and password when you register.</li>
            <li><span className="font-medium">Listings Information:</span> Details of vehicles you list for sale.</li>
            <li><span className="font-medium">Communications:</span> Messages sent via our Platform, including support inquiries.</li>
          </ul>

          <h3 className="text-lg font-medium mt-4 mb-2">b. Information We Collect Automatically</h3>
          <ul className="list-disc pl-6 mb-4 space-y-2">
            <li><span className="font-medium">Usage Data:</span> IP address, browser type, device type, and interactions with the Platform.</li>
            <li><span className="font-medium">Cookies & Tracking Technologies:</span> Data collected through cookies to improve user experience (see Section 8 for more details).</li>
          </ul>
        </section>

        <section className="mb-8">
          <h2 className="text-xl font-semibold mb-4">3. How We Use Your Information</h2>
          <p className="mb-2">We use your personal data for the following purposes:</p>
          <ul className="list-disc pl-6 mb-4 space-y-2">
            <li>To provide and manage your account.</li>
            <li>To facilitate vehicle listings and transactions between users.</li>
            <li>To improve our Platform, services, and security.</li>
            <li>To communicate with you about updates, offers, or support requests.</li>
            <li>To comply with legal obligations.</li>
          </ul>
        </section>

        <section className="mb-8">
          <h2 className="text-xl font-semibold mb-4">4. Legal Basis for Processing</h2>
          <p className="mb-2">We process personal data under the following legal grounds:</p>
          <ul className="list-disc pl-6 mb-4 space-y-2">
            <li><span className="font-medium">Contractual Obligation:</span> To provide services under our Terms & Conditions.</li>
            <li><span className="font-medium">Legitimate Interests:</span> To improve services, ensure security, and prevent fraud.</li>
            <li><span className="font-medium">Consent:</span> When you subscribe to newsletters or accept cookies.</li>
            <li><span className="font-medium">Legal Compliance:</span> To meet legal and regulatory requirements.</li>
          </ul>
        </section>

        <section className="mb-8">
          <h2 className="text-xl font-semibold mb-4">5. How We Share Your Data</h2>
          <p className="mb-4">We do not sell your data. However, we may share it with:</p>
          <ul className="list-disc pl-6 mb-4 space-y-2">
            <li><span className="font-medium">Service Providers:</span> Third-party companies that assist with hosting, analytics, and support services.</li>
            <li><span className="font-medium">Legal Authorities:</span> When required by law or to protect our rights.</li>
            <li><span className="font-medium">Business Transfers:</span> If we undergo a merger, acquisition, or asset sale.</li>
          </ul>
        </section>

        <section className="mb-8">
          <h2 className="text-xl font-semibold mb-4">6. Data Retention</h2>
          <p className="mb-4">
            We retain your personal data only as long as necessary for the purposes stated above, or as required by law. You may request account deletion at any time by contacting support@sourcemytruck.com.
          </p>
        </section>

        <section className="mb-8">
          <h2 className="text-xl font-semibold mb-4">7. Data Security</h2>
          <p className="mb-4">
            We implement industry-standard security measures to protect your data from unauthorised access, loss, or misuse. However, no method of transmission over the Internet is 100% secure, and we cannot guarantee absolute security.
          </p>
        </section>

        <section className="mb-8">
          <h2 className="text-xl font-semibold mb-4">8. Cookies & Tracking Technologies</h2>
          <p className="mb-4">
            We use cookies to enhance user experience and collect analytics. You can manage or disable cookies via your browser settings. For more details, see our Cookie Policy.
          </p>
        </section>

        <section className="mb-8">
          <h2 className="text-xl font-semibold mb-4">9. Your Rights Under UK GDPR</h2>
          <p className="mb-2">You have the right to:</p>
          <ul className="list-disc pl-6 mb-4 space-y-2">
            <li>Access your personal data.</li>
            <li>Request correction of inaccurate data.</li>
            <li>Request deletion of your data.</li>
            <li>Object to data processing.</li>
            <li>Withdraw consent (where applicable).</li>
            <li>Request data portability.</li>
          </ul>
          <p className="mb-4">
            To exercise any of these rights, contact support@sourcemytruck.com.
          </p>
        </section>

        <section className="mb-8">
          <h2 className="text-xl font-semibold mb-4">10. Third-Party Links</h2>
          <p className="mb-4">
            Our Platform may contain links to third-party websites. We are not responsible for their privacy practices, so we recommend reviewing their privacy policies separately.
          </p>
        </section>

        <section className="mb-8">
          <h2 className="text-xl font-semibold mb-4">11. Updates to This Privacy Policy</h2>
          <p className="mb-4">
            We may update this Privacy Policy from time to time. Any changes will be posted on this page with the updated revision date.
          </p>
        </section>

        <section className="mb-8">
          <h2 className="text-xl font-semibold mb-4">12. Contact Us</h2>
          <p className="mb-4">
            If you have any questions about this Privacy Policy or how we handle your data, please contact us at:
          </p>
          <p className="mb-4">
            Source My Truck<br />
            Email: support@sourcemytruck.com<br />
            Website: sourcemytruck.com
          </p>
        </section>

        <div className="border-t pt-4 text-sm text-gray-600">
          <p>This Privacy Policy is effective as of {effectiveDate}.</p>
        </div>
      </div>
    </PageLayout>
  );
};

export default PrivacyPolicy;
