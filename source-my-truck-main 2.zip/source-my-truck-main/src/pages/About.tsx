
import React from 'react';
import PageLayout from "@/components/layouts/PageLayout";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { Truck, Award, Clock, Users } from "lucide-react";
import SEO from "@/components/seo/SEO";
import { Separator } from "@/components/ui/separator";

const About = () => {
  return (
    <PageLayout>
      <SEO 
        title="About Source my Truck - Commercial Vehicle Marketplace"
        description="Learn about Source my Truck, the leading marketplace for commercial vehicles. Our mission is to connect sellers and buyers in the transportation industry."
        keywords="about source my truck, commercial vehicles marketplace, truck selling platform"
      />
      
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold mb-4">About Source my Truck</h1>
            <p className="text-xl text-gray-600">
              The leading marketplace for commercial vehicles
            </p>
          </div>
          
          <div className="prose prose-lg max-w-none mb-12">
            <p>
              Source my Truck was founded with a simple mission: to create the most efficient marketplace 
              for buying and selling commercial vehicles. We understand the challenges that both buyers 
              and sellers face in the trucking industry, and we've built a platform that addresses these 
              pain points directly.
            </p>
            
            <p>
              Our team brings together decades of experience in the transportation industry, vehicle 
              sales, and technology. This unique combination of expertise has allowed us to create a 
              platform that truly understands the needs of commercial vehicle buyers and sellers.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
            <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100">
              <h2 className="text-2xl font-semibold mb-4 flex items-center">
                <Truck className="mr-2 h-5 w-5 text-brand-blue" />
                Our Mission
              </h2>
              <p className="text-gray-700">
                To connect commercial vehicle buyers with trusted sellers through a platform that 
                prioritizes transparency, efficiency, and user experience. We aim to simplify the 
                process of buying and selling commercial vehicles, saving time and reducing stress 
                for all parties involved.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100">
              <h2 className="text-2xl font-semibold mb-4 flex items-center">
                <Award className="mr-2 h-5 w-5 text-brand-orange" />
                Our Values
              </h2>
              <ul className="list-disc pl-5 text-gray-700 space-y-2">
                <li>Transparency in all dealings</li>
                <li>Quality listings with accurate information</li>
                <li>Exceptional customer service</li>
                <li>Innovation in the commercial vehicle marketplace</li>
                <li>Building strong relationships with our customers</li>
              </ul>
            </div>
          </div>
          
          <Separator className="my-12" />
          
          <div className="mb-16">
            <h2 className="text-3xl font-bold mb-8 text-center">Why Choose Source my Truck?</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center p-6">
                <div className="bg-blue-50 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                  <Truck className="h-8 w-8 text-brand-blue" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Extensive Selection</h3>
                <p className="text-gray-600">
                  Browse thousands of commercial vehicles from trusted sellers across the country.
                </p>
              </div>
              
              <div className="text-center p-6">
                <div className="bg-orange-50 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                  <Clock className="h-8 w-8 text-brand-orange" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Time Saving</h3>
                <p className="text-gray-600">
                  Our platform streamlines the buying and selling process, saving you valuable time.
                </p>
              </div>
              
              <div className="text-center p-6">
                <div className="bg-green-50 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                  <Users className="h-8 w-8 text-green-600" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Community Focus</h3>
                <p className="text-gray-600">
                  We're building a community of trusted buyers and sellers in the transportation industry.
                </p>
              </div>
            </div>
          </div>
          
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-6">Ready to Get Started?</h2>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/listings">
                <Button size="lg" className="w-full sm:w-auto">
                  Browse Vehicles
                </Button>
              </Link>
              <Link to="/register">
                <Button size="lg" variant="outline" className="w-full sm:w-auto">
                  Register as a Seller
                </Button>
              </Link>
            </div>
          </div>
          
          <div className="bg-gray-50 p-8 rounded-lg">
            <h2 className="text-2xl font-semibold mb-4">Contact Us</h2>
            <p className="mb-4">
              Have questions or need assistance? Our team is here to help.
            </p>
            <Link to="/contact">
              <Button variant="outline">Contact Our Team</Button>
            </Link>
          </div>
        </div>
      </div>
    </PageLayout>
  );
};

export default About;
