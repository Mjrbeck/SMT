
import React, { useState } from 'react';
import PageLayout from "@/components/layouts/PageLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import BrokenLinkChecker from "@/components/seo/BrokenLinkChecker";
import SitemapVerifier from "@/components/seo/SitemapVerifier";
import SEO from "@/components/seo/SEO";
import { toast } from "sonner";
import { submitSitemapToSearchEngines, getSitemapUrls } from "@/services/vehicleService";

const SeoTools = () => {
  const [urlToCheck, setUrlToCheck] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const commonIssues = [
    {
      pattern: '/truck/',
      correction: '/vehicle/',
      description: 'Incorrect URL pattern - should use "vehicle" instead of "truck"'
    },
    {
      pattern: '/browse/',
      correction: '/listings/',
      description: 'Old URL pattern - should use "listings" instead of "browse"'
    },
    {
      pattern: '/dealer/',
      correction: '/seller/',
      description: 'Incorrect URL pattern - should use "seller" instead of "dealer"'
    }
  ];

  const handleSitemapSubmission = async () => {
    setIsSubmitting(true);
    try {
      const sitemapUrl = getSitemapUrls().main;
      const result = await submitSitemapToSearchEngines(sitemapUrl);
      
      if (result.success) {
        toast.success(result.message);
      } else {
        toast.error(result.message);
      }
    } catch (error) {
      toast.error(`Error submitting sitemap: ${error instanceof Error ? error.message : String(error)}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <PageLayout title="SEO Tools - 404 Analysis">
      <SEO 
        title="SEO Tools - Source my Truck"
        description="Internal tools for analyzing and fixing SEO issues like 404 errors"
        noindex={true}
      />
      
      <div className="max-w-5xl mx-auto">
        <h1 className="text-2xl font-bold mb-6">SEO Tools & 404 Analysis</h1>
        
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>404 Error Analysis</CardTitle>
            <CardDescription>
              Identify and fix common 404 errors on the site
            </CardDescription>
          </CardHeader>
          <CardContent>
            <h3 className="font-medium mb-3">Common 404 Issues</h3>
            <div className="space-y-3 mb-6">
              {commonIssues.map((issue, index) => (
                <div key={index} className="p-3 bg-gray-50 rounded-md">
                  <div className="flex justify-between">
                    <div>
                      <span className="text-red-500 font-mono">...{issue.pattern}...</span>
                      {' → '}
                      <span className="text-green-500 font-mono">...{issue.correction}...</span>
                    </div>
                  </div>
                  <p className="text-sm text-gray-600 mt-1">{issue.description}</p>
                </div>
              ))}
            </div>
            
            <div className="border-t pt-4">
              <h3 className="font-medium mb-3">Known 404 Pages</h3>
              <ul className="list-disc pl-5 space-y-1 mb-4">
                <li><code>/browse-trucks</code> (Old URL, should be <code>/listings</code>)</li>
                <li><code>/all-trucks</code> (Old URL, should be <code>/listings</code>)</li>
                <li><code>/dealer/123</code> (Should be <code>/seller/123</code>)</li>
                <li><code>/truck/123</code> (Should be <code>/vehicle/123</code>)</li>
                <li><code>/browse/category</code> (Should be <code>/listings/category</code>)</li>
              </ul>
            </div>
          </CardContent>
        </Card>
        
        <BrokenLinkChecker />
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
          <Card>
            <CardHeader>
              <CardTitle>Sitemap Verification</CardTitle>
              <CardDescription>
                Verify that your sitemap files are accessible and valid
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="mb-4">
                <Button 
                  onClick={handleSitemapSubmission} 
                  disabled={isSubmitting}
                  className="mb-4"
                >
                  {isSubmitting ? 'Submitting...' : 'Submit Sitemaps to Search Engines'}
                </Button>
                <p className="text-sm text-gray-600">
                  This will submit your main sitemap to Google and Bing's search indexes.
                </p>
              </div>
              
              <SitemapVerifier sitemapUrl="/sitemap.xml" />
              <SitemapVerifier sitemapUrl="/sitemap-static.xml" />
              <SitemapVerifier sitemapUrl="/sitemap-vehicles.xml" />
              <SitemapVerifier sitemapUrl="/sitemap-sellers.xml" />
              <SitemapVerifier sitemapUrl="/sitemap-blog.xml" />
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Google Search Console Integration</CardTitle>
              <CardDescription>
                Submit URLs to Google and check indexing status
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600 mb-4">
                This tool helps you manually submit URLs to Google's index and check their status.
              </p>
              
              <div className="flex gap-2 mb-4">
                <Input 
                  type="text" 
                  placeholder="https://sourcemytruck.com/vehicle/123" 
                  value={urlToCheck}
                  onChange={(e) => setUrlToCheck(e.target.value)}
                  className="flex-1"
                />
                <Button variant="outline" disabled={!urlToCheck}>
                  Check URL
                </Button>
              </div>
              
              <div className="p-4 bg-gray-50 rounded-md text-sm text-gray-600">
                <p>
                  Connect to Google Search Console for full functionality.
                </p>
                <p className="mt-2">
                  <a 
                    href="https://search.google.com/search-console" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-blue-600 hover:underline"
                  >
                    Open Google Search Console
                  </a>
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </PageLayout>
  );
};

export default SeoTools;
