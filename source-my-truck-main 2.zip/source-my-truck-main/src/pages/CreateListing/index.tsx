
import { useState, useCallback, useMemo, useEffect, useRef } from "react";
import { useParams, useSearchParams, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import DashboardLayout from "@/components/DashboardLayout";
import RegistrationLookup from "./RegistrationLookup";
import VehicleForm, { VehicleFormRef } from "./VehicleForm";
import PhotoUpload from "./PhotoUpload";
import { useVehicleEdit } from "./hooks/useVehicleEdit";
import { useVehicleCredits } from "./hooks/useVehicleCredits";
import { useVehicleFormSubmit } from "./hooks/useVehicleFormSubmit";
import NoCreditsCard from "./components/NoCreditsCard";
import { ArrowRight, ArrowLeft, Save, CheckCircle, Eye, AlertCircle } from "lucide-react";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";
import { Toaster } from "@/components/ui/sonner";
import LoadingSpinner from "@/components/ui/loading-spinner";
import { VehicleLookupData } from "@/services/types";
import TruckAnimation from "@/components/TruckAnimation";
import StyledCard from "@/components/ui/styled-card";
import { Camera } from "lucide-react";
import InsufficientCreditsDialog from "./components/InsufficientCreditsDialog";
import ListingTierSelector from "./components/ListingTierSelector";

interface UploadedImage {
  url: string;
  isMain: boolean;
}

interface CreateListingPageProps {
  editVehicleId?: string;
}

const CreateListingPage = ({ editVehicleId }: CreateListingPageProps = {}) => {
  const [images, setImages] = useState<UploadedImage[]>([]);
  const [showInsufficientCreditsDialog, setShowInsufficientCreditsDialog] = useState(false);
  const [requiredCredits, setRequiredCredits] = useState(1);
  const [detailsSaved, setDetailsSaved] = useState(false);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  const [currentListingTier, setCurrentListingTier] = useState("standard");
  const [showNoCreditsUI, setShowNoCreditsUI] = useState(false);
  const listingTierRef = useRef("standard");
  const vehicleDataRef = useRef<any>(null);
  
  const params = useParams();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  
  const vehicleFormRef = useRef<VehicleFormRef>(null);
  
  useEffect(() => {
    if (editVehicleId) {
      console.log("CreateListingPage received editVehicleId prop:", editVehicleId);
    }
  }, [editVehicleId]);
  
  const vehicleIdParam = editVehicleId || params.id || searchParams.get("edit");
  
  useEffect(() => {
    if (vehicleIdParam) {
      console.log("Using vehicle ID for edit mode:", vehicleIdParam);
      setDetailsSaved(true);
    }
  }, [vehicleIdParam]);
  
  const { 
    vehicleData, 
    setVehicleData, 
    isEditMode, 
    existingVehicleId, 
    existingImages,
    isLoading: isLoadingVehicle
  } = useVehicleEdit();
  
  useEffect(() => {
    if (vehicleData) {
      vehicleDataRef.current = vehicleData;
      
      if (vehicleData.listingTier && vehicleData.listingTier !== listingTierRef.current) {
        listingTierRef.current = vehicleData.listingTier;
        setCurrentListingTier(vehicleData.listingTier);
      }
    }
  }, [vehicleData]);
  
  const { 
    credits, 
    isCheckingCredits 
  } = useVehicleCredits();
  
  const {
    isLoading: isSubmitting,
    showAnimation,
    handleAnimationComplete,
    handleSubmit
  } = useVehicleFormSubmit(
    vehicleData, 
    images, 
    existingImages, 
    credits, 
    isEditMode, 
    existingVehicleId
  );

  const initialVehicleData = useMemo(() => {
    if (vehicleData) {
      const currentTier = listingTierRef.current;
      
      return {
        ...vehicleData,
        listingTier: currentTier
      };
    }
    
    return {
      make: "",
      model: "",
      year: "",
      bodyType: "",
      fuelType: "",
      transmission: "",
      engineSize: "",
      mileage: "",
      features: [],
      listingTier: listingTierRef.current
    };
  }, [vehicleData]);

  useEffect(() => {
    const hasEnoughCredits = !isCheckingCredits && credits !== null && (isEditMode || credits > 0);
    
    if (credits !== null && hasEnoughCredits) {
      console.log("Current credits available:", credits);
      console.log("Has enough credits:", hasEnoughCredits);
    }
  }, [credits, isCheckingCredits, isEditMode]);

  useEffect(() => {
    if (currentListingTier) {
      console.log("Current listing tier:", currentListingTier);
    }
  }, [currentListingTier]);

  const pageTitle = isEditMode ? "Edit Vehicle Listing" : "Create New Vehicle Listing";

  const handleRegistrationLookup = useCallback((data: VehicleLookupData) => {
    if (!isEditMode) {
      console.log("Setting vehicle data from lookup:", data);
      
      const currentTier = listingTierRef.current;
      console.log("Current tier when setting from lookup:", currentTier);
      
      const processedData = {
        ...data,
        year: data.year?.toString() || "",
        mileage: data.mileage?.toString() || "",
        weight: data.weight?.toString() || "",
        grossVehicleWeight: data.grossVehicleWeight?.toString() || "",
        numberOfSeats: data.numberOfSeats?.toString() || "",
        internalLength: data.internalLength?.toString() || "",
        internalWidth: data.internalWidth?.toString() || "",
        internalHeight: data.internalHeight?.toString() || "",
        externalLength: data.externalLength?.toString() || "",
        externalWidth: data.externalWidth?.toString() || "",
        externalHeight: data.externalHeight?.toString() || "",
        listingTier: currentTier
      };
      
      console.log("Processed vehicle data to set:", processedData);
      
      vehicleDataRef.current = processedData;
      
      setVehicleData(processedData);
      setDetailsSaved(false);
      
      toast.success("Vehicle details successfully retrieved", {
        description: `${data.make} ${data.model} ${data.year || ''}`,
        duration: 3000,
      });
    }
  }, [isEditMode, setVehicleData]);

  const handleVehicleFormSubmit = useCallback((data: any) => {
    if (!data || typeof data === 'function') {
      console.error("Invalid data in handleVehicleFormSubmit");
      return;
    }
    
    console.log("Submitting form data:", data);
    
    if (data.listingTier) {
      setCurrentListingTier(data.listingTier);
      listingTierRef.current = data.listingTier;
    }
    
    vehicleDataRef.current = { ...vehicleDataRef.current, ...data };
    
    setVehicleData(data);
    
    setHasUnsavedChanges(false);
    setDetailsSaved(true);
  }, [setVehicleData]);

  const handleFormChange = useCallback((hasChanges: boolean) => {
    console.log("Form has unsaved changes:", hasChanges);
    setHasUnsavedChanges(hasChanges);
    
    if (hasChanges) {
      setDetailsSaved(false);
    }
  }, []);

  const handleImageUpload = useCallback((newImages: UploadedImage[]) => {
    const hasNewMainImage = newImages.some(img => img.isMain);
    
    setImages(prevImages => {
      let updatedExistingImages = [...prevImages];
      if (hasNewMainImage) {
        updatedExistingImages = updatedExistingImages.map(img => ({
          ...img,
          isMain: false
        }));
      }
      
      return [...updatedExistingImages, ...newImages];
    });
    
    toast.success(`${newImages.length} images uploaded successfully`, {
      description: "Photos have been added to your listing",
    });
  }, []);

  const handleSubmitClick = useCallback(async () => {
    if (!detailsSaved && !isEditMode) {
      toast.error("Save details first", {
        description: "Please save your vehicle details before creating the listing",
      });
      return;
    }
    
    if (hasUnsavedChanges) {
      toast.error("Unsaved changes", {
        description: "Please save your changes before creating the listing",
      });
      return;
    }
    
    if (!vehicleData || !vehicleData.make) {
      toast.error("Missing vehicle data", {
        description: "Please make sure you have saved vehicle details before proceeding",
      });
      return;
    }
    
    const result = await handleSubmit();
    
    if (result?.success) {
      toast.success(isEditMode ? "Listing updated successfully" : "Listing created successfully", {
        description: isEditMode 
          ? "Your vehicle listing has been updated" 
          : "Your vehicle is now listed on the marketplace",
      });
    } else if (result?.insufficientCredits) {
      const tierName = vehicleData?.listingTier === 'premium' 
        ? 'Premium' 
        : 'Standard';
      
      setRequiredCredits(
        vehicleData?.listingTier === 'premium' 
          ? 3 
          : 1
      );
      
      setShowInsufficientCreditsDialog(true);
    } else if (result?.error) {
      toast.error("There was a problem", {
        description: result.error,
      });
    }
  }, [handleSubmit, isEditMode, vehicleData, detailsSaved, hasUnsavedChanges]);

  const handleBackToInventory = useCallback(() => {
    navigate("/inventory");
  }, [navigate]);
  
  const handleSaveDetails = useCallback(() => {
    console.log("Save button clicked, vehicleFormRef:", vehicleFormRef.current);
    
    if (vehicleFormRef.current) {
      vehicleFormRef.current.save();
      
      setHasUnsavedChanges(false);
      setDetailsSaved(true);
      
      setTimeout(() => {
        if (hasUnsavedChanges) {
          setHasUnsavedChanges(false);
        }
        if (!detailsSaved) {
          setDetailsSaved(true);
        }
      }, 100);
    }
  }, [vehicleFormRef, hasUnsavedChanges, detailsSaved]);

  const handleListingTierChange = useCallback((tier: string) => {
    setCurrentListingTier(tier);
    listingTierRef.current = tier;
    
    setVehicleData({ listingTier: tier });
    
    if (vehicleDataRef.current) {
      vehicleDataRef.current.listingTier = tier;
    } else {
      vehicleDataRef.current = { listingTier: tier };
    }
    
    setHasUnsavedChanges(true);
    setDetailsSaved(false);
  }, [setVehicleData]);

  const isButtonDisabled = useMemo(() => {
    return isSubmitting || 
           isLoadingVehicle || 
           (!isEditMode && credits !== null && credits <= 0) || 
           hasUnsavedChanges || 
           (!detailsSaved && !isEditMode);
  }, [isSubmitting, isLoadingVehicle, isEditMode, credits, detailsSaved, hasUnsavedChanges]);

  const buttonText = useMemo(() => {
    if (isSubmitting) {
      return isEditMode ? "Updating..." : "Creating...";
    }
    return isEditMode ? "Update Listing" : "Create Listing";
  }, [isSubmitting, isEditMode]);

  if (showNoCreditsUI) {
    return (
      <DashboardLayout title="Listing creation">
        <div className="container mx-auto px-4 py-8">
          <NoCreditsCard />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout title="Listing creation">
      <Toaster position="top-center" richColors />
      {showAnimation && (
        <TruckAnimation 
          animated={true} 
          onComplete={handleAnimationComplete} 
        />
      )}
      
      <InsufficientCreditsDialog
        isOpen={showInsufficientCreditsDialog}
        onClose={() => setShowInsufficientCreditsDialog(false)}
        requiredCredits={requiredCredits}
        currentCredits={credits}
        tierName={
          vehicleData?.listingTier === 'premium' 
            ? 'Premium' 
            : 'Standard'
        }
      />
      
      <div className="container mx-auto px-4 py-8 max-w-5xl">
        <div className="grid grid-cols-12 gap-6 items-start">
          <div className="hidden lg:block col-span-3">
            <div className="sticky top-24 bg-blue-50 rounded-lg p-5 shadow-sm border border-blue-100">
              <h3 className="font-semibold mb-4 text-blue-800">Listing Steps</h3>
              <div className="space-y-4">
                {!isEditMode && (
                  <div className="flex items-center gap-3 p-2 bg-white rounded-md shadow-sm">
                    <div className="bg-blue-600 text-white rounded-full w-7 h-7 flex items-center justify-center text-sm font-bold">1</div>
                    <span className="font-medium">Registration Lookup</span>
                  </div>
                )}
                <div className={`flex items-center gap-3 p-2 ${!isEditMode ? 'bg-white/60' : 'bg-white'} rounded-md shadow-sm`}>
                  <div className={`${!isEditMode ? 'bg-blue-400' : 'bg-blue-600'} text-white rounded-full w-7 h-7 flex items-center justify-center text-sm font-bold`}>
                    {isEditMode ? 1 : 2}
                  </div>
                  <span className="font-medium">Vehicle Details</span>
                </div>
                <div className="flex items-center gap-3 p-2 bg-white/60 rounded-md shadow-sm">
                  <div className="bg-blue-400 text-white rounded-full w-7 h-7 flex items-center justify-center text-sm font-bold">
                    {isEditMode ? 2 : 3}
                  </div>
                  <span className="font-medium">Upload Photos</span>
                </div>
                <div className="flex items-center gap-3 p-2 bg-white/60 rounded-md shadow-sm">
                  <div className="bg-blue-400 text-white rounded-full w-7 h-7 flex items-center justify-center text-sm font-bold">
                    {isEditMode ? 3 : 4}
                  </div>
                  <span className="font-medium">Review & Submit</span>
                </div>
              </div>
            </div>
          </div>
          
          <div className="col-span-12 lg:col-span-9 space-y-8">
            <div className="flex mb-6 lg:hidden">
              <Button
                variant="outline"
                size="sm"
                onClick={handleBackToInventory}
                className="gap-1"
              >
                <ArrowLeft className="h-4 w-4" />
                Back to Inventory
              </Button>
            </div>
            
            {!isEditMode && (
              <RegistrationLookup 
                onLookup={handleRegistrationLookup} 
              />
            )}

            {isLoadingVehicle ? (
              <div className="flex justify-center py-10">
                <LoadingSpinner text="Loading vehicle data..." />
              </div>
            ) : (
              <VehicleForm 
                ref={vehicleFormRef}
                initialValues={initialVehicleData} 
                onSubmit={handleVehicleFormSubmit}
                onSaveStateChange={setDetailsSaved}
                onFormChange={handleFormChange}
              />
            )}

            <StyledCard 
              title="Vehicle Photos" 
              description="Add high-quality photos to showcase your vehicle"
              icon={<Camera className="h-6 w-6 text-primary" />}
              className="bg-gradient-to-r from-blue-50 to-transparent border-l-4 border-l-blue-400"
            >
              <PhotoUpload 
                onUpload={handleImageUpload}
                existingImages={existingImages}
              />
            </StyledCard>
            
            <StyledCard 
              title="Listing Visibility" 
              description="Choose the visibility level for your listing"
              icon={<Eye className="h-6 w-6 text-primary" />}
              className="bg-gradient-to-r from-purple-50 to-transparent border-l-4 border-l-purple-400"
            >
              <div className="mt-4">
                <ListingTierSelector
                  value={currentListingTier}
                  onChange={handleListingTierChange}
                />
              </div>
            </StyledCard>

            <Separator className="my-8" />

            <div className="flex flex-col md:flex-row justify-between items-center gap-4 bg-gray-50 p-4 rounded-lg shadow-sm">
              <div className="flex items-center">
                {!isEditMode && (
                  <div className="flex items-center">
                    {hasUnsavedChanges ? (
                      <div className="flex items-center gap-2 text-amber-600">
                        <AlertCircle className="h-5 w-5" />
                        <span>You have unsaved changes</span>
                      </div>
                    ) : detailsSaved ? (
                      <div className="flex items-center gap-2 text-green-600">
                        <CheckCircle className="h-5 w-5" />
                        <span>Details saved</span>
                      </div>
                    ) : (
                      <div className="text-amber-600 flex items-center gap-2">
                        <AlertCircle className="h-5 w-5" />
                        <span>Save your details before proceeding</span>
                      </div>
                    )}
                  </div>
                )}
              </div>
              
              <div className="flex items-center gap-4">
                <Button 
                  variant={hasUnsavedChanges ? "default" : "secondary"}
                  className={`px-6 ${hasUnsavedChanges ? "bg-blue-600 hover:bg-blue-700" : ""}`}
                  onClick={handleSaveDetails}
                  id="save-vehicle-details-button"
                >
                  <Save className="h-4 w-4 mr-2" />
                  {hasUnsavedChanges ? "Save Changes" : "Save Details"}
                </Button>
                
                <Button
                  className={`px-8 py-6 text-lg gap-2 shadow-lg ${!detailsSaved || hasUnsavedChanges ? 'bg-gray-400 hover:bg-gray-400 cursor-not-allowed' : 'bg-blue-600 hover:bg-blue-700'}`}
                  onClick={handleSubmitClick}
                  disabled={isButtonDisabled}
                >
                  {isSubmitting ? (
                    <LoadingSpinner size={18} className="mr-2" />
                  ) : null}
                  {buttonText}
                  <ArrowRight className="h-5 w-5" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default CreateListingPage;
