
import { useState, useEffect, useCallback, useRef } from "react";
import { Card, CardContent } from "@/components/ui/card";
import VehicleFormContent from "./VehicleFormContent";

interface VehicleFormContainerProps {
  initialValues: any;
  onSubmit: (data: any) => void;
}

const VehicleFormContainer = ({ initialValues, onSubmit }: VehicleFormContainerProps) => {
  const [formValues, setFormValues] = useState({
    make: "",
    model: "",
    year: "",
    color: "",
    fuelType: "",
    transmission: "",
    engineSize: "",
    bodyType: "",
    axleConfiguration: "",
    weight: "",
    price: "",
    isPOA: false,
    description: "", // Initialize with empty string
    status: "active", // Default status
    interiorCondition: "",
    exteriorCondition: "",
    features: [],
    mileage: "",
    registration: "",
    cabType: "",
    driverPosition: "",
    enginePower: "",
    emissionsClass: "",
    numberOfSeats: "",
    grossVehicleWeight: "",
    volume: "",
    internalLength: "",
    internalWidth: "",
    internalHeight: "",
    externalLength: "",
    externalWidth: "",
    externalHeight: "",
    isNew: false
  });
  
  const [isInitialLoad, setIsInitialLoad] = useState(true);
  const [manuallyChanged, setManuallyChanged] = useState(false);
  const initialValuesRef = useRef(null);
  const debounceTimerRef = useRef<NodeJS.Timeout | null>(null);
  const previousInitialValuesRef = useRef<string | null>(null);

  useEffect(() => {
    // Only update form values if initialValues have actually changed
    // We'll stringify the initialValues to properly detect changes
    const initialValuesStr = JSON.stringify(initialValues);
    
    if (initialValues && 
        (previousInitialValuesRef.current !== initialValuesStr)) {
      
      console.log("Initial values updated in VehicleForm:", initialValues);
      initialValuesRef.current = initialValues;
      previousInitialValuesRef.current = initialValuesStr;
      
      setFormValues(prev => ({
        ...prev,
        make: initialValues.make || prev.make || "",
        model: initialValues.model || prev.model || "",
        year: initialValues.year || prev.year || "",
        color: initialValues.color || prev.color || "",
        fuelType: initialValues.fuelType || prev.fuelType || "",
        transmission: initialValues.transmission || prev.transmission || "",
        engineSize: initialValues.engineSize || prev.engineSize || "",
        bodyType: initialValues.bodyType || prev.bodyType || "",
        axleConfiguration: initialValues.axleConfiguration || prev.axleConfiguration || "",
        weight: initialValues.weight?.toString() || prev.weight || "",
        price: initialValues.price?.toString() || prev.price || "",
        isPOA: initialValues.isPOA || prev.isPOA || false,
        description: initialValues.description || prev.description || "", // Ensure description is never undefined
        status: initialValues.status || prev.status || "active", 
        interiorCondition: initialValues.interiorCondition || prev.interiorCondition || "",
        exteriorCondition: initialValues.exteriorCondition || prev.exteriorCondition || "",
        features: initialValues.features || prev.features || [],
        mileage: initialValues.mileage?.toString() || prev.mileage || "",
        registration: initialValues.registration || prev.registration || "",
        cabType: initialValues.cabType || prev.cabType || "",
        driverPosition: initialValues.driverPosition || prev.driverPosition || "",
        enginePower: initialValues.enginePower || prev.enginePower || "",
        emissionsClass: initialValues.emissionsClass || prev.emissionsClass || "",
        numberOfSeats: initialValues.numberOfSeats?.toString() || prev.numberOfSeats || "",
        grossVehicleWeight: initialValues.grossVehicleWeight?.toString() || prev.grossVehicleWeight || "",
        volume: initialValues.volume || prev.volume || "",
        internalLength: initialValues.internalLength?.toString() || prev.internalLength || "",
        internalWidth: initialValues.internalWidth?.toString() || prev.internalWidth || "",
        internalHeight: initialValues.internalHeight?.toString() || prev.internalHeight || "",
        externalLength: initialValues.externalLength?.toString() || prev.externalLength || "",
        externalWidth: initialValues.externalWidth?.toString() || prev.externalWidth || "",
        externalHeight: initialValues.externalHeight?.toString() || prev.externalHeight || "",
        isNew: initialValues.isNew || prev.isNew || false
      }));
      
      setIsInitialLoad(false);
    }
  }, [initialValues]);

  const handleInputChange = useCallback((e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { id, value } = e.target;
    
    console.log(`Input changed: ${id} = ${value}`);
    
    if (id === 'weight' || id === 'mileage') {
      const numericValue = value.replace(/[^\d]/g, '');
      setFormValues(prev => ({ ...prev, [id]: numericValue }));
    } else if (id === 'price') {
      let numericValue = value.replace(/[^\d]/g, '');
      numericValue = numericValue.replace(/^0+(?=\d)/, '');
      setFormValues(prev => ({ ...prev, [id]: numericValue }));
    } else {
      // Extra logging for description field to debug
      if (id === 'description') {
        console.log("Description field changed to:", value);
        console.log("Description type:", typeof value);
      }
      setFormValues(prev => ({ ...prev, [id]: value }));
    }
    setManuallyChanged(true);
  }, []);
  
  const handleSelectChange = useCallback((id: string, value: string) => {
    console.log(`Select change: ${id} = ${value}`);
    setFormValues(prev => ({ ...prev, [id]: value }));
    setManuallyChanged(true);
  }, []);

  const handleRadioChange = useCallback((id: string, value: string) => {
    console.log(`Radio change in VehicleForm: ${id} = ${value}`);
    setFormValues(prev => {
      const newValues = { 
        ...prev, 
        [id]: id === 'isNew' ? value === 'new' : value 
      };
      console.log("Updated form values after radio change:", newValues);
      return newValues;
    });
    setManuallyChanged(true);
  }, []);

  const handleFeaturesChange = useCallback((features: string[]) => {
    setFormValues(prev => ({ ...prev, features }));
    setManuallyChanged(true);
  }, []);

  const handleCheckboxChange = useCallback((checked: boolean) => {
    console.log("POA checkbox changed to:", checked);
    setFormValues(prev => ({ 
      ...prev, 
      isPOA: checked,
      price: checked ? "" : prev.price
    }));
    setManuallyChanged(true);
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Submitting form with values:", formValues);
    
    // Ensure description is always a string before submission
    const finalValues = {
      ...formValues,
      description: formValues.description || "", // Empty string is valid
      status: formValues.status || "active"
    };
    
    console.log("Final form values being submitted:", finalValues);
    onSubmit(finalValues);
  };

  useEffect(() => {
    if (manuallyChanged && !isInitialLoad) {
      // Clear any existing timer
      if (debounceTimerRef.current) {
        clearTimeout(debounceTimerRef.current);
      }
      
      // Set new timer with a longer debounce to reduce update frequency
      debounceTimerRef.current = setTimeout(() => {
        console.log("Updating parent with form values:", formValues);
        
        // Always ensure these critical fields have values
        const updatedValues = {
          ...formValues,
          description: formValues.description || "",  // Empty string is valid
          status: formValues.status || "active"
        };
        
        onSubmit(updatedValues);
      }, 1000); // Increased debounce time
    }
    
    // Cleanup timer on unmount
    return () => {
      if (debounceTimerRef.current) {
        clearTimeout(debounceTimerRef.current);
      }
    };
  }, [formValues, onSubmit, manuallyChanged, isInitialLoad]);

  return (
    <Card className="mb-6">
      <CardContent className="pt-6">
        <form onSubmit={(e) => {
          e.preventDefault();
          console.log("Form submitted with values:", formValues);
          onSubmit(formValues);
        }} className="space-y-6">
          <VehicleFormContent
            formValues={formValues}
            handleInputChange={handleInputChange}
            handleSelectChange={handleSelectChange} 
            handleRadioChange={handleRadioChange}
            handleFeaturesChange={handleFeaturesChange}
            handleCheckboxChange={handleCheckboxChange}
          />
        </form>
      </CardContent>
    </Card>
  );
};

export default VehicleFormContainer;
