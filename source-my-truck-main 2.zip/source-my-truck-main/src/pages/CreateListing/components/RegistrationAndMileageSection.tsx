
import { FormField } from "@/components/ui/form-field";

interface RegistrationAndMileageSectionProps {
  registration: string;
  mileage: string;
  handleInputChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => void;
}

const RegistrationAndMileageSection = ({
  registration,
  mileage, 
  handleInputChange
}: RegistrationAndMileageSectionProps) => {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <FormField
          id="registration"
          label="Registration Number (optional)"
          type="text"
          value={registration}
          onChange={handleInputChange}
          placeholder="Enter vehicle registration (if available)"
          className="uppercase"
        />
        
        <FormField
          id="mileage"
          label="Mileage (miles, optional)"
          type="text"
          value={mileage}
          onChange={handleInputChange}
          placeholder="Enter vehicle mileage if known"
        />
      </div>
    </div>
  );
};

export default RegistrationAndMileageSection;
