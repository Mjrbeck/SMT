
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { ShieldAlert, CreditCard } from "lucide-react";

interface InsufficientCreditsDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenChange?: (open: boolean) => void; // Added this property
  requiredCredits: number;
  currentCredits: number | null;
  tierName: string;
}

const InsufficientCreditsDialog = ({
  isOpen,
  onClose,
  onOpenChange,
  requiredCredits,
  currentCredits,
  tierName
}: InsufficientCreditsDialogProps) => {
  const navigate = useNavigate();
  const [showDialog, setShowDialog] = useState(isOpen);
  
  useEffect(() => {
    setShowDialog(isOpen);
  }, [isOpen]);
  
  const handlePurchase = () => {
    navigate("/settings?tab=credits");
    onClose();
  };
  
  const handleCancel = () => {
    setShowDialog(false);
    if (onOpenChange) {
      onOpenChange(false);
    }
    onClose();
  };
  
  const creditShortage = requiredCredits - (currentCredits || 0);
  
  return (
    <AlertDialog 
      open={showDialog} 
      onOpenChange={(open) => {
        setShowDialog(open);
        if (onOpenChange) {
          onOpenChange(open);
        }
        if (!open) {
          onClose();
        }
      }}
    >
      <AlertDialogContent className="max-w-md">
        <AlertDialogHeader>
          <div className="flex items-center gap-2 text-amber-500 mb-2">
            <ShieldAlert className="h-5 w-5" />
            <AlertDialogTitle>Insufficient Credits</AlertDialogTitle>
          </div>
          <AlertDialogDescription className="space-y-4">
            <p>
              You don't have enough credits to create a <span className="font-medium">{tierName}</span> listing.
            </p>
            <div className="bg-muted p-4 rounded-lg mt-4">
              <div className="flex justify-between items-center">
                <span>Required credits:</span>
                <span className="font-medium">{requiredCredits}</span>
              </div>
              <div className="flex justify-between items-center mt-1">
                <span>Your current balance:</span>
                <span className="font-medium">{currentCredits || 0}</span>
              </div>
              <div className="border-t border-border mt-2 pt-2 flex justify-between items-center">
                <span className="font-medium">Shortage:</span>
                <span className="font-medium text-red-500">{creditShortage > 0 ? creditShortage : 0}</span>
              </div>
            </div>
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter className="flex-col space-y-2 sm:space-y-0 sm:flex-row">
          <AlertDialogCancel onClick={handleCancel} className="mt-0">
            Close
          </AlertDialogCancel>
          <AlertDialogAction onClick={handlePurchase} className="bg-primary hover:bg-primary/90 gap-2">
            <CreditCard className="h-4 w-4" />
            Purchase Credits
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
};

export default InsufficientCreditsDialog;
