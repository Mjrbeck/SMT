import { useMemo, memo } from "react";
import { Separator } from "@/components/ui/separator";
import BasicVehicleInfoForm from "@/components/forms/BasicVehicleInfoForm";
import TechnicalSpecsForm from "@/components/forms/TechnicalSpecsForm";
import ListingDetailsForm from "@/components/forms/ListingDetailsForm";
import FeaturesInput from "@/components/vehicle/FeaturesInput";
import RegistrationAndMileageSection from "./RegistrationAndMileageSection";
import StyledCard from "@/components/ui/styled-card";
import { 
  Car, 
  Gauge, 
  TabletSmartphone, 
  Tag, 
  CheckSquare, 
  Truck,
  Video
} from "lucide-react";
import { FormField } from "@/components/ui/form-field";

interface VehicleFormContentProps {
  formValues: any;
  handleInputChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => void;
  handleSelectChange: (id: string, value: string) => void;
  handleRadioChange: (id: string, value: string) => void;
  handleFeaturesChange: (features: string[]) => void;
  handleCheckboxChange: (checked: boolean) => void;
}

// Use React.memo to prevent unnecessary re-renders
const VehicleFormContent = memo(({
  formValues,
  handleInputChange,
  handleSelectChange,
  handleRadioChange,
  handleFeaturesChange,
  handleCheckboxChange
}: VehicleFormContentProps) => {
  // Remove excessive logging

  const basicVehicleInfo = useMemo(() => ({
    make: formValues.make,
    model: formValues.model,
    year: formValues.year,
    color: formValues.color
  }), [formValues.make, formValues.model, formValues.year, formValues.color]);

  const technicalSpecs = useMemo(() => ({
    fuelType: formValues.fuelType,
    transmission: formValues.transmission,
    engineSize: formValues.engineSize,
    bodyType: formValues.bodyType,
    axleConfiguration: formValues.axleConfiguration,
    weight: formValues.weight ? formValues.weight.toString() : "",
    interiorCondition: formValues.interiorCondition,
    exteriorCondition: formValues.exteriorCondition,
    cabType: formValues.cabType,
    driverPosition: formValues.driverPosition,
    enginePower: formValues.enginePower,
    emissionsClass: formValues.emissionsClass,
    color: formValues.color,
    numberOfSeats: formValues.numberOfSeats ? formValues.numberOfSeats.toString() : "",
    grossVehicleWeight: formValues.grossVehicleWeight ? formValues.grossVehicleWeight.toString() : "",
    volume: formValues.volume,
    internalLength: formValues.internalLength ? formValues.internalLength.toString() : "",
    internalWidth: formValues.internalWidth ? formValues.internalWidth.toString() : "",
    internalHeight: formValues.internalHeight ? formValues.internalHeight.toString() : "",
    externalLength: formValues.externalLength ? formValues.externalLength.toString() : "",
    externalWidth: formValues.externalWidth ? formValues.externalWidth.toString() : "",
    externalHeight: formValues.externalHeight ? formValues.externalHeight.toString() : "",
    isNew: formValues.isNew
  }), [
    formValues.fuelType, 
    formValues.transmission, 
    formValues.engineSize, 
    formValues.bodyType, 
    formValues.axleConfiguration, 
    formValues.weight,
    formValues.interiorCondition,
    formValues.exteriorCondition,
    formValues.cabType,
    formValues.driverPosition,
    formValues.enginePower,
    formValues.emissionsClass,
    formValues.color,
    formValues.numberOfSeats,
    formValues.grossVehicleWeight,
    formValues.volume,
    formValues.internalLength,
    formValues.internalWidth,
    formValues.internalHeight,
    formValues.externalLength,
    formValues.externalWidth,
    formValues.externalHeight,
    formValues.isNew
  ]);

  const listingDetails = useMemo(() => ({
    price: formValues.price,
    isPOA: formValues.isPOA,
    description: formValues.description || "",
    status: formValues.status || "active",
    listingTier: "standard"
  }), [
    formValues.price, 
    formValues.isPOA, 
    formValues.description, 
    formValues.status
  ]);

  return (
    <div className="space-y-10">
      <StyledCard 
        title="Basic Information" 
        description="Essential details about your vehicle"
        icon={<Truck className="h-6 w-6 text-primary" />}
        className="bg-gradient-to-r from-blue-50 to-transparent border-l-4 border-l-blue-400"
      >
        <BasicVehicleInfoForm 
          formValues={basicVehicleInfo} 
          handleInputChange={handleInputChange}
        />
        
        <div className="mt-6">
          <RegistrationAndMileageSection
            registration={formValues.registration || ""}
            mileage={formValues.mileage?.toString() || ""}
            handleInputChange={handleInputChange}
          />
        </div>
      </StyledCard>
      
      <StyledCard 
        title="Technical Specifications" 
        description="Add detailed technical information about your vehicle"
        icon={<Gauge className="h-6 w-6 text-primary" />}
        className="bg-gradient-to-r from-purple-50 to-transparent border-l-4 border-l-purple-400"
      >
        <TechnicalSpecsForm 
          formValues={technicalSpecs}
          handleInputChange={handleInputChange}
          handleSelectChange={handleSelectChange}
          handleRadioChange={handleRadioChange}
        />
      </StyledCard>
      
      <StyledCard 
        title="Listing Details" 
        description="Set your price and add a description to attract buyers"
        icon={<Tag className="h-6 w-6 text-primary" />}
        className="bg-gradient-to-r from-amber-50 to-transparent border-l-4 border-l-amber-400"
      >
        <ListingDetailsForm 
          formValues={listingDetails}
          allVehicleData={formValues}
          handleInputChange={handleInputChange}
          handleSelectChange={handleSelectChange}
          handleCheckboxChange={handleCheckboxChange}
          handleRadioChange={handleRadioChange}
        />
      </StyledCard>
      
      <StyledCard 
        title="Vehicle Media" 
        description="Add a YouTube video to showcase your vehicle"
        icon={<Video className="h-6 w-6 text-primary" />}
        className="bg-gradient-to-r from-red-50 to-transparent border-l-4 border-l-red-400"
      >
        <div className="mt-4">
          <FormField
            id="videoUrl"
            label="YouTube Video URL"
            tooltip="Add a YouTube video link to showcase your vehicle in action"
            placeholder="https://www.youtube.com/watch?v=..."
            value={formValues.videoUrl || ""}
            onChange={handleInputChange}
            className="mb-2"
          />
          <p className="text-sm text-gray-500 mt-2">
            Enter a YouTube video URL to showcase your vehicle. This will be displayed on your listing page.
          </p>
        </div>
      </StyledCard>
      
      <StyledCard 
        title="Vehicle Features" 
        description="Select the features that your vehicle includes"
        icon={<CheckSquare className="h-6 w-6 text-primary" />}
        className="bg-gradient-to-r from-emerald-50 to-transparent border-l-4 border-l-emerald-400"
      >
        <FeaturesInput 
          features={formValues.features || []}
          onChange={handleFeaturesChange}
        />
      </StyledCard>
    </div>
  );
});

VehicleFormContent.displayName = 'VehicleFormContent';

export default VehicleFormContent;
