
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { CreditCard, BadgeAlert, BadgeCheck, AlertTriangle, RefreshCw } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useInventory } from "@/contexts/InventoryContext";
import { invalidateCreditsCache } from "@/services/credits";
import { toast } from "sonner";

const NoCreditsCard = () => {
  const navigate = useNavigate();
  const [isTestMode, setIsTestMode] = useState<boolean | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const { credits, fetchCredits } = useInventory();
  
  // Check if in test mode
  useEffect(() => {
    const checkTestMode = async () => {
      try {
        setIsLoading(true);
        const { data, error } = await supabase.functions.invoke('stripe-checkout', {
          body: { checkTestMode: true }
        });
        
        if (error) {
          console.error("Error checking test mode:", error);
        }
        
        if (data && typeof data.isTest === 'boolean') {
          setIsTestMode(data.isTest);
        }
        setIsLoading(false);
      } catch (error) {
        console.error("Error checking test mode:", error);
        setIsLoading(false);
      }
    };
    
    checkTestMode();
  }, []);
  
  // Force refresh global context credits
  const forceRefreshCredits = async () => {
    setIsRefreshing(true);
    try {
      if (fetchCredits) {
        // Invalidate cache first
        invalidateCreditsCache();
        await fetchCredits();
        toast.success("Credits refreshed");
      } else {
        toast.error("Could not refresh credits (context method unavailable)");
      }
    } catch (error) {
      console.error("Error refreshing credits:", error);
      toast.error("Error refreshing credits");
    } finally {
      setIsRefreshing(false);
    }
  };
  
  const handlePurchaseClick = () => {
    navigate('/settings?tab=credits');
  };
  
  return (
    <Card className="border-amber-200 shadow-lg max-w-2xl mx-auto">
      <CardHeader className="bg-gradient-to-r from-amber-50 to-amber-100 rounded-t-lg border-b border-amber-200">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center text-amber-700 text-xl">
            <AlertTriangle className="mr-2 h-6 w-6 text-amber-600" />
            No Credits Available
          </CardTitle>
          
          {isTestMode !== null && !isLoading && (
            <div className={`px-3 py-1 rounded-full text-xs font-medium flex items-center ${
              isTestMode ? 'bg-amber-100 text-amber-800 border border-amber-300' : 'bg-green-100 text-green-800 border border-green-300'
            }`}>
              {isTestMode ? (
                <>
                  <BadgeAlert className="h-3 w-3 mr-1" />
                  Test Mode
                </>
              ) : (
                <>
                  <BadgeCheck className="h-3 w-3 mr-1" />
                  Live Mode
                </>
              )}
            </div>
          )}
        </div>
        <CardDescription className="text-amber-700 font-medium mt-2">
          You need credits to create vehicle listings
        </CardDescription>
      </CardHeader>
      <CardContent className="pt-6 pb-4">
        <div className="bg-amber-50 p-4 rounded-lg border border-amber-100 mb-4">
          <p className="text-amber-800">
            You currently have <span className="font-bold">{credits === null ? "..." : credits} credits</span>. Each vehicle listing requires:
          </p>
          <ul className="list-disc list-inside mt-2 space-y-1 text-amber-700">
            <li><span className="font-medium">Standard listing</span>: 1 credit</li>
            <li><span className="font-medium">Premium listing</span>: 3 credits</li>
          </ul>
          <p className="mt-3 text-amber-800">
            New accounts receive 1 free credit upon registration, but it seems you've used it.
            Please purchase additional credits to continue.
          </p>
          
          <div className="mt-4 flex justify-end">
            <Button 
              size="sm" 
              variant="outline" 
              onClick={forceRefreshCredits}
              disabled={isRefreshing}
              className="text-xs h-8 bg-green-100 border-green-300 text-green-800 hover:bg-green-200 flex items-center"
            >
              <RefreshCw className={`h-3 w-3 mr-1.5 ${isRefreshing ? 'animate-spin' : ''}`} />
              {isRefreshing ? "Refreshing..." : "Refresh Credits"}
            </Button>
          </div>
        </div>
      </CardContent>
      <CardFooter className="bg-gradient-to-r from-amber-50 to-amber-100 rounded-b-lg border-t border-amber-200 pt-4">
        <Button 
          onClick={handlePurchaseClick} 
          className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2"
          size="lg"
          disabled={isLoading}
        >
          <CreditCard className="mr-2 h-5 w-5" />
          Purchase Credits
        </Button>
      </CardFooter>
    </Card>
  );
};

export default NoCreditsCard;
