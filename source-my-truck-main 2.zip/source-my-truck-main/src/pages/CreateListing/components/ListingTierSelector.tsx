
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { CircleIcon, CheckCircle2, RefreshCw } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { useInventory } from "@/contexts/InventoryContext";
import { useEffect, useRef, useState, memo } from "react";
import { Button } from "@/components/ui/button";
import { invalidateCreditsCache } from "@/services/credits";
import { toast } from "sonner";

interface ListingTierSelectorProps {
  value: string;
  onChange: (value: string) => void;
  showCreditsWarning?: boolean;
}

// Memoize the component to prevent unnecessary re-renders
const ListingTierSelector = memo(({ value, onChange, showCreditsWarning = true }: ListingTierSelectorProps) => {
  const { credits, fetchCredits } = useInventory();
  // Use a ref to track the selected tier and avoid sync issues
  const selectedTierRef = useRef("standard");
  const [internalValue, setInternalValue] = useState("standard");
  const isInitialMount = useRef(true);
  const [lastCreditsCheck, setLastCreditsCheck] = useState<number | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);
  
  // Update ref and internal state when prop changes
  useEffect(() => {
    if (value) {
      selectedTierRef.current = "standard";
      setInternalValue("standard");
    }
  }, [value]);
  
  // Track when credits change but don't log it
  useEffect(() => {
    const now = Date.now();
    setLastCreditsCheck(now);
  }, [credits]);
  
  const refreshCredits = async () => {
    setIsRefreshing(true);
    try {
      if (fetchCredits) {
        // Invalidate cache first
        invalidateCreditsCache();
        await fetchCredits();
        toast.success("Credits refreshed");
      } else {
        toast.error("Cannot refresh credits (method unavailable)");
      }
    } catch (error) {
      console.error("Error refreshing credits:", error);
    } finally {
      setIsRefreshing(false);
    }
  };
  
  // Define just the standard tier
  const tier = {
    id: "standard",
    name: "Standard Listing",
    description: "Basic listing that appears in the standard search results.",
    creditCost: 1,
    icon: CircleIcon,
    color: "bg-blue-100 text-blue-700",
    disabled: showCreditsWarning && credits !== null && credits < 1,
    benefits: [
      "Appears in standard search results",
      "Basic listing visibility",
      "30-day listing period"
    ]
  };

  // Always set to standard
  const handleTierChange = () => {
    // No-op since we only have standard now
    selectedTierRef.current = "standard";
    setInternalValue("standard");
    onChange("standard");
  };

  // Use the most reliable value source
  const displayValue = "standard";

  return (
    <div className="space-y-4">
      <div className="bg-blue-50 dark:bg-blue-950/30 p-4 rounded-md text-sm text-blue-700 dark:text-blue-300 border border-blue-100 dark:border-blue-800 mb-2">
        <div className="flex items-center justify-between">
          <p className="font-medium">Listing credits required:</p>
          <Button 
            size="sm" 
            variant="ghost" 
            onClick={refreshCredits}
            disabled={isRefreshing}
            className="text-xs h-7 text-blue-600 hover:text-blue-800 hover:bg-blue-100/50 flex items-center"
          >
            <RefreshCw className={`h-3 w-3 mr-1 ${isRefreshing ? 'animate-spin' : ''}`} />
            {isRefreshing ? "Refreshing..." : "Refresh"}
          </Button>
        </div>
        <ul className="list-disc pl-5 mt-2 space-y-1">
          <li>Standard listing: 1 credit</li>
        </ul>
        <p className="mt-2 font-medium">You currently have: <span className="text-blue-800 dark:text-blue-200 text-lg">{credits === null ? "Loading..." : credits} {credits === 1 ? 'credit' : 'credits'}</span></p>
      </div>
      
      <RadioGroup
        value={displayValue}
        onValueChange={handleTierChange}
        className="grid gap-4"
      >
        <div className="relative">
          <RadioGroupItem
            value="standard"
            id="tier-standard"
            className="sr-only"
            disabled={tier.disabled}
          />
          <Label
            htmlFor="tier-standard"
            className="cursor-pointer h-full"
          >
            <Card className={`p-4 h-full transition-all hover:shadow-md border-2 border-primary ring-1 ring-primary ${tier.disabled ? 'opacity-60' : ''}`}>
              <div className="flex flex-col h-full">
                <div className="flex items-center justify-between mb-3">
                  <div className={`p-2 rounded-full ${tier.color}`}>
                    <tier.icon className="h-4 w-4" />
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">
                      {tier.creditCost} Credit
                    </Badge>
                  </div>
                </div>
                
                <div className="mb-3">
                  <h4 className="font-medium text-lg">{tier.name}</h4>
                  <p className="text-sm text-muted-foreground mt-1">
                    {tier.description}
                  </p>
                </div>
                
                <div className="flex-1">
                  <div className="text-sm space-y-2">
                    {tier.benefits.map((benefit, index) => (
                      <div key={index} className="flex items-start">
                        <CheckCircle2 className="h-4 w-4 mr-2 text-green-600 mt-0.5 flex-shrink-0" />
                        <span>{benefit}</span>
                      </div>
                    ))}
                  </div>
                </div>
                
                {tier.disabled && showCreditsWarning && (
                  <div className="mt-3 text-xs text-red-500 bg-red-50 p-2 rounded border border-red-200">
                    Not enough credits available for this option
                  </div>
                )}
              </div>
            </Card>
          </Label>
        </div>
      </RadioGroup>
    </div>
  );
});

export default ListingTierSelector;
