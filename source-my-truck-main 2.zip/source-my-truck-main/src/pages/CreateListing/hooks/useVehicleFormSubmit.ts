import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";
import { saveVehicleListing } from "@/services/vehicles/vehicleManagementService";

interface UploadedImage {
  url: string;
  isMain: boolean;
}

interface SubmitResult {
  success: boolean;
  vehicleId?: string;
  error: string | null;
  insufficientCredits?: boolean;
}

const LISTING_TIER_COSTS = {
  standard: 1,
  premium: 3
};

export const useVehicleFormSubmit = (
  vehicleData: any,
  images: UploadedImage[],
  existingImages: UploadedImage[],
  credits: number | null,
  isEditMode: boolean,
  existingVehicleId: string | null
) => {
  const [isLoading, setIsLoading] = useState(false);
  const [showAnimation, setShowAnimation] = useState(false);
  const navigate = useNavigate();
  const { toast: legacyToast } = useToast();
  const { user } = useAuth();

  const validateRequiredFields = () => {
    const requiredFields = ['make', 'year'];
    
    if (!vehicleData) {
      return ['make', 'year'];
    }

    console.log("Validating vehicle data:", vehicleData);
    
    const missingFields = requiredFields.filter(field => !vehicleData[field]);
    
    const isPOA = vehicleData.isPOA === true || vehicleData.isPOA === "true";
    console.log("isPOA parsed value:", isPOA);
    
    if (!isPOA) {
      let priceValue: string | number = '';
      
      if (typeof vehicleData.price === 'number') {
        priceValue = vehicleData.price;
      } else if (typeof vehicleData.price === 'string') {
        priceValue = vehicleData.price;
      }
      
      const priceIsEmpty = priceValue === '' || priceValue === undefined;
      const priceIsZero = priceValue === '0' || priceValue === 0;
      
      console.log("Price validation - Value:", priceValue, 
                 "Empty:", priceIsEmpty, 
                 "Zero:", priceIsZero);
                 
      if (priceIsEmpty || priceIsZero) {
        missingFields.push('price');
      }
    }
    
    console.log("Missing fields:", missingFields);
    
    return missingFields;
  };

  const handleAnimationComplete = () => {
    setShowAnimation(false);
    navigate("/inventory");
  };

  const getRequiredCredits = async (newTier: string, existingTier?: string) => {
    if (isEditMode) {
      console.log(`Edit mode detected, no credits required to update listing`);
      return 0;
    }
    
    const newTierCost = LISTING_TIER_COSTS[newTier as keyof typeof LISTING_TIER_COSTS] || 1;
    console.log(`New listing with tier ${newTier}, cost: ${newTierCost}`);
    return newTierCost;
  };

  const handleSubmit = async (): Promise<SubmitResult> => {
    console.log("Starting form submission with data:", vehicleData);
    console.log("Button state check - isEditMode:", isEditMode);
    
    if (!vehicleData) {
      legacyToast({
        title: "Missing Vehicle Data",
        description: "Please complete the form before submitting.",
        variant: "destructive",
      });
      return { success: false, error: "Missing vehicle data" };
    }

    console.log("Starting vehicle form submit...");
    console.log("Vehicle data structure:", Object.keys(vehicleData));
    console.log("Make:", vehicleData.make);
    console.log("Model:", vehicleData.model);
    console.log("Year:", vehicleData.year);
    console.log("Price:", vehicleData.price);
    console.log("isPOA:", vehicleData.isPOA);
    console.log("Tier:", vehicleData.listingTier);
    console.log("IS EDIT MODE:", isEditMode);
    console.log("EXISTING VEHICLE ID:", existingVehicleId);

    const tier = (vehicleData.listingTier === 'premium') ? 'premium' : 'standard';
    
    const requiredCredits = await getRequiredCredits(tier);
    console.log("Required credits:", requiredCredits);

    if (requiredCredits > 0 && credits !== null && credits < requiredCredits) {
      console.log(`Client-side credit check failed: ${credits} available, ${requiredCredits} needed`);
      return { 
        success: false, 
        error: `You need at least ${requiredCredits} credits for this operation.`, 
        insufficientCredits: true 
      };
    }

    const missingFields = validateRequiredFields();
    if (missingFields.length > 0) {
      const errorMessage = `Please fill in all required fields: ${missingFields.join(', ')}`;
      legacyToast({
        title: "Required Fields Missing",
        description: errorMessage,
        variant: "destructive",
      });
      console.error("Validation failed - missing fields:", missingFields);
      return { success: false, error: errorMessage };
    }

    if (!user) {
      const errorMessage = "Please sign in to create a vehicle listing.";
      legacyToast({
        title: "Authentication Required",
        description: errorMessage,
        variant: "destructive",
      });
      return { success: false, error: errorMessage };
    }

    setIsLoading(true);

    try {
      console.log("Saving vehicle listing...");
      
      const isPOA = vehicleData.isPOA === true || vehicleData.isPOA === "true";
      
      let priceValue = 0;
      if (!isPOA && vehicleData.price !== undefined && vehicleData.price !== "") {
        if (typeof vehicleData.price === 'number') {
          priceValue = vehicleData.price;
        } else {
          const parsed = parseFloat(vehicleData.price);
          priceValue = isNaN(parsed) ? 0 : parsed;
        }
      }
      
      if (!isPOA && priceValue <= 0) {
        legacyToast({
          title: "Invalid Price",
          description: "Please enter a price greater than zero or select Price on Application (POA).",
          variant: "destructive",
        });
        setIsLoading(false);
        return { success: false, error: "Price must be greater than zero for non-POA listings" };
      }
      
      const processedVehicleData = {
        ...vehicleData,
        mileage: vehicleData.mileage !== undefined && vehicleData.mileage !== "" ? 
          parseFloat(vehicleData.mileage) : null,
        model: vehicleData.model !== undefined && vehicleData.model !== "" ?
          String(vehicleData.model) : null,
        status: vehicleData.status || 'active',
        description: vehicleData.description || "",
        isPOA: isPOA,
        listingTier: tier,
        price: isPOA ? 0 : priceValue
      };
      
      console.log("Processed data before saving:", processedVehicleData);
      
      const { success, vehicleId, error, insufficientCredits } = await saveVehicleListing(
        processedVehicleData,
        user.id,
        isEditMode ? existingVehicleId || undefined : undefined,
        requiredCredits
      );

      if (insufficientCredits) {
        console.log("Server reported insufficient credits");
        return { 
          success: false, 
          error: `You need at least ${requiredCredits} credits for this operation.`, 
          insufficientCredits: true 
        };
      }

      if (!success || !vehicleId) {
        console.error('Vehicle save error:', error);
        return { success: false, error: error || "Failed to save vehicle listing" };
      }
      
      if ((images.length > 0 || existingImages.length > 0) && vehicleId) {
        await handleImageUploads(vehicleId, images, existingImages, isEditMode);
      }
      
      if (!isEditMode) {
        setShowAnimation(true);
        setTimeout(() => {
          navigate("/inventory");
        }, 2000);
      } else {
        navigate("/inventory");
      }
      
      try {
        const { data: userData } = await supabase
          .from('profiles')
          .select('company_name')
          .eq('id', user.id)
          .single();

        const userName = userData?.company_name || 'valued customer';

        await supabase.functions.invoke('send-listing-email', {
          body: {
            vehicleTitle: processedVehicleData.title,
            userEmail: user.email,
            userName,
            registration: processedVehicleData.registration
          },
        });
      } catch (emailError) {
        console.error('Error sending confirmation email:', emailError);
      }
      
      return { success: true, vehicleId, error: null };
    } catch (error: any) {
      console.error('Error saving vehicle listing:', error);
      return { success: false, error: error.message || "Unknown error occurred" };
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleImageUploads = async (
    vehicleId: string,
    images: UploadedImage[],
    existingImages: UploadedImage[],
    isEditMode: boolean
  ) => {
    if (vehicleId && images.length > 0) {
      console.log("Saving image metadata:", images.length);
      const imagePromises = images.map(image => 
        supabase
          .from('vehicle_images')
          .insert({
            vehicle_id: vehicleId,
            image_url: image.url,
            is_main: image.isMain
          })
      );

      const results = await Promise.all(imagePromises);
      
      const imageErrors = results.filter(r => r.error).map(r => r.error);
      if (imageErrors.length > 0) {
        console.error("Some images failed to save:", imageErrors);
      }
      
      console.log("Image metadata saved successfully");
    }
    
    if (isEditMode && existingImages.length > 0 && vehicleId) {
      const mainImage = existingImages.find(img => img.isMain);
      
      if (mainImage) {
        console.log("Updating main image status");
        await supabase
          .from('vehicle_images')
          .update({ is_main: false })
          .eq('vehicle_id', vehicleId);
          
        const { error } = await supabase
          .from('vehicle_images')
          .update({ is_main: true })
          .eq('vehicle_id', vehicleId)
          .eq('image_url', mainImage.url);
          
        if (error) {
          console.error("Error updating main image:", error);
        }
      }
    }
  };

  return {
    isLoading,
    showAnimation,
    handleAnimationComplete,
    handleSubmit
  };
};
