
import { useState, useEffect, useRef } from "react";
import { getCurrentCredits, setCreditsLogging, invalidateCreditsCache } from "@/services/credits";
import { useInventory } from "@/contexts/InventoryContext";

export const useVehicleCredits = () => {
  const { credits: contextCredits, fetchCredits } = useInventory();
  const [creditsState, setCreditsState] = useState<number | null>(contextCredits);
  const [isCheckingCredits, setIsCheckingCredits] = useState(false);
  const [lastFetchTimestamp, setLastFetchTimestamp] = useState(0);
  const lastRequestRef = useRef<AbortController | null>(null);
  const fetchCounter = useRef(0);
  const isMountedRef = useRef(true);
  const initialFetchCompletedRef = useRef(false);
  const FETCH_THROTTLE_TIME = 60000; // 60 seconds

  // Disable verbose logging entirely
  useEffect(() => {
    setCreditsLogging(false);
    
    return () => {
      setCreditsLogging(false);
      isMountedRef.current = false;
    };
  }, []);
  
  // Force refresh credits on mount but only once
  useEffect(() => {
    if (initialFetchCompletedRef.current) {
      return; // Skip if we've already done the initial fetch
    }

    const forceFetchCredits = async () => {
      if (!isMountedRef.current) return;
      
      try {
        // Invalidate cache to ensure fresh data
        invalidateCreditsCache();
        
        if (fetchCredits) {
          await fetchCredits();
          if (isMountedRef.current && !initialFetchCompletedRef.current) {
            // Only log once in development mode
            if (process.env.NODE_ENV === 'development') {
              console.log("Initial credits fetch completed");
            }
            initialFetchCompletedRef.current = true;
          }
        } else {
          // Fallback if fetchCredits not available
          const { credits } = await getCurrentCredits();
          if (isMountedRef.current) {
            setCreditsState(credits);
            initialFetchCompletedRef.current = true;
          }
        }
      } catch (error) {
        console.error("Error in force fetch credits:", error);
      }
    };
    
    // Minimal logging in development mode only
    if (process.env.NODE_ENV === 'development') {
      console.log("Initial credits fetch started");
    }
    forceFetchCredits();
  }, [fetchCredits, contextCredits]);
  
  useEffect(() => {
    // Skip frequent fetches
    if (creditsState !== null) {
      return;
    }
    
    const fetchCredits = async () => {
      // Prevent multiple simultaneous requests
      if (isCheckingCredits) {
        return;
      }
      
      // Abort any previous request
      if (lastRequestRef.current) {
        lastRequestRef.current.abort();
      }
      
      // Create new abort controller
      const abortController = new AbortController();
      lastRequestRef.current = abortController;
      
      const now = Date.now();
      const fetchId = ++fetchCounter.current;
      
      // Throttle requests - only fetch once every 60 seconds
      const timeSinceLastFetch = now - lastFetchTimestamp;
      if (timeSinceLastFetch < FETCH_THROTTLE_TIME && contextCredits !== null && creditsState !== null) {
        return;
      }
      
      try {
        setIsCheckingCredits(true);
        setLastFetchTimestamp(now);
        
        const { credits, error } = await getCurrentCredits();
        
        // Check if request was aborted or component unmounted
        if (abortController.signal.aborted || !isMountedRef.current) {
          return;
        }
        
        if (error) {
          console.error(`Credits fetch error:`, error);
        } else {
          setCreditsState(credits);
          
          // Use context's fetchCredits to ensure global state is updated
          if (fetchCredits) {
            await fetchCredits();
          }
        }
      } catch (error) {
        console.error(`Unexpected error fetching credits:`, error);
      } finally {
        // Only clear checking state if this is the latest request and component is mounted
        if (fetchId === fetchCounter.current && isMountedRef.current) {
          setIsCheckingCredits(false);
          lastRequestRef.current = null;
        }
      }
    };

    // Initial fetch
    fetchCredits();
    
    // Setup interval for periodic refreshes (every 5 minutes)
    const intervalId = setInterval(fetchCredits, 300000);
    
    return () => {
      clearInterval(intervalId);
      if (lastRequestRef.current) {
        lastRequestRef.current.abort();
      }
      isMountedRef.current = false;
    };
  }, [contextCredits, creditsState, fetchCredits, isCheckingCredits, lastFetchTimestamp]);

  // Sync with context if it changes
  useEffect(() => {
    if (contextCredits !== null && contextCredits !== creditsState) {
      setCreditsState(contextCredits);
    }
  }, [contextCredits, creditsState]);

  // Add a manual refresh method
  const refreshCredits = async () => {
    invalidateCreditsCache();
    
    if (fetchCredits) {
      try {
        await fetchCredits();
      } catch (error) {
        console.error("Error in manual context refresh:", error);
      }
    } else {
      try {
        const { credits, error } = await getCurrentCredits();
        if (!error && credits !== null && isMountedRef.current) {
          setCreditsState(credits);
        }
      } catch (error) {
        console.error("Error in manual direct refresh:", error);
      }
    }
  };

  return {
    credits: creditsState,
    isCheckingCredits,
    refreshCredits
  };
};
