
import { useState, useCallback, useEffect, useRef, forwardRef, memo } from "react";
import VehicleFormContent from "./components/VehicleFormContent";

interface VehicleFormProps {
  initialValues?: any;
  onSubmit: (values: any) => void;
  onSaveStateChange: (isSaved: boolean) => void;
  onFormChange: (hasChanges: boolean) => void;
}

export interface VehicleFormRef {
  save: () => void;
}

// Using memo to prevent unnecessary renders from parent components
const VehicleForm = memo(forwardRef<VehicleFormRef, VehicleFormProps>(({ 
  initialValues = {}, 
  onSubmit, 
  onSaveStateChange, 
  onFormChange 
}, ref) => {
  const [isSaved, setIsSaved] = useState(false);
  const [hasChanges, setHasChanges] = useState(false);
  const previousFormValuesRef = useRef({});
  const forceSyncRef = useRef(false);
  const initialRenderRef = useRef(true);
  const debounceTimerRef = useRef<number | null>(null);
  
  // Initialize our form state with initial values from props
  const [formValues, setFormValues] = useState({
    make: "",
    model: "",
    year: "",
    color: "",
    registration: "",
    bodyType: "",
    fuelType: "",
    transmission: "",
    mileage: "",
    engineSize: "",
    price: "",
    isPOA: false,
    description: "",
    features: [] as string[],
    status: "active",
    listingTier: "standard",
    axleConfiguration: "",
    interiorCondition: "",
    exteriorCondition: "",
    cabType: "",
    driverPosition: "",
    enginePower: "",
    emissionsClass: "",
    numberOfSeats: "",
    grossVehicleWeight: "",
    volume: "",
    internalLength: "",
    internalWidth: "",
    internalHeight: "",
    externalLength: "",
    externalWidth: "",
    externalHeight: "",
    isNew: false,
    videoUrl: "", 
    ...initialValues,
  });

  // Only update formValues when initialValues change and are different
  useEffect(() => {
    if (!initialRenderRef.current && initialValues && Object.keys(initialValues).length > 0) {
      // Don't update if initialValues are the same as current formValues
      const initialValuesStr = JSON.stringify(initialValues);
      const prevValuesStr = JSON.stringify(previousFormValuesRef.current);
      
      if (initialValuesStr !== prevValuesStr || forceSyncRef.current) {
        previousFormValuesRef.current = initialValues;
        setFormValues(prevValues => ({
          ...prevValues,
          ...initialValues
        }));
        
        // Reset the force sync flag
        forceSyncRef.current = false;
        // Also reset hasChanges since we're syncing with initialValues
        if (hasChanges) {
          setHasChanges(false);
          onFormChange(false);
        }
      }
    } else if (initialRenderRef.current) {
      initialRenderRef.current = false;
      previousFormValuesRef.current = initialValues;
    }
  }, [initialValues, hasChanges, onFormChange]);

  const save = useCallback(() => {
    onSubmit(formValues);
    setIsSaved(true);
    
    // Set hasChanges to false and notify parent components
    setHasChanges(false);
    onSaveStateChange(true);
    onFormChange(false);
    
    // Force a sync with initialValues on next render
    forceSyncRef.current = true;
  }, [formValues, onSubmit, onSaveStateChange, onFormChange]);

  useEffect(() => {
    if (ref) {
      (ref as any).current = { save };
    }
  }, [ref, save]);

  // Notify parent of changes state with debouncing
  useEffect(() => {
    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current);
    }
    
    debounceTimerRef.current = window.setTimeout(() => {
      onFormChange(hasChanges);
    }, 300) as unknown as number;
    
    return () => {
      if (debounceTimerRef.current) {
        clearTimeout(debounceTimerRef.current);
      }
    };
  }, [hasChanges, onFormChange]);

  const handleInputChange = useCallback((e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { id, value } = e.target;
    const inputEl = e.target as HTMLInputElement;
    const type = inputEl.type;
    
    if (type === "checkbox") {
      setFormValues(prevValues => {
        const updatedValues = { ...prevValues, [id]: inputEl.checked };
        setHasChanges(true);
        return updatedValues;
      });
    } else {
      setFormValues(prevValues => {
        const updatedValues = { ...prevValues, [id]: value };
        setHasChanges(true);
        return updatedValues;
      });
    }
  }, []);

  const handleSelectChange = useCallback((id: string, value: string) => {
    setFormValues(prevValues => {
      const updatedValues = { ...prevValues, [id]: value };
      setHasChanges(true);
      return updatedValues;
    });
  }, []);

  const handleRadioChange = useCallback((id: string, value: string) => {
    setFormValues(prevValues => {
      const updatedValues = { ...prevValues, [id]: value };
      setHasChanges(true);
      return updatedValues;
    });
  }, []);

  const handleFeaturesChange = useCallback((features: string[]) => {
    setFormValues(prevValues => {
      const updatedValues = { ...prevValues, features: features };
      setHasChanges(true);
      return updatedValues;
    });
  }, []);

  const handleCheckboxChange = useCallback((checked: boolean) => {
    setFormValues(prevValues => {
      const updatedValues = { ...prevValues, isPOA: checked };
      setHasChanges(true);
      return updatedValues;
    });
  }, []);

  return (
    <form onSubmit={e => e.preventDefault()} className="space-y-6">
      <VehicleFormContent
        formValues={formValues}
        handleInputChange={handleInputChange}
        handleSelectChange={handleSelectChange}
        handleRadioChange={handleRadioChange}
        handleFeaturesChange={handleFeaturesChange}
        handleCheckboxChange={handleCheckboxChange}
      />
    </form>
  );
}));

VehicleForm.displayName = 'VehicleForm';

export default VehicleForm;
