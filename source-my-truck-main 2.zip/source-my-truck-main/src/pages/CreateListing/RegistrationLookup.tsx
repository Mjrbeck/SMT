
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Search } from "lucide-react";
import { VehicleLookupData } from "@/services/types";

interface RegistrationLookupProps {
  onLookup: (data: VehicleLookupData) => void;
}

const RegistrationLookup = ({ onLookup }: RegistrationLookupProps) => {
  const [registration, setRegistration] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleLookup = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!registration.trim()) {
      toast({
        title: "Registration required",
        description: "Please enter a valid vehicle registration number",
        variant: "destructive",
      });
      return;
    }
    
    setIsLoading(true);
    
    try {
      // Call our Supabase Edge Function
      const { data, error } = await supabase.functions.invoke('vehicle-lookup', {
        body: { registrationNumber: registration.trim() }
      });

      if (error) {
        throw new Error(error.message || "Failed to lookup vehicle information");
      }
      
      if (!data) {
        throw new Error("No data returned from vehicle lookup");
      }

      console.log("Vehicle data received from lookup:", data);
      
      // Process the data before sending it to the form - ensure consistent data types
      const vehicleData: VehicleLookupData = {
        make: data.make || "",
        model: data.model || "",
        year: data.year || "",
        color: data.color || "",
        fuelType: data.fuelType || "",
        transmission: data.transmission || "",
        engineSize: data.engineSize || "",
        bodyType: data.bodyType || "",
        axleConfiguration: data.axleConfiguration || "",
        registration: data.registration || registration.trim().toUpperCase(),
        mileage: data.mileage || "",
        weight: data.weight || "",
        
        // Include additional fields if they exist in the response
        cabType: data.cabType || "",
        driverPosition: data.driverPosition || "",
        enginePower: data.enginePower || "",
        emissionsClass: data.emissionsClass || "",
        numberOfSeats: data.numberOfSeats || "",
        grossVehicleWeight: data.grossVehicleWeight || "",
        volume: data.volume || "",
        internalLength: data.internalLength || "",
        internalWidth: data.internalWidth || "",
        internalHeight: data.internalHeight || "",
        externalLength: data.externalLength || "",
        externalWidth: data.externalWidth || "",
        externalHeight: data.externalHeight || "",
        isNew: data.isNew || false,
        interiorCondition: data.interiorCondition || "",
        exteriorCondition: data.exteriorCondition || "",
      };
      
      console.log("Mapped vehicle data being sent to form:", vehicleData);
      
      // Pass the processed vehicle data to the parent component
      onLookup(vehicleData);
      
      toast({
        title: "Vehicle found",
        description: "Vehicle details have been retrieved successfully.",
      });
    } catch (error) {
      console.error("Vehicle lookup error:", error);
      toast({
        title: "Lookup failed",
        description: error instanceof Error ? error.message : "Failed to retrieve vehicle information",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="mb-8 border-2 border-primary/10 bg-gradient-to-b from-card to-card/80 shadow-lg">
      <CardHeader className="bg-gradient-to-r from-primary/5 to-primary/10 pb-8">
        <CardTitle className="text-2xl font-bold text-primary">Quick Registration Lookup</CardTitle>
        <CardDescription className="text-base">
          Enter your vehicle's registration number to instantly retrieve DVLA details
        </CardDescription>
      </CardHeader>
      <CardContent className="-mt-4 p-6">
        <form onSubmit={handleLookup} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="registration" className="font-medium text-foreground/80">
              Registration Number
            </Label>
            <div className="flex space-x-4 items-center">
              <div className="flex-1">
                <Input
                  id="registration"
                  placeholder="e.g. AB12CDE"
                  value={registration}
                  onChange={(e) => setRegistration(e.target.value)}
                  className="h-12 border-2 border-input uppercase pl-4 text-lg font-medium focus-visible:ring-primary"
                />
              </div>
              <Button 
                type="submit" 
                disabled={isLoading}
                size="lg"
                className="h-12 min-w-32 gap-2 whitespace-nowrap"
              >
                <Search className="h-5 w-5" />
                {isLoading ? "Searching..." : "Lookup Vehicle"}
              </Button>
            </div>
            <p className="text-sm text-muted-foreground">Or fill in the details manually below</p>
          </div>
        </form>
      </CardContent>
    </Card>
  );
};

export default RegistrationLookup;
