
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Trash, StarIcon, ImagePlus } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { validateFile, uploadToStorage } from "@/utils/uploadUtils";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";

interface UploadedImage {
  url: string;
  isMain: boolean;
}

interface PhotoUploadProps {
  onUpload: (images: UploadedImage[]) => void;
  existingImages?: UploadedImage[];
}

const PhotoUpload = ({ onUpload, existingImages = [] }: PhotoUploadProps) => {
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [previewImages, setPreviewImages] = useState<{ file: File; preview: string }[]>([]);
  const [mainImageIndex, setMainImageIndex] = useState<number | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadedImages, setUploadedImages] = useState<UploadedImage[]>([]);
  const [showExistingImages, setShowExistingImages] = useState(true);
  
  const { toast: legacyToast } = useToast();
  const { user } = useAuth();

  useEffect(() => {
    if (existingImages && existingImages.length > 0) {
      const mainIndex = existingImages.findIndex(img => img.isMain);
      if (mainIndex !== -1) {
        setMainImageIndex(mainIndex);
      } else {
        setMainImageIndex(0);
      }
    }
  }, [existingImages]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const filesArray = Array.from(e.target.files);
      
      const validFiles = filesArray.filter(file => validateFile(file));
      
      if (validFiles.length !== filesArray.length) {
        toast.warning(`${filesArray.length - validFiles.length} files were rejected due to invalid type or size.`);
      }
      
      setSelectedFiles(prev => [...prev, ...validFiles]);
      
      const newPreviews = validFiles.map(file => ({
        file,
        preview: URL.createObjectURL(file)
      }));
      
      setPreviewImages(prev => [...prev, ...newPreviews]);
      
      if (previewImages.length === 0 && existingImages.length === 0 && newPreviews.length > 0) {
        setMainImageIndex(0);
      }
      
      e.target.value = '';
    }
  };

  const handleRemoveFile = (index: number) => {
    setSelectedFiles(prev => prev.filter((_, i) => i !== index));
    URL.revokeObjectURL(previewImages[index].preview);
    setPreviewImages(prev => prev.filter((_, i) => i !== index));
    
    if (mainImageIndex === index) {
      setMainImageIndex(previewImages.length > 1 ? 0 : null);
    } else if (mainImageIndex !== null && mainImageIndex > index) {
      setMainImageIndex(mainImageIndex - 1);
    }
  };

  const handleRemoveExistingImage = async (index: number) => {
    const updatedExistingImages = [...existingImages];
    updatedExistingImages.splice(index, 1);
    
    if (index === mainImageIndex) {
      if (updatedExistingImages.length > 0) {
        setMainImageIndex(0);
      } else if (previewImages.length > 0) {
        setMainImageIndex(0);
      } else {
        setMainImageIndex(null);
      }
    }
    
    setShowExistingImages(false);
    setTimeout(() => {
      setShowExistingImages(true);
      onUpload([...uploadedImages]);
    }, 100);
  };

  const handleSetMainImage = (index: number, isExisting: boolean = false) => {
    setMainImageIndex(index);
    
    if (!isExisting && uploadedImages.length > 0) {
      setUploadedImages(prevImages => 
        prevImages.map((img, i) => ({
          ...img,
          isMain: i === index
        }))
      );
    }
  };

  const handleUpload = async () => {
    if (selectedFiles.length === 0) {
      legacyToast({
        title: "No files selected",
        description: "Please select at least one image to upload.",
        variant: "destructive",
      });
      return;
    }
    
    if (!user) {
      legacyToast({
        title: "Authentication required",
        description: "Please sign in to upload images.",
        variant: "destructive",
      });
      return;
    }
    
    setIsUploading(true);
    
    try {
      const newUploadedImages: UploadedImage[] = [];
      
      for (let i = 0; i < selectedFiles.length; i++) {
        const file = selectedFiles[i];
        
        try {
          const result = await uploadToStorage(file, user.id, 'vehicle-images');
          
          newUploadedImages.push({
            url: result.url,
            isMain: mainImageIndex === i
          });
        } catch (error) {
          console.error('Error uploading file:', error);
          toast.error(`Failed to upload ${file.name}.`);
        }
      }
      
      if (newUploadedImages.length > 0) {
        const allUploaded = [...uploadedImages, ...newUploadedImages];
        setUploadedImages(allUploaded);
        
        onUpload(newUploadedImages);
        
        setSelectedFiles([]);
        
        previewImages.forEach(image => URL.revokeObjectURL(image.preview));
        setPreviewImages([]);
        
        setMainImageIndex(null);
        
        toast.success(`Successfully uploaded ${newUploadedImages.length} images.`);
      }
    } catch (error) {
      console.error('Unexpected error during upload:', error);
      legacyToast({
        title: "Upload failed",
        description: "An unexpected error occurred during upload.",
        variant: "destructive",
      });
    } finally {
      setIsUploading(false);
    }
  };

  const triggerFileInput = () => {
    document.getElementById("photos")?.click();
  };

  return (
    <div className="space-y-6">
      <div className="border-2 border-dashed border-primary rounded-lg p-6 text-center hover:border-primary/80 transition-colors hover:bg-primary/5 cursor-pointer" onClick={triggerFileInput}>
        <input 
          id="photos" 
          type="file" 
          accept="image/*" 
          multiple 
          onChange={handleFileChange}
          className="hidden"
        />
        <div className="flex flex-col items-center justify-center gap-4 py-4">
          <div className="bg-primary/10 p-4 rounded-full">
            <ImagePlus className="h-8 w-8 text-primary" />
          </div>
          <div>
            <h3 className="font-semibold text-lg mb-1">Upload Photos</h3>
            <p className="text-muted-foreground mb-2">Drag and drop or click to browse</p>
            <Button 
              type="button" 
              variant="default" 
              className="mt-2 bg-primary hover:bg-primary/90 text-white transition-colors shadow-md"
              onClick={triggerFileInput}
            >
              Choose Files
            </Button>
          </div>
        </div>
      </div>
      
      {existingImages.length > 0 && showExistingImages && (
        <div className="mb-4 bg-blue-50/50 rounded-lg p-4 border border-blue-100">
          <h3 className="font-medium mb-2 text-blue-700 flex items-center gap-2">
            <div className="w-1 h-5 bg-blue-500 rounded-full"></div>
            Existing Images
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 mb-6">
            {existingImages.map((image, index) => (
              <div key={`existing-${index}`} className="relative group">
                <img 
                  src={image.url} 
                  alt={`Vehicle ${index + 1}`} 
                  className="w-full h-32 object-cover rounded-md border border-gray-300 group-hover:border-primary transition-colors"
                />
                <div className="absolute top-2 right-2 flex space-x-1">
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className={`h-7 w-7 rounded-full ${mainImageIndex === index ? 'bg-amber-500 text-white' : 'bg-white text-gray-700'} opacity-90 hover:opacity-100`}
                    onClick={() => handleSetMainImage(index, true)}
                  >
                    <StarIcon className="h-4 w-4" />
                  </Button>
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="h-7 w-7 rounded-full bg-white text-red-500 opacity-90 hover:opacity-100"
                    onClick={() => handleRemoveExistingImage(index)}
                  >
                    <Trash className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
      
      {uploadedImages.length > 0 && (
        <div className="mb-4 bg-green-50/50 rounded-lg p-4 border border-green-100">
          <h3 className="font-medium mb-2 text-green-700 flex items-center gap-2">
            <div className="w-1 h-5 bg-green-500 rounded-full"></div>
            Uploaded Images
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 mb-6">
            {uploadedImages.map((image, index) => (
              <div key={`uploaded-${index}`} className="relative group">
                <img 
                  src={image.url} 
                  alt={`Uploaded ${index + 1}`} 
                  className="w-full h-32 object-cover rounded-md border border-gray-300 group-hover:border-primary transition-colors"
                />
                {image.isMain && (
                  <div className="absolute top-2 left-2">
                    <span className="bg-amber-500 text-white text-xs px-2 py-1 rounded-full shadow-sm">
                      Main
                    </span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    
      {previewImages.length > 0 && (
        <div className="bg-purple-50/50 rounded-lg p-4 border border-purple-100">
          <h3 className="font-medium mb-2 text-purple-700 flex items-center gap-2">
            <div className="w-1 h-5 bg-purple-500 rounded-full"></div>
            Selected Photos
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 mb-4">
            {previewImages.map((image, index) => (
              <div key={index} className="relative group">
                <img 
                  src={image.preview} 
                  alt={`Preview ${index + 1}`} 
                  className="w-full h-32 object-cover rounded-md border border-gray-300 group-hover:border-primary transition-colors"
                />
                <div className="absolute top-2 right-2 flex space-x-1">
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className={`h-7 w-7 rounded-full ${mainImageIndex === index ? 'bg-amber-500 text-white' : 'bg-white text-gray-700'} opacity-90 hover:opacity-100`}
                    onClick={() => handleSetMainImage(index)}
                  >
                    <StarIcon className="h-4 w-4" />
                  </Button>
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="h-7 w-7 rounded-full bg-white text-red-500 opacity-90 hover:opacity-100"
                    onClick={() => handleRemoveFile(index)}
                  >
                    <Trash className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
          
          <Button 
            type="button" 
            onClick={handleUpload} 
            disabled={isUploading}
            className="mt-2 bg-primary hover:bg-primary/90 transition-colors shadow-md"
          >
            {isUploading ? "Uploading..." : "Upload Selected Photos"}
          </Button>
        </div>
      )}
      
      <div className="text-sm text-gray-500 mt-4 bg-gray-50 p-4 rounded-lg border border-gray-100">
        <h4 className="font-medium text-gray-700 mb-2">Photo Guidelines:</h4>
        <ul className="list-disc pl-5 space-y-1">
          <li>Photos are optional. If none are provided, a default placeholder will be shown</li>
          <li>Add multiple photos to showcase your vehicle from different angles</li>
          <li>Select a main photo that will be displayed as the primary image</li>
          <li>High-quality images increase the chances of selling your vehicle</li>
        </ul>
      </div>
    </div>
  );
};

export default PhotoUpload;
