
import { useLocation, Link } from "react-router-dom";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import SEO from "@/components/seo/SEO";
import BrokenLinkChecker from "@/components/seo/BrokenLinkChecker";

const NotFound = () => {
  const location = useLocation();
  const [showLinkChecker, setShowLinkChecker] = useState(false);
  const [likelyRedirect, setLikelyRedirect] = useState<{ path: string; reason: string } | null>(null);
  const isAdminUser = false; // In a real app, check if user is admin
  
  const originalPath = location.pathname;
  
  // Check for common URL patterns that might need redirects
  useEffect(() => {
    const checkForRedirects = () => {
      // Check for common wrong URL patterns
      if (originalPath.startsWith('/vehicles/')) {
        const id = originalPath.split('/').pop();
        setLikelyRedirect({
          path: `/vehicle/${id}`,
          reason: "You're using 'vehicles' (plural) instead of 'vehicle' (singular)"
        });
      } else if (originalPath.startsWith('/truck/')) {
        const id = originalPath.split('/').pop();
        setLikelyRedirect({
          path: `/vehicle/${id}`,
          reason: "You're using 'truck' instead of 'vehicle'"
        });
      } else if (originalPath.startsWith('/dealer/')) {
        const id = originalPath.split('/').pop();
        setLikelyRedirect({
          path: `/seller/${id}`,
          reason: "You're using 'dealer' instead of 'seller'"
        });
      } else if (originalPath === '/browse-trucks' || originalPath === '/all-trucks') {
        setLikelyRedirect({
          path: "/listings",
          reason: "The listings page has been renamed"
        });
      }
    };
    
    checkForRedirects();
  }, [originalPath]);

  useEffect(() => {
    // Log for analytics purposes
    console.error(
      "404 Error: User attempted to access non-existent route:",
      location.pathname
    );
    
    // Send to analytics if available
    if (typeof window.gtag === 'function') {
      window.gtag('event', '404_error', {
        event_category: 'Error',
        event_label: location.pathname,
        non_interaction: true
      });
    }
  }, [location.pathname]);

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-100 px-4">
      <SEO 
        title="Page Not Found - Source my Truck"
        description="We couldn't find the page you were looking for. Please check the URL or go back to the homepage."
        noindex={true} // Tell search engines not to index 404 pages
      />
      
      <div className="bg-white p-8 rounded-lg shadow-md text-center w-full max-w-md">
        <h1 className="text-4xl font-bold mb-4 text-gray-800">404</h1>
        <p className="text-xl text-gray-600 mb-6">Oops! Page not found</p>
        <p className="text-gray-500 mb-6">
          The page you are looking for might have been removed, had its name changed, 
          or is temporarily unavailable.
        </p>
        
        {likelyRedirect && (
          <div className="mb-6 p-4 bg-blue-50 rounded-md border border-blue-200">
            <p className="text-sm mb-2">Did you mean to visit:</p>
            <Link to={likelyRedirect.path} className="text-blue-600 font-medium hover:underline">
              {likelyRedirect.path}
            </Link>
            <p className="text-xs mt-2 text-gray-600">{likelyRedirect.reason}</p>
          </div>
        )}
        
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <Link to="/">
            <Button className="w-full">Return to Home</Button>
          </Link>
          
          <Link to="/listings">
            <Button variant="outline" className="w-full">Browse Vehicles</Button>
          </Link>
        </div>
        
        {isAdminUser && (
          <div className="mt-8 border-t pt-4">
            <p className="mb-2 text-sm text-gray-600">Admin Tools</p>
            <Button 
              variant="ghost" 
              onClick={() => setShowLinkChecker(!showLinkChecker)}
              size="sm"
            >
              {showLinkChecker ? 'Hide Link Checker' : 'Check for Broken Links'}
            </Button>
            
            {showLinkChecker && <BrokenLinkChecker />}
          </div>
        )}
        
        <div className="mt-8 text-sm text-gray-500">
          <p>URL Path: {location.pathname}</p>
        </div>
      </div>
    </div>
  );
};

export default NotFound;
