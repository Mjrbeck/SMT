
import React from 'react';
import HealthCheck from '@/components/health/HealthCheck';
import NavBar from '@/components/NavBar';
import Footer from '@/components/Footer';

const HealthCheckPage = () => {
  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100">
      <NavBar />
      <div className="pt-16">
        <HealthCheck />
      </div>
      <Footer />
    </div>
  );
};

export default HealthCheckPage;
