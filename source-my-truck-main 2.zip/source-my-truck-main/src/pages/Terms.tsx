
import React from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";

const Terms = () => {
  return (
    <div className="bg-gray-50 min-h-screen">
      <div className="container mx-auto px-4 py-12 max-w-4xl">
        <Button
          variant="outline"
          size="sm"
          className="mb-6 flex items-center gap-2"
          asChild
        >
          <Link to="/">
            <ArrowLeft className="h-4 w-4" />
            Back to home
          </Link>
        </Button>

        <div className="bg-white p-8 rounded-lg shadow-sm">
          <h1 className="text-3xl font-bold text-gray-900 mb-6">Terms & Conditions</h1>
          
          <div className="space-y-8">
            <section>
              <h2 className="text-xl font-semibold text-gray-800 mb-3">1. Introduction</h2>
              <p className="text-gray-700">
                Welcome to Source My Truck ("we", "us", "our"). These Terms & Conditions govern your use of our truck marketplace website and services available at sourcemytruck.com ("the Platform"). By using the Platform, you agree to these Terms & Conditions. If you do not agree, please do not use our services.
              </p>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-gray-800 mb-3">2. About Source My Truck</h2>
              <p className="text-gray-700 mb-2">
                Source My Truck is an online marketplace that allows users to list and sell trucks and commercial vehicles.
              </p>
              <p className="text-gray-700 mb-2">
                We do not own, inspect, buy, or sell vehicles listed on the Platform. All transactions are solely between buyers and sellers.
              </p>
              <p className="text-gray-700">
                We are not responsible for any disputes, damages, or liabilities arising from transactions conducted through the Platform.
              </p>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-gray-800 mb-3">3. User Accounts</h2>
              <p className="text-gray-700 mb-2">
                To sell a vehicle, users must create an account and provide accurate information.
              </p>
              <p className="text-gray-700 mb-2">
                Users are responsible for maintaining account security and any activity occurring under their account.
              </p>
              <p className="text-gray-700">
                We reserve the right to suspend or terminate accounts that violate our policies.
              </p>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-gray-800 mb-3">4. Listings & Selling</h2>
              <p className="text-gray-700 mb-2">
                Sellers must provide accurate and truthful descriptions of vehicles.
              </p>
              <p className="text-gray-700 mb-2">
                Listings must not contain misleading, fraudulent, or illegal content.
              </p>
              <p className="text-gray-700">
                We reserve the right to remove listings that breach these terms.
              </p>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-gray-800 mb-3">5. Buying Vehicles</h2>
              <p className="text-gray-700 mb-2">
                Buyers must conduct their own due diligence before purchasing a vehicle.
              </p>
              <p className="text-gray-700 mb-2">
                We do not guarantee vehicle quality, accuracy of listings, or legitimacy of sellers.
              </p>
              <p className="text-gray-700">
                Buyers enter into agreements directly with sellers and should take necessary precautions.
              </p>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-gray-800 mb-3">6. Fees & Payments</h2>
              <p className="text-gray-700 mb-2">
                Some services, such as premium listings, may be subject to fees.
              </p>
              <p className="text-gray-700 mb-2">
                All payments made for Platform services are non-refundable, except where required by law.
              </p>
              <p className="text-gray-700">
                We do not process payments between buyers and sellers.
              </p>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-gray-800 mb-3">7. Disclaimers & Liability</h2>
              <p className="text-gray-700 mb-2">
                We provide the Platform "as is" and "as available", without warranties of any kind.
              </p>
              <p className="text-gray-700 mb-2">
                We are not liable for any losses, damages, or disputes arising from transactions or use of the Platform.
              </p>
              <p className="text-gray-700">
                We do not verify the identity of users or the legitimacy of listings.
              </p>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-gray-800 mb-3">8. Prohibited Activities</h2>
              <p className="text-gray-700 mb-2">Users must not:</p>
              <ul className="list-disc pl-6 text-gray-700 space-y-1">
                <li>Post fraudulent or misleading listings.</li>
                <li>Use the Platform for illegal activities.</li>
                <li>Violate any applicable laws or regulations.</li>
              </ul>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-gray-800 mb-3">9. Data Protection & GDPR Compliance</h2>
              <p className="text-gray-700 mb-2">
                We comply with UK GDPR regulations and take user data privacy seriously.
              </p>
              <p className="text-gray-700 mb-2">
                Our Privacy Policy outlines how we collect, use, and store personal data.
              </p>
              <p className="text-gray-700">
                For any GDPR-related inquiries, please contact support@sourcemytruck.com.
              </p>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-gray-800 mb-3">10. Termination & Account Suspension</h2>
              <p className="text-gray-700 mb-2">
                We reserve the right to suspend or terminate accounts for breaches of these Terms.
              </p>
              <p className="text-gray-700">
                Users may request to delete their accounts by contacting support@sourcemytruck.com.
              </p>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-gray-800 mb-3">11. Changes to These Terms</h2>
              <p className="text-gray-700 mb-2">
                We may update these Terms from time to time. Changes will be posted on the Platform and will take effect upon posting.
              </p>
              <p className="text-gray-700">
                Continued use of the Platform after changes constitutes acceptance of the new Terms.
              </p>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-gray-800 mb-3">12. Governing Law</h2>
              <p className="text-gray-700 mb-2">
                These Terms are governed by the laws of England & Wales.
              </p>
              <p className="text-gray-700">
                Any disputes shall be resolved in the courts of England & Wales.
              </p>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-gray-800 mb-3">13. Contact Information</h2>
              <p className="text-gray-700">
                For any inquiries or support, please contact us at support@sourcemytruck.com.
              </p>
            </section>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Terms;
