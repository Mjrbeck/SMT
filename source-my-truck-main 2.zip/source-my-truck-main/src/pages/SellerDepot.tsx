
import React from "react";
import { useParams, useSearchParams } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { getSellerWithVehicles } from "@/services/sellers/sellerDepotService";
import { getSellerTrustData } from "@/services/trustBadgeService";
import { TrustBadges } from "@/components/ui/trust-badges";
import VehicleResultsGrid from "@/components/vehicle/VehicleResultsGrid";
import { User, Store, MapPin, Phone, Link, Globe } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import PageLayout from "@/components/layouts/PageLayout";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Toaster } from "@/components/ui/toaster";
import NavBar from "@/components/NavBar";
import Footer from "@/components/Footer";
import { AspectRatio } from "@/components/ui/aspect-ratio";
import SEO from "@/components/seo/SEO";
import SchemaData from "@/components/seo/SchemaData";
import { 
  Pagination, 
  PaginationContent, 
  PaginationEllipsis, 
  PaginationItem, 
  PaginationLink, 
  PaginationNext, 
  PaginationPrevious 
} from "@/components/ui/pagination";
import { useEffect } from "react";

const SellerDepot = () => {
  const { slug } = useParams<{ slug: string }>();
  const [searchParams, setSearchParams] = useSearchParams();
  const currentPage = parseInt(searchParams.get("page") || "1", 10);
  const pageSize = 6; // Number of vehicles per page
  
  const { data: sellerData, isLoading, error } = useQuery({
    queryKey: ["sellerDepot", slug, currentPage, pageSize],
    queryFn: () => getSellerWithVehicles(slug || "", true, currentPage, pageSize),
    enabled: !!slug,
    staleTime: 300000, // 5 minutes
  });

  // Fetch trust data for the seller
  const { data: trustData } = useQuery({
    queryKey: ["sellerTrust", sellerData?.depot?.id],
    queryFn: () => getSellerTrustData(sellerData?.depot?.id || ""),
    enabled: !!sellerData?.depot?.id,
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [currentPage]);

  const copyToClipboard = () => {
    navigator.clipboard.writeText(window.location.href);
    toast.success("Shop URL copied to clipboard");
  };

  const handlePageChange = (page: number) => {
    setSearchParams(prev => {
      const newParams = new URLSearchParams(prev);
      newParams.set("page", page.toString());
      return newParams;
    });
  };

  const renderPagination = () => {
    if (!sellerData || sellerData.totalVehicles <= pageSize) return null;
    
    const totalPages = Math.ceil(sellerData.totalVehicles / pageSize);
    
    return (
      <Pagination className="my-8">
        <PaginationContent>
          {currentPage > 1 && (
            <PaginationItem>
              <PaginationPrevious 
                onClick={() => handlePageChange(currentPage - 1)}
                className="cursor-pointer"
              />
            </PaginationItem>
          )}
          
          {Array.from({ length: totalPages }, (_, i) => i + 1)
            .filter(page => {
              return (
                page === 1 || 
                page === totalPages || 
                (page >= currentPage - 1 && page <= currentPage + 1)
              );
            })
            .map((page, index, array) => {
              const showEllipsisAfter = index < array.length - 1 && array[index + 1] - page > 1;
              
              return (
                <React.Fragment key={page}>
                  <PaginationItem>
                    <PaginationLink
                      onClick={() => handlePageChange(page)}
                      isActive={page === currentPage}
                      className="cursor-pointer"
                    >
                      {page}
                    </PaginationLink>
                  </PaginationItem>
                  
                  {showEllipsisAfter && (
                    <PaginationItem>
                      <PaginationEllipsis />
                    </PaginationItem>
                  )}
                </React.Fragment>
              );
            })}
          
          {currentPage < totalPages && (
            <PaginationItem>
              <PaginationNext 
                onClick={() => handlePageChange(currentPage + 1)}
                className="cursor-pointer"
              />
            </PaginationItem>
          )}
        </PaginationContent>
      </Pagination>
    );
  };

  if (isLoading) {
    return (
      <div className="flex flex-col min-h-screen">
        <NavBar />
        <div className="container mx-auto px-4 py-12 flex flex-col items-center justify-center">
          <div className="w-full max-w-4xl">
            <div className="animate-pulse">
              <div className="h-8 bg-gray-200 rounded-full w-1/3 mb-4"></div>
              <div className="h-4 bg-gray-200 rounded-full w-1/2 mb-8"></div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <div className="h-36 bg-gray-200 rounded"></div>
                <div className="h-36 bg-gray-200 rounded"></div>
                <div className="h-36 bg-gray-200 rounded"></div>
              </div>
            </div>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  if (error || !sellerData) {
    return (
      <div className="flex flex-col min-h-screen">
        <NavBar />
        <div className="container mx-auto px-4 py-12 flex flex-col items-center justify-center">
          <div className="bg-red-50 border border-red-200 p-8 rounded-lg max-w-2xl w-full text-center">
            <h1 className="text-2xl font-bold text-red-800 mb-3">Seller not found</h1>
            <p className="text-red-600 mb-6">
              The seller depot you're looking for doesn't exist or is no longer available.
            </p>
            <Button variant="outline" onClick={() => window.history.back()}>
              Go Back
            </Button>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  const { depot, profile, vehicles, totalVehicles } = sellerData;
  const shopName = depot?.shop_name || profile.company_name;
  
  const sellerDescription = depot?.description || profile.company_description || 
    `${shopName} offers a range of commercial vehicles for sale. Browse ${vehicles.length} vehicles from this trusted seller on Source my Truck.`;
  
  const themeColor = depot?.theme_color || "#0284c7";
  const buttonColor = depot?.button_color || themeColor;
  const textColor = depot?.text_color || "#1e293b";
  const backgroundColor = depot?.background_color || "#f8fafc";
  const headerImageUrl = depot?.header_image_url || null;
  const websiteUrl = depot?.website_url || null;
  
  const sellerSchemaData = {
    name: shopName,
    description: sellerDescription,
    address: profile.company_address || "",
    telephone: profile.company_phone || "",
    logo: profile.logo_url || "",
    website: depot?.website_url || "",
    socialLinks: []
  };
  
  return (
    <div className="flex flex-col min-h-screen" style={{ backgroundColor, color: textColor }}>
      <SEO 
        title={`${shopName} - Commercial Vehicle Seller`}
        description={sellerDescription}
        keywords={`${shopName}, commercial vehicles for sale, truck seller, commercial trucks, ${profile.company_address || ''}`}
        ogImage={profile.logo_url || "/og-image.png"}
      />
      <SchemaData type="organization" data={sellerSchemaData} />
      
      <NavBar />
      
      <div className="container mx-auto px-4 pt-6">
        {headerImageUrl ? (
          <div className="w-full rounded-lg overflow-hidden shadow-sm mb-6">
            <AspectRatio ratio={5/1} className="w-full">
              <img 
                src={headerImageUrl} 
                alt={shopName} 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
            </AspectRatio>
          </div>
        ) : (
          <div 
            className="w-full h-20 rounded-lg mb-6"
            style={{ 
              backgroundColor: `${themeColor}15`
            }}
          />
        )}
      
        <div className="flex flex-col lg:flex-row gap-8 items-start">
          <div className="lg:w-1/3 bg-white p-6 rounded-lg shadow-sm" style={{ backgroundColor: 'white', color: textColor }}>
            <div className="flex items-center gap-4 mb-6">
              {profile.logo_url ? (
                <div className="w-20 h-16 rounded-md overflow-hidden border border-gray-100">
                  <img 
                    src={profile.logo_url} 
                    alt={shopName} 
                    className="w-full h-full object-contain bg-white p-1"
                  />
                </div>
              ) : (
                <div 
                  className="w-20 h-16 rounded-md flex items-center justify-center text-xl font-semibold"
                  style={{ 
                    backgroundColor: `${themeColor}30`,
                    color: themeColor
                  }}
                >
                  {shopName.substring(0, 2).toUpperCase()}
                </div>
              )}
               <div>
                 <h1 className="text-2xl font-bold">{shopName}</h1>
                 {depot?.tagline && (
                   <p style={{ color: `${textColor}99` }}>{depot.tagline}</p>
                 )}
                 
                 {trustData && (
                   <TrustBadges 
                     isTrusted={trustData.isTrusted}
                     depotVerified={trustData.depotVerified}
                     hasMultipleListings={trustData.hasMultipleListings}
                     size="md"
                     className="mt-3"
                   />
                 )}
               </div>
            </div>

            <Separator className="my-4" />
            
            {depot?.description || profile.company_description ? (
              <div className="mb-6">
                <h2 className="text-lg font-semibold mb-2">About Us</h2>
                <p style={{ color: `${textColor}cc` }}>{depot?.description || profile.company_description}</p>
              </div>
            ) : null}
            
            <div className="space-y-3">
              <div className="flex items-center gap-2" style={{ color: `${textColor}cc` }}>
                <Store className="h-5 w-5" style={{ color: `${textColor}99` }} />
                <span>{profile.company_name}</span>
              </div>
              
              {profile.company_address && (
                <div className="flex items-center gap-2" style={{ color: `${textColor}cc` }}>
                  <MapPin className="h-5 w-5" style={{ color: `${textColor}99` }} />
                  <span>{profile.company_address}</span>
                </div>
              )}
              
              {profile.company_phone && (
                <div className="flex items-center gap-2" style={{ color: `${textColor}cc` }}>
                  <Phone className="h-5 w-5" style={{ color: `${textColor}99` }} />
                  <span>{profile.company_phone}</span>
                </div>
              )}
              
              {websiteUrl && (
                <div className="flex items-center gap-2" style={{ color: `${textColor}cc` }}>
                  <Globe className="h-5 w-5" style={{ color: `${textColor}99` }} />
                  <a 
                    href={websiteUrl} 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    className="hover:underline"
                    style={{ color: themeColor }}
                  >
                    {websiteUrl.replace(/^https?:\/\//, '')}
                  </a>
                </div>
              )}
            </div>
            
            <Separator className="my-4" />
            
            <div className="space-y-3">
              {websiteUrl && (
                <a 
                  href={websiteUrl} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="w-full"
                >
                  <Button 
                    variant="outline" 
                    className="w-full flex items-center gap-2"
                    style={{ 
                      borderColor: themeColor,
                      color: themeColor
                    }}
                  >
                    <Globe className="h-4 w-4" />
                    <span>Visit Website</span>
                  </Button>
                </a>
              )}
              
              <Button 
                variant="outline" 
                size="sm" 
                className="w-full flex items-center gap-2"
                onClick={copyToClipboard}
                style={{ 
                  borderColor: themeColor,
                  color: themeColor
                }}
              >
                <Link className="h-4 w-4" />
                <span>Share Shop URL</span>
              </Button>
            </div>
          </div>
          
          <div className="lg:w-2/3">
            <div className="bg-white p-6 rounded-lg shadow-sm mb-6" style={{ backgroundColor: 'white', color: textColor }}>
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-bold">{shopName}'s Available Vehicles</h2>
                <Badge 
                  variant="outline" 
                  className="px-2 py-1"
                  style={{ 
                    borderColor: themeColor,
                    color: themeColor
                  }}
                >
                  {totalVehicles} {totalVehicles === 1 ? 'vehicle' : 'vehicles'}
                </Badge>
              </div>
              
              {vehicles.length > 0 ? (
                <p style={{ color: `${textColor}99` }} className="mb-4">
                  Browse our selection of quality commercial vehicles.
                  {totalVehicles > pageSize && (
                    <span className="ml-1">
                      Page {currentPage} of {Math.ceil(totalVehicles / pageSize)}
                    </span>
                  )}
                </p>
              ) : (
                <p style={{ color: `${textColor}99` }} className="mb-4">
                  No vehicles currently available from this seller.
                </p>
              )}
              
              {vehicles.length === 0 && (
                <Button
                  onClick={() => window.history.back()}
                  style={{ 
                    backgroundColor: buttonColor,
                    color: '#ffffff'
                  }}
                >
                  Back to all vehicles
                </Button>
              )}
            </div>
            
            {vehicles.length > 0 && (
              <>
                <VehicleResultsGrid 
                  vehicles={vehicles} 
                  isLoading={false}
                  showDistance={false}
                  compact={true}
                  columns={2}
                />
                
                {renderPagination()}
              </>
            )}
          </div>
        </div>
      </div>
      <Toaster />
      <Footer />
    </div>
  );
};

export default SellerDepot;
