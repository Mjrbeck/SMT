
import { Button } from "@/components/ui/button";
import { useMessages } from "@/hooks/useMessages";
import { useAuth } from "@/contexts/AuthContext";
import MessagesList from "@/components/messaging/MessagesList";
import DashboardLayout from "@/components/DashboardLayout";
import { ArrowDownIcon, ArrowUpIcon, MessageSquare } from "lucide-react";
import { useState, useCallback } from "react";
import ComposeMessageDialog from "@/components/messaging/ComposeMessageDialog";

const Messages = () => {
  const { isAuthenticated } = useAuth();
  const { messages, isLoading, error, fetchMessages } = useMessages();
  const [sortAscending, setSortAscending] = useState(false);
  const [showCompose, setShowCompose] = useState(false);

  const sortedMessages = [...messages].sort((a, b) => {
    const dateA = new Date(a.created_at).getTime();
    const dateB = new Date(b.created_at).getTime();
    return sortAscending ? dateA - dateB : dateB - dateA;
  });

  // Function to refresh messages when one is deleted
  const handleMessageDeleted = useCallback(() => {
    fetchMessages();
  }, [fetchMessages]);

  if (!isAuthenticated) {
    return (
      <DashboardLayout requireAuth={false} title="Messages">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-2xl font-bold mb-6">Messages</h1>
          <div className="text-center py-10">
            <p>Please log in to view your messages.</p>
          </div>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout title="Messages">
      <div className="max-w-3xl mx-auto">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold">Messages</h1>
          <div className="flex gap-2">
            <Button 
              variant="outline" 
              onClick={() => setSortAscending(!sortAscending)}
              className="flex items-center gap-2"
            >
              {sortAscending ? (
                <>
                  <ArrowUpIcon className="h-4 w-4" />
                  Oldest first
                </>
              ) : (
                <>
                  <ArrowDownIcon className="h-4 w-4" />
                  Newest first
                </>
              )}
            </Button>
            <Button 
              variant="outline" 
              onClick={() => fetchMessages()} 
              disabled={isLoading}
            >
              Refresh
            </Button>
            <Button 
              className="bg-brand-blue hover:bg-brand-blue/90"
              onClick={() => setShowCompose(true)}
            >
              <MessageSquare className="h-4 w-4 mr-2" />
              New Message
            </Button>
          </div>
        </div>

        <div className="bg-white shadow overflow-hidden rounded-lg mb-4">
          <div className="px-4 py-2 border-b border-gray-200 bg-gray-50">
            <p className="text-sm text-gray-500">
              Click the star to mark messages as important.
            </p>
          </div>
          <MessagesList 
            messages={sortedMessages} 
            isLoading={isLoading} 
            onMessageDeleted={handleMessageDeleted}
          />
        </div>

        {error && (
          <div className="mt-4 p-3 bg-red-100 text-red-800 rounded">
            {error}
          </div>
        )}
        
        <ComposeMessageDialog 
          isOpen={showCompose}
          onClose={() => setShowCompose(false)}
          onSuccess={() => {
            setShowCompose(false);
            fetchMessages(); // Refresh messages after sending
          }}
        />
      </div>
    </DashboardLayout>
  );
};

export default Messages;
