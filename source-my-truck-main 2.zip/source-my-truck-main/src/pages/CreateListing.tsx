
import React from "react";
import CreateListingPage from './CreateListing/index';
import { InventoryProvider } from "@/contexts/InventoryContext";

// Wrap the CreateListingPage in the InventoryProvider to ensure 
// that useInventory hook is accessible to the component
const CreateListing = () => {
  return (
    <InventoryProvider>
      <CreateListingPage />
    </InventoryProvider>
  );
};

// Export the wrapped component
export default CreateListing;
