
import { useEffect } from "react";
import { Link } from "react-router-dom";
import { Check, BadgePoundSterling, CreditCard, ArrowRight, Shield, Tags, Calendar } from "lucide-react";
import PageLayout from "@/components/layouts/PageLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

// Credit package definitions (must match PurchaseForm)
const SUBSCRIPTION_TIERS = [
  {
    id: "small",
    name: "Small Fleet",
    credits: 10,
    price: 3,
    pricePerCredit: 10.00,
    description: "For occasional sellers",
    features: [
      "10 Premium vehicle listings per month",
      "30 days per listing",
      "Enhanced analytics dashboard",
      "Featured in search results"
    ],
    popular: false
  },
  {
    id: "medium",
    name: "Medium Fleet",
    credits: 30,
    price: 9,
    pricePerCredit: 10.00,
    description: "For regular sellers",
    features: [
      "30 Premium vehicle listings per month",
      "30 days per listing",
      "Enhanced analytics dashboard",
      "Featured in search results",
      "Priority support"
    ],
    popular: true
  },
  {
    id: "large",
    name: "Large Fleet",
    credits: 50,
    price: 15,
    pricePerCredit: 10.00,
    description: "For dealerships & fleets",
    features: [
      "50 Premium vehicle listings per month",
      "30 days per listing",
      "Advanced analytics & reporting",
      "Priority placement in search",
      "Bulk upload capabilities",
      "Dedicated account manager"
    ],
    popular: false
  }
];

const Pricing = () => {
  // Set page title
  useEffect(() => {
    document.title = "Pricing | Source my Truck";
  }, []);

  return (
    <PageLayout>
      <div className="bg-gradient-to-b from-brand-blue/10 to-white">
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-4xl mx-auto mb-16 text-center">
            <h1 className="text-4xl font-bold mb-6">Transparent Pricing for Every Seller</h1>
            <p className="text-xl text-gray-600">
              Simple, flexible pricing options designed to help you sell your commercial vehicles quickly and efficiently.
            </p>
          </div>

          {/* Pricing Tabs */}
          <Tabs defaultValue="credits" className="max-w-5xl mx-auto mb-16">
            <div className="text-center mb-8">
              <TabsList className="inline-flex">
                <TabsTrigger value="credits" className="text-lg px-6 py-3">
                  <BadgePoundSterling className="mr-2 h-5 w-5" />
                  Credit System
                </TabsTrigger>
                <TabsTrigger value="comparison" className="text-lg px-6 py-3">
                  <Tags className="mr-2 h-5 w-5" />
                  Pricing Comparison
                </TabsTrigger>
              </TabsList>
            </div>

            <TabsContent value="credits" className="mt-0">
              {/* Credit System Explanation */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
                <Card className="shadow-md hover:shadow-lg transition-shadow">
                  <CardHeader className="pb-2">
                    <BadgePoundSterling className="h-10 w-10 text-brand-orange mb-2" />
                    <CardTitle>Pay As You Go</CardTitle>
                    <CardDescription>Only pay for what you need</CardDescription>
                  </CardHeader>
                  <CardContent className="pt-2">
                    <p className="text-gray-600">
                      Our credit system allows you to purchase exactly what you need for your listings. No subscription required.
                    </p>
                  </CardContent>
                </Card>

                <Card className="shadow-md hover:shadow-lg transition-shadow">
                  <CardHeader className="pb-2">
                    <Calendar className="h-10 w-10 text-brand-orange mb-2" />
                    <CardTitle>30-Day Listings</CardTitle>
                    <CardDescription>Active promotion for a full month</CardDescription>
                  </CardHeader>
                  <CardContent className="pt-2">
                    <p className="text-gray-600">
                      Each credit purchases a premium listing that remains active for 30 days, with options to renew.
                    </p>
                  </CardContent>
                </Card>

                <Card className="shadow-md hover:shadow-lg transition-shadow">
                  <CardHeader className="pb-2">
                    <Shield className="h-10 w-10 text-brand-orange mb-2" />
                    <CardTitle>No Hidden Fees</CardTitle>
                    <CardDescription>Complete transparency</CardDescription>
                  </CardHeader>
                  <CardContent className="pt-2">
                    <p className="text-gray-600">
                      We don't charge commission on sales or add hidden fees. What you see is what you pay.
                    </p>
                  </CardContent>
                </Card>
              </div>

              {/* Monthly Subscription Packages */}
              <h2 className="text-3xl font-bold mb-8 text-center">Monthly Subscription Packages</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {SUBSCRIPTION_TIERS.map((pkg) => (
                  <Card 
                    key={pkg.id} 
                    className={`border-2 ${
                      pkg.popular 
                        ? 'border-brand-orange shadow-lg hover:shadow-xl' 
                        : 'border-gray-200 hover:border-gray-300'
                    } transition-colors`}
                  >
                    {pkg.popular && (
                      <div className="bg-brand-orange text-white text-center py-2 text-sm font-medium">
                        MOST POPULAR
                      </div>
                    )}
                    <CardHeader>
                      <CardTitle>{pkg.name}</CardTitle>
                      <CardDescription>{pkg.description}</CardDescription>
                      <div className="mt-4">
                        <span className="text-4xl font-bold">£{pkg.price}</span>
                        <span className="text-gray-500 ml-2">/ month</span>
                      </div>
                      <p className="text-sm text-brand-orange font-medium mt-1">
                        {pkg.credits} credits per month (£{pkg.pricePerCredit.toFixed(2)} per credit)
                      </p>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        {pkg.features.map((feature, index) => (
                          <li key={index} className="flex items-start">
                            <Check className="h-5 w-5 text-green-500 mr-2 shrink-0 mt-0.5" />
                            <span>{feature}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                    <CardFooter>
                      <Link to="/profile?tab=credits" className="w-full">
                        <Button 
                          variant={pkg.popular ? "default" : "outline"} 
                          size="lg" 
                          className={`w-full ${pkg.popular ? '' : ''}`}
                        >
                          Subscribe Now
                        </Button>
                      </Link>
                    </CardFooter>
                  </Card>
                ))}
              </div>

              {/* Individual Credits Option */}
              <div className="mt-8 p-6 border rounded-lg bg-gray-50 max-w-2xl mx-auto">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="text-xl font-semibold">Pay-As-You-Go Credits</h3>
                    <p className="text-gray-600">For one-time sellers or specific needs</p>
                  </div>
                  <div className="text-right">
                    <span className="text-2xl font-bold">£10.00</span>
                    <span className="text-gray-500 block text-sm">per credit</span>
                  </div>
                </div>
                <p className="text-gray-600 mb-4">
                  Need just a credit or two? Purchase exactly what you need, when you need it.
                </p>
                <Link to="/profile?tab=credits" className="inline-block">
                  <Button variant="outline" size="sm">
                    Purchase Individual Credits
                  </Button>
                </Link>
              </div>
            </TabsContent>

            <TabsContent value="comparison" className="mt-0">
              <Card>
                <CardContent className="pt-6">
                  <div className="overflow-x-auto">
                    <table className="w-full border-collapse">
                      <thead>
                        <tr className="border-b-2 border-gray-200">
                          <th className="text-left p-4 text-gray-500">Feature</th>
                          <th className="p-4 text-center">Source my Truck</th>
                          <th className="p-4 text-center">Traditional Classifieds</th>
                          <th className="p-4 text-center">Dealership Networks</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr className="border-b border-gray-200">
                          <td className="p-4 font-medium">Cost Structure</td>
                          <td className="p-4 text-center">Pay-per-listing credits</td>
                          <td className="p-4 text-center">Monthly subscription</td>
                          <td className="p-4 text-center">High commission (8-15%)</td>
                        </tr>
                        <tr className="border-b border-gray-200">
                          <td className="p-4 font-medium">Listing Duration</td>
                          <td className="p-4 text-center">30 days standard</td>
                          <td className="p-4 text-center">7-14 days typical</td>
                          <td className="p-4 text-center">Until sold</td>
                        </tr>
                        <tr className="border-b border-gray-200">
                          <td className="p-4 font-medium">Industry Focus</td>
                          <td className="p-4 text-center">Commercial vehicles only</td>
                          <td className="p-4 text-center">General vehicles</td>
                          <td className="p-4 text-center">Mixed inventory</td>
                        </tr>
                        <tr className="border-b border-gray-200">
                          <td className="p-4 font-medium">Target Audience</td>
                          <td className="p-4 text-center">Serious commercial buyers</td>
                          <td className="p-4 text-center">General public</td>
                          <td className="p-4 text-center">Varied buyers</td>
                        </tr>
                        <tr className="border-b border-gray-200">
                          <td className="p-4 font-medium">Hidden Fees</td>
                          <td className="p-4 text-center">None</td>
                          <td className="p-4 text-center">Often</td>
                          <td className="p-4 text-center">Numerous</td>
                        </tr>
                        <tr>
                          <td className="p-4 font-medium">Seller Control</td>
                          <td className="p-4 text-center">Full control</td>
                          <td className="p-4 text-center">Limited</td>
                          <td className="p-4 text-center">Very limited</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

          {/* FAQ Section */}
          <div className="max-w-4xl mx-auto mt-16 mb-16">
            <h2 className="text-3xl font-bold mb-8 text-center">Frequently Asked Questions</h2>
            
            <div className="space-y-6">
              <Card className="shadow-sm hover:shadow-md transition-all cursor-pointer">
                <CardHeader className="py-6">
                  <CardTitle className="text-xl flex justify-between items-center">
                    <span>How do credits work?</span>
                  </CardTitle>
                  <CardContent className="p-0 pt-2">
                    <p className="text-gray-600">
                      Each credit allows you to create one premium vehicle listing that remains active for 30 days. You can purchase credits individually or through a monthly subscription, and they never expire, so you can use them whenever you need them.
                    </p>
                  </CardContent>
                </CardHeader>
              </Card>
              
              <Card className="shadow-sm hover:shadow-md transition-all cursor-pointer">
                <CardHeader className="py-6">
                  <CardTitle className="text-xl flex justify-between items-center">
                    <span>What happens after 30 days?</span>
                  </CardTitle>
                  <CardContent className="p-0 pt-2">
                    <p className="text-gray-600">
                      After 30 days, your listing will expire. You'll receive a notification before expiration, and you can choose to renew the listing using another credit or let it expire if the vehicle has been sold.
                    </p>
                  </CardContent>
                </CardHeader>
              </Card>
              
              <Card className="shadow-sm hover:shadow-md transition-all cursor-pointer">
                <CardHeader className="py-6">
                  <CardTitle className="text-xl flex justify-between items-center">
                    <span>Are there any commission fees?</span>
                  </CardTitle>
                  <CardContent className="p-0 pt-2">
                    <p className="text-gray-600">
                      No. Unlike many platforms, we don't charge any commission on sales. You only pay for the listing credits, and the full sale amount goes directly to you when you complete a sale.
                    </p>
                  </CardContent>
                </CardHeader>
              </Card>
              
              <Card className="shadow-sm hover:shadow-md transition-all cursor-pointer">
                <CardHeader className="py-6">
                  <CardTitle className="text-xl flex justify-between items-center">
                    <span>Can I get a refund if my vehicle sells quickly?</span>
                  </CardTitle>
                  <CardContent className="p-0 pt-2">
                    <p className="text-gray-600">
                      Credits are non-refundable once used, but they represent excellent value compared to traditional selling methods. Many of our sellers report sales within the first week of listing.
                    </p>
                  </CardContent>
                </CardHeader>
              </Card>
              
              <Card className="shadow-sm hover:shadow-md transition-all cursor-pointer">
                <CardHeader className="py-6">
                  <CardTitle className="text-xl flex justify-between items-center">
                    <span>Do you offer custom packages for large dealerships?</span>
                  </CardTitle>
                  <CardContent className="p-0 pt-2">
                    <p className="text-gray-600">
                      Yes, we offer custom enterprise solutions for dealerships and fleet managers with high volume needs. Contact our sales team at sales@sourcemytruck.com to discuss your specific requirements.
                    </p>
                  </CardContent>
                </CardHeader>
              </Card>
            </div>
          </div>

          {/* CTA Section */}
          <div className="bg-brand-blue rounded-xl p-8 text-white text-center">
            <h2 className="text-2xl font-bold mb-4">Ready to List Your Vehicles?</h2>
            <p className="mb-6 max-w-2xl mx-auto">
              Join thousands of successful sellers who have found the perfect buyers for their commercial vehicles on Source my Truck.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/register">
                <Button size="lg" variant="secondary" className="gap-2">
                  Create an Account
                  <ArrowRight className="h-4 w-4" />
                </Button>
              </Link>
              <Link to="/profile?tab=credits">
                <Button size="lg" variant="outline" className="bg-transparent border-white text-white hover:bg-white hover:text-brand-blue">
                  Purchase Credits
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </PageLayout>
  );
};

export default Pricing;
