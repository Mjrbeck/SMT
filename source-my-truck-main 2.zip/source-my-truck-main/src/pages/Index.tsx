import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { Link } from "react-router-dom";
import NavBar from "@/components/NavBar";
import Footer from "@/components/Footer";
import SearchBoxWrapper from "@/components/SearchBoxWrapper";
import { Truck, PoundSterling, ShieldCheck, HeartHandshake, StarIcon, Gift, CheckCircle, AlertTriangle } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import FeaturedVehicles from "@/components/FeaturedVehicles";
import { ErrorBoundary } from "react-error-boundary";
import { cn } from "@/lib/utils";
import { motion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";
import HowItWorks from "@/components/home/HowItWorks";
import SEO from "@/components/seo/SEO";
import SchemaData from "@/components/seo/SchemaData";
import StyledCard from "@/components/ui/styled-card";

const ErrorFallback = ({ error, resetErrorBoundary }) => (
  <div className="flex flex-col items-center justify-center min-h-[300px] p-6 text-center bg-card border border-destructive/20 rounded-lg my-6">
    <AlertTriangle className="h-12 w-12 text-destructive mb-4" />
    <h2 className="text-xl font-semibold text-foreground mb-2">Something went wrong</h2>
    <p className="text-muted-foreground mb-4 max-w-md">
      We encountered an error while loading this section. Please try refreshing the page.
    </p>
    <div className="flex flex-col sm:flex-row gap-3">
      <Button 
        onClick={resetErrorBoundary} 
        variant="default"
      >
        Try Again
      </Button>
      <Button 
        onClick={() => window.location.reload()} 
        variant="outline"
      >
        Refresh Page
      </Button>
    </div>
  </div>
);

const Index = () => {
  const navigate = useNavigate();
  const { isAuthenticated } = useAuth();
  const heroRef = useRef(null);
  
  const { scrollY } = useScroll();
  const truckX = useTransform(scrollY, [0, 500], ['50%', '150%']);
  
  const fadeInUp = {
    initial: { opacity: 0, y: 20 },
    animate: { opacity: 1, y: 0, transition: { duration: 0.6 } }
  };

  const staggerContainer = {
    animate: { 
      transition: { 
        staggerChildren: 0.1,
        delayChildren: 0.3
      } 
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100">
      <SEO 
        title="Find Your Perfect Commercial Vehicle"
        description="Source my Truck is the UK's leading marketplace for buying and selling commercial vehicles. Browse thousands of listings from trusted sellers."
        keywords="commercial trucks, UK commercial vehicles, truck marketplace, buy trucks, sell trucks, transport vehicles"
      />
      <SchemaData type="website" data={{}} />
      <SchemaData 
        type="organization" 
        data={{
          socialLinks: [
            "https://facebook.com/sourcemytruck",
            "https://twitter.com/sourcemytruck",
            "https://linkedin.com/company/sourcemytruck"
          ]
        }} 
      />
      
      {/* Promotional Banner - Added back */}
      {!isAuthenticated && (
        <div className="bg-brand-orange text-white py-2 px-4 text-center">
          <p className="font-medium">
            <Gift className="inline-block mr-2 h-4 w-4" />
            Sign up today and get 1 FREE credit to list your vehicle!
            <Link to="/register" className="underline ml-2 font-bold hover:text-white/90">
              Register Now
            </Link>
          </p>
        </div>
      )}
      
      <NavBar />
      
      {/* Hero Section */}
      <section className="relative overflow-hidden" ref={heroRef}>
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-gradient-to-r from-gray-900 via-brand-blue to-blue-900 animate-gradient-x"></div>
        </div>
        
        {/* Animated truck that moves right on scroll */}
        <motion.div 
          className="absolute opacity-10"
          style={{ 
            left: truckX,
            top: '50%',
            y: '-50%',
            x: '-50%'
          }}
        >
          <Truck size={500} className="text-white" />
        </motion.div>
        
        <div className="container mx-auto px-6 py-24 md:py-32 relative z-10 text-white">
          <motion.div 
            className="max-w-3xl"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ 
              duration: 0.8,
              ease: [0.2, 0.65, 0.3, 0.9] 
            }}
          >
            <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight tracking-tight">
              Find Your Perfect <span className="text-brand-orange drop-shadow-sm">Commercial Vehicle</span>
            </h1>
            <p className="text-xl md:text-2xl mb-10 text-gray-100 font-light leading-relaxed">
              Source my Truck is the UK's leading marketplace for buying and selling 
              commercial vehicles. Browse thousands of listings from trusted sellers.
            </p>
            
            <motion.div 
              className="flex flex-wrap gap-4"
              variants={staggerContainer}
              initial="initial"
              animate="animate"
            >
              <motion.div 
                variants={fadeInUp}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.98 }}
              >
                <Link to="/listings">
                  <Button className="bg-brand-orange hover:bg-brand-orange/90 text-white px-8 py-6 text-lg shadow-lg hover:shadow-xl transition-all transform hover:-translate-y-1">
                    Browse Vehicles
                  </Button>
                </Link>
              </motion.div>
              <motion.div 
                variants={fadeInUp}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.98 }}
              >
                <Link to={isAuthenticated ? "/create-listing" : "/register"}>
                  <Button variant="outline" className="border-white text-brand-orange bg-white hover:bg-white/90 px-8 py-6 text-lg shadow-lg hover:shadow-xl transition-all transform hover:-translate-y-1">
                    {isAuthenticated ? "Create Listing" : "Become a Seller"}
                  </Button>
                </Link>
              </motion.div>
            </motion.div>
          </motion.div>
        </div>
      </section>
      
      {/* Search Box Section */}
      <section className="container mx-auto px-4 -mt-8 relative z-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <ErrorBoundary FallbackComponent={ErrorFallback}>
            <SearchBoxWrapper />
          </ErrorBoundary>
        </motion.div>
      </section>
      
      {/* Featured Vehicles Sections */}
      <section className="container mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.4 }}
        >
          <ErrorBoundary FallbackComponent={ErrorFallback}>
            <FeaturedVehicles />
          </ErrorBoundary>
        </motion.div>
      </section>
      
      {/* How It Works Section */}
      <HowItWorks />
      
      {/* Benefits Section */}
      <section className="bg-gray-100 py-16">
        <div className="container mx-auto px-4">
          <motion.h2 
            className="text-3xl font-bold text-center mb-12"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            Why Choose Source my Truck
          </motion.h2>
          
          <motion.div 
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8"
            variants={staggerContainer}
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
          >
            {[
              { 
                icon: <Truck size={32} />, 
                title: "Extensive Selection", 
                description: "Thousands of commercial vehicles from trusted sellers across the UK." 
              },
              { 
                icon: <PoundSterling size={32} />, 
                title: "Competitive Pricing", 
                description: "Compare prices and find the best deal for your business needs." 
              },
              { 
                icon: <ShieldCheck size={32} />, 
                title: "Verified Sellers", 
                description: "All our sellers are verified to ensure a safe and reliable experience." 
              },
              { 
                icon: <HeartHandshake size={32} />, 
                title: "Expert Support", 
                description: "Our team is here to help with any questions throughout the process." 
              }
            ].map((benefit, index) => (
              <motion.div 
                key={index}
                className={cn(
                  "bg-white p-6 rounded-lg shadow-sm text-center transform transition-all duration-300 hover:shadow-lg hover:-translate-y-1",
                )}
                variants={fadeInUp}
              >
                <div className="inline-flex items-center justify-center w-16 h-16 bg-brand-blue/10 text-brand-blue rounded-full mb-4">
                  {benefit.icon}
                </div>
                <h3 className="text-xl font-semibold mb-2">{benefit.title}</h3>
                <p className="text-gray-600">
                  {benefit.description}
                </p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-gradient-to-r from-brand-blue to-blue-900"></div>
        </div>
        
        <div className="container mx-auto px-4 py-16 text-center relative z-10">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="max-w-2xl mx-auto"
          >
            <h2 className="text-3xl font-bold mb-4 text-white">Ready to Sell Your Vehicles?</h2>
            <p className="text-xl mb-8 text-gray-100">
              Join thousands of successful sellers on the UK's leading commercial vehicle marketplace.
            </p>
            <motion.div
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Link to={isAuthenticated ? "/create-listing" : "/register"}>
                <Button className="bg-brand-orange hover:bg-brand-orange/90 text-white px-8 py-6 text-lg shadow-lg">
                  {isAuthenticated ? "Create Your Listing" : "Register Now"}
                </Button>
              </Link>
            </motion.div>
          </motion.div>
        </div>
        
        <div className="absolute top-0 left-0 w-full h-32 bg-gradient-to-b from-gray-100 to-transparent"></div>
      </section>
      
      <Footer />
    </div>
  );
};

export default Index;
