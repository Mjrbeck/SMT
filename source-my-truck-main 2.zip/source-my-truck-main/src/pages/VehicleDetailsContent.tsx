import { useAuth } from "@/contexts/AuthContext";
import { useVehicleDetails } from "@/hooks/useVehicleDetails";
import { recordVehicleView } from "@/services/vehicles/vehicleViewsService";
import VehicleDetailsLoading from "@/components/vehicle/VehicleDetailsLoading";
import VehicleDetailsError from "@/components/vehicle/VehicleDetailsError";
import VehicleContent from "@/components/vehicle/VehicleContent";
import { useEffect, useState, useMemo } from "react";
import SEO from "@/components/seo/SEO";
import OpenGraphImage from "@/components/seo/OpenGraphImage";
import SchemaData from "@/components/seo/SchemaData";
import { getVehicleImageData } from "@/utils/vehicleUtils";
import VehicleBreadcrumbs from "@/components/vehicle/VehicleBreadcrumbs";
import { Toaster } from "sonner";
import { useIsMobile } from "@/hooks/use-mobile";
import VehicleActions from "@/components/vehicle/VehicleActions";

const VehicleDetailsContent = ({ id }: { id: string }) => {
  const { user } = useAuth();
  const isMobile = useIsMobile();
  const [isExpired, setIsExpired] = useState(false);

  const {
    vehicle,
    sellerDetails,
    isLoading,
    error,
    refetch,
  } = useVehicleDetails(id);

  const isOwner = user && vehicle && user.id === vehicle.user_id;

  useEffect(() => {
    if (vehicle && vehicle.expires_at) {
      const expiryDate = new Date(vehicle.expires_at);
      setIsExpired(expiryDate < new Date());
    }
  }, [vehicle]);

  useEffect(() => {
    if (vehicle && id && !isOwner) {
      recordVehicleView(id, user?.id).catch((err) =>
        console.error("Error recording view:", err)
      );
    }
  }, [id, vehicle, user, isOwner]);

  const handleNavigate = () => {
    console.log("Preparing to navigate away from vehicle details");
  };

  const handleImageUpdate = () => {
    refetch();
  };

  const seoData = useMemo(() => {
    if (!vehicle) return null;

    const vehicleTitle = `${vehicle.year || ''} ${vehicle.make || ''} ${vehicle.model || ''} ${vehicle.bodyType || ''}`.trim();
    const priceDisplay = vehicle.isPOA ? 'POA' : `£${vehicle.price?.toLocaleString() || '0'}`;
    const vehicleDescription = `${vehicleTitle} - ${priceDisplay}. ${vehicle.mileage ? vehicle.mileage.toLocaleString() + ' miles, ' : ''}${vehicle.engineSize || ''} ${vehicle.fuelType || ''}. Available now on Source My Truck.`;
    const vehicleKeywords = `${vehicle.make || ''}, ${vehicle.model || ''}, ${vehicle.bodyType || ''}, commercial vehicle, ${vehicle.transmission || ''}, ${vehicle.fuelType || ''}, used truck`;

    let vehicleMainImage = null;
    if (Array.isArray(vehicle.vehicle_images) && vehicle.vehicle_images.length > 0) {
      const mainImageObj = vehicle.vehicle_images.find(img => img.is_main === true);
      if (mainImageObj?.image_url) {
        vehicleMainImage = mainImageObj.image_url;
      } else if (vehicle.vehicle_images[0]?.image_url) {
        vehicleMainImage = vehicle.vehicle_images[0].image_url;
      }
    }

    const socialImage = vehicleMainImage && vehicleMainImage.trim() !== ''
      ? String(vehicleMainImage)
      : `${window.location.origin}/source-my-truck-logo.png`;

    return {
      title: String(`${vehicleTitle} - ${priceDisplay}`),
      description: String(vehicleDescription),
      keywords: String(vehicleKeywords),
      image: String(socialImage),
    };
  }, [vehicle]);

  if (isLoading) {
    return <VehicleDetailsLoading />;
  }

  if (error || !vehicle) {
    return <VehicleDetailsError message={error ? String(error) : "Vehicle not found"} />;
  }

  const enhancedVehicle = {
    ...vehicle,
    features: vehicle.features || [],
  };

  const { mainImage } = getVehicleImageData(vehicle);
  const vehicleWithMainImage = {
    ...enhancedVehicle,
    imageUrl: mainImage || enhancedVehicle.imageUrl,
  };

  return (
    <>
      {/* Inject vehicle data for social sharing */}
      {vehicle && (
        <script
          id={`vehicle-data-${vehicle.id}`}
          data-vehicle-id={vehicle.id}
          type="application/json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              id: vehicle.id,
              title: vehicle.title,
              make: vehicle.make,
              model: vehicle.model,
              year: vehicle.year,
              price: vehicle.price,
              mileage: vehicle.mileage,
              description: vehicle.description
            })
          }}
        />
      )}

      {seoData && (
        <>
          <SEO
            title={seoData.title}
            description={seoData.description}
            keywords={seoData.keywords}
            ogImage={seoData.image}
            ogType="product"
          />
          <OpenGraphImage
            title={seoData.title}
            description={seoData.description}
            imageUrl={seoData.image}
            type="product"
          />
          <SchemaData type="vehicle" data={vehicleWithMainImage} />
          {sellerDetails && <SchemaData type="seller" data={sellerDetails} />}
        </>
      )}

      <Toaster position="top-center" />

      <div className={isMobile ? "px-2 pb-16" : ""}>
        <VehicleBreadcrumbs
          make={vehicle.make}
          model={vehicle.model}
          title={vehicle.title}
        />

        {isOwner && (
          <div className="mb-4">
            <VehicleActions
              vehicle={vehicleWithMainImage}
              isOwner={isOwner}
              isExpired={isExpired}
              onNavigate={handleNavigate}
            />
          </div>
        )}

        <VehicleContent
          vehicle={vehicleWithMainImage}
          sellerDetails={sellerDetails}
          onImageUpdate={handleImageUpdate}
        />
      </div>
    </>
  );
};

export default VehicleDetailsContent;
