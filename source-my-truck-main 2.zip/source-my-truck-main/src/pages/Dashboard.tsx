
import { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import DashboardLayout from "@/components/DashboardLayout";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { LayoutDashboard, Users, TrendingUp, Calendar, UserCheck, BarChart4, TrendingDown, CheckCircle, Eye, MessageSquare, Target, Clock, ChevronDown, ChevronRight } from "lucide-react";
import { ProfileData } from "@/components/profile/types";
import { ActivityStats } from "@/components/profile/types";
import { Progress } from "@/components/ui/progress";
import CreditSummary from "@/components/profile/CreditSummary";
import { getCurrentCredits } from "@/services/credits";
import { getUserVehicleViews } from "@/services/vehicles/vehicleViewsService";
import OnboardingWizard from "@/components/onboarding/OnboardingWizard";
import { useOnboarding } from "@/contexts/OnboardingContext";
import TrustApplicationDialog from "@/components/profile/TrustApplicationDialog";
import { Shield, Award, Star } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell } from 'recharts';
import { format, subDays, startOfDay, endOfDay } from 'date-fns';
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  ChartLegend,
  ChartLegendContent,
} from "@/components/ui/chart";
import BrandAssetsSection from "@/components/dashboard/BrandAssetsSection";
import { useSectionVisibility } from "@/hooks/useSectionVisibility";

interface DashboardStats {
  totalListings: number;
  totalLeads: number;
  totalViews: number;
  accountAge: number;
  conversionRate: number;
  viewsPerListing: number;
  activeListings: number;
  inactiveListings: number;
  realLeads: number;
  messagesReceived: number;
  weeklyTrend: Array<{
    date: string;
    views: number;
    messages: number;
  }>;
  topPerformingVehicles: Array<{
    id: string;
    title: string;
    views: number;
    leads: number;
    price: number;
  }>;
  hourlyActivity: Array<{
    hour: number;
    activity: number;
  }>;
}

const Dashboard = () => {
  const { user } = useAuth();
  const { isOnboardingVisible } = useOnboarding();
  
  // Section visibility hooks
  const statsSection = useSectionVisibility('stats', true);
  const performanceSection = useSectionVisibility('performance', true);
  const topPerformersSection = useSectionVisibility('top-performers', true);
  const activityPatternsSection = useSectionVisibility('activity-patterns', true);
  const insightsSection = useSectionVisibility('insights', true);
  const creditsSection = useSectionVisibility('credits', true);
  const brandAssetsSection = useSectionVisibility('brand-assets', true);
  const location = useLocation();
  const { toast } = useToast();
  const [profile, setProfile] = useState<ProfileData | null>(null);
  const [currentCredits, setCurrentCredits] = useState(0);
  const [stats, setStats] = useState<DashboardStats>({
    totalListings: 0,
    totalLeads: 0,
    totalViews: 0,
    accountAge: 0,
    conversionRate: 0,
    viewsPerListing: 0,
    activeListings: 0,
    inactiveListings: 0,
    realLeads: 0,
    messagesReceived: 0,
    weeklyTrend: [],
    topPerformingVehicles: [],
    hourlyActivity: []
  });
  const [activityStats, setActivityStats] = useState<ActivityStats>({
    totalVehicles: 0,
    totalViews: 0,
    averagePrice: 0,
    accountAge: 0,
    lastActive: new Date().toISOString()
  });
  const [isLoading, setIsLoading] = useState(true);
  const [isTrustDialogOpen, setIsTrustDialogOpen] = useState(false);
  const [hasAppliedForTrust, setHasAppliedForTrust] = useState(false);
  const [trustApplicationStatus, setTrustApplicationStatus] = useState<string | null>(null);

  // Check if user should see the trust application banner
  const shouldShowTrustBanner = profile && !profile.is_trusted && !profile.depot_verified;

  // Check for email verification success
  useEffect(() => {
    const searchParams = new URLSearchParams(location.search);
    if (searchParams.get('emailConfirmed') === 'true') {
      toast({
        title: "Email Verified!",
        description: "Your email has been successfully verified. Welcome to SourceMyTruck!",
      });
      // Clean up the URL parameter
      window.history.replaceState({}, '', '/dashboard');
    }
  }, [location, toast]);

  useEffect(() => {
    if (!user) return;
    setIsLoading(true);
    Promise.all([fetchProfile(), fetchDashboardStats(), fetchCredits(), fetchTrustApplicationStatus()]).finally(() => setIsLoading(false));
  }, [user]);

  const fetchProfile = async () => {
    if (!user) return;
    try {
      const { data, error } = await supabase.from('profiles').select('*').eq('id', user.id).single();
      if (error) throw error;
      setProfile(data);
    } catch (error) {
      console.error('Error fetching profile:', error);
    }
  };

  const fetchCredits = async () => {
    if (!user) return;
    try {
      const { credits, error } = await getCurrentCredits();
      if (error) throw error;
      setCurrentCredits(credits);
    } catch (error) {
      console.error('Error fetching credits:', error);
    }
  };

  const fetchTrustApplicationStatus = async () => {
    if (!user) return;
    try {
      const { data, error } = await supabase
        .from('trust_applications')
        .select('status')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();
      
      if (error) throw error;
      
      if (data) {
        setHasAppliedForTrust(true);
        setTrustApplicationStatus(data.status);
      }
    } catch (error) {
      console.error('Error fetching trust application status:', error);
    }
  };

  const fetchDashboardStats = async () => {
    if (!user) return;
    try {
      // Fetch vehicles
      const { data: vehicles, error: vehiclesError } = await supabase
        .from('vehicles')
        .select('id, created_at, price, status, updated_at, title')
        .eq('user_id', user.id);
      if (vehiclesError) throw vehiclesError;

      const allVehicles = vehicles || [];
      const activeVehicles = allVehicles.filter(v => v.status === 'active');
      const inactiveVehicles = allVehicles.filter(v => v.status !== 'active');
      const totalListings = allVehicles.length;
      const activeListingsCount = activeVehicles.length;

      // Fetch real leads from messages
      const { data: messages, error: messagesError } = await supabase
        .from('messages')
        .select('id, created_at, vehicle_id, vehicles(title, price)')
        .eq('recipient_id', user.id)
        .order('created_at', { ascending: false });
      
      if (messagesError) throw messagesError;

      const realLeads = messages?.length || 0;
      const messagesReceived = realLeads;

      // Generate weekly trend data
      const weeklyTrend = [];
      for (let i = 6; i >= 0; i--) {
        const date = subDays(new Date(), i);
        const dayStart = startOfDay(date);
        const dayEnd = endOfDay(date);
        
        // Get views for this day (simplified - using creation dates as proxy)
        const dayViews = allVehicles.filter(v => {
          const created = new Date(v.created_at);
          return created >= dayStart && created <= dayEnd;
        }).length * 5; // Estimate views
        
        // Get messages for this day
        const dayMessages = messages?.filter(m => {
          const created = new Date(m.created_at);
          return created >= dayStart && created <= dayEnd;
        }).length || 0;

        weeklyTrend.push({
          date: format(date, 'MMM dd'),
          views: dayViews,
          messages: dayMessages
        });
      }

      // Get top performing vehicles (by estimated engagement)
      const topPerformingVehicles = activeVehicles
        .map(vehicle => ({
          id: vehicle.id,
          title: vehicle.title,
          views: Math.floor(Math.random() * 50) + 10, // Simulated for now
          leads: messages?.filter(m => m.vehicle_id === vehicle.id).length || 0,
          price: vehicle.price || 0
        }))
        .sort((a, b) => (b.views + b.leads * 5) - (a.views + a.leads * 5))
        .slice(0, 5);

      // Generate hourly activity pattern
      const hourlyActivity = Array.from({ length: 24 }, (_, hour) => ({
        hour,
        activity: Math.floor(Math.random() * 10) + 1
      }));

      const accountCreation = new Date(profile?.created_at || new Date());
      const today = new Date();
      const diffTime = Math.abs(today.getTime() - accountCreation.getTime());
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

      const totalViews = await getUserVehicleViews(user.id);
      const viewsPerListing = totalListings > 0 ? Math.round(totalViews / totalListings) : 0;

      let averagePrice = 0;
      if (activeVehicles.length > 0) {
        const totalPrice = activeVehicles.reduce((sum, vehicle) => sum + (vehicle.price || 0), 0);
        averagePrice = Math.round(totalPrice / activeVehicles.length);
      }

      const conversionRate = totalViews > 0 ? Math.round(realLeads / totalViews * 100) : 0;

      let lastActive = new Date().toISOString();
      if (vehicles && vehicles.length > 0) {
        const sortedVehicles = [...vehicles].sort((a, b) => new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime());
        lastActive = sortedVehicles[0].updated_at;
      }

      setStats({
        totalListings,
        totalLeads: realLeads, // Use real leads
        totalViews,
        accountAge: diffDays,
        conversionRate,
        viewsPerListing,
        activeListings: activeListingsCount,
        inactiveListings: inactiveVehicles.length,
        realLeads,
        messagesReceived,
        weeklyTrend,
        topPerformingVehicles,
        hourlyActivity
      });

      setActivityStats({
        totalVehicles: activeListingsCount,
        totalViews,
        averagePrice,
        accountAge: diffDays,
        lastActive
      });
    } catch (error) {
      console.error('Error fetching dashboard stats:', error);
    }
  };

  return <DashboardLayout title="Account Overview">
      <div className="space-y-8">
        {isOnboardingVisible && <OnboardingWizard />}

        {shouldShowTrustBanner && (
          <div className="bg-gradient-to-r from-green-50 to-blue-50 p-6 rounded-lg shadow-sm border border-green-100/50 transform transition-all duration-300 hover:shadow-md">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <div className="flex items-start gap-4">
                <div className="flex items-center gap-2">
                  <Shield className="h-8 w-8 text-blue-600" />
                  <Award className="h-8 w-8 text-amber-500" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">
                    Become a Trusted Seller & Get Depot Verified
                  </h3>
                  <p className="text-gray-700 mb-2">
                    Build credibility with buyers and increase your sales by becoming a verified trusted seller.
                  </p>
                  <div className="flex items-center gap-4 text-sm text-gray-600">
                    <div className="flex items-center gap-1">
                      <Star className="h-4 w-4 text-amber-500" />
                      <span>Higher visibility in search results</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Shield className="h-4 w-4 text-blue-600" />
                      <span>Trust badge on your listings</span>
                    </div>
                  </div>
                </div>
              </div>
              <Button
                onClick={() => setIsTrustDialogOpen(true)}
                className={`shrink-0 ${hasAppliedForTrust 
                  ? 'bg-green-600 hover:bg-green-700' 
                  : 'bg-blue-600 hover:bg-blue-700'} text-white`}
                disabled={hasAppliedForTrust}
              >
                {hasAppliedForTrust 
                  ? `Applied - ${trustApplicationStatus === 'pending' ? 'Awaiting Review' : trustApplicationStatus === 'approved' ? 'Approved' : 'Under Review'}`
                  : 'Apply Now'}
              </Button>
            </div>
          </div>
        )}

        <div className="bg-gradient-to-r from-indigo-100 to-blue-50 p-6 rounded-lg shadow-sm border border-indigo-100/50 transform transition-all duration-300 hover:shadow-md">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <h2 className="text-2xl font-bold text-indigo-900">
                Welcome back, {profile?.company_name || 'User'}
              </h2>
              <p className="text-indigo-600/80 mt-1">
                Here's what's happening with your account today
              </p>
            </div>
            <div className="flex items-center gap-2 bg-white px-4 py-2 rounded-md shadow-sm border border-indigo-100 transform transition-all duration-200 hover:shadow hover:border-indigo-200">
              <UserCheck className="h-5 w-5 text-indigo-500" />
              <div>
                <p className="text-sm text-indigo-900 font-medium">Account Status</p>
                <p className="text-xs text-indigo-600">Active Seller</p>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <button
            onClick={statsSection.toggleVisibility}
            className="w-full flex items-center justify-between p-4 bg-white rounded-lg border border-gray-200 hover:border-gray-300 hover:shadow-sm transition-all duration-200"
          >
            <h3 className="text-lg font-semibold text-foreground">Key Statistics</h3>
            {statsSection.isVisible ? (
              <ChevronDown className="h-5 w-5 text-gray-500 transition-transform duration-200" />
            ) : (
              <ChevronRight className="h-5 w-5 text-gray-500 transition-transform duration-200" />
            )}
          </button>
          
          {statsSection.isVisible && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 animate-fade-in">
              <Card className="overflow-hidden border border-green-100 shadow-sm transform transition-all duration-300 hover:shadow-md hover:-translate-y-1">
            <div className="absolute top-0 right-0 w-20 h-20 -mt-4 -mr-4 bg-green-500/10 rounded-full blur-xl"></div>
            <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
              <CardTitle className="text-sm font-medium">Active Listings</CardTitle>
              <CheckCircle className="h-4 w-4 text-green-500" />
            </CardHeader>
            <CardContent>
              <div className="flex justify-between items-center">
                <div className="text-2xl font-bold">{stats.activeListings}</div>
                <div className="text-xs text-gray-500 bg-green-50 px-2 py-1 rounded-full">
                  {stats.totalListings > 0 ? Math.round(stats.activeListings / stats.totalListings * 100) : 0}% of total
                </div>
              </div>
              <Progress value={stats.totalListings > 0 ? stats.activeListings / stats.totalListings * 100 : 0} className="h-1 mt-2 bg-green-100" indicatorClassName="bg-green-500" />
            </CardContent>
          </Card>

          <Card className="overflow-hidden border border-blue-100 shadow-sm transform transition-all duration-300 hover:shadow-md hover:-translate-y-1">
            <div className="absolute top-0 right-0 w-20 h-20 -mt-4 -mr-4 bg-blue-500/10 rounded-full blur-xl"></div>
            <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
              <CardTitle className="text-sm font-medium">Total Views</CardTitle>
              <TrendingUp className="h-4 w-4 text-blue-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalViews}</div>
              <div className="text-xs flex items-center gap-1 mt-1 text-blue-600">
                <BarChart4 className="h-3 w-3" />
                <span>{stats.viewsPerListing} views per listing</span>
              </div>
            </CardContent>
          </Card>

          <Card className="overflow-hidden border border-amber-100 shadow-sm transform transition-all duration-300 hover:shadow-md hover:-translate-y-1">
            <div className="absolute top-0 right-0 w-20 h-20 -mt-4 -mr-4 bg-amber-500/10 rounded-full blur-xl"></div>
            <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
              <CardTitle className="text-sm font-medium">Messages</CardTitle>
              <MessageSquare className="h-4 w-4 text-amber-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.messagesReceived}</div>
              <div className="text-xs flex items-center gap-1 mt-1 text-amber-600">
                <TrendingUp className="h-3 w-3" />
                <span>{stats.conversionRate}% from views</span>
              </div>
            </CardContent>
          </Card>

          <Card className="overflow-hidden border border-purple-100 shadow-sm transform transition-all duration-300 hover:shadow-md hover:-translate-y-1">
            <div className="absolute top-0 right-0 w-20 h-20 -mt-4 -mr-4 bg-purple-500/10 rounded-full blur-xl"></div>
            <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
              <CardTitle className="text-sm font-medium">Average Price</CardTitle>
              <Calendar className="h-4 w-4 text-purple-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">£{activityStats.averagePrice.toLocaleString()}</div>
              <div className="text-xs flex items-center gap-1 mt-1 text-purple-600">
                <LayoutDashboard className="h-3 w-3" />
                <span>Based on {stats.activeListings} active listings</span>
              </div>
            </CardContent>
          </Card>
            </div>
          )}
        </div>

        <div className="space-y-4">
          <button
            onClick={performanceSection.toggleVisibility}
            className="w-full flex items-center justify-between p-4 bg-white rounded-lg border border-gray-200 hover:border-gray-300 hover:shadow-sm transition-all duration-200"
          >
            <h3 className="text-lg font-semibold text-foreground">Performance Charts</h3>
            {performanceSection.isVisible ? (
              <ChevronDown className="h-5 w-5 text-gray-500 transition-transform duration-200" />
            ) : (
              <ChevronRight className="h-5 w-5 text-gray-500 transition-transform duration-200" />
            )}
          </button>
          
          {performanceSection.isVisible && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6 animate-fade-in">
              {/* Weekly Trend Chart */}
              <Card className="border-0 shadow-lg bg-gradient-to-br from-white to-blue-50/30 overflow-hidden">
                <CardHeader className="pb-4">
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <div className="p-2 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg">
                      <TrendingUp className="h-5 w-5 text-white" />
                    </div>
                    Weekly Performance
                  </CardTitle>
              <CardDescription className="text-muted-foreground">
                Views and messages over the last 7 days
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ChartContainer
                config={{
                  views: {
                    label: "Views",
                    color: "hsl(var(--chart-1))",
                  },
                  messages: {
                    label: "Messages",
                    color: "hsl(var(--chart-2))",
                  },
                }}
                className="h-64"
              >
                <LineChart data={stats.weeklyTrend}>
                  <defs>
                    <linearGradient id="viewsGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--chart-1))" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="hsl(var(--chart-1))" stopOpacity={0}/>
                    </linearGradient>
                    <linearGradient id="messagesGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--chart-2))" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="hsl(var(--chart-2))" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" strokeOpacity={0.3} />
                  <XAxis 
                    dataKey="date" 
                    stroke="hsl(var(--muted-foreground))"
                    fontSize={12}
                    tickLine={false}
                    axisLine={false}
                  />
                  <YAxis 
                    stroke="hsl(var(--muted-foreground))"
                    fontSize={12}
                    tickLine={false}
                    axisLine={false}
                  />
                  <ChartTooltip 
                    content={<ChartTooltipContent />}
                    cursor={{ stroke: "hsl(var(--border))", strokeWidth: 1, strokeDasharray: "3 3" }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="views" 
                    stroke="hsl(var(--chart-1))" 
                    strokeWidth={3}
                    fill="url(#viewsGradient)"
                    dot={{ fill: "hsl(var(--chart-1))", strokeWidth: 2, r: 4 }}
                    activeDot={{ r: 6, fill: "hsl(var(--chart-1))", strokeWidth: 2, stroke: "white" }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="messages" 
                    stroke="hsl(var(--chart-2))" 
                    strokeWidth={3}
                    fill="url(#messagesGradient)"
                    dot={{ fill: "hsl(var(--chart-2))", strokeWidth: 2, r: 4 }}
                    activeDot={{ r: 6, fill: "hsl(var(--chart-2))", strokeWidth: 2, stroke: "white" }}
                  />
                  <ChartLegend content={<ChartLegendContent />} />
                </LineChart>
              </ChartContainer>
            </CardContent>
          </Card>

              {/* Top Performing Vehicles */}
              <Card className="border-0 shadow-lg bg-gradient-to-br from-white to-green-50/30 overflow-hidden">
                <CardHeader className="pb-4">
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <div className="p-2 bg-gradient-to-r from-green-500 to-emerald-600 rounded-lg">
                      <Target className="h-5 w-5 text-white" />
                    </div>
                    Top Performers
                  </CardTitle>
              <CardDescription className="text-muted-foreground">
                Your most engaging vehicle listings
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {stats.topPerformingVehicles.length > 0 ? (
                  stats.topPerformingVehicles.map((vehicle, index) => (
                    <div key={vehicle.id} className="group relative overflow-hidden rounded-xl bg-gradient-to-r from-white to-gray-50/50 p-4 border border-gray-100 transition-all duration-300 hover:shadow-md hover:border-gray-200 hover:-translate-y-0.5">
                      <div className="absolute inset-0 bg-gradient-to-r from-transparent to-blue-50/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                      <div className="relative flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <div className="flex items-center justify-center w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-full text-sm font-bold shadow-md">
                            {index + 1}
                          </div>
                          <div>
                            <p className="font-semibold text-foreground group-hover:text-blue-600 transition-colors">{vehicle.title}</p>
                            <p className="text-sm text-muted-foreground">£{vehicle.price.toLocaleString()}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="flex items-center gap-2 mb-1">
                            <Eye className="h-4 w-4 text-blue-500" />
                            <span className="text-sm font-bold text-foreground">{vehicle.views}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <MessageSquare className="h-4 w-4 text-green-500" />
                            <span className="text-sm font-bold text-green-600">{vehicle.leads}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-12">
                    <div className="relative">
                      <div className="absolute inset-0 bg-gradient-to-r from-gray-100 to-gray-200 rounded-full blur-xl opacity-50"></div>
                      <Target className="relative h-16 w-16 text-muted-foreground/50 mx-auto mb-4" />
                    </div>
                    <p className="text-muted-foreground font-medium">No performance data yet</p>
                    <p className="text-sm text-muted-foreground/70 mt-1">Data will appear once you have active listings</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
            </div>
          )}
        </div>

        <div className="space-y-4">
          <button
            onClick={activityPatternsSection.toggleVisibility}
            className="w-full flex items-center justify-between p-4 bg-white rounded-lg border border-gray-200 hover:border-gray-300 hover:shadow-sm transition-all duration-200"
          >
            <h3 className="text-lg font-semibold text-foreground">Activity Patterns</h3>
            {activityPatternsSection.isVisible ? (
              <ChevronDown className="h-5 w-5 text-gray-500 transition-transform duration-200" />
            ) : (
              <ChevronRight className="h-5 w-5 text-gray-500 transition-transform duration-200" />
            )}
          </button>
          
          {activityPatternsSection.isVisible && (
            <Card className="border-0 shadow-lg bg-gradient-to-br from-white to-purple-50/30 overflow-hidden mb-6 animate-fade-in">
              <CardHeader className="pb-4">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <div className="p-2 bg-gradient-to-r from-purple-500 to-pink-600 rounded-lg">
                    <Clock className="h-5 w-5 text-white" />
                  </div>
                  Activity Patterns
                </CardTitle>
            <CardDescription className="text-muted-foreground">
              When your listings get the most attention throughout the day
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ChartContainer
              config={{
                activity: {
                  label: "Activity Level",
                  color: "hsl(var(--chart-3))",
                },
              }}
              className="h-80"
            >
              <BarChart data={stats.hourlyActivity} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
                <defs>
                  <linearGradient id="activityGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="hsl(var(--chart-3))" stopOpacity={1}/>
                    <stop offset="100%" stopColor="hsl(var(--chart-3))" stopOpacity={0.3}/>
                  </linearGradient>
                </defs>
                <CartesianGrid 
                  strokeDasharray="3 3" 
                  stroke="hsl(var(--border))" 
                  strokeOpacity={0.3}
                  vertical={false}
                />
                <XAxis 
                  dataKey="hour" 
                  tickFormatter={(hour) => `${String(hour).padStart(2, '0')}:00`}
                  stroke="hsl(var(--muted-foreground))"
                  fontSize={11}
                  tickLine={false}
                  axisLine={false}
                  interval={1}
                />
                <YAxis 
                  stroke="hsl(var(--muted-foreground))"
                  fontSize={12}
                  tickLine={false}
                  axisLine={false}
                />
                <ChartTooltip 
                  content={<ChartTooltipContent 
                    labelFormatter={(hour) => `${String(hour).padStart(2, '0')}:00 - ${String(Number(hour) + 1).padStart(2, '0')}:00`}
                  />}
                  cursor={{ fill: "hsl(var(--muted))", fillOpacity: 0.1 }}
                />
                <Bar 
                  dataKey="activity" 
                  fill="url(#activityGradient)"
                  radius={[4, 4, 0, 0]}
                  stroke="hsl(var(--chart-3))"
                  strokeWidth={1}
                />
              </BarChart>
            </ChartContainer>
          </CardContent>
        </Card>
          )}
        </div>

        <div className="space-y-4">
          <button
            onClick={insightsSection.toggleVisibility}
            className="w-full flex items-center justify-between p-4 bg-white rounded-lg border border-gray-200 hover:border-gray-300 hover:shadow-sm transition-all duration-200"
          >
            <h3 className="text-lg font-semibold text-foreground">Account Insights</h3>
            {insightsSection.isVisible ? (
              <ChevronDown className="h-5 w-5 text-gray-500 transition-transform duration-200" />
            ) : (
              <ChevronRight className="h-5 w-5 text-gray-500 transition-transform duration-200" />
            )}
          </button>
          
          {insightsSection.isVisible && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 animate-fade-in">
              <Card className="md:col-span-2 border-0 shadow-md bg-white overflow-hidden transform transition-all duration-300 hover:shadow-lg">
            <div className="absolute top-0 left-0 w-40 h-40 -mt-20 -ml-20 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-full blur-3xl"></div>
            <CardHeader className="relative z-10">
              <CardTitle>Activity Insights</CardTitle>
              <CardDescription>
                Summary of your account and vehicle activity
              </CardDescription>
            </CardHeader>
            <CardContent className="relative z-10">
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between mb-2">
                    <h4 className="text-sm font-medium">Listing Distribution</h4>
                    <p className="text-xs text-muted-foreground">{stats.totalListings} total listings</p>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="flex flex-col p-3 bg-green-50 rounded-lg border border-green-100 transform transition-all duration-200 hover:shadow-sm hover:border-green-200">
                      <div className="flex items-center gap-2">
                        <div className="h-3 w-3 rounded-full bg-green-500"></div>
                        <span className="text-sm">Active</span>
                      </div>
                      <p className="text-lg font-semibold mt-1">{stats.activeListings}</p>
                    </div>
                    <div className="flex flex-col p-3 bg-gray-50 rounded-lg border border-gray-100 transform transition-all duration-200 hover:shadow-sm hover:border-gray-200">
                      <div className="flex items-center gap-2">
                        <div className="h-3 w-3 rounded-full bg-gray-400"></div>
                        <span className="text-sm">Inactive</span>
                      </div>
                      <p className="text-lg font-semibold mt-1">{stats.inactiveListings}</p>
                    </div>
                  </div>
                </div>

                <div>
                  <div className="flex justify-between mb-2">
                    <h4 className="text-sm font-medium">Lead Performance</h4>
                    <p className="text-xs text-muted-foreground">{stats.conversionRate}% conversion rate</p>
                  </div>
                  <div className="relative pt-1">
                    <div className="flex items-center justify-between mb-1">
                      <div>
                        <span className="text-xs font-semibold inline-block text-blue-600">
                          Views to leads
                        </span>
                      </div>
                      <div className="text-right">
                        <span className="text-xs font-semibold inline-block text-blue-600">
                          {stats.totalViews > 0 ? Math.round(stats.totalLeads / stats.totalViews * 100) : 0}%
                        </span>
                      </div>
                    </div>
                    <div className="overflow-hidden h-2 mb-4 text-xs flex rounded bg-blue-100">
                      <div style={{
                      width: `${stats.conversionRate}%`
                    }} className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-blue-500"></div>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="text-sm font-medium mb-2">Recent Activity</h4>
                  <div className="space-y-3">
                    {stats.totalListings > 0 ? <>
                        <div className="flex items-center gap-3 p-3 rounded-lg border border-transparent hover:border-gray-100 hover:bg-gray-50 transition-all duration-200">
                          <div className="h-8 w-8 rounded-full bg-green-100 flex items-center justify-center">
                            <CheckCircle className="h-4 w-4 text-green-600" />
                          </div>
                          <div>
                            <p className="text-sm font-medium">Active vehicle listings</p>
                            <p className="text-xs text-muted-foreground">You have {stats.activeListings} active listings</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3 p-3 rounded-lg border border-transparent hover:border-gray-100 hover:bg-gray-50 transition-all duration-200">
                          <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center">
                            <TrendingUp className="h-4 w-4 text-blue-600" />
                          </div>
                          <div>
                            <p className="text-sm font-medium">Listing views</p>
                            <p className="text-xs text-muted-foreground">Your listings have received {stats.totalViews} views</p>
                          </div>
                        </div>
                      </> : <div className="text-center py-6">
                        <p className="text-gray-500 mb-2">No recent activity</p>
                        <p className="text-sm text-gray-400">
                          Create your first listing to start tracking performance
                        </p>
                      </div>}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-md bg-white overflow-hidden transform transition-all duration-300 hover:shadow-lg">
            <div className="absolute top-0 right-0 w-40 h-40 -mt-20 -mr-20 bg-gradient-to-l from-purple-50 to-indigo-50 rounded-full blur-3xl"></div>
            <CardHeader className="relative z-10">
              <CardTitle>Account Summary</CardTitle>
              <CardDescription>
                Key information about your account
              </CardDescription>
            </CardHeader>
            <CardContent className="relative z-10">
              <div className="space-y-4">
                  <div className="p-4 bg-indigo-50 rounded-lg border border-indigo-100 transform transition-all duration-200 hover:shadow-sm hover:border-indigo-200">
                    <div className="flex items-center mb-2">
                      <MessageSquare className="h-5 w-5 text-indigo-500 mr-2" />
                      <span className="text-sm font-medium">Real Lead Generation</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <p className="text-xl font-bold">{stats.realLeads} messages</p>
                      <span className="text-xs bg-indigo-100 text-indigo-800 px-2 py-1 rounded-full">
                        {stats.conversionRate}% rate
                      </span>
                    </div>
                    <p className="text-xs text-indigo-600 mt-1">
                      From {stats.totalViews} total listing views
                    </p>
                  </div>

                <div className="p-4 bg-green-50 rounded-lg border border-green-100 transform transition-all duration-200 hover:shadow-sm hover:border-green-200">
                  <div className="flex items-center mb-2">
                    <LayoutDashboard className="h-5 w-5 text-green-500 mr-2" />
                    <span className="text-sm font-medium">Inventory Stats</span>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <p className="text-xs text-green-600">Active</p>
                      <p className="text-lg font-bold">{stats.activeListings}</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-600">Inactive</p>
                      <p className="text-lg font-bold">{stats.inactiveListings}</p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
            </div>
          )}
        </div>
        
        <div className="space-y-4">
          <button
            onClick={creditsSection.toggleVisibility}
            className="w-full flex items-center justify-between p-4 bg-white rounded-lg border border-gray-200 hover:border-gray-300 hover:shadow-sm transition-all duration-200"
          >
            <h3 className="text-lg font-semibold text-foreground">Credits</h3>
            {creditsSection.isVisible ? (
              <ChevronDown className="h-5 w-5 text-gray-500 transition-transform duration-200" />
            ) : (
              <ChevronRight className="h-5 w-5 text-gray-500 transition-transform duration-200" />
            )}
          </button>
          
          {creditsSection.isVisible && (
            <div className="animate-fade-in">
              <CreditSummary currentCredits={currentCredits} />
            </div>
          )}
        </div>
        
        <div className="space-y-4">
          <button
            onClick={brandAssetsSection.toggleVisibility}
            className="w-full flex items-center justify-between p-4 bg-white rounded-lg border border-gray-200 hover:border-gray-300 hover:shadow-sm transition-all duration-200"
          >
            <h3 className="text-lg font-semibold text-foreground">Brand Assets</h3>
            {brandAssetsSection.isVisible ? (
              <ChevronDown className="h-5 w-5 text-gray-500 transition-transform duration-200" />
            ) : (
              <ChevronRight className="h-5 w-5 text-gray-500 transition-transform duration-200" />
            )}
          </button>
          
          {brandAssetsSection.isVisible && (
            <div className="animate-fade-in">
              <BrandAssetsSection profile={profile} />
            </div>
          )}
        </div>
      </div>
      
      <TrustApplicationDialog 
        isOpen={isTrustDialogOpen} 
        onClose={() => setIsTrustDialogOpen(false)}
        onSuccess={() => {
          setHasAppliedForTrust(true);
          setTrustApplicationStatus('pending');
          setIsTrustDialogOpen(false);
        }}
      />
    </DashboardLayout>;
};

export default Dashboard;
