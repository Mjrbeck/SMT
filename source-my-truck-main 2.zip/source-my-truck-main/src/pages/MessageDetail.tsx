
import PageLayout from "@/components/layouts/PageLayout";
import MessageDetailComponent from "@/components/messaging/MessageDetail";

const MessageDetailPage = () => {
  return (
    <PageLayout title="Message Details">
      <MessageDetailComponent />
    </PageLayout>
  );
};

export default MessageDetailPage;
