
import { useParams } from "react-router-dom";
import { useState, useEffect } from "react";
import ErrorBoundary from "@/components/ErrorBoundary";
import PageLayout from "@/components/layouts/PageLayout";
import VehicleDetailsLoading from "@/components/vehicle/VehicleDetailsLoading";
import VehicleDetailsError from "@/components/vehicle/VehicleDetailsError";


// Import the component directly instead of using lazy loading
import VehicleDetailsContent from "./VehicleDetailsContent";

const VehicleDetails = () => {
  const { id } = useParams<{ id: string }>();
  const [hasError, setHasError] = useState(false);
  
  useEffect(() => {
    // Reset error state when the ID changes
    setHasError(false);
  }, [id]);

  useEffect(() => {
    // Set canonical URL for SEO
    if (id) {
      const canonicalUrl = `${window.location.origin}/vehicle/${id}`;
      
      // Remove existing canonical tag if present
      const existingCanonical = document.querySelector('link[rel="canonical"]');
      if (existingCanonical) {
        existingCanonical.remove();
      }
      
      // Add new canonical tag
      const canonicalLink = document.createElement('link');
      canonicalLink.rel = 'canonical';
      canonicalLink.href = canonicalUrl;
      document.head.appendChild(canonicalLink);
    }

    // Cleanup function to remove canonical tag when component unmounts
    return () => {
      const existingCanonical = document.querySelector('link[rel="canonical"]');
      if (existingCanonical) {
        existingCanonical.remove();
      }
    };
  }, [id]);
  
  if (!id) {
    return (
      <PageLayout>
        <VehicleDetailsError message="Vehicle ID is missing" />
      </PageLayout>
    );
  }
  
  if (hasError) {
    return (
      <PageLayout>
        <VehicleDetailsError message="Failed to load vehicle details. Please try again later." />
      </PageLayout>
    );
  }
  
  return (
    <ErrorBoundary 
      fallback={
        <PageLayout>
          <VehicleDetailsError message="Failed to load vehicle details" />
        </PageLayout>
      }
      onError={() => setHasError(true)}
    >
      <PageLayout>
        <VehicleDetailsContent id={id} />
      </PageLayout>
    </ErrorBoundary>
  );
};

export default VehicleDetails;
