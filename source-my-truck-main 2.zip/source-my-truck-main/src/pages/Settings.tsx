
import { useState, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import DashboardLayout from "@/components/DashboardLayout";
import { Tabs, TabsContent } from "@/components/ui/tabs";
import { CreditBalance } from "@/components/profile/CreditBalance";
import { useInventory } from "@/contexts/InventoryContext";
import { ProfileProvider } from "@/contexts/ProfileContext";
import { SettingsTabsHeader } from "@/components/settings/SettingsTabsHeader";
import InvoicesList from "@/components/profile/InvoicesList";
import { InventoryProvider } from "@/contexts/InventoryContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Shield, KeyRound, BadgeInfo } from "lucide-react";
import { StyledCard } from "@/components/ui/consistent-ui";
import { useAuth } from "@/contexts/AuthContext";
import { useUserRole } from "@/hooks/useUserRole";

const Settings = () => {
  const [searchParams] = useSearchParams();
  const { isSeller } = useUserRole();
  const tabParam = searchParams.get("tab");
  const [activeTab, setActiveTab] = useState(tabParam || (isSeller ? "credits" : "security"));
  
  useEffect(() => {
    if (tabParam) {
      setActiveTab(tabParam);
    }
  }, [tabParam]);
  
  useEffect(() => {
    document.title = `Settings - Source my Truck`;
  }, []);
  
  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
  };

  return (
    <DashboardLayout title="Settings">
      <div className="max-w-7xl mx-auto">
        <ProfileProvider>
          <InventoryProvider>            
            <Tabs defaultValue={activeTab} className="w-full" onValueChange={handleTabChange}>
              <SettingsTabsHeader activeTab={activeTab} handleTabChange={handleTabChange} />
              
              {isSeller && (
                <TabsContent value="credits" className="mt-6 animate-fade-in">
                  <CreditSettings />
                </TabsContent>
              )}

              {isSeller && (
                <TabsContent value="invoices" className="mt-6 animate-fade-in">
                  <InvoicesSettings />
                </TabsContent>
              )}

              <TabsContent value="security" className="mt-6 animate-fade-in">
                <SecuritySettings />
              </TabsContent>
            </Tabs>
          </InventoryProvider>
        </ProfileProvider>
      </div>
    </DashboardLayout>
  );
};

const CreditSettings = () => {
  const { credits } = useInventory();
  
  return (
    <div className="space-y-6">
      <CreditBalance credits={credits} />
    </div>
  );
};

const InvoicesSettings = () => {
  return (
    <div className="space-y-6">
      <StyledCard>
        <CardHeader className="bg-gradient-to-r from-brand-blue to-brand-darkBlue text-white">
          <CardTitle className="flex items-center gap-2">
            <KeyRound className="h-5 w-5" />
            Payment History
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <InvoicesList />
        </CardContent>
      </StyledCard>
    </div>
  );
};

const SecuritySettings = () => {
  const { signOut } = useAuth();
  
  const handleLogout = async () => {
    try {
      await signOut();
    } catch (error) {
      console.error("Error signing out:", error);
    }
  };

  return (
    <div className="space-y-6">
      <StyledCard>
        <CardHeader className="bg-gradient-to-r from-brand-blue to-brand-darkBlue text-white">
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Security Settings
          </CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          <div className="space-y-6">
            <div className="bg-blue-50 border-l-4 border-blue-500 p-4 rounded">
              <div className="flex">
                <div className="flex-shrink-0">
                  <BadgeInfo className="h-5 w-5 text-blue-500" />
                </div>
                <div className="ml-3">
                  <p className="text-sm text-blue-700">
                    Your account is protected with industry-standard security measures.
                  </p>
                </div>
              </div>
            </div>
            
            <div>
              <h3 className="text-lg font-medium mb-3 flex items-center">
                <Shield className="h-4 w-4 mr-2 text-brand-blue" /> 
                Password Management
              </h3>
              <div className="bg-white p-4 rounded-lg border shadow-sm">
                <p className="text-gray-600">
                  To reset your password, please log out and use the "Forgot password?" option on the login page.
                  This helps ensure the security of your account.
                </p>
                <button 
                  className="mt-4 bg-brand-blue hover:bg-brand-darkBlue text-white px-4 py-2 rounded-md transition-colors"
                  onClick={handleLogout}
                >
                  Log Out
                </button>
              </div>
            </div>
            
            <div className="pt-4 border-t border-gray-200">
              <h3 className="text-lg font-medium mb-3 flex items-center">
                <KeyRound className="h-4 w-4 mr-2 text-brand-blue" />
                Account Protection
              </h3>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="bg-white p-4 rounded-lg border shadow-sm">
                  <h4 className="font-medium mb-2">Strong Password</h4>
                  <p className="text-gray-600 text-sm">
                    Use a unique password with at least 12 characters including numbers, symbols, and mixed case.
                  </p>
                </div>
                <div className="bg-white p-4 rounded-lg border shadow-sm">
                  <h4 className="font-medium mb-2">Regular Updates</h4>
                  <p className="text-gray-600 text-sm">
                    Change your password periodically and avoid reusing passwords across different sites.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </StyledCard>
    </div>
  );
};

export default Settings;
