import { useState, useEffect } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { LogIn, Mail, CheckCircle, AlertCircle } from "lucide-react";
import TruckAnimation from "@/components/TruckAnimation";
import { useAuth } from '@/contexts/AuthContext';

const LoginPage = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [formErrors, setFormErrors] = useState<{email?: string; password?: string; general?: string}>({});
  const [showForgotPassword, setShowForgotPassword] = useState(false);
  const [resetEmailSent, setResetEmailSent] = useState(false);
  const [emailNotVerified, setEmailNotVerified] = useState(false);
  const [resendEmailSent, setResendEmailSent] = useState(false);
  
  const navigate = useNavigate();
  const location = useLocation();
  const { signIn, sendPasswordReset, resendEmailConfirmation, isActionLoading, isAuthenticated } = useAuth();
  
  // Redirect if already authenticated
  useEffect(() => {
    if (isAuthenticated) {
      navigate('/dashboard');
    }
  }, [isAuthenticated, navigate]);

  // Check URL params
  useEffect(() => {
    const searchParams = new URLSearchParams(location.search);
    if (searchParams.get('forgotPassword') === 'true') {
      setShowForgotPassword(true);
    }
  }, [location]);

  const validateForm = () => {
    const errors: {email?: string; password?: string} = {};
    let isValid = true;

    if (!email) {
      errors.email = "Email is required";
      isValid = false;
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      errors.email = "Email is invalid";
      isValid = false;
    }

    if (!showForgotPassword && !password) {
      errors.password = "Password is required";
      isValid = false;
    }

    setFormErrors(errors);
    return isValid;
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;
    
    try {
      setFormErrors({});
      setEmailNotVerified(false);
      
      await signIn(email, password);
    } catch (error: any) {
      if (error.message?.includes('verify your email')) {
        setEmailNotVerified(true);
      } else {
        setFormErrors({ general: error.message });
      }
    }
  };

  const handlePasswordReset = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;
    
    try {
      setFormErrors({});
      await sendPasswordReset(email);
      setResetEmailSent(true);
    } catch (error: any) {
      setFormErrors({ general: error.message });
    }
  };

  const handleResendConfirmation = async () => {
    try {
      await resendEmailConfirmation(email);
      setResendEmailSent(true);
      setEmailNotVerified(false);
    } catch (error: any) {
      setFormErrors({ general: error.message });
    }
  };

  const toggleForgotPassword = () => {
    setShowForgotPassword(!showForgotPassword);
    setFormErrors({});
    setResetEmailSent(false);
    setEmailNotVerified(false);
    setResendEmailSent(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-gray-50 to-gray-100 px-4 py-12">
      <div className="w-full max-w-md space-y-8">
        <div className="text-center relative">
          <Link to="/" className="inline-flex items-center justify-center">
            <span className="text-3xl font-bold text-brand-blue">Source my <span className="text-brand-orange">Truck</span></span>
          </Link>
          
          <TruckAnimation size={80} className="mx-auto" />
          
          <h2 className="mt-4 text-3xl font-extrabold text-gray-900">
            {showForgotPassword ? "Reset your password" : "Sign in to your account"}
          </h2>
          <p className="mt-2 text-gray-600">
            {showForgotPassword ? (
              <>
                Remember your password?{" "}
                <button 
                  onClick={toggleForgotPassword}
                  className="font-medium text-brand-blue hover:text-brand-blue/80"
                >
                  Back to login
                </button>
              </>
            ) : (
              <>
                Or{" "}
                <Link to="/register" className="font-medium text-brand-blue hover:text-brand-blue/80">
                  create an account
                </Link>
              </>
            )}
          </p>
        </div>
        
        <Card className="shadow-lg border-0 bg-white/70 backdrop-blur-sm animate-fade-in">
          <CardHeader>
            <CardTitle className="text-xl">
              {showForgotPassword ? "Reset Password" : "Account Login"}
            </CardTitle>
            <CardDescription>
              {showForgotPassword 
                ? "Enter your email to receive a password reset link" 
                : "Enter your credentials to continue"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {emailNotVerified && !resendEmailSent && (
              <div className="mb-6 p-4 rounded-md bg-amber-50 border border-amber-200 text-amber-700 flex items-start space-y-2">
                <AlertCircle className="h-5 w-5 mr-2 mt-0.5 flex-shrink-0" />
                <div className="space-y-2">
                  <p className="font-medium">Email verification required</p>
                  <p className="text-sm">Please check your inbox for a verification email.</p>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={handleResendConfirmation}
                    disabled={isActionLoading}
                    className="mt-2 border-amber-300 hover:bg-amber-100 text-amber-700"
                  >
                    <Mail className="h-4 w-4 mr-2" />
                    Resend verification email
                  </Button>
                </div>
              </div>
            )}

            {resendEmailSent && (
              <div className="mb-6 p-4 rounded-md bg-green-50 border border-green-200 text-green-700 flex items-start">
                <CheckCircle className="h-5 w-5 mr-2 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="font-medium">Verification email sent</p>
                  <p className="text-sm">Please check your inbox and click the verification link.</p>
                </div>
              </div>
            )}

            {resetEmailSent ? (
              <div className="p-3 bg-green-50 border border-green-200 text-green-700 rounded-md text-sm">
                Password reset link has been sent to your email. Please check your inbox.
              </div>
            ) : (
              <form onSubmit={showForgotPassword ? handlePasswordReset : handleLogin} className="space-y-4">
                {formErrors.general && (
                  <div className={`p-3 border rounded-md text-sm ${
                    formErrors.general.includes('confirmed') 
                      ? 'bg-green-50 border-green-200 text-green-700'
                      : 'bg-red-50 border-red-200 text-red-700'
                  }`}>
                    {formErrors.general}
                  </div>
                )}
                
                <div className="space-y-2">
                  <Label htmlFor="email">Email address</Label>
                  <Input 
                    id="email"
                    type="email" 
                    placeholder="you@company.com" 
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    disabled={isActionLoading}
                    className={`transition-all duration-300 focus:ring-2 focus:ring-brand-blue ${formErrors.email ? 'border-red-500' : ''}`}
                  />
                  {formErrors.email && (
                    <p className="text-sm text-red-500">{formErrors.email}</p>
                  )}
                </div>
                
                {!showForgotPassword && (
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="password">Password</Label>
                      <button
                        type="button"
                        onClick={toggleForgotPassword}
                        className="text-sm font-medium text-brand-blue hover:text-brand-blue/80"
                      >
                        Forgot password?
                      </button>
                    </div>
                    <Input 
                      id="password"
                      type="password" 
                      placeholder="••••••••" 
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                      disabled={isActionLoading}
                      className={`transition-all duration-300 focus:ring-2 focus:ring-brand-blue ${formErrors.password ? 'border-red-500' : ''}`}
                    />
                    {formErrors.password && (
                      <p className="text-sm text-red-500">{formErrors.password}</p>
                    )}
                  </div>
                )}
                
                <Button
                  type="submit"
                  className="w-full bg-brand-blue hover:bg-brand-blue/90 transition-all duration-300 mt-4"
                  disabled={isActionLoading}
                >
                  {isActionLoading ? (
                    <span className="flex items-center justify-center">
                      <div className="animate-spin -ml-1 mr-2 h-4 w-4 border-2 border-white border-t-transparent rounded-full"></div>
                      {showForgotPassword ? "Sending reset link..." : "Signing in..."}
                    </span>
                  ) : (
                    <span className="flex items-center justify-center">
                      {showForgotPassword ? (
                        "Send Reset Link"
                      ) : (
                        <>
                          <LogIn className="mr-2 h-4 w-4" />
                          Sign in
                        </>
                      )}
                    </span>
                  )}
                </Button>
              </form>
            )}
          </CardContent>
          <CardFooter className="flex flex-col justify-center text-sm text-gray-500 space-y-2 py-4">
            <div className="text-center">By signing in, you agree to our</div>
            <div className="flex items-center justify-center space-x-2">
              <Link to="/terms" className="text-brand-blue hover:underline font-medium transition-colors">
                Terms of Service
              </Link>
              <span className="text-gray-400">and</span>
              <Link to="/privacy" className="text-brand-blue hover:underline font-medium transition-colors">
                Privacy Policy
              </Link>
            </div>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
};

export default LoginPage;