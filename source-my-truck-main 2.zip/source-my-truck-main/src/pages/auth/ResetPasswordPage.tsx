import { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { KeyRound, CheckCircle } from "lucide-react";
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';

const ResetPasswordPage = () => {
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [formErrors, setFormErrors] = useState<{password?: string; confirmPassword?: string; general?: string}>({});
  const [isValidSession, setIsValidSession] = useState<boolean | null>(null);
  const [resetComplete, setResetComplete] = useState(false);
  const [userEmail, setUserEmail] = useState<string | null>(null);
  
  const navigate = useNavigate();
  const { updatePassword, sendPasswordReset, isActionLoading } = useAuth();

  useEffect(() => {
    console.log("ResetPasswordPage: Component mounted");
    console.log("ResetPasswordPage: Current URL:", window.location.href);
    console.log("ResetPasswordPage: Hash:", window.location.hash);
    console.log("ResetPasswordPage: Search:", window.location.search);
    
    const checkRecoverySession = async () => {
      try {
        console.log("ResetPasswordPage: Starting recovery session check");
        
        // First check if we have recovery tokens in the URL
        const url = new URL(window.location.href);
        const hasRecoveryToken = url.hash.includes('type=recovery') || url.search.includes('type=recovery');
        
        console.log('ResetPasswordPage: Initial token check:', { 
          hasRecoveryToken, 
          hash: url.hash, 
          search: url.search,
          fullUrl: url.href
        });

        if (hasRecoveryToken) {
          // Extract tokens from URL
          let params = new URLSearchParams();
          if (url.hash) {
            const hashParams = new URLSearchParams(url.hash.substring(1));
            for (const [key, value] of hashParams.entries()) {
              params.append(key, value);
            }
          }
          if (url.search) {
            const searchParams = new URLSearchParams(url.search);
            for (const [key, value] of searchParams.entries()) {
              if (!params.has(key)) {
                params.append(key, value);
              }
            }
          }

          const access_token = params.get('access_token');
          const refresh_token = params.get('refresh_token');
          
          console.log('ResetPasswordPage: Setting recovery session with tokens');
          
          if (access_token) {
            // Set the session with the recovery tokens
            const { data: { session }, error } = await supabase.auth.setSession({
              access_token,
              refresh_token: refresh_token || ''
            });
            
            if (error) {
              console.error('ResetPasswordPage: Error setting recovery session:', error);
              setIsValidSession(false);
              return;
            }
            
            if (session?.user) {
              console.log('ResetPasswordPage: Recovery session established for:', session.user.email);
              setIsValidSession(true);
              setUserEmail(session.user.email);
              return;
            }
          }
        }

        // Fallback to checking existing session
        const { data: { session }, error } = await supabase.auth.getSession();
        
        console.log('Session check result:', { 
          hasSession: !!session, 
          error: error?.message || null, 
          userEmail: session?.user?.email || null 
        });
        
        if (error || !session) {
          console.log('No valid recovery session found', error);
          setIsValidSession(false);
          return;
        }

        // Check if this is a recovery session by looking at the URL or session metadata
        const urlCheck = new URL(window.location.href);
        const hasRecoveryTokenCheck = urlCheck.hash.includes('type=recovery') || urlCheck.search.includes('type=recovery');
        
        console.log('Recovery token check:', { 
          hasRecoveryToken: hasRecoveryTokenCheck, 
          hash: urlCheck.hash, 
          search: urlCheck.search,
          fullUrl: urlCheck.href
        });
        
        if (!hasRecoveryTokenCheck) {
          console.log('Not a recovery session');
          setIsValidSession(false);
          return;
        }

        console.log('Valid recovery session found for:', session.user.email);
        setIsValidSession(true);
        setUserEmail(session.user.email || null);
        
      } catch (error) {
        console.error('Error checking recovery session:', error);
        setIsValidSession(false);
      }
    };

    checkRecoverySession();
  }, []);

  const validateForm = () => {
    const errors: typeof formErrors = {};
    let isValid = true;

    if (!password) {
      errors.password = "Password is required";
      isValid = false;
    } else if (password.length < 6) {
      errors.password = "Password must be at least 6 characters";
      isValid = false;
    }

    if (!confirmPassword) {
      errors.confirmPassword = "Please confirm your password";
      isValid = false;
    } else if (password !== confirmPassword) {
      errors.confirmPassword = "Passwords do not match";
      isValid = false;
    }

    setFormErrors(errors);
    return isValid;
  };

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;
    
    try {
      setFormErrors({});
      
      await updatePassword(password);
      setResetComplete(true);
      
      // Clear URL parameters
      window.history.replaceState(null, '', window.location.pathname);
      
      // Redirect to login after a delay
      setTimeout(() => {
        navigate('/login');
      }, 3000);
      
    } catch (error: any) {
      console.error('Password reset error:', error);
      setFormErrors({ general: error.message });
    }
  };

  const handleRequestNewLink = async () => {
    if (userEmail) {
      try {
        await sendPasswordReset(userEmail);
      } catch (error) {
        console.error('Error requesting new reset link:', error);
      }
    } else {
      navigate('/login?forgotPassword=true');
    }
  };

  // Loading state
  if (isValidSession === null) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-gray-50 to-gray-100">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-blue mx-auto"></div>
          <p className="mt-2 text-gray-600">Verifying reset link...</p>
        </div>
      </div>
    );
  }

  // Invalid session
  if (!isValidSession) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-gray-50 to-gray-100 px-4 py-12">
        <div className="w-full max-w-md">
          <Card className="shadow-lg border-0">
            <CardHeader className="text-center space-y-2">
              <CardTitle className="text-2xl font-bold text-destructive">
                Reset Link Expired
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-center">
              <p className="text-gray-600">
                The password reset link has expired or is invalid. Please request a new one.
              </p>
              <div className="space-y-2">
                <Button
                  onClick={handleRequestNewLink}
                  disabled={isActionLoading}
                  className="w-full bg-brand-blue hover:bg-brand-blue/90"
                >
                  {userEmail ? 'Send New Reset Link' : 'Go to Reset Password'}
                </Button>
                <Button
                  variant="outline"
                  onClick={() => navigate('/login')}
                  className="w-full"
                >
                  Back to Login
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Success state
  if (resetComplete) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-gray-50 to-gray-100 px-4 py-12">
        <div className="w-full max-w-md text-center space-y-6">
          <div className="mx-auto w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
            <CheckCircle className="w-8 h-8 text-green-600" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900">Password Reset Successful</h2>
          <p className="text-gray-600">
            Your password has been updated successfully. You will be redirected to the login page in a few seconds.
          </p>
          <Button 
            onClick={() => navigate('/login')}
            className="bg-brand-blue hover:bg-brand-blue/90"
          >
            Go to Login Now
          </Button>
        </div>
      </div>
    );
  }

  // Reset form
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-gray-50 to-gray-100 px-4 py-12">
      <div className="w-full max-w-md">
        <Card className="shadow-lg border-0">
          <CardHeader className="text-center space-y-2">
            <CardTitle className="text-2xl font-bold text-gray-900">
              Create New Password
            </CardTitle>
            {userEmail && (
              <p className="text-sm text-gray-600">
                Resetting password for: <span className="font-semibold">{userEmail}</span>
              </p>
            )}
          </CardHeader>
          <CardContent>
            <form onSubmit={handleResetPassword} className="space-y-4">
              {formErrors.general && (
                <div className="p-3 bg-red-50 border border-red-200 text-red-700 rounded-md text-sm">
                  {formErrors.general}
                </div>
              )}
              
              <div className="space-y-2">
                <Label htmlFor="password">New Password</Label>
                <Input 
                  id="password"
                  type="password" 
                  placeholder="••••••••" 
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  disabled={isActionLoading}
                  className={`transition-all duration-300 focus:ring-2 focus:ring-brand-blue ${formErrors.password ? 'border-red-500' : ''}`}
                />
                {formErrors.password && (
                  <p className="text-sm text-red-500">{formErrors.password}</p>
                )}
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="confirmPassword">Confirm New Password</Label>
                <Input 
                  id="confirmPassword"
                  type="password" 
                  placeholder="••••••••" 
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  required
                  disabled={isActionLoading}
                  className={`transition-all duration-300 focus:ring-2 focus:ring-brand-blue ${formErrors.confirmPassword ? 'border-red-500' : ''}`}
                />
                {formErrors.confirmPassword && (
                  <p className="text-sm text-red-500">{formErrors.confirmPassword}</p>
                )}
              </div>
              
              <Button
                type="submit"
                className="w-full bg-brand-blue hover:bg-brand-blue/90 transition-all duration-300 mt-4"
                disabled={isActionLoading}
              >
                {isActionLoading ? (
                  <span className="flex items-center justify-center">
                    <div className="animate-spin -ml-1 mr-2 h-4 w-4 border-2 border-white border-t-transparent rounded-full"></div>
                    Updating Password...
                  </span>
                ) : (
                  <span className="flex items-center justify-center">
                    <KeyRound className="mr-2 h-4 w-4" />
                    Update Password
                  </span>
                )}
              </Button>
            </form>
            
            <div className="mt-4 text-center">
              <Link 
                to="/login" 
                className="text-sm text-brand-blue hover:text-brand-blue/80"
              >
                Back to Login
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default ResetPasswordPage;