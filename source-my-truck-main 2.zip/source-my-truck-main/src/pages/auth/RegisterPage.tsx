import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { UserPlus, Mail } from "lucide-react";
import TruckAnimation from "@/components/TruckAnimation";
import { useAuth } from '@/contexts/AuthContext';

const RegisterPage = () => {
  const [formData, setFormData] = useState({
    userType: "seller" as "buyer" | "seller",
    companyName: "",
    email: "",
    password: "",
    confirmPassword: "",
  });

  const [formErrors, setFormErrors] = useState<{
    companyName?: string;
    email?: string;
    password?: string;
    confirmPassword?: string;
    general?: string;
  }>({});
  
  const [registrationComplete, setRegistrationComplete] = useState(false);
  const [requiresEmailConfirmation, setRequiresEmailConfirmation] = useState(false);
  
  const navigate = useNavigate();
  const { signUp, isActionLoading, isAuthenticated } = useAuth();
  
  // Redirect if already authenticated
  useEffect(() => {
    if (isAuthenticated) {
      navigate('/dashboard');
    }
  }, [isAuthenticated, navigate]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));

    // Clear errors when user starts typing
    if (formErrors[name as keyof typeof formErrors]) {
      setFormErrors((prev) => ({ ...prev, [name]: undefined }));
    }
  };

  const validateForm = () => {
    const errors: typeof formErrors = {};
    let isValid = true;

    if (formData.userType === "seller" && !formData.companyName.trim()) {
      errors.companyName = "Company name is required for seller accounts";
      isValid = false;
    }

    if (!formData.email) {
      errors.email = "Email is required";
      isValid = false;
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      errors.email = "Please enter a valid email address";
      isValid = false;
    }

    if (!formData.password) {
      errors.password = "Password is required";
      isValid = false;
    } else if (formData.password.length < 6) {
      errors.password = "Password must be at least 6 characters long";
      isValid = false;
    }

    if (!formData.confirmPassword) {
      errors.confirmPassword = "Please confirm your password";
      isValid = false;
    } else if (formData.password !== formData.confirmPassword) {
      errors.confirmPassword = "Passwords do not match";
      isValid = false;
    }

    setFormErrors(errors);
    return isValid;
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) return;

    try {
      setFormErrors({});
      
      const result = await signUp(
        formData.email,
        formData.password,
        formData.userType === "seller" ? formData.companyName : "N/A",
        formData.userType
      );
      
      setRegistrationComplete(true);
      setRequiresEmailConfirmation(result.requiresEmailConfirmation);
      
    } catch (error: any) {
      console.error('Registration failed:', error);
      setFormErrors({ general: error.message });
    }
  };

  if (registrationComplete) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-gray-50 to-gray-100 px-4 py-12">
        <div className="w-full max-w-md space-y-8 text-center">
          <Link to="/" className="inline-flex items-center justify-center">
            <span className="text-3xl font-bold text-brand-blue">
              Source my <span className="text-brand-orange">Truck</span>
            </span>
          </Link>

          <Card className="shadow-lg border-0 bg-white/70 backdrop-blur-sm animate-fade-in overflow-hidden">
            <CardHeader className="bg-green-50 pb-6">
              <CardTitle className="text-xl text-green-700">Registration Successful!</CardTitle>
              <CardDescription className="text-green-600">
                {requiresEmailConfirmation ? "Please verify your email" : "Welcome to SourceMyTruck!"}
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-8 pb-6 text-center">
              {requiresEmailConfirmation ? (
                <>
                  <Mail size={48} className="text-brand-blue mx-auto mb-4" />
                  <TruckAnimation size={60} className="mx-auto my-4" />
                  <h3 className="text-lg font-medium text-gray-800 mt-4">Check your email</h3>
                  <p className="text-gray-600 text-center max-w-xs mt-2">
                    We've sent a verification link to <strong>{formData.email}</strong>.
                    Please click the link to verify your account.
                  </p>
                </>
              ) : (
                <>
                  <TruckAnimation size={80} className="mx-auto my-4" />
                  <h3 className="text-lg font-medium text-gray-800 mt-4">You're all set!</h3>
                  <p className="text-gray-600 text-center max-w-xs mt-2">
                    Your account has been created and you're now signed in.
                  </p>
                </>
              )}
            </CardContent>
            <CardFooter className="flex flex-col gap-3 pb-6">
              {requiresEmailConfirmation ? (
                <Button
                  variant="outline"
                  onClick={() => navigate("/login")}
                  className="w-full"
                >
                  Go to Login
                </Button>
              ) : (
                <Button
                  onClick={() => navigate("/dashboard")}
                  className="w-full bg-brand-blue hover:bg-brand-blue/90"
                >
                  Go to Dashboard
                </Button>
              )}
            </CardFooter>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-gray-50 to-gray-100 px-4 py-12">
      <div className="w-full max-w-md space-y-8">
        <div className="text-center">
          <Link to="/" className="inline-flex items-center justify-center">
            <span className="text-3xl font-bold text-brand-blue">
              Source my <span className="text-brand-orange">Truck</span>
            </span>
          </Link>
          <TruckAnimation size={80} className="mx-auto" />
          <h2 className="mt-4 text-3xl font-extrabold text-gray-900">Create your account</h2>
          <p className="mt-2 text-gray-600">
            Already have an account?{" "}
            <Link to="/login" className="font-medium text-brand-blue hover:text-brand-blue/80">
              Sign in
            </Link>
          </p>
        </div>

        <Card className="shadow-lg border-0 bg-white/70 backdrop-blur-sm animate-fade-in">
          <CardHeader>
            <CardTitle className="text-xl">Account Registration</CardTitle>
            <CardDescription>Choose your account type and create your profile</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleRegister} className="space-y-4">
              {formErrors.general && (
                <div className="p-3 bg-red-50 border border-red-200 text-red-700 rounded-md text-sm">
                  {formErrors.general}
                </div>
              )}

              {/* Account Type Selection */}
              <div className="space-y-3">
                <Label>I want to:</Label>
                <div className="grid grid-cols-1 gap-3">
                  {["buyer", "seller"].map((type) => (
                    <label
                      key={type}
                      className={`relative flex cursor-pointer rounded-lg border p-4 transition-all ${
                        formData.userType === type
                          ? "border-brand-blue bg-brand-blue/5 ring-2 ring-brand-blue"
                          : "border-gray-200 hover:border-gray-300"
                      }`}
                    >
                      <input
                        type="radio"
                        name="userType"
                        value={type}
                        checked={formData.userType === type}
                        onChange={handleChange}
                        className="sr-only"
                        disabled={isActionLoading}
                      />
                      <div className="flex w-full items-center justify-between">
                        <div className="text-sm">
                          <div className="font-medium text-gray-900">
                            {type === "buyer" ? "Browse & Buy Vehicles" : "Sell Vehicles (Business)"}
                          </div>
                          <div className="text-gray-500">
                            {type === "buyer"
                              ? "Search, save, and contact sellers"
                              : "List and manage vehicle inventory"}
                          </div>
                        </div>
                      </div>
                    </label>
                  ))}
                </div>
              </div>

              {formData.userType === "seller" && (
                <div className="space-y-2">
                  <Label htmlFor="companyName">Company Name</Label>
                  <Input
                    id="companyName"
                    name="companyName"
                    placeholder="Your company name"
                    value={formData.companyName}
                    onChange={handleChange}
                    required
                    disabled={isActionLoading}
                    className={`transition-all duration-300 focus:ring-2 focus:ring-brand-blue ${formErrors.companyName ? 'border-red-500' : ''}`}
                  />
                  {formErrors.companyName && (
                    <p className="text-sm text-red-500">{formErrors.companyName}</p>
                  )}
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="email">Email Address</Label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  placeholder="you@company.com"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  disabled={isActionLoading}
                  className={`transition-all duration-300 focus:ring-2 focus:ring-brand-blue ${formErrors.email ? 'border-red-500' : ''}`}
                />
                {formErrors.email && (
                  <p className="text-sm text-red-500">{formErrors.email}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  name="password"
                  type="password"
                  placeholder="••••••••"
                  value={formData.password}
                  onChange={handleChange}
                  required
                  disabled={isActionLoading}
                  className={`transition-all duration-300 focus:ring-2 focus:ring-brand-blue ${formErrors.password ? 'border-red-500' : ''}`}
                />
                {formErrors.password && (
                  <p className="text-sm text-red-500">{formErrors.password}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="confirmPassword">Confirm Password</Label>
                <Input
                  id="confirmPassword"
                  name="confirmPassword"
                  type="password"
                  placeholder="••••••••"
                  value={formData.confirmPassword}
                  onChange={handleChange}
                  required
                  disabled={isActionLoading}
                  className={`transition-all duration-300 focus:ring-2 focus:ring-brand-blue ${formErrors.confirmPassword ? 'border-red-500' : ''}`}
                />
                {formErrors.confirmPassword && (
                  <p className="text-sm text-red-500">{formErrors.confirmPassword}</p>
                )}
              </div>

              <Button
                type="submit"
                className="w-full bg-brand-blue hover:bg-brand-blue/90 transition-all duration-300 mt-2"
                disabled={isActionLoading}
              >
                {isActionLoading ? (
                  <span className="flex items-center justify-center">
                    <div className="animate-spin -ml-1 mr-2 h-4 w-4 border-2 border-white border-t-transparent rounded-full"></div>
                    Creating account...
                  </span>
                ) : (
                  <span className="flex items-center justify-center">
                    <UserPlus className="mr-2 h-4 w-4" />
                    Create Account
                  </span>
                )}
              </Button>
            </form>
          </CardContent>
          <CardFooter className="flex justify-center text-sm text-gray-500">
            By creating an account, you agree to our Terms of Service and Privacy Policy
          </CardFooter>
        </Card>
      </div>
    </div>
  );
};

export default RegisterPage;