import React, { useState } from "react";
import { useParams, Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, Calendar, Clock, ImageOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import PageLayout from "@/components/layouts/PageLayout";
import { fetchBlogArticleById } from "@/services/blog/blogService";
import { getValidImageUrl } from "@/utils/imageUtils";

const CATEGORY_FALLBACK_IMAGES: Record<string, string> = {
  "technology": "https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=800&h=600",
  "industry": "https://images.unsplash.com/photo-1601584115197-04ecc0da31d7?auto=format&fit=crop&w=800&h=600",
  "trucking": "https://images.unsplash.com/photo-1601584115197-04ecc0da31d7?auto=format&fit=crop&w=800&h=600",
  "logistics": "https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d?auto=format&fit=crop&w=800&h=600",
  "innovation": "https://images.unsplash.com/photo-1488590528505-98d2a5aee158?auto=format&fit=crop&w=800&h=600",
  "sustainability": "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&w=800&h=600",
  "maintenance": "https://images.unsplash.com/photo-1487058792275-0ad4aaf24ca7?auto=format&fit=crop&w=800&h=600",
  "safety": "https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=800&h=600",
  "regulations": "https://images.unsplash.com/photo-1461749280684-dccba630e2f6?auto=format&fit=crop&w=800&h=600",
  "news": "https://images.unsplash.com/photo-1649972904349-6e44c42644a7?auto=format&fit=crop&w=800&h=600"
};

const DEFAULT_FALLBACK = "https://images.unsplash.com/photo-1584824486509-112e4181ff6b?auto=format&fit=crop&w=800&h=600&q=80";

const getRelevantImage = (article: any): string => {
  if (getValidImageUrl(article.image)) {
    return article.image;
  }
  
  const lowerCategory = article.category.toLowerCase();
  if (CATEGORY_FALLBACK_IMAGES[lowerCategory]) {
    return CATEGORY_FALLBACK_IMAGES[lowerCategory];
  }
  
  const title = article.title.toLowerCase();
  
  if (title.includes('tech') || title.includes('digital') || title.includes('software') || title.includes('computer')) {
    return CATEGORY_FALLBACK_IMAGES.technology;
  }
  
  if (title.includes('trucking') || title.includes('vehicle') || title.includes('transport') || title.includes('truck')) {
    return CATEGORY_FALLBACK_IMAGES.trucking;
  }
  
  if (title.includes('green') || title.includes('sustain') || title.includes('environment') || title.includes('eco')) {
    return CATEGORY_FALLBACK_IMAGES.sustainability;
  }
  
  if (title.includes('regulations') || title.includes('compliance') || title.includes('law') || title.includes('policy')) {
    return CATEGORY_FALLBACK_IMAGES.regulations;
  }
  
  if (title.includes('maintenance') || title.includes('repair') || title.includes('service')) {
    return CATEGORY_FALLBACK_IMAGES.maintenance;
  }
  
  return DEFAULT_FALLBACK;
};

const BlogDetail = () => {
  const { id } = useParams<{ id: string }>();
  const [imageError, setImageError] = useState(false);
  
  const { data: article, isLoading, error } = useQuery({
    queryKey: ["blogArticle", id],
    queryFn: () => fetchBlogArticleById(id || ""),
    enabled: !!id,
  });

  const handleImageError = () => {
    setImageError(true);
  };

  if (error) {
    return (
      <PageLayout title="Article Not Found" subtitle="We couldn't find the article you were looking for">
        <div className="flex flex-col items-center justify-center py-12">
          <h2 className="text-2xl font-bold text-gray-800 mb-4">Sorry, this article doesn't exist</h2>
          <p className="text-gray-600 mb-8">The article you're looking for may have been removed or is temporarily unavailable.</p>
          <Link to="/blog">
            <Button>
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to All Articles
            </Button>
          </Link>
        </div>
      </PageLayout>
    );
  }

  if (isLoading) {
    return (
      <PageLayout title="Loading Article" subtitle="">
        <div className="mb-6">
          <Link to="/blog" className="text-brand-blue hover:text-brand-orange flex items-center mb-8">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Articles
          </Link>
          <Skeleton className="h-12 w-2/3 mb-4" />
          <div className="flex items-center gap-4 mb-8">
            <Skeleton className="h-6 w-24" />
            <Skeleton className="h-6 w-24" />
          </div>
          <Skeleton className="h-64 w-full mb-8" />
          <div className="space-y-4">
            <Skeleton className="h-6 w-full" />
            <Skeleton className="h-6 w-full" />
            <Skeleton className="h-6 w-5/6" />
            <Skeleton className="h-6 w-full" />
            <Skeleton className="h-6 w-4/6" />
          </div>
        </div>
      </PageLayout>
    );
  }

  const relevantImage = article ? getRelevantImage(article) : DEFAULT_FALLBACK;

  if (!article) {
    return (
      <PageLayout title="Article Not Found" subtitle="We couldn't find the article you were looking for">
        <div className="flex flex-col items-center justify-center py-12">
          <h2 className="text-2xl font-bold text-gray-800 mb-4">Sorry, this article doesn't exist</h2>
          <p className="text-gray-600 mb-8">The article you're looking for may have been removed or is temporarily unavailable.</p>
          <Link to="/blog">
            <Button>
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to All Articles
            </Button>
          </Link>
        </div>
      </PageLayout>
    );
  }

  return (
    <PageLayout title={article.title} subtitle={article.excerpt}>
      <div className="max-w-4xl mx-auto">
        <Link to="/blog" className="text-brand-blue hover:text-brand-orange flex items-center mb-8">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Articles
        </Link>

        <div className="mb-8">
          <div className="flex items-center gap-4 mb-6">
            <Badge variant="outline" className="bg-brand-blue/10 text-brand-blue border-brand-blue/30">
              {article.category}
            </Badge>
            <div className="flex items-center text-gray-500 text-sm">
              <Calendar className="h-4 w-4 mr-1" />
              {article.date}
            </div>
            <div className="flex items-center text-gray-500 text-sm">
              <Clock className="h-4 w-4 mr-1" />
              {article.readTime}
            </div>
          </div>

          <div className="rounded-lg overflow-hidden mb-8 h-96 bg-gray-100 relative">
            {imageError ? (
              <div className="w-full h-full flex items-center justify-center bg-gray-200">
                <ImageOff className="h-16 w-16 text-gray-400" />
              </div>
            ) : (
              <img
                src={relevantImage}
                alt={article.title}
                className="w-full h-full object-cover"
                onError={handleImageError}
              />
            )}
          </div>

          <div className="prose prose-lg max-w-none">
            <div dangerouslySetInnerHTML={{ __html: article.content.replace(/\n/g, '<br />') }} />
          </div>

          {article.tags && article.tags.length > 0 && (
            <div className="mt-12 pt-6 border-t border-gray-200">
              <h3 className="text-lg font-medium mb-4">Related Tags</h3>
              <div className="flex flex-wrap gap-2">
                {article.tags.map((tag, index) => (
                  <Badge key={index} variant="secondary" className="bg-gray-100">
                    {tag}
                  </Badge>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </PageLayout>
  );
};

export default BlogDetail;
