
import { Suspense, lazy, memo, useEffect } from "react";
import { ErrorBoundary } from "react-error-boundary";
import { AlertTriangle } from "lucide-react";
import NavBar from "@/components/NavBar";
import Footer from "@/components/Footer";
import SearchBoxWrapper from "@/components/SearchBoxWrapper";
import LocationAlert from "@/components/vehicle/LocationAlert";
import { useVehicleFilters } from "@/hooks/useVehicleFilters";
import PageLayout from "@/components/layouts/PageLayout";
import LoadingSpinner from "@/components/ui/loading-spinner";
import { OptimizedSkeleton } from "@/components/common/OptimizedSkeleton";
import SEO from "@/components/seo/SEO";
import SchemaData from "@/components/seo/SchemaData";
import { Button } from "@/components/ui/button";

// Lazy load the heavy component
const VehicleListingsContainer = lazy(() => 
  import("@/components/vehicle/VehicleListingsContainer")
);

const ErrorFallback = () => (
  <PageLayout>
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col items-center justify-center min-h-[400px] p-8 text-center bg-card border border-destructive/20 rounded-lg">
        <AlertTriangle className="h-16 w-16 text-destructive mb-4" />
        <h2 className="text-2xl font-semibold text-foreground mb-2">Something went wrong</h2>
        <p className="text-muted-foreground mb-6 max-w-md">
          We encountered an error while loading the vehicle listings. Please try refreshing the page.
        </p>
        <div className="flex flex-col sm:flex-row gap-3">
          <Button 
            onClick={() => window.location.reload()} 
            variant="default"
          >
            Refresh Page
          </Button>
          <Button 
            onClick={() => window.history.back()} 
            variant="outline"
          >
            Go Back
          </Button>
        </div>
      </div>
    </div>
  </PageLayout>
);

// Memoize the vehicle listings content for better performance
const VehicleListingsContent = memo(() => {
  // This component uses useVehicleFilters which contains React Query hooks
  try {
    const {
      yearRange,
      setYearRange,
      selectedMakes,
      selectedBodyTypes,
      sortBy,
      setSortBy,
      location,
      radius,
      searchCoordinates,
      isLocationSearching,
      locationError,
      filteredVehicles,
      availableMakes,
      availableBodyTypes,
      isLoading,
      handleMakeChange,
      handleBodyTypeChange,
      trustedSellersOnly,
      setTrustedSellersOnly,
      depotVerifiedOnly,
      setDepotVerifiedOnly,
    } = useVehicleFilters();

    if (isLoading || isLocationSearching) {
      return (
        <div className="flex flex-col min-h-screen">
          <NavBar />
          <div className="container mx-auto px-4 py-8 flex items-center justify-center">
            <div className="w-full space-y-6">
              <OptimizedSkeleton variant="card" count={3} />
            </div>
          </div>
          <Footer />
        </div>
      );
    }

    return (
      <div className="flex flex-col min-h-screen">
        <SEO 
          title="Browse Commercial Trucks"
          description="Find commercial trucks and vehicles from trusted sellers. Filter by make, body type, year, and location to find the perfect vehicle for your business."
          keywords="browse trucks, commercial vehicles for sale, used trucks, new trucks, truck listings"
        />
        <SchemaData type="website" data={{}} />
        
        <NavBar />
        
        <div className="container mx-auto px-4 py-8">
          <h1 className="text-3xl font-bold mb-6">Browse Trucks</h1>
          
          <div className="mb-8">
            <SearchBoxWrapper />
          </div>
          
          <LocationAlert 
            locationError={locationError}
            location={location}
            searchCoordinates={searchCoordinates}
            radius={radius}
            filteredVehicleCount={filteredVehicles.length}
          />
          
          <Suspense fallback={<OptimizedSkeleton variant="card" count={3} />}>
            <VehicleListingsContainer 
              yearRange={yearRange}
              setYearRange={setYearRange}
              selectedMakes={selectedMakes}
              handleMakeChange={handleMakeChange}
              selectedBodyTypes={selectedBodyTypes}
              handleBodyTypeChange={handleBodyTypeChange}
              availableMakes={availableMakes ? availableMakes as string[] : []}
              availableBodyTypes={availableBodyTypes ? availableBodyTypes as string[] : []}
              filteredVehicles={filteredVehicles}
              sortBy={sortBy}
              setSortBy={setSortBy}
              isLoading={isLoading}
              showDistance={!!location && !!searchCoordinates}
              trustedSellersOnly={trustedSellersOnly}
              setTrustedSellersOnly={setTrustedSellersOnly}
              depotVerifiedOnly={depotVerifiedOnly}
              setDepotVerifiedOnly={setDepotVerifiedOnly}
            />
          </Suspense>
        </div>
        
        <div className="mt-auto">
          <Footer />
        </div>
      </div>
    );
  } catch (error) {
    console.error("Error in VehicleListingsContent:", error);
    return <ErrorFallback />;
  }
});

VehicleListingsContent.displayName = 'VehicleListingsContent';

const VehicleListings = () => {
  return (
    <ErrorBoundary FallbackComponent={ErrorFallback}>
      <VehicleListingsContent />
    </ErrorBoundary>
  );
};

export default VehicleListings;
