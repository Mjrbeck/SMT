import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { Heart, Trash2, UserPlus, LogIn } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Separator } from '@/components/ui/separator';
import NavBar from '@/components/NavBar';
import Footer from '@/components/Footer';
import VehicleCard from '@/components/VehicleCard';
import { useWatchlist } from '@/contexts/WatchlistContext';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { convertToVehicleData } from '@/utils/vehicleUtils';
import { VehicleWithImages } from '@/services/types';
import { OptimizedSkeleton } from '@/components/common/OptimizedSkeleton';
import SEO from '@/components/seo/SEO';

const Watchlist = () => {
  const { watchedVehicles, watchlistCount, clearWatchlist } = useWatchlist();
  const { isAuthenticated } = useAuth();
  
  // Fetch vehicle details for watched vehicles
  const { data: vehicles, isLoading, error } = useQuery({
    queryKey: ['watchlist-vehicles', watchedVehicles],
    queryFn: async () => {
      if (watchedVehicles.length === 0) return [];
      
      const { data, error } = await supabase
        .from('vehicles')
        .select(`
          *,
          vehicle_images(*)
        `)
        .in('id', watchedVehicles)
        .eq('status', 'active');
      
      if (error) throw error;
      
      return data?.map((vehicle: VehicleWithImages) => convertToVehicleData(vehicle)) || [];
    },
    enabled: watchedVehicles.length > 0,
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  if (watchlistCount === 0) {
    return (
      <div className="flex flex-col min-h-screen">
        <SEO 
          title="My Watchlist - Source My Truck"
          description="View your saved commercial vehicles and create an account to sync across devices."
        />
        <NavBar />
        
        <div className="container mx-auto px-4 py-12 flex-1">
          <div className="max-w-2xl mx-auto text-center">
            <div className="mb-8">
              <Heart className="h-16 w-16 mx-auto text-gray-300 mb-4" />
              <h1 className="text-3xl font-bold text-gray-900 mb-2">Your Watchlist is Empty</h1>
              <p className="text-gray-600 mb-6">
                Start browsing vehicles and click the heart icon to save them to your watchlist.
              </p>
            </div>
            
            <div className="space-y-4">
              <Link to="/listings">
                <Button size="lg" className="w-full sm:w-auto">
                  Browse Vehicles
                </Button>
              </Link>
              
              {!isAuthenticated && (
                <div className="text-sm text-gray-500">
                  <p>Create an account to sync your watchlist across devices</p>
                  <div className="flex gap-2 justify-center mt-2">
                    <Link to="/register">
                      <Button variant="outline" size="sm">
                        <UserPlus className="h-4 w-4 mr-2" />
                        Sign Up
                      </Button>
                    </Link>
                    <Link to="/login">
                      <Button variant="outline" size="sm">
                        <LogIn className="h-4 w-4 mr-2" />
                        Log In
                      </Button>
                    </Link>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
        
        <Footer />
      </div>
    );
  }

  return (
    <div className="flex flex-col min-h-screen">
      <SEO 
        title={`My Watchlist (${watchlistCount}) - Source My Truck`}
        description={`View your ${watchlistCount} saved commercial vehicles and create an account to sync across devices.`}
      />
      <NavBar />
      
      <div className="container mx-auto px-4 py-8 flex-1">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-8">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">My Watchlist</h1>
              <p className="text-gray-600">
                {watchlistCount} {watchlistCount === 1 ? 'vehicle' : 'vehicles'} saved locally
              </p>
            </div>
            
            <div className="flex gap-2 mt-4 sm:mt-0">
              <Button
                variant="outline"
                onClick={clearWatchlist}
                className="gap-2"
              >
                <Trash2 className="h-4 w-4" />
                Clear All
              </Button>
            </div>
          </div>

          {/* Account Promotion Banner - Only show for non-authenticated users */}
          {!isAuthenticated && (
            <Alert className="mb-8 border-blue-200 bg-blue-50">
              <Heart className="h-4 w-4 text-blue-600" />
              <AlertDescription className="text-blue-800">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                  <span>
                    Create an account to permanently save your watchlist and sync across devices.
                  </span>
                  <div className="flex gap-2 mt-2 sm:mt-0">
                    <Link to="/register">
                      <Button size="sm" variant="default">
                        <UserPlus className="h-4 w-4 mr-2" />
                        Sign Up Free
                      </Button>
                    </Link>
                    <Link to="/login">
                      <Button size="sm" variant="outline">
                        <LogIn className="h-4 w-4 mr-2" />
                        Log In
                      </Button>
                    </Link>
                  </div>
                </div>
              </AlertDescription>
            </Alert>
          )}

          {/* Watchlist Limit Info - Only show for non-authenticated users */}
          {!isAuthenticated && (
            <Card className="mb-8">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-1">Watchlist Usage</h3>
                    <p className="text-sm text-gray-600">
                      You can watch up to 8 vehicles without an account
                    </p>
                  </div>
                  <Badge variant={watchlistCount >= 8 ? "destructive" : "secondary"}>
                    {watchlistCount}/8
                  </Badge>
                </div>
                {watchlistCount >= 8 && (
                  <Alert className="mt-4 border-orange-200 bg-orange-50">
                    <AlertDescription className="text-orange-800">
                      You've reached the watchlist limit. Sign up to watch unlimited vehicles!
                    </AlertDescription>
                  </Alert>
                )}
              </CardContent>
            </Card>
          )}

          {/* Vehicles Grid */}
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <OptimizedSkeleton variant="card" count={3} />
            </div>
          ) : error ? (
            <Alert variant="destructive">
              <AlertDescription>
                Error loading watchlist vehicles. Please try again later.
              </AlertDescription>
            </Alert>
          ) : vehicles && vehicles.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {vehicles.map((vehicle) => (
                <VehicleCard
                  key={vehicle.id}
                  vehicle={vehicle}
                  showDistance={false}
                />
              ))}
            </div>
          ) : (
            <Alert>
              <AlertDescription>
                Some watched vehicles may no longer be available or have been removed by their sellers.
              </AlertDescription>
            </Alert>
          )}

          {/* Missing Vehicles Info */}
          {vehicles && vehicles.length < watchedVehicles.length && (
            <Alert className="mt-6">
              <AlertDescription>
                {watchedVehicles.length - vehicles.length} watched {watchedVehicles.length - vehicles.length === 1 ? 'vehicle is' : 'vehicles are'} no longer available.
              </AlertDescription>
            </Alert>
          )}
        </div>
      </div>
      
      <Footer />
    </div>
  );
};

export default Watchlist;