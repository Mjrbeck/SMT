
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react-swc";
import path from "path";
import { componentTagger } from "lovable-tagger";
import type { IncomingMessage, ServerResponse } from "http";

// Bot detection function
const isBotUserAgent = (userAgent: string): boolean => {
  if (!userAgent) return false;
  
  const botPatterns = [
    'facebookexternalhit',
    'twitterbot',
    'linkedinbot',
    'whatsapp',
    'pinterest',
    'slackbot',
    'discordbot',
    'telegrambot',
    'facebot',
    'twittercliffside',
    'tumblr',
    'socialflow',
    'bufferapp',
    'snapchat',
    'embedly',
    'skypeuripreview',
    'vkshare',
    'redditbot',
    'applebot',
    'googlebot',
    'bingbot'
  ];
  
  const lowerUserAgent = userAgent.toLowerCase();
  return botPatterns.some(pattern => lowerUserAgent.includes(pattern));
};

// https://vitejs.dev/config/
export default defineConfig(({ mode }) => ({
  server: {
    host: "::",
    port: 8080,
    middlewareMode: false,
    // Add custom middleware for bot detection and proxying
    middlewares: [
      // Custom middleware to handle bot requests
      (req: IncomingMessage, res: ServerResponse, next: () => void) => {
        const userAgent = req.headers['user-agent'] || '';
        const isBot = isBotUserAgent(userAgent);
        
        // Check if this is a vehicle page request from a bot
        if (isBot && req.url && req.url.match(/^\/vehicle\/[^\/]+$/)) {
          const vehicleId = req.url.split('/')[2];
          const edgeFunctionUrl = `https://xfpokywrvoshtwtevyaz.supabase.co/functions/v1/vehicle-prerender/${vehicleId}`;
          
          console.log(`Bot detected (${userAgent.substring(0, 50)}...), proxying ${req.url} to Edge Function`);
          
          // Redirect the bot to the edge function
          res.writeHead(302, {
            'Location': edgeFunctionUrl,
            'Cache-Control': 'no-cache'
          });
          res.end();
          return;
        }
        
        next();
      }
    ]
  },
  plugins: [
    react(),
    mode === 'development' && componentTagger(),
  ].filter(Boolean),
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
}));
