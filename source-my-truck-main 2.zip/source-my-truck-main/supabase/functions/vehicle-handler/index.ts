import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  console.log('🚗 Vehicle-handler function called')
  console.log('📍 Request URL:', req.url)
  console.log('🔍 Request method:', req.method)
  
  const userAgent = req.headers.get('user-agent') || ''
  console.log('👤 User agent:', userAgent)

  // Handle CORS
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  // Check if this is a social media crawler or bot
  const isSocialBot = /facebookexternalhit|twitterbot|linkedinbot|whatsapp|telegram|discord|slack|bot|crawler|spider|scraper|facebook|twitter|instagram|pinterest|reddit/i.test(userAgent)
  
  console.log('🤖 Is social bot:', isSocialBot)

  try {
    const url = new URL(req.url)
    const pathSegments = url.pathname.split('/')
    const vehicleId = pathSegments[pathSegments.length - 1]

    console.log('🚗 Vehicle ID extracted:', vehicleId)

    if (!vehicleId) {
      console.log('❌ No valid vehicle ID provided')
      return new Response('Vehicle ID not provided', { status: 400, headers: corsHeaders })
    }

    // For social bots, serve vehicle-specific HTML
    if (isSocialBot) {
      // Initialize Supabase client
      const supabaseUrl = Deno.env.get('SUPABASE_URL')!
      const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
      const supabase = createClient(supabaseUrl, supabaseServiceKey)

      console.log('📡 Fetching vehicle data from Supabase...')

      // Fetch vehicle data
      const { data: vehicle, error } = await supabase
        .from('vehicles')
        .select(`
          *,
          vehicle_images(*)
        `)
        .eq('id', vehicleId)
        .eq('status', 'active')
        .maybeSingle()

      if (error) {
        console.error('❌ Supabase error:', error)
        return new Response('Database error', { status: 500, headers: corsHeaders })
      }

      if (!vehicle) {
        console.log('❌ Vehicle not found')
        return new Response('Vehicle not found', { status: 404, headers: corsHeaders })
      }

      console.log('✅ Vehicle found:', vehicle.title)

      // Extract main image URL
      let mainImageUrl = 'https://sourcemytruck.com/source-my-truck-logo.png'
      
      if (vehicle.vehicle_images && vehicle.vehicle_images.length > 0) {
        // Find main image
        const mainImage = vehicle.vehicle_images.find((img: any) => img.is_main === true)
        if (mainImage?.image_url) {
          mainImageUrl = mainImage.image_url
          console.log('🖼️ Using main image:', mainImageUrl)
        } else if (vehicle.vehicle_images[0]?.image_url) {
          // Fallback to first image
          mainImageUrl = vehicle.vehicle_images[0].image_url
          console.log('🖼️ Using first image:', mainImageUrl)
        }
      }

      // Format vehicle details
      const vehicleTitle = `${vehicle.year} ${vehicle.make} ${vehicle.model || ''}`.trim()
      const priceDisplay = vehicle.is_poa ? 'POA' : `£${vehicle.price?.toLocaleString()}`
      const mileageText = vehicle.mileage ? `${vehicle.mileage.toLocaleString()} miles` : ''
      const engineText = vehicle.engine_size ? `${vehicle.engine_size}` : ''
      const fuelText = vehicle.fuel_type ? `${vehicle.fuel_type}` : ''
      
      const description = [mileageText, engineText, fuelText]
        .filter(Boolean)
        .join(', ') + '. Available now on Source My Truck.'

      const fullTitle = `${vehicleTitle} - ${priceDisplay}`
      const vehicleUrl = `https://sourcemytruck.com/vehicle/${vehicleId}`

      console.log('📝 Generated title:', fullTitle)
      console.log('🔗 Vehicle URL:', vehicleUrl)
      
      // Generate HTML response for social media crawlers and bots
      const html = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${fullTitle}</title>
    <meta name="description" content="${description}" />
    
    <!-- Open Graph Meta Tags -->
    <meta property="og:title" content="${fullTitle}" />
    <meta property="og:description" content="${description}" />
    <meta property="og:image" content="${mainImageUrl}" />
    <meta property="og:image:secure_url" content="${mainImageUrl}" />
    <meta property="og:image:width" content="1200" />
    <meta property="og:image:height" content="628" />
    <meta property="og:url" content="${vehicleUrl}" />
    <meta property="og:type" content="product" />
    <meta property="og:site_name" content="Source my Truck" />
    
    <!-- Twitter Card Meta Tags -->
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:title" content="${fullTitle}" />
    <meta name="twitter:description" content="${description}" />
    <meta name="twitter:image" content="${mainImageUrl}" />
    <meta name="twitter:url" content="${vehicleUrl}" />
    
    <!-- Canonical URL -->
    <link rel="canonical" href="${vehicleUrl}" />
    
    <!-- Redirect browsers to main site after a delay -->
    <script>
      setTimeout(function() {
        if (!/bot|crawler|spider|facebookexternalhit|twitterbot/i.test(navigator.userAgent)) {
          window.location.replace('${vehicleUrl}');
        }
      }, 1000);
    </script>
</head>
<body>
    <div style="font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px;">
        <h1>${fullTitle}</h1>
        <img src="${mainImageUrl}" alt="${vehicleTitle}" style="max-width: 100%; height: auto; border-radius: 8px;" />
        <p>${description}</p>
        <p><strong>Make:</strong> ${vehicle.make}</p>
        ${vehicle.model ? `<p><strong>Model:</strong> ${vehicle.model}</p>` : ''}
        <p><strong>Year:</strong> ${vehicle.year}</p>
        ${vehicle.mileage ? `<p><strong>Mileage:</strong> ${vehicle.mileage.toLocaleString()} miles</p>` : ''}
        ${vehicle.engine_size ? `<p><strong>Engine Size:</strong> ${vehicle.engine_size}</p>` : ''}
        ${vehicle.fuel_type ? `<p><strong>Fuel Type:</strong> ${vehicle.fuel_type}</p>` : ''}
        <p><strong>Price:</strong> ${priceDisplay}</p>
        <p><a href="${vehicleUrl}">View full details on Source my Truck</a></p>
    </div>
</body>
</html>`

      console.log('🎯 Returning HTML response for social bot')

      return new Response(html, {
        headers: {
          ...corsHeaders,
          'content-type': 'text/html; charset=utf-8',
          'cache-control': 'public, max-age=300', // Cache for 5 minutes
        },
      })
    } else {
      // For regular users, redirect to the main React app
      console.log('👨‍💻 Regular user - redirecting to React app')
      const redirectUrl = `https://sourcemytruck.com/vehicle/${vehicleId}`
      
      return new Response(null, {
        status: 302,
        headers: {
          ...corsHeaders,
          'Location': redirectUrl,
          'Cache-Control': 'no-cache'
        }
      })
    }

  } catch (error) {
    console.error('💥 Error in vehicle-handler function:', error)
    return new Response(`Internal server error: ${error.message}`, { 
      status: 500,
      headers: corsHeaders 
    })
  }
})