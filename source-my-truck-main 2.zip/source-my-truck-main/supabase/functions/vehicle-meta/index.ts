import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  console.log('🚗 Vehicle-meta function called')
  console.log('📍 Request URL:', req.url)
  console.log('🔍 Request method:', req.method)
  
  const userAgent = req.headers.get('user-agent') || ''
  console.log('👤 User agent:', userAgent)

  // Handle CORS
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const url = new URL(req.url)
    const vehicleId = url.searchParams.get('id')

    console.log('🚗 Vehicle ID from query:', vehicleId)

    if (!vehicleId) {
      console.log('❌ No vehicle ID provided')
      return new Response(JSON.stringify({ error: 'Vehicle ID required' }), { 
        status: 400, 
        headers: { ...corsHeaders, 'content-type': 'application/json' }
      })
    }

    // Initialize Supabase client
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    const supabase = createClient(supabaseUrl, supabaseServiceKey)

    console.log('📡 Fetching vehicle data from Supabase...')

    // Fetch vehicle data
    const { data: vehicle, error } = await supabase
      .from('vehicles')
      .select(`
        *,
        vehicle_images(*)
      `)
      .eq('id', vehicleId)
      .eq('status', 'active')
      .maybeSingle()

    if (error) {
      console.error('❌ Supabase error:', error)
      return new Response(JSON.stringify({ error: 'Database error' }), { 
        status: 500, 
        headers: { ...corsHeaders, 'content-type': 'application/json' }
      })
    }

    if (!vehicle) {
      console.log('❌ Vehicle not found')
      return new Response(JSON.stringify({ error: 'Vehicle not found' }), { 
        status: 404, 
        headers: { ...corsHeaders, 'content-type': 'application/json' }
      })
    }

    console.log('✅ Vehicle found:', vehicle.title)

    // Extract main image URL
    let mainImageUrl = 'https://sourcemytruck.com/source-my-truck-logo.png'
    
    if (vehicle.vehicle_images && vehicle.vehicle_images.length > 0) {
      // Find main image
      const mainImage = vehicle.vehicle_images.find((img: any) => img.is_main === true)
      if (mainImage?.image_url) {
        mainImageUrl = mainImage.image_url
        console.log('🖼️ Using main image:', mainImageUrl)
      } else if (vehicle.vehicle_images[0]?.image_url) {
        // Fallback to first image
        mainImageUrl = vehicle.vehicle_images[0].image_url
        console.log('🖼️ Using first image:', mainImageUrl)
      }
    }

    // Format vehicle details
    const vehicleTitle = `${vehicle.year} ${vehicle.make} ${vehicle.model || ''}`.trim()
    const priceDisplay = vehicle.is_poa ? 'POA' : `£${vehicle.price?.toLocaleString()}`
    const mileageText = vehicle.mileage ? `${vehicle.mileage.toLocaleString()} miles` : ''
    const engineText = vehicle.engine_size ? `${vehicle.engine_size}` : ''
    const fuelText = vehicle.fuel_type ? `${vehicle.fuel_type}` : ''
    
    const description = [mileageText, engineText, fuelText]
      .filter(Boolean)
      .join(', ') + '. Available now on Source My Truck.'

    const fullTitle = `${vehicleTitle} - ${priceDisplay}`
    const vehicleUrl = `https://sourcemytruck.com/vehicle/${vehicleId}`

    console.log('📝 Generated title:', fullTitle)
    console.log('🔗 Vehicle URL:', vehicleUrl)

    // Return JSON with meta data
    const metaData = {
      title: fullTitle,
      description: description,
      image: mainImageUrl,
      url: vehicleUrl,
      vehicle: {
        id: vehicleId,
        title: vehicleTitle,
        make: vehicle.make,
        model: vehicle.model,
        year: vehicle.year,
        price: priceDisplay,
        mileage: vehicle.mileage,
        engineSize: vehicle.engine_size,
        fuelType: vehicle.fuel_type
      }
    }
    
    console.log('🎯 Returning meta data')

    return new Response(JSON.stringify(metaData), {
      headers: {
        ...corsHeaders,
        'content-type': 'application/json',
        'cache-control': 'public, max-age=300', // Cache for 5 minutes
      },
    })

  } catch (error) {
    console.error('💥 Error in vehicle-meta function:', error)
    return new Response(JSON.stringify({ error: `Internal server error: ${error.message}` }), { 
      status: 500,
      headers: { ...corsHeaders, 'content-type': 'application/json' }
    })
  }
})