import { createClient } from 'https://cdn.skypack.dev/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const pathname = url.pathname;

    console.log('Sitemap proxy request for:', pathname);

    // Determine which sitemap to serve based on the path
    let sitemapContent = '';
    
    if (pathname.includes('sitemap-vehicles.xml')) {
      // Fetch dynamic vehicles sitemap
      const supabase = createClient(
        Deno.env.get('SUPABASE_URL') ?? '',
        Deno.env.get('SUPABASE_ANON_KEY') ?? ''
      );

      console.log('Fetching active vehicles for sitemap...');

      const { data: vehicles, error } = await supabase
        .from('vehicles')
        .select('id, updated_at')
        .eq('status', 'active')
        .order('updated_at', { ascending: false });

      if (error) {
        console.error('Error fetching vehicles:', error);
        throw error;
      }

      console.log(`Found ${vehicles?.length || 0} active vehicles`);

      // Generate XML sitemap
      const baseUrl = 'https://sourcemytruck.com';
      let xml = '<?xml version="1.0" encoding="UTF-8"?>\n';
      xml += '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n';

      // Add main listings page
      xml += '  <url>\n';
      xml += `    <loc>${baseUrl}/listings</loc>\n`;
      xml += `    <lastmod>${new Date().toISOString().split('T')[0]}</lastmod>\n`;
      xml += '    <changefreq>daily</changefreq>\n';
      xml += '    <priority>0.9</priority>\n';
      xml += '  </url>\n';

      // Add individual vehicle pages
      if (vehicles && vehicles.length > 0) {
        for (const vehicle of vehicles) {
          const lastmod = new Date(vehicle.updated_at).toISOString().split('T')[0];
          
          xml += '  <url>\n';
          xml += `    <loc>${baseUrl}/vehicle/${vehicle.id}</loc>\n`;
          xml += `    <lastmod>${lastmod}</lastmod>\n`;
          xml += '    <changefreq>daily</changefreq>\n';
          xml += '    <priority>0.8</priority>\n';
          xml += '  </url>\n';
        }
      }

      xml += '</urlset>';
      sitemapContent = xml;

    } else if (pathname.includes('sitemap.xml')) {
      // Main sitemap index
      sitemapContent = `<?xml version="1.0" encoding="UTF-8"?>
<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <sitemap>
    <loc>https://sourcemytruck.com/sitemap-static.xml</loc>
  </sitemap>
  <sitemap>
    <loc>https://sourcemytruck.com/sitemap-sellers.xml</loc>
  </sitemap>
  <sitemap>
    <loc>https://sourcemytruck.com/sitemap-blog.xml</loc>
  </sitemap>
  <sitemap>
    <loc>https://sourcemytruck.com/sitemap-vehicles.xml</loc>
  </sitemap>
</sitemapindex>`;

    } else if (pathname.includes('sitemap-static.xml')) {
      // Static pages sitemap
      sitemapContent = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>https://sourcemytruck.com/</loc>
    <lastmod>2024-06-24T12:00:00+00:00</lastmod>
    <changefreq>weekly</changefreq>
    <priority>1.0</priority>
  </url>
  <url>
    <loc>https://sourcemytruck.com/about</loc>
    <lastmod>2024-06-24T12:00:00+00:00</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>https://sourcemytruck.com/contact</loc>
    <lastmod>2024-06-24T12:00:00+00:00</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>https://sourcemytruck.com/terms</loc>
    <lastmod>2024-06-24T12:00:00+00:00</lastmod>
    <changefreq>yearly</changefreq>
    <priority>0.5</priority>
  </url>
  <url>
    <loc>https://sourcemytruck.com/privacy</loc>
    <lastmod>2024-06-24T12:00:00+00:00</lastmod>
    <changefreq>yearly</changefreq>
    <priority>0.5</priority>
  </url>
  <url>
    <loc>https://sourcemytruck.com/seller-guide</loc>
    <lastmod>2024-06-24T12:00:00+00:00</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.7</priority>
  </url>
  <url>
    <loc>https://sourcemytruck.com/pricing</loc>
    <lastmod>2024-06-24T12:00:00+00:00</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.7</priority>
  </url>
  <url>
    <loc>https://sourcemytruck.com/listings</loc>
    <lastmod>2024-07-03T12:00:00+00:00</lastmod>
    <changefreq>daily</changefreq>
    <priority>0.9</priority>
  </url>
</urlset>`;

    } else if (pathname.includes('sitemap-sellers.xml')) {
      // Sellers sitemap
      sitemapContent = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>https://sourcemytruck.com/sellers</loc>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>https://sourcemytruck.com/sellers/featured</loc>
    <changefreq>weekly</changefreq>
    <priority>0.7</priority>
  </url>
  <url>
    <loc>https://sourcemytruck.com/sellers/new</loc>
    <changefreq>weekly</changefreq>
    <priority>0.7</priority>
  </url>
</urlset>`;

    } else if (pathname.includes('sitemap-blog.xml')) {
      // Blog sitemap
      sitemapContent = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>https://sourcemytruck.com/blog</loc>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>https://sourcemytruck.com/blog/categories/buying-guides</loc>
    <changefreq>monthly</changefreq>
    <priority>0.7</priority>
  </url>
  <url>
    <loc>https://sourcemytruck.com/blog/categories/vehicle-maintenance</loc>
    <changefreq>monthly</changefreq>
    <priority>0.7</priority>
  </url>
  <url>
    <loc>https://sourcemytruck.com/blog/categories/industry-news</loc>
    <changefreq>weekly</changefreq>
    <priority>0.7</priority>
  </url>
</urlset>`;
    } else {
      return new Response('Sitemap not found', { 
        status: 404,
        headers: corsHeaders 
      });
    }

    console.log(`Generated sitemap for ${pathname}`);

    // Return XML response
    return new Response(sitemapContent, {
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/xml; charset=utf-8',
        'Cache-Control': 'public, max-age=3600', // Cache for 1 hour
      },
    });

  } catch (error) {
    console.error('Error generating sitemap:', error);
    
    return new Response(
      JSON.stringify({ error: 'Failed to generate sitemap' }), 
      { 
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  }
});