import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  console.log('🚀 Vehicle-meta-prerender function called')
  console.log('📍 Request URL:', req.url)
  console.log('🔍 Request method:', req.method)
  
  const userAgent = req.headers.get('user-agent') || ''
  console.log('👤 User agent:', userAgent.substring(0, 100))

  // Handle CORS
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const url = new URL(req.url)
    const pathSegments = url.pathname.split('/')
    const vehicleId = pathSegments[pathSegments.length - 1]

    console.log('🚗 Vehicle ID extracted:', vehicleId)

    if (!vehicleId || vehicleId === 'vehicle-meta-prerender') {
      console.log('❌ No valid vehicle ID provided')
      return new Response('Vehicle ID not provided', { 
        status: 400, 
        headers: corsHeaders 
      })
    }

    // Initialize Supabase client with Service Role Key for full access
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    const supabase = createClient(supabaseUrl, supabaseServiceKey)

    console.log('📡 Fetching vehicle data from Supabase...')

    // Fetch vehicle data with images
    const { data: vehicle, error } = await supabase
      .from('vehicles')
      .select(`
        *,
        vehicle_images(*)
      `)
      .eq('id', vehicleId)
      .eq('status', 'active')
      .maybeSingle()

    if (error) {
      console.error('❌ Supabase error:', error)
      return new Response('Database error', { 
        status: 500, 
        headers: corsHeaders 
      })
    }

    if (!vehicle) {
      console.log('❌ Vehicle not found')
      return new Response(`
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vehicle Not Found | Source my Truck</title>
    <meta name="description" content="The vehicle you're looking for is no longer available." />
    <meta name="robots" content="noindex, nofollow" />
    <link rel="canonical" href="https://sourcemytruck.com/" />
</head>
<body>
    <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; text-align: center; padding: 50px;">
        <h1>Vehicle Not Found</h1>
        <p>This vehicle is no longer available.</p>
        <script>
          setTimeout(function() {
            window.location.replace('https://sourcemytruck.com/listings');
          }, 3000);
        </script>
    </div>
</body>
</html>`, {
        status: 404,
        headers: {
          ...corsHeaders,
          'content-type': 'text/html; charset=utf-8',
        }
      })
    }

    console.log('✅ Vehicle found:', vehicle.id, '-', vehicle.make, vehicle.model)

    // Fetch seller details separately
    const { data: seller } = await supabase
      .from('profiles')
      .select('company_name, logo_url, is_trusted, depot_verified')
      .eq('id', vehicle.user_id)
      .maybeSingle()

    console.log('👤 Seller info:', seller?.company_name || 'Unknown')

    // Extract main image URL with fallback
    let mainImageUrl = 'https://sourcemytruck.com/lovable-uploads/a4996b55-dc58-40bd-b548-af7de97e900a.png'
    
    if (vehicle.vehicle_images && vehicle.vehicle_images.length > 0) {
      // Find main image
      const mainImage = vehicle.vehicle_images.find((img: any) => img.is_main === true)
      if (mainImage?.image_url) {
        mainImageUrl = mainImage.image_url
        console.log('🖼️ Using main image:', mainImageUrl)
      } else if (vehicle.vehicle_images[0]?.image_url) {
        // Fallback to first image
        mainImageUrl = vehicle.vehicle_images[0].image_url
        console.log('🖼️ Using first image:', mainImageUrl)
      }
    } else {
      // Use a commercial vehicle placeholder from Unsplash as fallback
      mainImageUrl = 'https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?w=1200&h=628&fit=crop&auto=format'
      console.log('🖼️ Using fallback placeholder image')
    }

    // Format vehicle details for SEO
    const vehicleTitle = `${vehicle.year} ${vehicle.make} ${vehicle.model || ''}`.trim()
    const priceDisplay = vehicle.is_poa ? 'POA' : `£${vehicle.price?.toLocaleString()}`
    const fullTitle = `${vehicleTitle} - ${priceDisplay}`
    const vehicleUrl = `https://sourcemytruck.com/vehicle/${vehicleId}`
    
    // Create comprehensive description
    const specifications = [
      vehicle.mileage ? `${vehicle.mileage.toLocaleString()} miles` : null,
      vehicle.engine_size ? vehicle.engine_size : null,
      vehicle.fuel_type ? vehicle.fuel_type : null,
      vehicle.transmission ? vehicle.transmission : null,
      vehicle.body_type ? vehicle.body_type : null
    ].filter(Boolean)
    
    const description = `${specifications.join(', ')}${specifications.length > 0 ? '. ' : ''}${vehicle.description ? vehicle.description.substring(0, 100) + '...' : 'Available now on Source My Truck - UK\'s leading commercial vehicle marketplace.'}`
    
    // Keywords for SEO
    const keywords = [
      vehicle.make,
      vehicle.model,
      vehicle.body_type,
      'commercial vehicle',
      'truck for sale',
      vehicle.fuel_type,
      'UK trucks'
    ].filter(Boolean).join(', ')

    // Seller information
    const sellerName = seller?.company_name || 'Source my Truck'
    const isTrustedSeller = seller?.is_trusted || false

    console.log('📝 Generated SEO data:')
    console.log('- Title:', fullTitle)
    console.log('- Description:', description.substring(0, 50) + '...')
    console.log('- Image:', mainImageUrl.substring(0, 50) + '...')
    
    // Generate complete SEO-optimized HTML
    const html = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${fullTitle} | Source my Truck</title>
    <meta name="description" content="${description}" />
    <meta name="keywords" content="${keywords}" />
    <meta name="robots" content="index, follow" />
    <meta name="author" content="Source my Truck" />
    
    <!-- Open Graph Meta Tags for Social Sharing -->
    <meta property="og:title" content="${fullTitle}" />
    <meta property="og:description" content="${description}" />
    <meta property="og:image" content="${mainImageUrl}" />
    <meta property="og:image:secure_url" content="${mainImageUrl}" />
    <meta property="og:image:width" content="1200" />
    <meta property="og:image:height" content="628" />
    <meta property="og:image:alt" content="${vehicleTitle} - Commercial Vehicle for Sale" />
    <meta property="og:url" content="${vehicleUrl}" />
    <meta property="og:type" content="product" />
    <meta property="og:site_name" content="Source my Truck" />
    <meta property="product:price:amount" content="${vehicle.price}" />
    <meta property="product:price:currency" content="GBP" />
    ${isTrustedSeller ? '<meta property="product:condition" content="verified_seller" />' : ''}
    
    <!-- Twitter Card Meta Tags -->
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:site" content="@sourcemytruck" />
    <meta name="twitter:title" content="${fullTitle}" />
    <meta name="twitter:description" content="${description}" />
    <meta name="twitter:image" content="${mainImageUrl}" />
    <meta name="twitter:image:alt" content="${vehicleTitle} - Commercial Vehicle for Sale" />
    <meta name="twitter:url" content="${vehicleUrl}" />
    
    <!-- Canonical URL -->
    <link rel="canonical" href="${vehicleUrl}" />
    
    <!-- Favicon -->
    <link rel="icon" href="https://sourcemytruck.com/lovable-uploads/f09b9e95-9ff8-4f42-abac-98f2720b5949.png" type="image/png" />
    
    <!-- Preconnect for performance -->
    <link rel="preconnect" href="https://sourcemytruck.com">
    <link rel="dns-prefetch" href="https://sourcemytruck.com">
    
    <!-- Schema.org Structured Data -->
    <script type="application/ld+json">
    {
      "@context": "https://schema.org/",
      "@type": "Vehicle",
      "name": "${vehicleTitle}",
      "description": "${description}",
      "brand": {
        "@type": "Brand",
        "name": "${vehicle.make}"
      },
      "model": "${vehicle.model || ''}",
      "vehicleYear": ${vehicle.year},
      ${vehicle.mileage ? `"mileageFromOdometer": {
        "@type": "QuantitativeValue",
        "value": ${vehicle.mileage},
        "unitCode": "SMI"
      },` : ''}
      "offers": {
        "@type": "Offer",
        "price": "${vehicle.price}",
        "priceCurrency": "GBP",
        "availability": "https://schema.org/InStock",
        "seller": {
          "@type": "Organization",
          "name": "${sellerName}"${isTrustedSeller ? ',\n          "trustLevel": "verified"' : ''}
        }
      },
      "image": "${mainImageUrl}",
      "url": "${vehicleUrl}",
      ${vehicle.fuel_type ? `"fuelType": "${vehicle.fuel_type}",` : ''}
      ${vehicle.body_type ? `"bodyType": "${vehicle.body_type}",` : ''}
      ${vehicle.color ? `"color": "${vehicle.color}",` : ''}
      "mainEntityOfPage": "${vehicleUrl}"
    }
    </script>
    
    <!-- Auto-redirect script for regular browsers -->
    <script>
      // Only redirect if not a bot/crawler
      setTimeout(function() {
        var userAgent = navigator.userAgent.toLowerCase();
        var isCrawler = /googlebot|bingbot|slurp|duckduckbot|baiduspider|yandexbot|facebookexternalhit|facebot|twitterbot|linkedinbot|whatsapp|telegram|discord|slack|bot|crawler|spider|scraper|facebook|twitter|instagram|pinterest|reddit|ia_archiver/i.test(userAgent);
        
        if (!isCrawler) {
          console.log('Redirecting user to main app...');
          window.location.replace('${vehicleUrl}');
        } else {
          console.log('Crawler detected, staying on prerendered page');
        }
      }, 2000);
    </script>
    
    <style>
      body {
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
        line-height: 1.6;
        color: #333;
        background-color: #f8fafc;
        margin: 0;
        padding: 20px;
      }
      .container {
        max-width: 800px;
        margin: 0 auto;
        background: white;
        border-radius: 12px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        overflow: hidden;
      }
      .header {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 30px;
        text-align: center;
      }
      .badge {
        display: inline-block;
        background: rgba(255, 255, 255, 0.2);
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 12px;
        margin-bottom: 10px;
      }
      .content {
        padding: 30px;
      }
      .vehicle-image {
        width: 100%;
        height: 300px;
        object-fit: cover;
        border-radius: 8px;
        margin-bottom: 20px;
      }
      .specs-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 15px;
        background: #f8fafc;
        padding: 20px;
        border-radius: 8px;
        margin: 20px 0;
      }
      .spec-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 8px 0;
        border-bottom: 1px solid #e2e8f0;
      }
      .spec-item:last-child {
        border-bottom: none;
      }
      .price {
        font-size: 24px;
        font-weight: bold;
        color: #e53e3e;
        text-align: center;
        margin: 20px 0;
      }
      .cta-button {
        display: inline-block;
        background: #3182ce;
        color: white;
        padding: 15px 30px;
        text-decoration: none;
        border-radius: 8px;
        font-weight: bold;
        text-align: center;
        width: 100%;
        box-sizing: border-box;
        margin-top: 20px;
      }
      .footer {
        background: #2d3748;
        color: white;
        padding: 20px 30px;
        text-align: center;
      }
      .footer a {
        color: #63b3ed;
        text-decoration: none;
      }
    </style>
</head>
<body>
    <div class="container">
        <header class="header">
            <div class="badge">Commercial Vehicle</div>
            <h1>${fullTitle}</h1>
            <p>Listed by ${sellerName}${isTrustedSeller ? ' ✓ Trusted Seller' : ''}</p>
        </header>
        
        <main class="content">
            <img src="${mainImageUrl}" alt="${vehicleTitle}" class="vehicle-image" />
            
            <div class="price">${priceDisplay}</div>
            
            <div class="specs-grid">
                <div class="spec-item">
                    <strong>Make:</strong>
                    <span>${vehicle.make}</span>
                </div>
                ${vehicle.model ? `<div class="spec-item">
                    <strong>Model:</strong>
                    <span>${vehicle.model}</span>
                </div>` : ''}
                <div class="spec-item">
                    <strong>Year:</strong>
                    <span>${vehicle.year}</span>
                </div>
                ${vehicle.mileage ? `<div class="spec-item">
                    <strong>Mileage:</strong>
                    <span>${vehicle.mileage.toLocaleString()} miles</span>
                </div>` : ''}
                ${vehicle.engine_size ? `<div class="spec-item">
                    <strong>Engine:</strong>
                    <span>${vehicle.engine_size}</span>
                </div>` : ''}
                ${vehicle.fuel_type ? `<div class="spec-item">
                    <strong>Fuel Type:</strong>
                    <span>${vehicle.fuel_type}</span>
                </div>` : ''}
                ${vehicle.body_type ? `<div class="spec-item">
                    <strong>Body Type:</strong>
                    <span>${vehicle.body_type}</span>
                </div>` : ''}
                ${vehicle.transmission ? `<div class="spec-item">
                    <strong>Transmission:</strong>
                    <span>${vehicle.transmission}</span>
                </div>` : ''}
            </div>
            
            ${vehicle.description ? `<div>
                <h3>Description</h3>
                <p>${vehicle.description}</p>
            </div>` : ''}
            
            <a href="${vehicleUrl}" class="cta-button">View Full Details & Contact Seller</a>
        </main>
        
        <footer class="footer">
            <p>This vehicle is listed on <a href="https://sourcemytruck.com">Source my Truck</a></p>
            <p>The UK's leading marketplace for commercial vehicles</p>
        </footer>
    </div>
</body>
</html>`

    console.log('🎯 Returning SEO-optimized HTML response')

    return new Response(html, {
      headers: {
        ...corsHeaders,
        'content-type': 'text/html; charset=utf-8',
        'cache-control': 'public, max-age=300, s-maxage=300', // Cache for 5 minutes
        'x-robots-tag': 'index, follow',
      },
    })

  } catch (error) {
    console.error('💥 Error in vehicle-meta-prerender function:', error)
    return new Response(`Internal server error: ${error.message}`, { 
      status: 500,
      headers: {
        ...corsHeaders,
        'content-type': 'text/plain',
      }
    })
  }
})