
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { Resend } from "npm:resend@2.0.0";

const resend = new Resend(Deno.env.get('RESEND_API_KEY'));

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { vehicleTitle, userEmail, userName, registration } = await req.json();

    console.log('Sending listing confirmation email to:', userEmail);

    const { data, error } = await resend.emails.send({
      from: 'SourceMyTruck <notifications@sourcemytruck.com>',
      to: [userEmail],
      subject: `Your vehicle listing for ${registration} is now live!`,
      html: `
        <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto;">
          <h1 style="color: #1a56db;">Vehicle Listing Confirmed</h1>
          <p>Hi ${userName},</p>
          <p>Your vehicle listing for <strong>${vehicleTitle}</strong> (${registration}) has been successfully created and is now live on SourceMyTruck.</p>
          <p>You can view and manage your listings in your inventory dashboard.</p>
          <p style="margin-top: 24px;">Best regards,<br>The SourceMyTruck Team</p>
        </div>
      `,
    });

    if (error) {
      console.error('Error sending email:', error);
      throw error;
    }

    console.log('Email sent successfully:', data);

    return new Response(JSON.stringify({ success: true }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error('Error in send-listing-email function:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  }
});
