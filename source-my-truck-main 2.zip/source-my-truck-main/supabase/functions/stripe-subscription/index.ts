import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@12.0.0?target=deno";

// CORS headers for cross-origin requests
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

// Helper to determine if we're in test mode
const isTestMode = (): boolean => {
  const stripeKey = Deno.env.get('STRIPE_SECRET_KEY') || '';
  return stripeKey.startsWith('sk_test_');
};

// Response helper functions
const createResponse = (data: any, status = 200) => {
  return new Response(
    JSON.stringify(data),
    { status, headers: { ...corsHeaders, "Content-Type": "application/json" } }
  );
};

const errorResponse = (message: string, status = 400) => {
  console.error(`Error: ${message}`);
  return createResponse({ error: message }, status);
};

// Main request handler
serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { 
      headers: corsHeaders,
      status: 204
    });
  }

  try {
    // Get Stripe secret key from environment variables
    const stripeSecretKey = Deno.env.get('STRIPE_SECRET_KEY');
    if (!stripeSecretKey) {
      return errorResponse("Stripe secret key not found");
    }
    
    // Initialize Stripe
    const stripe = new Stripe(stripeSecretKey, {
      apiVersion: '2023-10-16',
    });

    // Parse request data
    const requestData = await req.json();
    console.log("Request data:", requestData);
    
    // Handle subscription status check
    if (requestData.checkStatus === true) {
      console.log("Checking subscription status");
      
      // Get the user information from the authorization header
      const authHeader = req.headers.get('Authorization');
      if (!authHeader) {
        return errorResponse("Authorization header missing", 401);
      }

      // Extract and validate the JWT token
      const token = authHeader.replace('Bearer ', '');
      
      // Get user from Supabase auth
      const supabaseUrl = Deno.env.get('SUPABASE_URL');
      const supabaseAnonKey = Deno.env.get('SUPABASE_ANON_KEY');
      
      if (!supabaseUrl || !supabaseAnonKey) {
        return errorResponse("Supabase configuration missing");
      }
      
      // Get user information
      const userResponse = await fetch(`${supabaseUrl}/auth/v1/user`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'apikey': supabaseAnonKey
        }
      });
      
      if (!userResponse.ok) {
        console.error("Failed to get user information", await userResponse.text());
        return errorResponse("Authentication failed", 401);
      }
      
      const userData = await userResponse.json();
      const userId = userData.id;
      const userEmail = userData.email;
      
      if (!userId || !userEmail) {
        return errorResponse("User information incomplete");
      }
      
      try {
        // Check if the customer exists
        const customers = await stripe.customers.list({
          email: userEmail,
          limit: 1
        });
        
        if (customers.data.length === 0) {
          // No customer found, return empty subscription
          return createResponse({ subscription: null });
        }
        
        const customerId = customers.data[0].id;
        
        // Get active subscriptions
        const subscriptions = await stripe.subscriptions.list({
          customer: customerId,
          status: 'active',
          limit: 10
        });
        
        if (subscriptions.data.length === 0) {
          // No active subscriptions
          return createResponse({ subscription: null });
        }
        
        // Find relevant subscription
        let relevantSubscription = null;
        
        for (const subscription of subscriptions.data) {
          // Find subscription for our plans
          const item = subscription.items.data[0];
          const priceId = item?.price?.id;
          
          // Map the subscription to our internal structure
          if (priceId) {
            // Get the plan details
            let tier = '';
            let credits = 0;
            
            if (item.price.metadata && item.price.metadata.tier) {
              tier = item.price.metadata.tier;
              credits = parseInt(item.price.metadata.credits || '0');
            } else {
              // Try to match by price amount if metadata is not available
              const amount = item.price.unit_amount || 0;
              
              if (amount === 8000) {
                tier = 'small';
                credits = 10;
              } else if (amount === 24000) {
                tier = 'medium';
                credits = 30;
              } else if (amount === 39000) {
                tier = 'large';
                credits = 50;
              }
            }
            
            if (tier) {
              relevantSubscription = {
                id: subscription.id,
                status: subscription.status,
                currentPeriodEnd: subscription.current_period_end,
                cancelAtPeriodEnd: subscription.cancel_at_period_end,
                plan: {
                  id: tier,
                  name: tier.charAt(0).toUpperCase() + tier.slice(1) + ' Fleet',
                  credits: credits,
                },
              };
              break;
            }
          }
        }
        
        return createResponse({ subscription: relevantSubscription });
      } catch (error) {
        console.error("Stripe error when checking subscription:", error);
        return errorResponse(`Stripe error: ${error.message}`);
      }
    }
    
    // Handle subscription cancellation
    if (requestData.action === 'cancel' && requestData.subscriptionId) {
      try {
        const subscription = await stripe.subscriptions.update(
          requestData.subscriptionId,
          { cancel_at_period_end: true }
        );
        
        return createResponse({ 
          success: true,
          subscription: {
            id: subscription.id,
            status: subscription.status,
            cancelAtPeriodEnd: subscription.cancel_at_period_end,
            currentPeriodEnd: subscription.current_period_end
          }
        });
      } catch (error) {
        console.error("Error cancelling subscription:", error);
        return errorResponse(`Failed to cancel subscription: ${error.message}`);
      }
    }
    
    // For new subscription creation
    const { tierId, productId, timestamp } = requestData;
    
    // Validate request parameters
    if (!tierId || !productId) {
      console.error("Invalid request parameters", { tierId, productId });
      return errorResponse("Invalid request parameters");
    }

    // Get the user information from the authorization header
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return errorResponse("Authorization header missing", 401);
    }

    // Extract and validate the JWT token
    const token = authHeader.replace('Bearer ', '');
    
    // Get user from Supabase auth
    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    const supabaseAnonKey = Deno.env.get('SUPABASE_ANON_KEY');
    
    if (!supabaseUrl || !supabaseAnonKey) {
      return errorResponse("Supabase configuration missing");
    }
    
    // Get user information
    const userResponse = await fetch(`${supabaseUrl}/auth/v1/user`, {
      headers: {
        'Authorization': `Bearer ${token}`,
        'apikey': supabaseAnonKey
      }
    });
    
    if (!userResponse.ok) {
      console.error("Failed to get user information", await userResponse.text());
      return errorResponse("Authentication failed", 401);
    }
    
    const userData = await userResponse.json();
    const userId = userData.id;
    const userEmail = userData.email;
    
    if (!userId || !userEmail) {
      return errorResponse("User information incomplete");
    }
    
    // Get origin URL for redirects
    const originUrl = req.headers.get('origin') || 'http://localhost:5173';

    // Check if the customer already exists
    let customerId: string | undefined;
    
    const customers = await stripe.customers.list({
      email: userEmail,
      limit: 1
    });

    if (customers.data.length > 0) {
      customerId = customers.data[0].id;
    } else {
      // Create a new customer
      const customer = await stripe.customers.create({
        email: userEmail,
        metadata: {
          userId
        }
      });
      customerId = customer.id;
    }
    
    // Set price based on tier
    let unitAmount: number;
    let creditsPerMonth: number;
    
    switch(tierId) {
      case 'small':
        unitAmount = 8000; // £80
        creditsPerMonth = 10;
        break;
      case 'medium':
        unitAmount = 24000; // £240
        creditsPerMonth = 30;
        break;
      case 'large':
        unitAmount = 39000; // £390
        creditsPerMonth = 50;
        break;
      default:
        return errorResponse("Invalid tier selected");
    }
    
    // Create the subscription checkout session
    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      payment_method_types: ['card'],
      line_items: [
        {
          price_data: {
            currency: 'gbp',
            product: productId,
            recurring: {
              interval: 'month'
            },
            unit_amount: unitAmount
          },
          quantity: 1,
        },
      ],
      mode: 'subscription',
      success_url: `${originUrl}/settings?tab=credits&subscription_success=true`,
      cancel_url: `${originUrl}/settings?tab=credits&subscription_canceled=true`,
      metadata: {
        userId: userId,
        tierId: tierId,
        creditsPerMonth: creditsPerMonth.toString(),
        isTest: isTestMode().toString()
      },
    });
    
    if (!session.url) {
      return errorResponse("Failed to create checkout session URL");
    }
    
    // Return checkout URL
    return createResponse({ 
      url: session.url,
      subscriptionId: session.id,
      isTest: isTestMode()
    });
    
  } catch (error) {
    console.error("Unhandled error:", error);
    return errorResponse(`Unhandled error: ${error.message}`, 500);
  }
});
