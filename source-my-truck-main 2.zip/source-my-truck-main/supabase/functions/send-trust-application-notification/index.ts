import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { Resend } from "npm:resend@2.0.0";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

interface TrustApplicationNotificationRequest {
  applicationId: string;
  userId: string;
  fullName: string;
  companyName?: string;
  businessEmail: string;
  companyRegistrationNumber?: string;
  yearsInBusiness: number;
  websiteOrSocialLinks?: string;
  phoneNumber?: string;
  reason: string;
  documentUrl?: string;
}

const handler = async (req: Request): Promise<Response> => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const applicationData: TrustApplicationNotificationRequest = await req.json();
    
    console.log('Processing trust application notification for:', applicationData.fullName);

    // Create email content
    const emailHtml = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="background: linear-gradient(135deg, #2563eb, #1d4ed8); color: white; padding: 20px; border-radius: 8px 8px 0 0;">
          <h1 style="margin: 0; font-size: 24px;">🛡️ New Trusted Seller Application</h1>
          <p style="margin: 5px 0 0 0; opacity: 0.9;">A new application has been submitted for review</p>
        </div>
        
        <div style="background: #f8fafc; padding: 20px; border: 1px solid #e2e8f0; border-top: none;">
          <h2 style="color: #1e293b; margin-top: 0;">Application Details</h2>
          
          <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px;">
            <tr style="background: white;">
              <td style="padding: 12px; border: 1px solid #e2e8f0; font-weight: bold; width: 30%;">Application ID:</td>
              <td style="padding: 12px; border: 1px solid #e2e8f0;">${applicationData.applicationId}</td>
            </tr>
            <tr>
              <td style="padding: 12px; border: 1px solid #e2e8f0; font-weight: bold;">Full Name:</td>
              <td style="padding: 12px; border: 1px solid #e2e8f0;">${applicationData.fullName}</td>
            </tr>
            ${applicationData.companyName ? `
            <tr style="background: white;">
              <td style="padding: 12px; border: 1px solid #e2e8f0; font-weight: bold;">Company Name:</td>
              <td style="padding: 12px; border: 1px solid #e2e8f0;">${applicationData.companyName}</td>
            </tr>
            ` : ''}
            <tr ${!applicationData.companyName ? 'style="background: white;"' : ''}>
              <td style="padding: 12px; border: 1px solid #e2e8f0; font-weight: bold;">Business Email:</td>
              <td style="padding: 12px; border: 1px solid #e2e8f0;">
                <a href="mailto:${applicationData.businessEmail}" style="color: #2563eb;">${applicationData.businessEmail}</a>
              </td>
            </tr>
            ${applicationData.companyRegistrationNumber ? `
            <tr style="background: white;">
              <td style="padding: 12px; border: 1px solid #e2e8f0; font-weight: bold;">Company Registration:</td>
              <td style="padding: 12px; border: 1px solid #e2e8f0;">${applicationData.companyRegistrationNumber}</td>
            </tr>
            ` : ''}
            <tr ${!applicationData.companyRegistrationNumber ? 'style="background: white;"' : ''}>
              <td style="padding: 12px; border: 1px solid #e2e8f0; font-weight: bold;">Years in Business:</td>
              <td style="padding: 12px; border: 1px solid #e2e8f0;">${applicationData.yearsInBusiness} years</td>
            </tr>
            ${applicationData.websiteOrSocialLinks ? `
            <tr style="background: white;">
              <td style="padding: 12px; border: 1px solid #e2e8f0; font-weight: bold;">Website/Social:</td>
              <td style="padding: 12px; border: 1px solid #e2e8f0;">
                <a href="${applicationData.websiteOrSocialLinks}" target="_blank" style="color: #2563eb;">${applicationData.websiteOrSocialLinks}</a>
              </td>
            </tr>
            ` : ''}
            ${applicationData.phoneNumber ? `
            <tr ${!applicationData.websiteOrSocialLinks ? 'style="background: white;"' : ''}>
              <td style="padding: 12px; border: 1px solid #e2e8f0; font-weight: bold;">Phone Number:</td>
              <td style="padding: 12px; border: 1px solid #e2e8f0;">
                <a href="tel:${applicationData.phoneNumber}" style="color: #2563eb;">${applicationData.phoneNumber}</a>
              </td>
            </tr>
            ` : ''}
          </table>

          <div style="background: white; padding: 16px; border: 1px solid #e2e8f0; border-radius: 6px; margin-bottom: 20px;">
            <h3 style="margin-top: 0; color: #1e293b;">Why they want to become a Trusted Seller:</h3>
            <p style="margin-bottom: 0; line-height: 1.6; color: #475569;">${applicationData.reason}</p>
          </div>

          ${applicationData.documentUrl ? `
          <div style="background: #fef3c7; border: 1px solid #f59e0b; padding: 16px; border-radius: 6px; margin-bottom: 20px;">
            <h3 style="margin-top: 0; color: #92400e;">📄 Document Uploaded</h3>
            <p style="margin-bottom: 8px; color: #92400e;">The applicant has uploaded a document for verification:</p>
            <a href="${applicationData.documentUrl}" target="_blank" style="color: #1d4ed8; font-weight: bold;">View Document</a>
          </div>
          ` : ''}

          <div style="background: #dbeafe; border: 1px solid #2563eb; padding: 16px; border-radius: 6px;">
            <h3 style="margin-top: 0; color: #1e40af;">📋 Next Steps</h3>
            <ol style="margin-bottom: 0; color: #1e40af;">
              <li>Review the application details above</li>
              <li>Verify the provided information and documents</li>
              <li>Log into the <a href="https://supabase.com/dashboard/project/62ccf24e-9989-4dbc-a332-731ded28f080/editor" style="color: #1d4ed8;">Supabase Dashboard</a></li>
              <li>Update the user's profile to set is_trusted and/or depot_verified to true</li>
              <li>Update the application status in the trust_applications table</li>
            </ol>
          </div>
        </div>
        
        <div style="background: #1e293b; color: white; padding: 16px; border-radius: 0 0 8px 8px; text-align: center;">
          <p style="margin: 0; font-size: 14px; opacity: 0.8;">
            This notification was sent from Source My Truck | 
            <a href="https://sourcemytruck.com" style="color: #60a5fa;">sourcemytruck.com</a>
          </p>
        </div>
      </div>
    `;

    // Send the email
    const emailResponse = await resend.emails.send({
      from: "Source My Truck <no-reply@sourcemytruck.com>",
      to: ["support@sourcemytruck.com"],
      subject: `🛡️ New Trusted Seller Application - ${applicationData.fullName}`,
      html: emailHtml,
    });

    console.log("Trust application notification sent successfully:", emailResponse);

    return new Response(JSON.stringify({ 
      success: true, 
      emailId: emailResponse.data?.id 
    }), {
      status: 200,
      headers: {
        "Content-Type": "application/json",
        ...corsHeaders,
      },
    });
  } catch (error: any) {
    console.error("Error sending trust application notification:", error);
    return new Response(
      JSON.stringify({ 
        error: error.message,
        success: false 
      }),
      {
        status: 500,
        headers: { 
          "Content-Type": "application/json", 
          ...corsHeaders 
        },
      }
    );
  }
};

serve(handler);