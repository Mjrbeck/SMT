
// Follow this setup guide to integrate the Deno runtime into your application:
// https://deno.com/deploy/docs/projects
// This Edge Function allows decrementing credits by a variable amount

import { serve } from "https://deno.land/std@0.131.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.0.0";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// RPC function for decrementing credits by variable amount
export const decrementCredits = async (userId: string, amount: number) => {
  console.log(`Decrementing ${amount} credits for user ${userId}`);
  
  const supabaseClient = createClient(
    Deno.env.get("SUPABASE_URL") ?? "",
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
  );
  
  // Get current credits
  const { data: profile, error: profileError } = await supabaseClient
    .from("profiles")
    .select("credits")
    .eq("id", userId)
    .single();
  
  if (profileError) {
    console.error("Error fetching user profile:", profileError);
    throw new Error("Failed to fetch user profile");
  }
  
  // Validate credit amount is positive
  if (amount <= 0) {
    console.error("Invalid credit amount to decrement:", amount);
    throw new Error("Credit amount must be greater than zero");
  }
  
  // Ensure user has enough credits - using >= to fix exact amount validation
  if (profile.credits < amount) {
    console.error(`User ${userId} has insufficient credits: ${profile.credits}, needed: ${amount}`);
    throw new Error("Insufficient credits");
  }
  
  // Calculate new credits value (never go below 0)
  const newCredits = Math.max(0, profile.credits - amount);
  console.log(`Updating credits from ${profile.credits} to ${newCredits}`);
  
  // Update credits
  const { error: updateError } = await supabaseClient
    .from("profiles")
    .update({ credits: newCredits })
    .eq("id", userId);
  
  if (updateError) {
    console.error("Error updating credits:", updateError);
    throw new Error("Failed to update credits");
  }
  
  console.log(`Successfully decremented ${amount} credits for user ${userId}`);
  return newCredits;
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }
  
  try {
    // Parse the request body
    const requestData = await req.json();
    const { userId, amount } = requestData;
    
    if (!userId || !amount) {
      return new Response(
        JSON.stringify({ error: "Missing parameters: userId and amount are required" }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 400 }
      );
    }
    
    // Ensure amount is a positive number
    if (amount <= 0) {
      return new Response(
        JSON.stringify({ error: "Amount must be greater than zero" }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 400 }
      );
    }
    
    const newCredits = await decrementCredits(userId, amount);
    
    return new Response(
      JSON.stringify({ success: true, remainingCredits: newCredits }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Error in decrement_credits function:", error);
    
    // Check for specific error types
    const errorMessage = error.message || "An unexpected error occurred";
    const status = errorMessage.includes("Insufficient credits") ? 402 : 500;
    
    return new Response(
      JSON.stringify({ 
        error: errorMessage,
        insufficientCredits: errorMessage.includes("Insufficient credits")
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" }, status }
    );
  }
});
