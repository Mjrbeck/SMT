
// CORS headers for cross-origin requests
export const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Environment variable names
export const ENV_VARS = {
  STRIPE_SECRET_KEY: 'STRIPE_SECRET_KEY',
  STRIPE_WEBHOOK_SECRET: 'STRIPE_WEBHOOK_SECRET',
  SUPABASE_URL: 'SUPABASE_URL',
  SUPABASE_SERVICE_ROLE_KEY: 'SUPABASE_SERVICE_ROLE_KEY',
};

// Helper to determine if we're in test mode
export const isTestMode = (): boolean => {
  const stripeKey = Deno.env.get(ENV_VARS.STRIPE_SECRET_KEY) || '';
  return stripeKey.startsWith('sk_test_');
};

// Helper to get environment mode display name
export const getEnvironmentMode = (): string => {
  return isTestMode() ? 'Test Mode' : 'Live Mode';
};
