
import { getRequiredEnvVar } from "./utils.ts";
import { ENV_VARS } from "./config.ts";

// Supabase client functions
export const updateTransactionStatus = async (paymentIntentId: string, status: string) => {
  console.log(`Updating transaction status for payment_intent_id: ${paymentIntentId} to ${status}`);
  
  const supabaseUrl = getRequiredEnvVar(ENV_VARS.SUPABASE_URL);
  const supabaseKey = getRequiredEnvVar(ENV_VARS.SUPABASE_SERVICE_ROLE_KEY);
  
  try {
    // First, check if the transaction exists
    const checkResponse = await fetch(`${supabaseUrl}/rest/v1/transactions?payment_intent_id=eq.${paymentIntentId}&select=id,status`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${supabaseKey}`,
        'apikey': supabaseKey
      }
    });
    
    if (!checkResponse.ok) {
      const errorText = await checkResponse.text();
      throw new Error(`Failed to check transaction: ${errorText} (Status: ${checkResponse.status})`);
    }
    
    const transactions = await checkResponse.json();
    console.log(`Found ${transactions.length} transactions for payment_intent_id: ${paymentIntentId}`);
    
    if (transactions.length === 0) {
      console.warn(`No transaction found for payment_intent_id: ${paymentIntentId}`);
      return false;
    }
    
    // Update transaction status
    const response = await fetch(`${supabaseUrl}/rest/v1/transactions?payment_intent_id=eq.${paymentIntentId}`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${supabaseKey}`,
        'apikey': supabaseKey,
        'Prefer': 'return=minimal'
      },
      body: JSON.stringify({ status })
    });
    
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Failed to update transaction status: ${errorText} (Status: ${response.status})`);
    }
    
    console.log(`Transaction status successfully updated to '${status}' for payment_intent_id: ${paymentIntentId}`);
    return true;
  } catch (error) {
    console.error(`Error updating transaction status: ${error.message}`);
    return false;
  }
};

export const callDatabaseFunction = async (functionName: string, params: any) => {
  console.log(`Calling database function ${functionName} with params:`, params);
  
  const supabaseUrl = getRequiredEnvVar(ENV_VARS.SUPABASE_URL);
  const supabaseKey = getRequiredEnvVar(ENV_VARS.SUPABASE_SERVICE_ROLE_KEY);
  
  try {
    const response = await fetch(`${supabaseUrl}/rest/v1/rpc/${functionName}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${supabaseKey}`,
        'apikey': supabaseKey,
      },
      body: JSON.stringify(params),
    });
    
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Failed to call ${functionName}: ${errorText} (Status: ${response.status})`);
    }
    
    console.log(`Successfully called ${functionName}`);
    return true;
  } catch (error) {
    console.error(`Error calling ${functionName}: ${error.message}`);
    return false;
  }
};

// Create or update a transaction record in credits_transactions table
export const createCreditsTransaction = async (paymentIntentId: string, userId: string, creditAmount: number, costPence: number) => {
  console.log(`Creating credits transaction record for user ${userId}, amount: ${creditAmount}, cost: ${costPence}p`);
  
  const supabaseUrl = getRequiredEnvVar(ENV_VARS.SUPABASE_URL);
  const supabaseKey = getRequiredEnvVar(ENV_VARS.SUPABASE_SERVICE_ROLE_KEY);
  
  try {
    // First check if a transaction already exists
    const checkResponse = await fetch(`${supabaseUrl}/rest/v1/credits_transactions?payment_intent_id=eq.${paymentIntentId}`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${supabaseKey}`,
        'apikey': supabaseKey
      }
    });
    
    if (!checkResponse.ok) {
      throw new Error(`Failed to check existing transaction: ${await checkResponse.text()}`);
    }
    
    const existingTransactions = await checkResponse.json();
    
    if (existingTransactions.length > 0) {
      // Update existing transaction to completed
      console.log(`Updating existing credits transaction to completed`);
      const updateResponse = await fetch(`${supabaseUrl}/rest/v1/credits_transactions?payment_intent_id=eq.${paymentIntentId}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${supabaseKey}`,
          'apikey': supabaseKey,
          'Prefer': 'return=minimal'
        },
        body: JSON.stringify({
          status: 'completed'
        })
      });
      
      if (!updateResponse.ok) {
        throw new Error(`Failed to update credits transaction: ${await updateResponse.text()}`);
      }
      
      console.log(`Credits transaction updated successfully`);
      return true;
    } else {
      // Create new transaction record
      console.log(`Creating new credits transaction record`);
      const createResponse = await fetch(`${supabaseUrl}/rest/v1/credits_transactions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${supabaseKey}`,
          'apikey': supabaseKey,
          'Prefer': 'return=minimal'
        },
        body: JSON.stringify({
          user_id: userId,
          payment_intent_id: paymentIntentId,
          amount: creditAmount,
          cost_pence: costPence,
          status: 'completed'
        })
      });
      
      if (!createResponse.ok) {
        throw new Error(`Failed to create credits transaction: ${await createResponse.text()}`);
      }
      
      console.log(`Credits transaction created successfully`);
      return true;
    }
  } catch (error) {
    console.error(`Error creating/updating credits transaction: ${error.message}`);
    return false;
  }
};

export const updateUserCredits = async (userId: string, creditAmount: number) => {
  console.log(`Directly updating profile credits for user ${userId} with ${creditAmount} credits`);
  
  const supabaseUrl = getRequiredEnvVar(ENV_VARS.SUPABASE_URL);
  const supabaseKey = getRequiredEnvVar(ENV_VARS.SUPABASE_SERVICE_ROLE_KEY);
  
  // Implement retry mechanism with exponential backoff
  const MAX_RETRIES = 3;
  let retryCount = 0;
  let lastError = null;
  
  while (retryCount < MAX_RETRIES) {
    try {
      // First fetch the current profile to verify it exists
      console.log(`Attempt ${retryCount + 1}/${MAX_RETRIES}: Checking if profile exists for user ${userId}`);
      const checkProfileResponse = await fetch(`${supabaseUrl}/rest/v1/profiles?id=eq.${userId}&select=id,credits`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${supabaseKey}`,
          'apikey': supabaseKey
        }
      });
      
      if (!checkProfileResponse.ok) {
        const errorText = await checkProfileResponse.text();
        throw new Error(`Failed to check profile: ${errorText} (Status: ${checkProfileResponse.status})`);
      }
      
      const profiles = await checkProfileResponse.json();
      
      if (profiles.length === 0) {
        console.error(`No profile found for user ${userId}, attempting to create one`);
        
        // Create a profile if it doesn't exist
        const createProfileResponse = await fetch(`${supabaseUrl}/rest/v1/profiles`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${supabaseKey}`,
            'apikey': supabaseKey,
            'Prefer': 'return=minimal'
          },
          body: JSON.stringify({
            id: userId,
            credits: creditAmount,
            company_name: 'My Company'
          })
        });
        
        if (!createProfileResponse.ok) {
          const errorText = await createProfileResponse.text();
          throw new Error(`Failed to create profile: ${errorText} (Status: ${createProfileResponse.status})`);
        }
        
        console.log(`Created new profile for user ${userId} with ${creditAmount} credits`);
        return true;
      }
      
      const currentCredits = profiles[0].credits || 0;
      console.log(`Current credits for user ${userId}: ${currentCredits}`);
      
      // Now update the credits with addition
      console.log(`Updating credits from ${currentCredits} to ${currentCredits + creditAmount}`);
      const updateResponse = await fetch(`${supabaseUrl}/rest/v1/profiles?id=eq.${userId}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${supabaseKey}`,
          'apikey': supabaseKey,
          'Prefer': 'return=minimal'
        },
        body: JSON.stringify({
          credits: currentCredits + creditAmount
        })
      });
      
      if (!updateResponse.ok) {
        const errorText = await updateResponse.text();
        throw new Error(`Failed to update credits: ${errorText} (Status: ${updateResponse.status})`);
      }
      
      // Verify the update was successful
      const verifyResponse = await fetch(`${supabaseUrl}/rest/v1/profiles?id=eq.${userId}&select=credits`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${supabaseKey}`,
          'apikey': supabaseKey
        }
      });
      
      if (!verifyResponse.ok) {
        throw new Error(`Failed to verify credit update (Status: ${verifyResponse.status})`);
      }
      
      const updatedProfiles = await verifyResponse.json();
      const newCredits = updatedProfiles[0].credits;
      
      if (newCredits !== currentCredits + creditAmount) {
        console.warn(`Credit verification failed! Expected ${currentCredits + creditAmount} but got ${newCredits}`);
      } else {
        console.log(`✅ Credit update verified! New balance: ${newCredits}`);
      }
      
      return true;
    } catch (error) {
      lastError = error;
      console.error(`Attempt ${retryCount + 1}/${MAX_RETRIES} failed: ${error.message}`);
      retryCount++;
      
      if (retryCount < MAX_RETRIES) {
        // Exponential backoff: 1s, 2s, 4s...
        const delay = 1000 * Math.pow(2, retryCount - 1);
        console.log(`Retrying in ${delay}ms...`);
        await new Promise(resolve => setTimeout(resolve, delay));
      }
    }
  }
  
  console.error(`All ${MAX_RETRIES} attempts to update user credits failed. Last error: ${lastError?.message}`);
  return false;
};
