
import { corsHeaders, ENV_VARS } from "./config.ts";

// Environment validation
export const getRequiredEnvVar = (name: string): string => {
  const value = Deno.env.get(name);
  if (!value) {
    throw new Error(`Missing ${name} in environment variables`);
  }
  return value;
};

// Response helper functions
export const createResponse = (data: any, status = 200) => {
  return new Response(
    JSON.stringify(data),
    { status, headers: { ...corsHeaders, "Content-Type": "application/json" } }
  );
};

export const errorResponse = (message: string, status = 400) => {
  console.error(`Error: ${message}`);
  return createResponse({ error: message }, status);
};

// Helper function to log events with environment information
export const logEventProcessing = (eventType: string, metadata: any = {}) => {
  const stripeKey = Deno.env.get(ENV_VARS.STRIPE_SECRET_KEY) || '';
  const mode = stripeKey.startsWith('sk_test_') ? 'TEST MODE' : 'LIVE MODE';
  
  console.log(`[${mode}] Processing ${eventType} event:`, JSON.stringify(metadata, null, 2));
};
