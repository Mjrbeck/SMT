import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@12.0.0?target=deno";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }
  
  try {
    // Validate Stripe signature
    const signature = req.headers.get('stripe-signature');
    if (!signature) {
      console.error("Missing Stripe signature");
      return new Response('Missing Stripe signature', { status: 400 });
    }
    
    // Get the raw request body
    const body = await req.text();
    
    // Initialize Stripe
    const stripeSecretKey = Deno.env.get('STRIPE_SECRET_KEY');
    const webhookSecret = Deno.env.get('STRIPE_WEBHOOK_SECRET');
    
    if (!stripeSecretKey || !webhookSecret) {
      console.error("Missing Stripe configuration");
      return new Response('Missing Stripe configuration', { status: 500 });
    }
    
    const stripe = new Stripe(stripeSecretKey, {
      apiVersion: '2023-10-16',
    });
    
    // Verify the webhook signature
    let event;
    try {
      event = stripe.webhooks.constructEvent(body, signature, webhookSecret);
      console.log(`🔔 Webhook event verified: ${event.type} with ID ${event.id}`);
    } catch (err) {
      console.error(`Webhook signature verification failed: ${err.message}`);
      return new Response(`Webhook signature verification failed: ${err.message}`, { status: 400 });
    }
    
    // Initialize Supabase client with service role key
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
      { auth: { persistSession: false } }
    );
    
    // Handle checkout.session.completed events
    if (event.type === 'checkout.session.completed') {
      const session = event.data.object;
      console.log("🔔 Processing checkout.session.completed event");
      console.log("Payment status:", session.payment_status);
      console.log("Session metadata:", JSON.stringify(session.metadata, null, 2));
      console.log("Session ID:", session.id);
      console.log("Payment intent:", session.payment_intent);
      
      // In test mode, we also process 'unpaid' status as Stripe test payments may show as unpaid
      const isTestMode = session.livemode === false;
      const shouldProcess = session.payment_status === 'paid' || (isTestMode && session.metadata?.userId);
      
      if (shouldProcess) {
        const metadata = session.metadata || {};
        const userId = metadata.userId;
        const creditAmount = metadata.creditAmount ? parseInt(metadata.creditAmount) : null;
        const paymentIntentId = session.payment_intent || `session_${session.id}`;
        
        if (!userId || !creditAmount) {
          console.error(`Missing required metadata. userId: ${userId}, creditAmount: ${creditAmount}`);
          return new Response('Missing required metadata', { status: 400 });
        }
        
        console.log(`🔔 Processing payment for user ${userId}, adding ${creditAmount} credits`);
        
        try {
          // Add credits to user profile
          const { error: addCreditsError } = await supabase.rpc('add_credits', {
            user_id: userId,
            credit_amount: creditAmount
          });
          
          if (addCreditsError) {
            console.error("Error adding credits:", addCreditsError);
            return new Response('Failed to add credits', { status: 500 });
          }
          
          // Create transaction record
          const { error: transactionError } = await supabase
            .from('credits_transactions')
            .update({
              status: 'completed',
              payment_intent_id: paymentIntentId
            })
            .eq('user_id', userId)
            .eq('amount', creditAmount)
            .eq('status', 'pending')
            .order('created_at', { ascending: false })
            .limit(1);
          
          if (transactionError) {
            console.error("Error updating transaction:", transactionError);
            // Don't fail the whole operation if just the transaction update fails
          }
          
          console.log(`✅ Successfully processed payment: ${creditAmount} credits added to user ${userId}`);
          
          return new Response(JSON.stringify({ 
            received: true, 
            processed: true, 
            message: `Payment for ${creditAmount} credits processed successfully`
          }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
            status: 200,
          });
        } catch (error) {
          console.error("Error processing payment:", error);
          return new Response('Error processing payment', { status: 500 });
        }
      } else {
        console.log(`Payment not complete yet. Status: ${session.payment_status}`);
        return new Response(JSON.stringify({ 
          received: true, 
          processed: false, 
          message: `Payment status is ${session.payment_status}, not processed`
        }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 200,
        });
      }
    }
    
    // Handle payment_intent.succeeded events
    if (event.type === 'payment_intent.succeeded') {
      const paymentIntent = event.data.object;
      console.log("Payment intent succeeded:", paymentIntent.id);
      console.log("Payment intent metadata:", paymentIntent.metadata);
      
      const metadata = paymentIntent.metadata || {};
      const userId = metadata.userId;
      const creditAmount = metadata.creditAmount ? parseInt(metadata.creditAmount) : null;
      
      if (!userId || !creditAmount) {
        console.error(`Missing required metadata in payment intent. userId: ${userId}, creditAmount: ${creditAmount}`);
        return new Response('Missing required metadata', { status: 400 });
      }
      
      console.log(`🔔 Processing payment intent for user ${userId}, adding ${creditAmount} credits`);
      
      try {
        // Add credits to user profile
        const { error: addCreditsError } = await supabase.rpc('add_credits', {
          user_id: userId,
          credit_amount: creditAmount
        });
        
        if (addCreditsError) {
          console.error("Error adding credits:", addCreditsError);
          return new Response('Failed to add credits', { status: 500 });
        }
        
        // Create transaction record
        const { error: transactionError } = await supabase
          .from('credits_transactions')
          .update({
            status: 'completed',
            payment_intent_id: paymentIntent.id
          })
          .eq('user_id', userId)
          .eq('amount', creditAmount)
          .eq('status', 'pending')
          .order('created_at', { ascending: false })
          .limit(1);
        
        if (transactionError) {
          console.error("Error updating transaction:", transactionError);
          // Don't fail the whole operation if just the transaction update fails
        }
        
        console.log(`✅ Successfully processed payment intent: ${creditAmount} credits added to user ${userId}`);
        
        return new Response(JSON.stringify({ 
          received: true, 
          processed: true, 
          message: `Payment intent for ${creditAmount} credits processed successfully`
        }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 200,
        });
      } catch (error) {
        console.error("Error processing payment intent:", error);
        return new Response('Error processing payment intent', { status: 500 });
      }
    }
    
    // For any other event type, just acknowledge receipt
    console.log(`Event type ${event.type} received but not processed`);
    return new Response(JSON.stringify({ 
      received: true, 
      processed: false, 
      message: `Event type ${event.type} not processed` 
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 200,
    });
    
  } catch (error) {
    console.error(`Webhook handler error: ${error.message}`);
    return new Response(`Webhook error: ${error.message}`, { status: 500 });
  }
});