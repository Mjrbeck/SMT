
import { updateTransactionStatus, callDatabaseFunction, updateUserCredits, createCreditsTransaction } from "./supabaseClient.ts";
import { ENV_VARS } from "./config.ts";
import { getRequiredEnvVar } from "./utils.ts";

// Process a successful payment by adding credits to user account
export const processSuccessfulPayment = async (paymentIntentId: string, userId: string, creditAmount: number): Promise<boolean> => {
  console.log(`Processing successful payment for user ${userId}, adding ${creditAmount} credits`);

  try {
    // Calculate cost in pence (assuming £10.00 per credit)
    const costPence = creditAmount * 1000; // £10.00 per credit = 1000 pence per credit
    
    // Attempt different strategies to update user credits, in order of preference
    
    // First attempt: Use the database function
    console.log("Attempt 1: Using 'add_credits' database function");
    const dbFunctionSuccess = await callDatabaseFunction('add_credits', {
      user_id: userId,
      credit_amount: creditAmount
    });
    
    if (dbFunctionSuccess) {
      console.log(`Successfully added ${creditAmount} credits using database function`);
      
      // Create/update the credits transaction record
      await createCreditsTransaction(paymentIntentId, userId, creditAmount, costPence);
      
      // Update transaction status if it exists in the old transactions table
      await updateTransactionStatus(paymentIntentId, 'completed');
      return true;
    }
    
    // Second attempt: Direct update using REST API
    console.log("Attempt 2: Using direct profile update via REST API");
    const directUpdateSuccess = await updateUserCredits(userId, creditAmount);
    
    if (directUpdateSuccess) {
      console.log(`Successfully added ${creditAmount} credits using direct update`);
      
      // Create/update the credits transaction record
      await createCreditsTransaction(paymentIntentId, userId, creditAmount, costPence);
      
      // Update transaction status if it exists in the old transactions table
      await updateTransactionStatus(paymentIntentId, 'completed');
      return true;
    }
    
    // If both attempts failed, log the error and return false
    console.error(`All attempts to add credits failed for user ${userId}`);
    return false;
  } catch (error) {
    console.error(`Error in processSuccessfulPayment: ${error.message}`);
    return false;
  }
};

// Process a successful subscription by adding subscription record
export const processSuccessfulSubscription = async (
  subscriptionId: string, 
  customerId: string,
  userId: string, 
  tierId: string,
  credits: number
): Promise<boolean> => {
  console.log(`Processing subscription ${subscriptionId} for user ${userId}, tier ${tierId}`);
  
  try {
    const supabaseUrl = getRequiredEnvVar(ENV_VARS.SUPABASE_URL);
    const supabaseKey = getRequiredEnvVar(ENV_VARS.SUPABASE_SERVICE_ROLE_KEY);
    
    // Check if a subscription record already exists for this user
    const checkResponse = await fetch(`${supabaseUrl}/rest/v1/subscriptions?user_id=eq.${userId}`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${supabaseKey}`,
        'apikey': supabaseKey
      }
    });
    
    if (!checkResponse.ok) {
      throw new Error(`Failed to check subscription: ${await checkResponse.text()}`);
    }
    
    const existingSubscriptions = await checkResponse.json();
    
    // If subscription exists, update it
    if (existingSubscriptions.length > 0) {
      const updateResponse = await fetch(`${supabaseUrl}/rest/v1/subscriptions?user_id=eq.${userId}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${supabaseKey}`,
          'apikey': supabaseKey,
          'Prefer': 'return=minimal'
        },
        body: JSON.stringify({
          subscription_id: subscriptionId,
          customer_id: customerId,
          tier: tierId,
          status: 'active',
          credits_per_cycle: credits,
          updated_at: new Date().toISOString()
        })
      });
      
      if (!updateResponse.ok) {
        throw new Error(`Failed to update subscription: ${await updateResponse.text()}`);
      }
      
    } else {
      // Create new subscription record
      const createResponse = await fetch(`${supabaseUrl}/rest/v1/subscriptions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${supabaseKey}`,
          'apikey': supabaseKey,
          'Prefer': 'return=minimal'
        },
        body: JSON.stringify({
          user_id: userId,
          subscription_id: subscriptionId,
          customer_id: customerId,
          tier: tierId,
          status: 'active',
          credits_per_cycle: credits,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        })
      });
      
      if (!createResponse.ok) {
        throw new Error(`Failed to create subscription: ${await createResponse.text()}`);
      }
    }
    
    // Also add initial credits for the first month
    const creditSuccess = await processSuccessfulPayment(`subscription_${subscriptionId}`, userId, credits);
    if (!creditSuccess) {
      console.warn(`Failed to add initial subscription credits for user ${userId}`);
    }
    
    return true;
  } catch (error) {
    console.error(`Error in processSuccessfulSubscription: ${error.message}`);
    return false;
  }
};
