
import { processSuccessfulPayment, processSuccessfulSubscription } from "./paymentProcessor.ts";
import { createResponse, errorResponse } from "./utils.ts";

// Stripe event handler
export const handleStripeEvent = async (event: any) => {
  console.log(`🔔 Processing ${event.type} event with ID ${event.id}`);
  console.log(`Event object keys:`, Object.keys(event));
  console.log(`Event data object keys:`, Object.keys(event.data?.object || {}));
  
  try {
    // Handle checkout.session.completed events
    if (event.type === 'checkout.session.completed') {
      const session = event.data.object;
      console.log("Payment status:", session.payment_status);
      console.log("Session metadata:", session.metadata);
      
      // Important: In test mode, we need to handle 'unpaid' status as well
      // This is because test payments may have payment_status 'unpaid' but still need to be processed
      const isTestMode = session.livemode === false;
      const shouldProcessTestPayment = isTestMode && session.metadata?.userId && session.metadata?.creditAmount;
      
      // For checkout.session.completed, we check the payment status
      if (session.payment_status === 'paid' || shouldProcessTestPayment) {
        const metadata = session.metadata || {};
        const userId = metadata.userId;
        const creditAmount = metadata.creditAmount ? parseInt(metadata.creditAmount) : null;
        const paymentIntentId = session.payment_intent || `test_session_${session.id}`;
        
        if (!userId || !creditAmount) {
          return errorResponse(`Missing required metadata in session. userId: ${userId}, creditAmount: ${creditAmount}`);
        }
        
        console.log(`🔔 DETECTED PAID CHECKOUT SESSION: Processing payment for user ${userId}, adding ${creditAmount} credits`);
        console.log(`Test mode: ${isTestMode}, Payment Status: ${session.payment_status}`);
        
        try {
          // Process the payment - Pass the exact credit amount from metadata
          const success = await processSuccessfulPayment(paymentIntentId, userId, creditAmount);
          
          if (success) {
            return createResponse({ 
              received: true, 
              processed: true, 
              message: `Payment for ${creditAmount} credits processed successfully for user ${userId}`,
              testMode: isTestMode
            });
          } else {
            return errorResponse("Failed to process payment: All payment processing methods failed", 500);
          }
        } catch (error) {
          return errorResponse(`Error processing payment: ${error.message}`, 500);
        }
      } else {
        console.log(`Payment not complete yet. Status: ${session.payment_status}`);
        return createResponse({ 
          received: true, 
          processed: false, 
          message: `Payment status is ${session.payment_status}, not processed`,
          testMode: session.livemode === false
        });
      }
    }
    
    // Handle payment_intent.succeeded events for direct payment confirmations
    if (event.type === 'payment_intent.succeeded') {
      const paymentIntent = event.data.object;
      console.log("Payment intent succeeded:", paymentIntent.id);
      console.log("Payment intent metadata:", paymentIntent.metadata);
      
      const metadata = paymentIntent.metadata || {};
      const userId = metadata.userId;
      const creditAmount = metadata.creditAmount ? parseInt(metadata.creditAmount) : null;
      
      if (!userId || !creditAmount) {
        return errorResponse(`Missing required metadata in payment intent. userId: ${userId}, creditAmount: ${creditAmount}`);
      }
      
      console.log(`🔔 DETECTED SUCCESSFUL PAYMENT INTENT: Processing payment for user ${userId}, adding ${creditAmount} credits`);
      
      try {
        // Process the payment - Pass the exact credit amount from metadata
        const success = await processSuccessfulPayment(paymentIntent.id, userId, creditAmount);
        
        if (success) {
          return createResponse({ 
            received: true, 
            processed: true, 
            message: `Payment intent ${paymentIntent.id} for ${creditAmount} credits processed successfully for user ${userId}`,
            testMode: paymentIntent.livemode === false
          });
        } else {
          return errorResponse("Failed to process payment: All payment processing methods failed", 500);
        }
      } catch (error) {
        return errorResponse(`Error processing payment intent: ${error.message}`, 500);
      }
    }

    // Handle invoice.payment_succeeded events for subscription renewals
    if (event.type === 'invoice.payment_succeeded') {
      const invoice = event.data.object;
      console.log("Invoice payment succeeded:", invoice.id);
      
      // Make sure this is a subscription invoice
      if (invoice.subscription) {
        console.log("Processing subscription invoice:", invoice.subscription);
        
        try {
          // Get the subscription details to find the customer and plan info
          const stripeSecretKey = Deno.env.get('STRIPE_SECRET_KEY');
          if (!stripeSecretKey) {
            return errorResponse("Stripe secret key not found");
          }
          
          // Initialize Stripe
          const stripe = new Stripe(stripeSecretKey, {
            apiVersion: '2023-10-16',
          });
          
          // Get the subscription
          const subscription = await stripe.subscriptions.retrieve(invoice.subscription);
          const customerId = subscription.customer as string;
          
          // Find the subscription in our database to get user ID
          const supabaseUrl = Deno.env.get('SUPABASE_URL');
          const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
          
          if (!supabaseUrl || !supabaseKey) {
            return errorResponse("Supabase configuration missing");
          }
          
          // Get subscription record by subscription ID
          const subscriptionResponse = await fetch(`${supabaseUrl}/rest/v1/subscriptions?subscription_id=eq.${invoice.subscription}`, {
            method: 'GET',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${supabaseKey}`,
              'apikey': supabaseKey
            }
          });
          
          if (!subscriptionResponse.ok) {
            throw new Error(`Failed to get subscription: ${await subscriptionResponse.text()}`);
          }
          
          const subscriptionData = await subscriptionResponse.json();
          
          if (!subscriptionData || subscriptionData.length === 0) {
            return errorResponse(`No subscription found with ID ${invoice.subscription}`);
          }
          
          const userId = subscriptionData[0].user_id;
          const creditsPerCycle = subscriptionData[0].credits_per_cycle;
          
          if (!userId || !creditsPerCycle) {
            return errorResponse(`Missing user_id or credits_per_cycle in subscription data`);
          }
          
          console.log(`🔄 RECURRING SUBSCRIPTION PAYMENT: Adding ${creditsPerCycle} credits to user ${userId}`);
          
          // Add credits to user account - use the subscription ID as payment intent ID with a prefix
          const success = await processSuccessfulPayment(`subscription_renewal_${invoice.id}`, userId, creditsPerCycle);
          
          if (success) {
            return createResponse({ 
              received: true, 
              processed: true, 
              message: `Subscription renewal processed: ${creditsPerCycle} credits added to user ${userId}`,
              testMode: invoice.livemode === false
            });
          } else {
            return errorResponse("Failed to process subscription renewal payment", 500);
          }
        } catch (error) {
          console.error(`Error processing subscription invoice: ${error.message}`, error);
          return errorResponse(`Error processing subscription invoice: ${error.message}`, 500);
        }
      }
    }
    
    // For any other event type, just acknowledge receipt but don't process
    console.log(`Event type ${event.type} not processed`);
    return createResponse({ received: true, processed: false, message: `Event type ${event.type} not processed` });
  } catch (error) {
    console.error(`Error in handleStripeEvent: ${error.message}`);
    return errorResponse(`Unhandled error: ${error.message}`, 500);
  }
};
