import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  console.log('🚀 Vehicle-prerender function called')
  console.log('📍 Request URL:', req.url)
  console.log('🔍 Request method:', req.method)
  
  const userAgent = req.headers.get('user-agent') || ''
  console.log('👤 User agent:', userAgent)
  console.log('🤖 User agent length:', userAgent.length)
  console.log('🔍 Contains facebook:', userAgent.toLowerCase().includes('facebook'))
  console.log('🔍 Contains externalhit:', userAgent.toLowerCase().includes('externalhit'))

  // Handle CORS
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  // Enhanced bot detection for search engines and social media
  const isSocialBot = /googlebot|bingbot|slurp|duckduckbot|baiduspider|yandexbot|facebookexternalhit|facebot|twitterbot|linkedinbot|whatsapp|telegram|discord|slack|bot|crawler|spider|scraper|facebook|twitter|instagram|pinterest|reddit|ia_archiver/i.test(userAgent)
  
  console.log('🤖 Is social bot:', isSocialBot)
  
  // For regular users, redirect to React app
  if (!isSocialBot) {
    console.log('👨‍💻 Regular user - redirecting to React app')
    const url = new URL(req.url)
    const vehicleId = url.pathname.split('/').pop()
    const redirectUrl = `https://source-my-truck.vercel.app/vehicle/${vehicleId}`
    
    return new Response(null, {
      status: 302,
      headers: {
        ...corsHeaders,
        'Location': redirectUrl,
        'Cache-Control': 'no-cache'
      }
    })
  }
  
  console.log('🤖 Social bot detected - serving HTML')

  try {
    const url = new URL(req.url)
    const pathSegments = url.pathname.split('/')
    const vehicleId = pathSegments[pathSegments.length - 1]

    console.log('🚗 Vehicle ID extracted:', vehicleId)

    if (!vehicleId || vehicleId === 'vehicle-prerender') {
      console.log('❌ No valid vehicle ID provided')
      return new Response('Vehicle ID not provided', { status: 400, headers: corsHeaders })
    }

    // Initialize Supabase client
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    const supabase = createClient(supabaseUrl, supabaseServiceKey)

    console.log('📡 Fetching vehicle data from Supabase...')

    // Fetch vehicle data
    const { data: vehicle, error } = await supabase
      .from('vehicles')
      .select(`
        *,
        vehicle_images(*)
      `)
      .eq('id', vehicleId)
      .eq('status', 'active')
      .maybeSingle()

    if (error) {
      console.error('❌ Supabase error:', error)
      return new Response('Database error', { status: 500, headers: corsHeaders })
    }

    if (!vehicle) {
      console.log('❌ Vehicle not found - redirecting to 404')
      // For bots, return a simple 404 page, for users redirect to main site
      if (isSocialBot) {
        return new Response('Vehicle not found', { status: 404, headers: corsHeaders })
      } else {
        return new Response(null, {
          status: 302,
          headers: {
            ...corsHeaders,
            'Location': 'https://source-my-truck.vercel.app/',
            'Cache-Control': 'no-cache'
          }
        })
      }
    }

    console.log('✅ Vehicle found:', vehicle.title)

    // Extract main image URL
    let mainImageUrl = 'https://source-my-truck.vercel.app/source-my-truck-logo.png'
    
    if (vehicle.vehicle_images && vehicle.vehicle_images.length > 0) {
      // Find main image
      const mainImage = vehicle.vehicle_images.find((img: any) => img.is_main === true)
      if (mainImage?.image_url) {
        mainImageUrl = mainImage.image_url
        console.log('🖼️ Using main image:', mainImageUrl)
      } else if (vehicle.vehicle_images[0]?.image_url) {
        // Fallback to first image
        mainImageUrl = vehicle.vehicle_images[0].image_url
        console.log('🖼️ Using first image:', mainImageUrl)
      }
    }

    // Format vehicle details
    const vehicleTitle = `${vehicle.year} ${vehicle.make} ${vehicle.model || ''}`.trim()
    const priceDisplay = vehicle.is_poa ? 'POA' : `£${vehicle.price?.toLocaleString()}`
    const mileageText = vehicle.mileage ? `${vehicle.mileage.toLocaleString()} miles` : ''
    const engineText = vehicle.engine_size ? `${vehicle.engine_size}` : ''
    const fuelText = vehicle.fuel_type ? `${vehicle.fuel_type}` : ''
    
    const description = [mileageText, engineText, fuelText]
      .filter(Boolean)
      .join(', ') + '. Available now on Source My Truck.'

    const fullTitle = `${vehicleTitle} - ${priceDisplay}`
    const vehicleUrl = `https://source-my-truck.vercel.app/vehicle/${vehicleId}`

    console.log('📝 Generated title:', fullTitle)
    console.log('🔗 Vehicle URL:', vehicleUrl)
    
    // Generate complete HTML response optimized for SEO and social sharing
    const html = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${fullTitle} | Source my Truck</title>
    <meta name="description" content="${description}" />
    <meta name="keywords" content="${vehicle.make}, ${vehicle.model || ''}, commercial vehicle, ${vehicle.body_type || ''}, truck for sale" />
    <meta name="robots" content="index, follow" />
    
    <!-- Open Graph Meta Tags -->
    <meta property="og:title" content="${fullTitle}" />
    <meta property="og:description" content="${description}" />
    <meta property="og:image" content="${mainImageUrl}" />
    <meta property="og:image:secure_url" content="${mainImageUrl}" />
    <meta property="og:image:width" content="1200" />
    <meta property="og:image:height" content="628" />
    <meta property="og:image:alt" content="${vehicleTitle} - Commercial Vehicle for Sale" />
    <meta property="og:url" content="${vehicleUrl}" />
    <meta property="og:type" content="product" />
    <meta property="og:site_name" content="Source my Truck" />
    <meta property="product:price:amount" content="${vehicle.price}" />
    <meta property="product:price:currency" content="GBP" />
    
    <!-- Twitter Card Meta Tags -->
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:site" content="@sourcemytruck" />
    <meta name="twitter:title" content="${fullTitle}" />
    <meta name="twitter:description" content="${description}" />
    <meta name="twitter:image" content="${mainImageUrl}" />
    <meta name="twitter:image:alt" content="${vehicleTitle} - Commercial Vehicle for Sale" />
    <meta name="twitter:url" content="${vehicleUrl}" />
    
    <!-- Canonical URL -->
    <link rel="canonical" href="${vehicleUrl}" />
    
    <!-- Favicon -->
    <link rel="icon" href="https://source-my-truck.vercel.app/lovable-uploads/f09b9e95-9ff8-4f42-abac-98f2720b5949.png" type="image/png" />
    
    <!-- Schema.org structured data -->
    <script type="application/ld+json">
    {
      "@context": "https://schema.org/",
      "@type": "Vehicle",
      "name": "${vehicleTitle}",
      "description": "${description}",
      "brand": {
        "@type": "Brand",
        "name": "${vehicle.make}"
      },
      "model": "${vehicle.model || ''}",
      "vehicleYear": ${vehicle.year},
      "mileageFromOdometer": {
        "@type": "QuantitativeValue",
        "value": ${vehicle.mileage || 0},
        "unitCode": "SMI"
      },
      "offers": {
        "@type": "Offer",
        "price": "${vehicle.price}",
        "priceCurrency": "GBP",
        "availability": "https://schema.org/InStock",
        "seller": {
          "@type": "Organization",
          "name": "Source my Truck"
        }
      },
      "image": "${mainImageUrl}",
      "url": "${vehicleUrl}"
    }
    </script>
    
    <!-- Redirect browsers to main site after crawlers read content -->
    <script>
      setTimeout(function() {
        if (!/googlebot|bingbot|bot|crawler|spider|facebookexternalhit|twitterbot|linkedinbot/i.test(navigator.userAgent)) {
          window.location.replace('https://source-my-truck.vercel.app/vehicle/${vehicleId}');
        }
      }, 2000);
    </script>
</head>
<body>
    <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; line-height: 1.6;">
        <header>
            <h1 style="color: #1a365d; margin-bottom: 10px;">${fullTitle}</h1>
            <p style="color: #666; margin-bottom: 20px;">Commercial Vehicle for Sale | Source my Truck</p>
        </header>
        
        <main>
            <img src="${mainImageUrl}" alt="${vehicleTitle}" style="max-width: 100%; height: auto; border-radius: 8px; margin-bottom: 20px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);" />
            
            <section style="background: #f7fafc; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
                <h2 style="color: #2d3748; margin-top: 0;">Vehicle Details</h2>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px;">
                    <div><strong>Make:</strong> ${vehicle.make}</div>
                    ${vehicle.model ? `<div><strong>Model:</strong> ${vehicle.model}</div>` : ''}
                    <div><strong>Year:</strong> ${vehicle.year}</div>
                    ${vehicle.mileage ? `<div><strong>Mileage:</strong> ${vehicle.mileage.toLocaleString()} miles</div>` : ''}
                    ${vehicle.engine_size ? `<div><strong>Engine Size:</strong> ${vehicle.engine_size}</div>` : ''}
                    ${vehicle.fuel_type ? `<div><strong>Fuel Type:</strong> ${vehicle.fuel_type}</div>` : ''}
                    ${vehicle.body_type ? `<div><strong>Body Type:</strong> ${vehicle.body_type}</div>` : ''}
                    <div><strong>Price:</strong> <span style="color: #e53e3e; font-weight: bold;">${priceDisplay}</span></div>
                </div>
            </section>
            
            <section>
                <p style="margin-bottom: 20px;">${description}</p>
                <a href="${vehicleUrl}" style="display: inline-block; background: #3182ce; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; font-weight: bold;">View Full Details</a>
            </section>
        </main>
        
        <footer style="margin-top: 40px; padding-top: 20px; border-top: 1px solid #e2e8f0; text-align: center; color: #666;">
            <p>This vehicle is listed on <a href="https://source-my-truck.vercel.app" style="color: #3182ce;">Source my Truck</a> - The UK's leading marketplace for commercial vehicles.</p>
        </footer>
    </div>
</body>
</html>`

    console.log('🎯 Returning HTML response')

    return new Response(html, {
      headers: {
        ...corsHeaders,
        'content-type': 'text/html; charset=utf-8',
        'cache-control': 'public, max-age=300', // Cache for 5 minutes
      },
    })

  } catch (error) {
    console.error('💥 Error in vehicle-prerender function:', error)
    return new Response(`Internal server error: ${error.message}`, { 
      status: 500,
      headers: corsHeaders 
    })
  }
})