
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@12.0.0?target=deno";

// CORS headers for cross-origin requests
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

// Helper to determine if we're in test mode
const isTestMode = (): boolean => {
  const stripeKey = Deno.env.get('STRIPE_SECRET_KEY') || '';
  return stripeKey.startsWith('sk_test_');
};

// Response helper functions
const createResponse = (data: any, status = 200) => {
  return new Response(
    JSON.stringify(data),
    { status, headers: { ...corsHeaders, "Content-Type": "application/json" } }
  );
};

const errorResponse = (message: string, status = 400) => {
  console.error(`Error: ${message}`);
  return createResponse({ error: message }, status);
};

// Environment validation
const getRequiredEnvVar = (name: string): string => {
  const value = Deno.env.get(name);
  if (!value) {
    throw new Error(`Missing ${name} in environment variables`);
  }
  return value;
};

// Supabase client function
const createTransactionRecord = async (
  supabaseUrl: string,
  supabaseKey: string,
  userId: string,
  amount: number,
  costPence: number,
  paymentIntentId: string | null
) => {
  console.log(`Creating transaction record for user ${userId}, amount: ${amount}, paymentIntentId: ${paymentIntentId}`);
  
  try {
    // Create record in credits_transactions table (the new standard)
    const creditsResponse = await fetch(`${supabaseUrl}/rest/v1/credits_transactions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${supabaseKey}`,
        'apikey': supabaseKey,
      },
      body: JSON.stringify({
        user_id: userId,
        amount: amount,
        cost_pence: costPence,
        status: 'pending',
        payment_intent_id: paymentIntentId,
      }),
    });
    
    if (!creditsResponse.ok) {
      const errorText = await creditsResponse.text();
      console.error(`Failed to create credits transaction record: ${errorText}`);
      // Don't fail the whole operation, try the legacy table
    } else {
      console.log("Credits transaction record created successfully");
    }

    // Also create record in legacy transactions table for backward compatibility
    const legacyResponse = await fetch(`${supabaseUrl}/rest/v1/transactions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${supabaseKey}`,
        'apikey': supabaseKey,
      },
      body: JSON.stringify({
        user_id: userId,
        amount: amount,
        cost_pence: costPence,
        status: 'pending',
        payment_intent_id: paymentIntentId,
      }),
    });
    
    if (!legacyResponse.ok) {
      const errorText = await legacyResponse.text();
      console.warn(`Failed to create legacy transaction record: ${errorText}`);
      // This is not critical since we have the credits_transactions record
    } else {
      console.log("Legacy transaction record created successfully");
    }
    
    return { success: true };
  } catch (error) {
    console.error(`Error creating transaction record: ${error.message}`);
    return { success: false, error: error.message };
  }
};

// Create Stripe checkout session
const createStripeCheckoutSession = async (
  stripe: Stripe,
  originUrl: string,
  amount: number,
  userId: string,
  pricePerCredit: number
) => {
  console.log(`Creating Stripe checkout session for user ${userId}, amount: ${amount}, price per credit: ${pricePerCredit}`);
  
  // Calculate price in pence (£ * 100)
  const unitAmount = Math.round(pricePerCredit * 100);
  const costPence = unitAmount * amount;
  
    // Create metadata for the session
    const metadata = {
      userId,
      creditAmount: amount.toString(), // Ensure it's a string for Stripe metadata
      pricePerCredit: pricePerCredit.toString(),
      isTest: isTestMode().toString()
    };
  
  try {
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items: [
        {
          price_data: {
            currency: 'gbp',
            product_data: {
              name: 'Credit Package',
              description: `${amount} credits for your truck listings`,
            },
            unit_amount: unitAmount, // Price per credit in pence
          },
          quantity: amount, // The number of credits they're purchasing
        },
      ],
      mode: 'payment',
      // Update the URL to redirect to the settings page with the credits tab
      success_url: `${originUrl}/settings?tab=credits&success=true&session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${originUrl}/settings?tab=credits&canceled=true`,
      metadata,
    });
    
    return { 
      success: true, 
      session, 
      costPence 
    };
  } catch (error) {
    console.error(`Error creating Stripe checkout session: ${error.message}`);
    return { 
      success: false, 
      error: error.message 
    };
  }
};

// Main request handler
serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { 
      headers: corsHeaders,
      status: 204
    });
  }

  try {
    // Get required environment variables
    const stripeSecretKey = getRequiredEnvVar('STRIPE_SECRET_KEY');
    const supabaseUrl = getRequiredEnvVar('SUPABASE_URL');
    const supabaseKey = getRequiredEnvVar('SUPABASE_SERVICE_ROLE_KEY');
    
    // Initialize Stripe
    const stripe = new Stripe(stripeSecretKey, {
      apiVersion: '2023-10-16',
    });

    // Parse request body
    const requestData = await req.json();
    
    // Check if we're just checking the test mode
    if (requestData.checkTestMode) {
      return createResponse({ isTest: isTestMode() });
    }
    
    const { amount, userId, pricePerCredit = 10.00 } = requestData;
    
    // Validate request parameters
    if (!amount || amount < 1 || !userId) {
      console.error("Invalid request parameters", { amount, userId });
      return errorResponse("Invalid request parameters");
    }
    
    // Get origin URL for redirects
    const originUrl = req.headers.get('origin') || 'http://localhost:5173';
    
    // Create Stripe checkout session
    const sessionResult = await createStripeCheckoutSession(
      stripe, 
      originUrl, 
      amount, 
      userId, 
      pricePerCredit
    );
    
    if (!sessionResult.success) {
      return errorResponse(`Failed to create checkout session: ${sessionResult.error}`);
    }
    
    const { session, costPence } = sessionResult;
    
    // Create transaction record
    const transactionResult = await createTransactionRecord(
      supabaseUrl,
      supabaseKey,
      userId,
      amount,
      costPence,
      session.payment_intent as string || null
    );
    
    if (!transactionResult.success) {
      console.warn(`Failed to create transaction record: ${transactionResult.error}`);
      // Continue even if transaction record creation fails
      // The webhook will attempt to reconcile this
    }
    
    // For live mode, trim the success URL to avoid potential issues with long session IDs
    let successUrl = `${originUrl}/settings?tab=credits&success=true`;
    if (session.id && !isTestMode()) {
      // For live mode, we'll use a shorter session parameter to avoid URL length issues
      successUrl += '&session_id=' + session.id.substring(0, 40);
    } else {
      // In test mode, use the full session ID which is fine for testing
      successUrl += '&session_id={CHECKOUT_SESSION_ID}';
    }
    
    // Update the session with the new success URL if in live mode
    if (!isTestMode() && session.id) {
      try {
        await stripe.checkout.sessions.update(session.id, {
          success_url: successUrl
        });
        console.log("Updated session success URL for live mode");
      } catch (updateError) {
        console.warn(`Could not update session success URL: ${updateError.message}`);
        // Continue with original URL - this is not critical
      }
    }
    
    // Return checkout URL
    return createResponse({ 
      url: session.url,
      transactionId: session.payment_intent as string || null,
      isTest: isTestMode()
    });
    
  } catch (error) {
    console.error("Unhandled error:", error);
    return errorResponse(`Unhandled error: ${error.message}`, 500);
  }
});
