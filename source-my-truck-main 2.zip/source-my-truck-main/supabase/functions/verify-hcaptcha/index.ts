import { serve } from "https://deno.land/std@0.168.0/http/server.ts"

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const { token } = await req.json()
    
    if (!token) {
      return new Response(
        JSON.stringify({ 
          success: false, 
          error: 'hCaptcha token is required' 
        }),
        {
          status: 400,
          headers: { 
            ...corsHeaders,
            'Content-Type': 'application/json' 
          },
        }
      )
    }

    const hcaptchaSecretKey = Deno.env.get('HCAPTCHA_SECRET_KEY')
    
    if (!hcaptchaSecretKey) {
      console.error('HCAPTCHA_SECRET_KEY not found in environment variables')
      return new Response(
        JSON.stringify({ 
          success: false, 
          error: 'hCaptcha verification service not configured' 
        }),
        {
          status: 500,
          headers: { 
            ...corsHeaders,
            'Content-Type': 'application/json' 
          },
        }
      )
    }

    // Verify the hCaptcha token with hCaptcha's API
    const verifyResponse = await fetch('https://hcaptcha.com/siteverify', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: new URLSearchParams({
        secret: hcaptchaSecretKey,
        response: token,
      }),
    })

    const verifyData = await verifyResponse.json()
    
    console.log('hCaptcha verification response:', {
      success: verifyData.success,
      hostname: verifyData.hostname,
      timestamp: verifyData.challenge_ts,
      errorCodes: verifyData['error-codes']
    })

    if (verifyData.success) {
      return new Response(
        JSON.stringify({ 
          success: true,
          message: 'hCaptcha verification successful'
        }),
        {
          headers: { 
            ...corsHeaders,
            'Content-Type': 'application/json' 
          },
        }
      )
    } else {
      console.error('hCaptcha verification failed:', verifyData['error-codes'])
      return new Response(
        JSON.stringify({ 
          success: false, 
          error: 'hCaptcha verification failed',
          details: verifyData['error-codes']
        }),
        {
          status: 400,
          headers: { 
            ...corsHeaders,
            'Content-Type': 'application/json' 
          },
        }
      )
    }
  } catch (error) {
    console.error('Error in verify-hcaptcha function:', error)
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: 'Internal server error during hCaptcha verification' 
      }),
      {
        status: 500,
        headers: { 
          ...corsHeaders,
          'Content-Type': 'application/json' 
        },
      }
    )
  }
})