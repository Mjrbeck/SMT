-- Fix search_path security warnings for all database functions

-- 1. Fix handle_successful_payment function
CREATE OR REPLACE FUNCTION public.handle_successful_payment(payment_intent_id text, user_id uuid, credit_amount integer)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path = public
AS $function$
BEGIN
  -- Update transaction record status
  UPDATE transactions
  SET status = 'completed'
  WHERE payment_intent_id = handle_successful_payment.payment_intent_id;
  
  -- Add credits to user profile
  UPDATE profiles
  SET credits = credits + credit_amount
  WHERE id = user_id;
END;
$function$;

-- 2. Fix is_admin function
CREATE OR REPLACE FUNCTION public.is_admin(user_id uuid)
 RETURNS boolean
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path = public
AS $function$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = user_id AND role = 'administrator'
  );
END;
$function$;

-- 3. Fix decrement_credits function
CREATE OR REPLACE FUNCTION public.decrement_credits(amount integer)
 RETURNS integer
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path = public
AS $function$
DECLARE
  current_credits INTEGER;
  new_credits INTEGER;
BEGIN
  -- Get current user's credits
  SELECT credits INTO current_credits FROM profiles WHERE id = auth.uid();
  
  -- Calculate new credits value (never go below 0)
  new_credits := GREATEST(0, current_credits - amount);
  
  -- Update credits
  UPDATE profiles SET credits = new_credits WHERE id = auth.uid();
  
  -- Return new credits value
  RETURN new_credits;
END;
$function$;

-- 4. Fix set_blog_articles_updated_at function
CREATE OR REPLACE FUNCTION public.set_blog_articles_updated_at()
 RETURNS trigger
 LANGUAGE plpgsql
 SET search_path = public
AS $function$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$function$;

-- 5. Fix handle_new_user function
CREATE OR REPLACE FUNCTION public.handle_new_user()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path = public
AS $function$
BEGIN
  INSERT INTO public.profiles (id, company_name, credits, role)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'company_name', 'Unknown Company'),
    3,  -- Give 3 free credits on signup
    'seller' -- Default role for new users
  );
  RETURN NEW;
END;
$function$;

-- 6. Fix add_credits function
CREATE OR REPLACE FUNCTION public.add_credits(user_id uuid, credit_amount integer)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path = public
AS $function$
BEGIN
  UPDATE profiles
  SET credits = credits + credit_amount
  WHERE id = user_id;
END;
$function$;

-- 7. Fix has_enough_credits function
CREATE OR REPLACE FUNCTION public.has_enough_credits(user_id uuid)
 RETURNS boolean
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path = public
AS $function$
DECLARE
  user_credits INTEGER;
BEGIN
  SELECT credits INTO user_credits FROM profiles WHERE id = user_id;
  RETURN user_credits > 0;
END;
$function$;

-- 8. Fix deduct_credit_on_vehicle_create function
CREATE OR REPLACE FUNCTION public.deduct_credit_on_vehicle_create()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path = public
AS $function$
BEGIN
  -- Check if user has credits before deducting
  IF (SELECT credits FROM profiles WHERE id = NEW.user_id) > 0 THEN
    UPDATE profiles SET credits = credits - 1 WHERE id = NEW.user_id;
    RETURN NEW;
  ELSE
    RAISE EXCEPTION 'Not enough credits to create a vehicle listing';
  END IF;
END;
$function$;

-- 9. Fix set_updated_at function
CREATE OR REPLACE FUNCTION public.set_updated_at()
 RETURNS trigger
 LANGUAGE plpgsql
 SET search_path = public
AS $function$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$function$;