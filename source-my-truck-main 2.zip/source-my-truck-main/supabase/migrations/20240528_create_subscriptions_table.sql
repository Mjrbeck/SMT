
-- Create a table for subscriptions if it doesn't exist yet
CREATE TABLE IF NOT EXISTS public.subscriptions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users NOT NULL,
  subscription_id TEXT NOT NULL,
  customer_id TEXT NOT NULL,
  tier TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active',
  credits_per_cycle INTEGER NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Add index for faster lookups by subscription_id
CREATE INDEX IF NOT EXISTS subscriptions_subscription_id_idx ON public.subscriptions(subscription_id);

-- Add update trigger for updated_at timestamp
CREATE OR REPLACE TRIGGER set_subscriptions_updated_at
BEFORE UPDATE ON public.subscriptions
FOR EACH ROW
EXECUTE FUNCTION set_updated_at();

-- Add RLS policies
ALTER TABLE public.subscriptions ENABLE ROW LEVEL SECURITY;

-- Allow users to read their own subscriptions
CREATE POLICY "Users can view their own subscriptions"
ON public.subscriptions
FOR SELECT
USING (auth.uid() = user_id);

-- Only allow service role to insert/update/delete subscriptions
CREATE POLICY "Service role can manage subscriptions"
ON public.subscriptions
USING (auth.jwt() ->> 'role' = 'service_role');
