
-- Update trigger function to handle expiration date extension
CREATE OR REPLACE FUNCTION public.update_expires_at_on_reactivate()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- If the vehicle is being activated from a non-active state,
  -- update the expiration date to 30 days from now
  IF NEW.status = 'active' AND (OLD.status <> 'active' OR OLD.status IS NULL) THEN
    NEW.expires_at = NOW() + INTERVAL '30 days';
  END IF;
  
  RETURN NEW;
END;
$$;

-- Create trigger to update expires_at on vehicle status change if it doesn't exist
DROP TRIGGER IF EXISTS update_vehicle_expires_at ON public.vehicles;
CREATE TRIGGER update_vehicle_expires_at
BEFORE UPDATE ON public.vehicles
FOR EACH ROW
WHEN (NEW.status = 'active' AND (OLD.status <> 'active' OR OLD.status IS NULL))
EXECUTE FUNCTION public.update_expires_at_on_reactivate();
