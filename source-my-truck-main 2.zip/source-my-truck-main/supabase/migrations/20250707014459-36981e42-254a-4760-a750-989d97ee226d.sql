-- Drop the existing trigger first
DROP TRIGGER IF EXISTS delete_vehicle_image_trigger ON public.vehicle_images;

-- Update the function to use the correct approach for deleting from Supabase storage
CREATE OR REPLACE FUNCTION public.delete_vehicle_image_from_storage()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public', 'storage'
AS $function$
BEGIN
  -- Delete from storage.objects table directly using the image URL
  DELETE FROM storage.objects 
  WHERE bucket_id = 'vehicle-images' 
  AND name = regexp_replace(OLD.image_url, '.*/([^/]+)$', '\1');
  
  RETURN OLD;
END;
$function$;

-- Recreate the trigger
CREATE TRIGGER delete_vehicle_image_trigger
  AFTER DELETE ON public.vehicle_images
  FOR EACH ROW
  EXECUTE FUNCTION public.delete_vehicle_image_from_storage();