-- Update handle_new_user function to give 1 free credit instead of 3
CREATE OR REPLACE FUNCTION public.handle_new_user()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path = public
AS $function$
BEGIN
  INSERT INTO public.profiles (id, company_name, credits, role)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'company_name', 'Unknown Company'),
    1,  -- Give 1 free credit on signup
    'seller' -- Default role for new users
  );
  RETURN NEW;
END;
$function$;