-- Complete the most recent pending transaction
UPDATE credits_transactions 
SET status = 'completed', payment_intent_id = 'manual_completion_' || id::text
WHERE user_id = '41dcc080-8a7c-42bb-9df0-cfcbce7814bc' 
AND id = 'bf8368c5-e0e1-4f9a-b9c3-285e657c2086'
AND status = 'pending';

-- Add the credits to the user's profile (2 credits from the most recent transaction)
UPDATE profiles 
SET credits = credits + 2
WHERE id = '41dcc080-8a7c-42bb-9df0-cfcbce7814bc';