
-- Function to update transaction status
CREATE OR REPLACE FUNCTION update_transaction_status(payment_intent_id TEXT, new_status TEXT)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE transactions
  SET status = new_status
  WHERE payment_intent_id = update_transaction_status.payment_intent_id;
END;
$$;

-- Function to ensure payment is properly handled
CREATE OR REPLACE FUNCTION handle_successful_payment(payment_intent_id TEXT, user_id UUID, credit_amount INTEGER)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Update transaction status to completed
  UPDATE transactions
  SET status = 'completed'
  WHERE payment_intent_id = handle_successful_payment.payment_intent_id;
  
  -- Add credits to user
  UPDATE profiles
  SET credits = credits + credit_amount
  WHERE id = user_id;
END;
$$;
