-- Fix storage policy for trust application documents to match actual folder structure
DROP POLICY IF EXISTS "Users can upload their own trust documents" ON storage.objects;
DROP POLICY IF EXISTS "Users can view their own trust documents" ON storage.objects;

-- Create corrected policies that match the trust-documents/{user_id}/ folder structure
CREATE POLICY "Users can upload their own trust documents" 
ON storage.objects 
FOR INSERT 
WITH CHECK (bucket_id = 'documents' AND auth.uid()::text = (storage.foldername(name))[2]);

CREATE POLICY "Users can view their own trust documents" 
ON storage.objects 
FOR SELECT 
USING (bucket_id = 'documents' AND auth.uid()::text = (storage.foldername(name))[2]);