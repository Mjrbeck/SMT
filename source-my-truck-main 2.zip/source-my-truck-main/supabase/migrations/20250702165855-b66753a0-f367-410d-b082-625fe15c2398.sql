-- Update RLS policies for credits_transactions table to allow edge functions to insert and update
-- First, drop the restrictive policies that are preventing inserts
DROP POLICY IF EXISTS "Users can view their own transactions" ON public.credits_transactions;

-- Recreate the policy for users to view their own transactions
CREATE POLICY "Users can view their own transactions" 
ON public.credits_transactions 
FOR SELECT 
USING (auth.uid() = user_id);

-- Allow edge functions to insert new transactions (bypasses RLS)
CREATE POLICY "Service role can insert transactions" 
ON public.credits_transactions 
FOR INSERT 
WITH CHECK (true);

-- Allow edge functions to update transaction status (bypasses RLS)  
CREATE POLICY "Service role can update transactions" 
ON public.credits_transactions 
FOR UPDATE 
USING (true);