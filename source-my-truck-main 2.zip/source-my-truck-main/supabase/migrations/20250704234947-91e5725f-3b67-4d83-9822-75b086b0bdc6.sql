-- Add CASCADE delete for vehicle images when vehicles are deleted
ALTER TABLE public.vehicle_images DROP CONSTRAINT IF EXISTS vehicle_images_vehicle_id_fkey;
ALTER TABLE public.vehicle_images ADD CONSTRAINT vehicle_images_vehicle_id_fkey 
  FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON DELETE CASCADE;

-- Create function to delete image files from storage when vehicle_images records are deleted
CREATE OR REPLACE FUNCTION public.delete_vehicle_image_from_storage()
RETURNS TRIGGER AS $$
BEGIN
  -- Extract filename from the URL to delete from storage
  PERFORM 
    storage.delete_object('vehicle-images', 
      regexp_replace(OLD.image_url, '.*/([^/]+)$', '\1')
    );
  RETURN OLD;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger to delete storage files when vehicle_images records are deleted
DROP TRIGGER IF EXISTS delete_vehicle_image_storage_trigger ON public.vehicle_images;
CREATE TRIGGER delete_vehicle_image_storage_trigger
  AFTER DELETE ON public.vehicle_images
  FOR EACH ROW
  EXECUTE FUNCTION public.delete_vehicle_image_from_storage();

-- Create function to clean up orphaned vehicle images (images without associated vehicles)
CREATE OR REPLACE FUNCTION public.cleanup_orphaned_vehicle_images()
RETURNS void AS $$
BEGIN
  -- Delete vehicle_image records that reference non-existent vehicles
  DELETE FROM public.vehicle_images 
  WHERE vehicle_id NOT IN (SELECT id FROM public.vehicles);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;