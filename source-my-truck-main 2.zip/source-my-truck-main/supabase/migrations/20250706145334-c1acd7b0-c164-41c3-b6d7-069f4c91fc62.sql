-- Fix search_path security issue for trust applications function
CREATE OR REPLACE FUNCTION public.update_trust_applications_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public';