-- Complete the pending transaction for the user who just made a payment
-- Update the transaction status to completed and add credits to the user
UPDATE credits_transactions 
SET status = 'completed', payment_intent_id = 'manual_completion_' || id::text
WHERE user_id = '41dcc080-8a7c-42bb-9df0-cfcbce7814bc' 
AND status = 'pending' 
AND created_at::date = CURRENT_DATE;

-- Add the credits to the user's profile
UPDATE profiles 
SET credits = credits + 5
WHERE id = '41dcc080-8a7c-42bb-9df0-cfcbce7814bc';

-- Also update the legacy transactions table for consistency
UPDATE transactions 
SET status = 'completed', payment_intent_id = 'manual_completion_' || id::text
WHERE user_id = '41dcc080-8a7c-42bb-9df0-cfcbce7814bc' 
AND status = 'pending' 
AND created_at::date = CURRENT_DATE;