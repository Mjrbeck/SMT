-- Create trust applications table
CREATE TABLE public.trust_applications (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  full_name TEXT NOT NULL,
  company_name TEXT,
  business_email TEXT NOT NULL,
  company_registration_number TEXT,
  years_in_business INTEGER NOT NULL,
  website_or_social_links TEXT,
  phone_number TEXT,
  document_url TEXT,
  reason TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.trust_applications ENABLE ROW LEVEL SECURITY;

-- Create policies for user access
CREATE POLICY "Users can view their own applications" 
ON public.trust_applications 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own applications" 
ON public.trust_applications 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own applications" 
ON public.trust_applications 
FOR UPDATE 
USING (auth.uid() = user_id);

-- Create function to update timestamps
CREATE OR REPLACE FUNCTION public.update_trust_applications_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for automatic timestamp updates
CREATE TRIGGER update_trust_applications_updated_at
  BEFORE UPDATE ON public.trust_applications
  FOR EACH ROW
  EXECUTE FUNCTION public.update_trust_applications_updated_at();

-- Create index for better performance
CREATE INDEX idx_trust_applications_user_id ON public.trust_applications(user_id);
CREATE INDEX idx_trust_applications_status ON public.trust_applications(status);