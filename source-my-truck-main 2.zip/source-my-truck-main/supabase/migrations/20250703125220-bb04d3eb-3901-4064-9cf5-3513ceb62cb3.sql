-- First, let's check what foreign key constraints exist that reference auth.users
-- and fix them to use ON DELETE CASCADE

-- Drop and recreate foreign key constraints with CASCADE delete

-- 1. Profiles table - this should reference auth.users(id) with CASCADE
-- First check if constraint exists and drop it
ALTER TABLE public.profiles DROP CONSTRAINT IF EXISTS profiles_id_fkey;
-- Add the proper foreign key constraint with CASCADE
ALTER TABLE public.profiles ADD CONSTRAINT profiles_id_fkey 
  FOREIGN KEY (id) REFERENCES auth.users(id) ON DELETE CASCADE;

-- 2. Vehicles table - user_id should reference auth.users(id) with CASCADE  
ALTER TABLE public.vehicles DROP CONSTRAINT IF EXISTS vehicles_user_id_fkey;
ALTER TABLE public.vehicles ADD CONSTRAINT vehicles_user_id_fkey 
  FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;

-- 3. Messages table - sender_id and recipient_id should reference auth.users(id) with CASCADE
ALTER TABLE public.messages DROP CONSTRAINT IF EXISTS messages_sender_id_fkey;
ALTER TABLE public.messages DROP CONSTRAINT IF EXISTS messages_recipient_id_fkey;
ALTER TABLE public.messages ADD CONSTRAINT messages_sender_id_fkey 
  FOREIGN KEY (sender_id) REFERENCES auth.users(id) ON DELETE CASCADE;
ALTER TABLE public.messages ADD CONSTRAINT messages_recipient_id_fkey 
  FOREIGN KEY (recipient_id) REFERENCES auth.users(id) ON DELETE CASCADE;

-- 4. Transactions table - user_id should reference auth.users(id) with CASCADE
ALTER TABLE public.transactions DROP CONSTRAINT IF EXISTS transactions_user_id_fkey;
ALTER TABLE public.transactions ADD CONSTRAINT transactions_user_id_fkey 
  FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;

-- 5. Credits transactions table - user_id should reference auth.users(id) with CASCADE
ALTER TABLE public.credits_transactions DROP CONSTRAINT IF EXISTS credits_transactions_user_id_fkey;
ALTER TABLE public.credits_transactions ADD CONSTRAINT credits_transactions_user_id_fkey 
  FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;

-- 6. Chat sessions table - seller_id should reference auth.users(id) with CASCADE
ALTER TABLE public.chat_sessions DROP CONSTRAINT IF EXISTS chat_sessions_seller_id_fkey;
ALTER TABLE public.chat_sessions ADD CONSTRAINT chat_sessions_seller_id_fkey 
  FOREIGN KEY (seller_id) REFERENCES auth.users(id) ON DELETE CASCADE;

-- 7. Seller depots table - id should reference auth.users(id) with CASCADE
ALTER TABLE public.seller_depots DROP CONSTRAINT IF EXISTS seller_depots_id_fkey;
ALTER TABLE public.seller_depots ADD CONSTRAINT seller_depots_id_fkey 
  FOREIGN KEY (id) REFERENCES auth.users(id) ON DELETE CASCADE;

-- 8. Vehicle views table - viewer_id should reference auth.users(id) with CASCADE
ALTER TABLE public.vehicle_views DROP CONSTRAINT IF EXISTS vehicle_views_viewer_id_fkey;
ALTER TABLE public.vehicle_views ADD CONSTRAINT vehicle_views_viewer_id_fkey 
  FOREIGN KEY (viewer_id) REFERENCES auth.users(id) ON DELETE CASCADE;

-- Create RLS policies to allow service_role to delete records
-- This is needed for the auth.admin.deleteUser() function to work properly

-- Profiles table - allow service role to delete
DROP POLICY IF EXISTS "Service role can delete profiles" ON public.profiles;
CREATE POLICY "Service role can delete profiles" ON public.profiles
  FOR DELETE USING (true);

-- Vehicles table - allow service role to delete  
DROP POLICY IF EXISTS "Service role can delete vehicles" ON public.vehicles;
CREATE POLICY "Service role can delete vehicles" ON public.vehicles
  FOR DELETE USING (true);

-- Messages table - already has service role policy for all operations

-- Transactions table - allow service role to delete
DROP POLICY IF EXISTS "Service role can delete transactions" ON public.transactions;
CREATE POLICY "Service role can delete transactions" ON public.transactions
  FOR DELETE USING (true);

-- Credits transactions table - allow service role to delete
DROP POLICY IF EXISTS "Service role can delete credits_transactions" ON public.credits_transactions;
CREATE POLICY "Service role can delete credits_transactions" ON public.credits_transactions
  FOR DELETE USING (true);

-- Chat sessions table - allow service role to delete
DROP POLICY IF EXISTS "Service role can delete chat_sessions" ON public.chat_sessions;
CREATE POLICY "Service role can delete chat_sessions" ON public.chat_sessions
  FOR DELETE USING (true);

-- Seller depots table - allow service role to delete
DROP POLICY IF EXISTS "Service role can delete seller_depots" ON public.seller_depots;
CREATE POLICY "Service role can delete seller_depots" ON public.seller_depots
  FOR DELETE USING (true);

-- Vehicle views table - allow service role to delete
DROP POLICY IF EXISTS "Service role can delete vehicle_views" ON public.vehicle_views;
CREATE POLICY "Service role can delete vehicle_views" ON public.vehicle_views
  FOR DELETE USING (true);