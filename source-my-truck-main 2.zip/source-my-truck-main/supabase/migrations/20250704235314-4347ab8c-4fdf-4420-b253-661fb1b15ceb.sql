-- Fix security warnings by setting search_path for the functions

-- Update delete_vehicle_image_from_storage function with proper search_path
CREATE OR REPLACE FUNCTION public.delete_vehicle_image_from_storage()
RETURNS TRIGGER 
LANGUAGE plpgsql 
SECURITY DEFINER
SET search_path = public, storage
AS $$
BEGIN
  -- Extract filename from the URL to delete from storage
  PERFORM 
    storage.delete_object('vehicle-images', 
      regexp_replace(OLD.image_url, '.*/([^/]+)$', '\1')
    );
  RETURN OLD;
END;
$$;

-- Update cleanup_orphaned_vehicle_images function with proper search_path
CREATE OR REPLACE FUNCTION public.cleanup_orphaned_vehicle_images()
RETURNS void 
LANGUAGE plpgsql 
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Delete vehicle_image records that reference non-existent vehicles
  DELETE FROM public.vehicle_images 
  WHERE vehicle_id NOT IN (SELECT id FROM public.vehicles);
END;
$$;