-- First, drop the existing foreign key constraint
ALTER TABLE public.messages DROP CONSTRAINT IF EXISTS messages_vehicle_id_fkey;

-- Add the foreign key constraint back with CASCADE DELETE
ALTER TABLE public.messages 
ADD CONSTRAINT messages_vehicle_id_fkey 
FOREIGN KEY (vehicle_id) 
REFERENCES public.vehicles(id) 
ON DELETE CASCADE;