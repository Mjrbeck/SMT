-- Add trust and verification fields to profiles table
ALTER TABLE public.profiles 
ADD COLUMN is_trusted boolean DEFAULT false,
ADD COLUMN depot_verified boolean DEFAULT false;

-- Create an index for better performance when querying trusted sellers
CREATE INDEX idx_profiles_is_trusted ON public.profiles(is_trusted);
CREATE INDEX idx_profiles_depot_verified ON public.profiles(depot_verified);