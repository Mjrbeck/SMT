-- Complete the pending transactions for user 2fdd0783-7d0f-4e6a-9101-ba2bd9270e60
-- and add the corresponding credits to their account

-- First, get the total pending credits for this user
DO $$
DECLARE
    user_id_to_fix UUID := '2fdd0783-7d0f-4e6a-9101-ba2bd9270e60';
    total_pending_credits INTEGER;
BEGIN
    -- Calculate total pending credits
    SELECT COALESCE(SUM(amount), 0) INTO total_pending_credits
    FROM credits_transactions 
    WHERE user_id = user_id_to_fix AND status = 'pending';
    
    -- Update all pending transactions to completed
    UPDATE credits_transactions 
    SET status = 'completed'
    WHERE user_id = user_id_to_fix AND status = 'pending';
    
    -- Add the credits to the user's account
    UPDATE profiles 
    SET credits = credits + total_pending_credits
    WHERE id = user_id_to_fix;
    
    -- Log the operation
    RAISE NOTICE 'Fixed user %: completed % pending transactions and added % credits', 
        user_id_to_fix, 
        (SELECT COUNT(*) FROM credits_transactions WHERE user_id = user_id_to_fix AND status = 'completed'),
        total_pending_credits;
END $$;