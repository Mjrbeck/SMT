
-- Function to add credits to a user
CREATE OR REPLACE FUNCTION add_credits(user_id UUID, credit_amount INTEGER)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE profiles
  SET credits = credits + credit_amount
  WHERE id = user_id;
END;
$$;
