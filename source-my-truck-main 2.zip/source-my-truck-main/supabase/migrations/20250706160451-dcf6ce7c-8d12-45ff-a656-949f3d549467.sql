-- Update handle_new_user function to support buyer/seller roles
CREATE OR REPLACE FUNCTION public.handle_new_user()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path = public
AS $function$
BEGIN
  INSERT INTO public.profiles (id, company_name, credits, role)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'company_name', 'Unknown Company'),
    1,  -- Give 1 free credit on signup
    COALESCE(NEW.raw_user_meta_data->>'user_type', 'seller') -- Use user_type from metadata, default to seller
  );
  RETURN NEW;
END;
$function$;